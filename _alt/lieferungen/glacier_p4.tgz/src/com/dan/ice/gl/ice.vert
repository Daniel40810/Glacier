// ice.vert — ein Eiskörper: Lage im Körper (für Risse, Bänder, Glitzer, die mit ihm wandern), in der Welt, Normale.
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNrm;
uniform mat4 uVP, uModel;
out vec3 vW, vN, vL;
void main() {
    vec4 w = uModel * vec4(aPos, 1.0);
    vW = w.xyz;
    vN = normalize(mat3(uModel) * aNrm);
    vL = aPos;
    gl_Position = uVP * w;
}
