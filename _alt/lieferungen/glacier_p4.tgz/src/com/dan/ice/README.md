# com.dan.ice – Eis als Material und als Körper

**Stand: Material (Phase 4).** Der Gletscher als Körper folgt in Phase 5 (Werkbuch Glacier, Abschnitt 9).

Eis, das wie Eis aussieht – nicht wie Glas und nicht wie Gips: weiß am Rand, blau in der Tiefe, Risse, die in der Sonne blitzen. Das Package kennt keine App und kein anderes Package; der Kern braucht nur Java 21, `gl/` zusätzlich JOGL, `demo/` zusätzlich `FStyle.jar`.

Zum Herauskopieren reicht `src/com/dan/ice/`.

## Was das Material rechnet

- **Absorption je Farbkanal** (Beer-Lambert) mit den Werten von reinem Eis: Rot 0,25 /m, Grün 0,035 /m, Blau 0,006 /m [G, Bandmittel nach Warren & Brandt 2008 und Picard et al. 2016]. Rot ist nach 2,8 m halbiert, Grün nach 20 m, Blau erst nach 116 m.
- **Dicke je Bildpunkt** aus einem Rückseiten-Durchgang: Abstand zur Rückseite minus Abstand zur Vorderseite.
- **Streuung durch Luftblasen**, Anteil 0..1 logarithmisch auf 0,05 bis 200 /m, Asymmetrie g = 0,8. Firn streut so stark, dass er weiß ist; altes, gepresstes Eis kommt blau zurück.
- **Kubelka-Munk** für Reflexion R und diffuse Durchlässigkeit T einer Schicht (K = 2α, S = ¾σ(1 − g)), stabil auch für 500 m Dicke. Dazu der ungestreute Anteil, durch den man durch klares Eis hindurchsieht.
- **Verwitterte Kruste**: eine zweite, stark streuende Schicht über dem Eis. Sie ist fleckig, an steilen, frisch gebrochenen Flächen dünn und in Schmelzrinnen weggewaschen.
- **Risse** als Zellgrenzen im Volumen (Kachel 64³, nahtlos). 2 bis 8 Proben längs des gebrochenen Strahls, je nach Stufe. Rissflächen streuen weiß und spiegeln die Sonne (Totalreflexion, Blitzen).
- **Licht von hinten**: Was an besonnten Flächen eintritt, kommt im Schatten gefiltert und blau heraus.
- **Oberfläche**: Moränenbänder, Schnee auf flachen Stellen, Schmelzwasserfilm (glatt, Fresnel), Glitzer der Kristallflächen.
- **Unter Wasser**: Auf dem Weg durchs Wasser wird das Licht geschluckt und vom trüben Wasser überstrahlt, der Fuß eines Eisbergs wird türkis.

## Gebrauch

```java
IceGl ice = new IceGl();
ice.init(gl);
IceMesh m = IceShapes.iceberg(seed, 7, 0.85, 3);
double wl = m.waterline(Ice.iceberg().submergedFraction(1000));     // 90 % unter Wasser
IceGl.Body body = ice.upload(gl, IceShapes.shifted(m, 0, -wl, 0));
IceGl.Instance berg = new IceGl.Instance(body, Ice.iceberg()).place(x, waterLevel, z, yaw);
// je Bild, in das gebundene HDR-Ziel (dessen Tiefe gilt):
ice.draw(gl, List.of(berg), view, light);     // view: viewProj, eye, reversedZ, Größe; light: Sonne, Mond, Himmel, Dunst, Wasser
```

Das Licht kommt vorbelichtet von außen, wie bei den anderen Packages. Ist ein Rundumbild des Himmels gesetzt (`skyTexture`, Abbildung u = atan(x, −z)/2π + 0,5 wie bei `ocean`), wird es für die Spiegelung genutzt, sonst ein Verlauf aus `skyTop` und `skyHorizon`.

## Presets

| Preset | Blasen | Risse | Kruste | Film | Wofür |
|---|---|---|---|---|---|
| `firn()` | 90 % | 10 % | 100 % | 5 % | junger Schnee, weiß |
| `glacier()` | 50 % | 50 % | 60 % | 20 % | Gletscherfront, Moräne 15 % |
| `blue()` | 10 % | 20 % | 5 % | 60 % | Spaltentiefe, Fuß eines Eisbergs |
| `iceberg()` | 30 % | 35 % | 30 % | 70 % | geschwommen, nass |

## Aufbau

| Klasse | Aufgabe |
|---|---|
| `Ice` | Kern: Presets, offene Werte, Qualitätsstufen, `describe()` |
| `IceOptics` | Optik ohne Grafikkarte, Zeile für Zeile wie `gl/ice_common.glsl` |
| `IceNoise` | Risskachel 64³ (R: Nähe zur Fläche, GBA: deren Normale) |
| `IceMesh` | flaches Dreiecksnetz, Volumen, Volumen unter einer Ebene (genau), Wasserlinie, Schwerpunkt |
| `IceShapes` | Block mit Fasen, Eisberg aus Ikosaederkugel mit Bruchebenen |
| `gl/IceGl` | Rückseiten-Durchgang (R32F), Vorderseiten ins Ziel des Aufrufers; Shader als Ressourcen |
| `demo/IceDemo` | Fenster: Block 10 m, Eisberg, Regler; `--bild datei.png [breite] [fotos]` ohne Fenster |
| `demo/IceCheck` | Prüfung ohne Fenster (Optik, Netze, Risse, Shadervertrag), endet mit „Alles in Ordnung.“ |

## Qualitätsstufen

| Stufe | Proben durch die Risse |
|---|---|
| LOW | 2 |
| MEDIUM | 4 |
| HIGH | 6 |
| ULTRA | 8 |

## Grenzen

- Die Absorptionswerte sind Bandmittel und gerundet [G]. Die Messungen für Blau streuen um den Faktor zehn (Warren 2006 gegen Picard 2016).
- Die Dicke kommt aus dem vordersten Paar von Vorder- und Rückseite. Ein Körper hinter einem anderen sieht die Rückseite des vorderen nicht.
- Keine Brechung des Hintergrunds, die Durchsicht nimmt den Himmel in Richtung des gebrochenen Strahls. Schatten auf das Eis kommen mit dem Gletscher in Phase 5.
