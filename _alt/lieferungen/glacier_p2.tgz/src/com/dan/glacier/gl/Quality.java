package com.dan.glacier.gl;

import com.dan.forest.ForestField;
import com.dan.ocean.Ocean;
import com.dan.reed.Reed;

import java.util.Locale;

/**
 * Qualitätsstufen der App (aus Haithabu, entschlackt). Phase 1: Anteil der Bildgröße, in dem gerechnet wird, und das
 * Zeitbudget. Phase 2: Sichtweite des Geländes (Knotengrößen je Stufe), FFT des Sees ({@code com.dan.ocean}),
 * Reichweite und Dichte der Halme ({@code com.dan.reed}), Wald ({@code com.dan.forest}), Sonnenschatten der Bäume und
 * der Halbmesser der Bodendecke ({@code com.dan.ground}). Jede weitere Package-Phase hängt die Stufe ihres Packages an
 * (Phase 3: Himmel und Wetter; Phase 4–9: ice, fracture, wave, buoyancy). Die Packages haben ihre eigene Kopie dieser
 * Aufzählung (Paketvertrag Punkt 7).
 * Ziel (F21 A): „Mittel“ hält 60 Bilder/s in Full HD auf der Radeon 680M, „Hoch“ mindestens 30.
 */
public enum Quality {
    NIEDRIG("Niedrig", 0.67, 1.8, Ocean.Quality.LOW, Reed.Quality.LOW, ForestField.Quality.LOW, 1024, 150, 16),
    MITTEL("Mittel", 0.85, 2.3, Ocean.Quality.MEDIUM, Reed.Quality.MEDIUM, ForestField.Quality.MEDIUM, 2048, 220, 24),
    HOCH("Hoch", 1.0, 2.8, Ocean.Quality.HIGH, Reed.Quality.HIGH, ForestField.Quality.HIGH, 2048, 300, 30),
    ULTRA("Ultra", 1.0, 3.4, Ocean.Quality.ULTRA, Reed.Quality.ULTRA, ForestField.Quality.ULTRA, 4096, 420, 36);

    public final String label;
    /** Anteil der Bildgröße, in dem gerechnet wird. */
    public final double renderScale;
    /** Phase 2: Sichtweite jeder Geländestufe in ihren Knotengrößen (CDLOD). */
    public final double terrainRange;
    /** Phase 2: Stufe des Sees, der Halme und des Waldes. */
    public final Ocean.Quality ocean;
    public final Reed.Quality reed;
    public final ForestField.Quality forest;
    /** Phase 2: Sonnenschattenkarte (Texel, halbe Kante in m) und Halbmesser der Bodendecke um das Auge (m). */
    public final int shadowSize;
    public final double shadowHalf, groundRadius;

    Quality(String label, double renderScale, double terrainRange, Ocean.Quality ocean, Reed.Quality reed, ForestField.Quality forest,
            int shadowSize, double shadowHalf, double groundRadius) {
        this.label = label;
        this.renderScale = renderScale;
        this.terrainRange = terrainRange;
        this.ocean = ocean;
        this.reed = reed;
        this.forest = forest;
        this.shadowSize = shadowSize;
        this.shadowHalf = shadowHalf;
        this.groundRadius = groundRadius;
    }

    /**
     * Bildzeit, die die Stufe höchstens verbrauchen darf (ms): „Mittel“ 15,7 ms nach dem Budget im Werkbuch
     * (Abschnitt 10, 1 ms Reserve auf 16,7 ms), „Hoch“ das Doppelte, „Niedrig“ die Hälfte.
     */
    public double budgetMs() {
        return switch (this) { case NIEDRIG -> 7.85; case MITTEL -> 15.7; case HOCH -> 31.4; case ULTRA -> 50.0; };
    }

    /** Was die Stufe einstellt, als eine Zeile (Bedienfeld, README). */
    public String summary() {
        return String.format(Locale.GERMAN, "%s: %d %% der Auflösung, Budget %.1f ms, Gelände %.1f Knoten, See %d × %d², Halme %.0f %% Reichweite, Wald bis %,.0f m, Sonnenschatten %d² über %.0f m, Bodendecke %.0f m",
                label, Math.round(renderScale * 100), budgetMs(), terrainRange, ocean.cascades, ocean.n, reed.range * 100, forest.radius, shadowSize, shadowHalf * 2, groundRadius);
    }

    @Override public String toString() { return label; }
}
