package com.dan.glacier.gl;

import com.dan.glacier.camera.Camera;
import com.dan.forest.ForestField;
import com.dan.forest.gl.ForestGl;
import com.dan.glacier.scene.Bodendecke;
import com.dan.glacier.scene.Physik;
import com.dan.glacier.scene.SceneClock;
import com.dan.glacier.scene.Site;
import com.dan.glacier.scene.Sun;
import com.dan.glacier.scene.Terrain;
import com.dan.glacier.scene.Vegetation;
import com.dan.glacier.wiring.Wiring;
import com.dan.ground.Biome;
import com.dan.ground.Meadow;
import com.dan.ground.gl.GroundGl;
import com.dan.ocean.Ocean;
import com.dan.ocean.gl.OceanGl;
import com.dan.reed.Reed;
import com.dan.reed.gl.ReedGl;
import com.jogamp.common.nio.Buffers;
import com.jogamp.opengl.GL;
import com.jogamp.opengl.GL4;
import com.jogamp.opengl.GLAutoDrawable;
import com.jogamp.opengl.GLEventListener;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.ByteBuffer;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.function.Consumer;

/**
 * Die Engine auf der Grafikkarte, übernommen aus Haithabu und entschlackt (F4 A). Je Bild:
 * <ol>
 * <li>Himmel als Verlauf nach der Sonnenhöhe (Platzhalter bis {@code com.dan.sky} in Phase 3) in einen HDR-Puffer
 * (RGBA16F, umgekehrte 32F-Tiefe), dazu als kleines Rundumbild für die Spiegelung im See.</li>
 * <li>Phase 2: Sonnenschatten der Südbuchen um den Blickpunkt ({@link SunShadow}).</li>
 * <li>Phase 2: das Gelände aus Copernicus GLO-30 ({@link Terrain}, {@link TerrainLod}, {@code terrain.vert/frag}):
 * Fels, Moräne, Steppe, Waldboden und Kronendach, Schnee über der Schneegrenze, die Zunge als weiße Fläche, der
 * Seegrund; außerhalb des Rasters ein Rahmen aus Bergen.</li>
 * <li>Phase 2: Wald aus {@code com.dan.forest} (Lenga, Ñire, Guindo), Bodendecke aus {@code com.dan.ground} (nur zu
 * Fuß), der See aus {@code com.dan.ocean} (Preset „Lago“, das Gelände als Grund, Türkis vom Gletschermehl),
 * Steppengras und Ufergras aus {@code com.dan.reed}.</li>
 * <li>Nachbearbeitung: Belichtung, Filmkurve, Gamma; dann das HUD.</li>
 * </ol>
 * Geblieben aus Haithabu: Qualitätsstufen mit Auflösungsregelung, Zeitmessung jedes Durchgangs auf der Grafikkarte
 * (Zeitstempel, ein Bild versetzt gelesen), Compute-Test beim Start, HUD kurz/voll/aus, Foto (F12), Shader neu laden
 * (F5), Standbilder ohne Fenster ({@code tools.Tempo}). Neu: der Faden der Physik ({@link Physik}) mit festem Schritt
 * (F21 A); der Bildlauf gibt ihm nur die Zeit. Im Bildlauf werden keine Dateien gelesen.
 * <p>
 * Abgestellt gegenüber Haithabu (kommt mit der jeweiligen Phase wieder): Augenanpassung an das Bild, Wolkenschatten,
 * Bildfolgen, Regiebücher, Klang. Ohne Höhendaten zeichnet dasselbe Gelände die Bühne von Phase 1 ({@link Terrain#flat}).
 */
public final class Renderer implements GLEventListener {
    public static final int MIN_MAJOR = 4, MIN_MINOR = 3;
    public static final String VERSION = "Phase 2";
    /** Die Phase, die dieser Stand erfüllt (für Ansichten und HUD). */
    public static final int PHASE = 2;
    static final String[] PASSES = {"Himmel", "Schatten", "Gelände", "Wald", "Boden", "See", "Halme", "Nachbearbeitung", "HUD"};
    private static final int MARKS = PASSES.length + 1;

    public final SceneClock clock;
    public final Wiring wiring;
    public final Camera camera = new Camera();
    /** Der Faden der Physik (Phase 1 ohne Aufgaben). */
    public final Physik physik = new Physik();
    /** Phase 2: das Gelände (aus daten/gelaende) und was darauf wächst. */
    public final Terrain terrain;
    public final Vegetation vegetation;
    private final TerrainLod lod = new TerrainLod();
    private int coverTex, panoTex, panoFbo;
    static final int PANO_W = 256, PANO_H = 128;
    /** Phase 2: der See (Preset „Lago“; die Verdrahtung gibt Wind und Spiegel). */
    public final Ocean ocean = Ocean.lago(4);
    private final OceanGl oceanGl = new OceanGl();
    private volatile boolean oceanOk;
    private volatile String oceanCheck = "";
    /** Phase 2: Steppengras und Ufergras. */
    public final Reed reed = Reed.beaufort(4);
    private final ReedGl reedGl = new ReedGl();
    private volatile boolean reedOk;
    /** Phase 2: Wald aus Lenga, Ñire, Guindo, mit Sonnenschatten. */
    public final ForestField forest;
    private final ForestGl forestGl;
    private volatile boolean forestOk;
    private final SunShadow sunShadow = new SunShadow();
    /** Phase 2: Bodendecke um das Auge (Biom Patagonien). */
    public final Meadow meadow;
    private final GroundGl groundGl = new GroundGl();
    private volatile boolean groundOk;
    public volatile boolean showWater = true, showReed = true, showForest = true, showSunShadow = true, showGround = true;

    private volatile Quality quality = Quality.MITTEL;
    public volatile double renderScale = quality.renderScale;
    /**
     * Regelt die Auflösung nach der Zeit der Grafikkarte: über dem Budget von {@link #targetFps} sinkt sie in Schritten
     * bis {@link #MIN_SCALE}, mit Luft steigt sie wieder bis zur Stufe (aus Haithabu).
     */
    public volatile boolean autoScale = true;
    public volatile double targetFps = 60;
    public static final double MIN_SCALE = 0.5;
    private long scaleNanos;
    private int scaleSteps;

    public volatile boolean showHud = true, hudFull;
    /** Marken im Gelände: Raster von 1 km. */
    public volatile boolean showMarks = true;
    /** Szene anhalten (Uhr, Kamera, Physik). */
    public volatile boolean frozen;
    /** Belichtung in Blendenstufen von Hand dazu. */
    public volatile double exposureBias;
    public volatile boolean photoRequest;
    /** Das nächste fertige Fensterbild an diesen Empfänger (einmal; im GL-Faden). */
    public volatile Consumer<BufferedImage> grabRequest;
    /** Ordner für Fotos (F12); ohne Angabe {@code docs/status} im Arbeitsverzeichnis. */
    public volatile File photoDir;

    private final Shader skyShader = new Shader("Himmel", null, "fullscreen.vert", "sky.frag"),
            skyPano = new Shader("Himmelspanorama", null, "fullscreen.vert", "skypano.frag"),
            terrainShader = new Shader("Gelände", null, "terrain.vert", "terrain.frag"),
            post = new Shader("Nachbearbeitung", null, "fullscreen.vert", "post.frag"),
            overlay = new Shader("Überlagerung", null, "fullscreen.vert", "overlay.frag");
    private final Shader[] all = {skyShader, skyPano, terrainShader, post, overlay};
    private final HudOverlay hud = new HudOverlay();
    private int emptyVao, hdrTex, depthTex, hdrFbo, hdrW, hdrH, surfW = 1, surfH = 1, defaultFbo;
    private boolean reversedZ, ready;
    private final int[][] stamp = new int[2][MARKS];
    private final double[] passMs = new double[MARKS - 1];
    private int frame;
    private long lastNanos, statsNanos;
    private int statsFrames;
    private double fps, gpuMs, cpuMs, worstMs;
    private volatile String glInfo = "", error;
    private volatile ComputeProbe.Result compute;
    private volatile boolean reloadShaders;
    private Consumer<String> statusListener = s -> { };
    private Consumer<String> errorListener = s -> { };
    private volatile String photoMsg = "";
    private volatile long photoMsgUntil;

    public Renderer(SceneClock clock, Wiring wiring) { this(clock, wiring, Terrain.load(Terrain.defaultDir())); }

    public Renderer(SceneClock clock, Wiring wiring, Terrain terrain) {
        this.clock = clock;
        this.wiring = wiring;
        this.terrain = terrain;
        com.dan.glacier.camera.Ansichten.use(terrain);
        this.vegetation = new Vegetation(terrain);
        this.forestGl = new ForestGl(Vegetation.species(), 4, 2026);
        this.forest = new ForestField(3, 4, vegetation, (x, z) -> (float) terrain.height(x, z), 2026);
        forest.setHeights(forestGl.heights());
        this.meadow = new Meadow(Biome.patagonia(), new Bodendecke(terrain, vegetation));
        meadow.radius = 24;
        meadow.near = 6.5f;
        meadow.seed = 2026;
        ocean.seed = 2026;
        setQuality(quality);
        if (wiring != null) {
            wiring.terrain = terrain;
            wiring.feed(ocean);
        }
        camera.groundLevel = terrain.height(camera.eye[0], camera.eye[2]);
        camera.snap();
    }

    public Renderer() { this(new SceneClock(), null, Terrain.flat()); }

    // ------------------------------------------------------------------ Zugriff
    public void setStatusListener(Consumer<String> l) { statusListener = l; }
    public void setErrorListener(Consumer<String> l) { errorListener = l; }
    public String glInfo() { return glInfo; }
    public String error() { return error; }
    public double fps() { return fps; }
    public double gpuMs() { return gpuMs; }
    public double cpuMs() { return cpuMs; }
    public boolean reversedDepth() { return reversedZ; }
    public ComputeProbe.Result compute() { return compute; }
    public Quality quality() { return quality; }
    public void requestShaderReload() { reloadShaders = true; }
    public double[] lastPassTimes() { return passMs.clone(); }
    public long frames() { return frame; }
    public double takeWorstFrameMs() { double w = worstMs; worstMs = 0; return w; }

    /** Die Programme der App (für die Prüfung). */
    public static String[][] shaderFiles() {
        return new String[][]{{"fullscreen.vert", "sky.frag"}, {"fullscreen.vert", "skypano.frag"}, {"terrain.vert", "terrain.frag"},
                {"fullscreen.vert", "post.frag"}, {"fullscreen.vert", "overlay.frag"}, {"probe.comp"}};
    }

    public void setQuality(Quality q) {
        quality = q;
        renderScale = q.renderScale;
        lod.lodRange = q.terrainRange;
        ocean.quality = q.ocean;
        reed.quality = q.reed;
        if (forest != null) forest.apply(q.forest);
        sunShadow.half = q.shadowHalf;
        if (meadow != null) meadow.radius = (float) q.groundRadius;
    }

    public TerrainLod lod() { return lod; }
    public boolean oceanRunning() { return oceanOk; }
    public String oceanCheck() { return oceanCheck; }
    public boolean forestReady() { return forestOk && forestGl.ready(); }
    public String forestInfo() { return forestOk ? forestGl.info() : "Wald: nicht gestartet"; }
    public String reedInfo() { return reedOk ? reedGl.info() : "Halme: nicht gestartet"; }

    /** Tag im Jahr (1..365) an der Front. */
    public int dayOfYear() { return clock.date().getDayOfYear(); }

    /** Belichtung aus der Helligkeitstabelle des Platzhalter-Himmels (bis Phase 3 die Augenanpassung bringt). */
    public double exposure() {
        double b = Sun.skyBrightness(clock.sun()[0]);
        return 0.6 * Math.pow(b, -0.85) * Math.pow(2, exposureBias);
    }

    /** Senkrechter Bildwinkel in Grad. */
    public double fovy() { return Camera.FOVY; }

    // ------------------------------------------------------------------ Lebenslauf

    @Override
    public void init(GLAutoDrawable d) {
        GL4 gl = d.getGL().getGL4();
        int major = d.getContext().getGLVersionNumber().getMajor(), minor = d.getContext().getGLVersionNumber().getMinor();
        String renderer = gl.glGetString(GL.GL_RENDERER), vendor = gl.glGetString(GL.GL_VENDOR), version = gl.glGetString(GL.GL_VERSION);
        glInfo = renderer + " · OpenGL " + major + "." + minor;
        System.out.println("Glacier: " + vendor + " · " + renderer + " · " + version);
        if (major < MIN_MAJOR || (major == MIN_MAJOR && minor < MIN_MINOR)) {
            fail("Die Grafikkarte meldet OpenGL " + major + "." + minor + " (" + renderer + ", Treiber " + version
                    + "). Glacier braucht OpenGL " + MIN_MAJOR + "." + MIN_MINOR + ".\nBitte den Grafiktreiber aktualisieren.");
            return;
        }
        gl.setSwapInterval(1);
        defaultFbo = d.getContext().getDefaultDrawFramebuffer();
        reversedZ = (major > 4 || minor >= 5) || gl.isExtensionAvailable("GL_ARB_clip_control");
        if (reversedZ) gl.glClipControl(GL4.GL_LOWER_LEFT, GL4.GL_ZERO_TO_ONE);
        try {
            for (Shader s : all) s.build(gl);
        } catch (RuntimeException e) {
            fail(e.getMessage());
            return;
        }
        int[] v = new int[1];
        gl.glGenVertexArrays(1, v, 0);
        emptyVao = v[0];
        for (int[] s : stamp) gl.glGenQueries(MARKS, s, 0);
        compute = ComputeProbe.run(gl);
        System.out.println("Glacier: " + compute.line());
        // Phase 2: Gelände, Bedeckung, Himmelspanorama, See, Halme, Wald, Bodendecke (jedes für sich; was nicht startet, fehlt)
        lod.upload(gl, terrain);
        coverTex = coverTexture(gl, vegetation);
        panoTex = Gpu.texture(gl, PANO_W, PANO_H, GL.GL_RGBA16F, false);
        gl.glBindTexture(GL.GL_TEXTURE_2D, panoTex);
        gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_S, GL.GL_REPEAT);
        gl.glBindTexture(GL.GL_TEXTURE_2D, 0);
        panoFbo = Gpu.fbo(gl, panoTex, 0);
        System.out.println("Glacier: Gelände " + terrain.describe());
        System.out.println("Glacier: " + vegetation.describe());
        if (compute.ok()) {
            try {
                oceanGl.init(gl);
                oceanOk = true;
                System.out.println("Glacier: See " + oceanGl.info());
            } catch (RuntimeException e) {
                System.err.println("Glacier: See nicht verfügbar: " + e.getMessage());
                errorListener.accept("Der See (com.dan.ocean) lässt sich nicht starten.\n" + e.getMessage());
            }
        }
        try {
            reedGl.init(gl);
            reedOk = true;
        } catch (RuntimeException e) {
            System.err.println("Glacier: Halme nicht verfügbar: " + e.getMessage());
            errorListener.accept("Steppe und Gras (com.dan.reed) lassen sich nicht starten.\n" + e.getMessage());
        }
        try {
            forestGl.init(gl);
            forestGl.setSeason(Wiring.northernDay(dayOfYear()), 0);
            sunShadow.ensure(gl, quality.shadowSize);
            forestOk = true;
        } catch (RuntimeException e) {
            System.err.println("Glacier: Wald nicht verfügbar: " + e.getMessage());
            errorListener.accept("Der Wald (com.dan.forest) lässt sich nicht starten.\n" + e.getMessage());
        }
        try {
            groundGl.init(gl);
            groundOk = true;
        } catch (RuntimeException e) {
            System.err.println("Glacier: Bodendecke nicht verfügbar: " + e.getMessage());
            errorListener.accept("Die Bodendecke (com.dan.ground) lässt sich nicht starten.\n" + e.getMessage());
        }
        physik.start();
        lastNanos = System.nanoTime();
        statsNanos = lastNanos;
        camera.snap();
        ready = true;
    }

    @Override
    public void reshape(GLAutoDrawable d, int x, int y, int w, int h) {
        surfW = Math.max(1, d.getSurfaceWidth());
        surfH = Math.max(1, d.getSurfaceHeight());
    }

    /** Uhr, Physik und Kamera um dt weiterrechnen (vom Bildlauf aufgerufen; Standbilder rufen es mit festem dt). */
    public void step(double dt) {
        clock.step(dt);
        physik.advance(dt);
        if (wiring != null) {
            wiring.feed(ocean);
            wiring.feed(reed, dayOfYear());
        }
        ocean.step(dt);
        camera.groundLevel = terrain.height(camera.eye[0], camera.eye[2]);
        camera.targetGround = terrain.height(camera.tx, camera.tz);
        camera.waterLevel = ocean.waterLevel;
        camera.step(dt);
    }

    @Override
    public void display(GLAutoDrawable d) {
        GL4 gl = d.getGL().getGL4();
        if (!ready) {
            gl.glClearColor(0.04f, 0.07f, 0.10f, 1);
            gl.glClear(GL.GL_COLOR_BUFFER_BIT);
            return;
        }
        if (reloadShaders) {
            reloadShaders = false;
            try {
                for (Shader s : all) s.build(gl);
                System.out.println("Shader neu geladen.");
            } catch (RuntimeException e) {
                System.err.println(e.getMessage());
                errorListener.accept(e.getMessage());
            }
        }
        defaultFbo = d.getContext().getDefaultDrawFramebuffer();
        readMarks(gl);
        long now = System.nanoTime();
        double rawMs = (now - lastNanos) / 1e6;
        if (frame > 2 && rawMs > worstMs) worstMs = rawMs;
        double dt = Math.min(0.1, (now - lastNanos) / 1e9);
        lastNanos = now;
        if (!frozen) step(dt);

        surfW = Math.max(1, d.getSurfaceWidth());
        surfH = Math.max(1, d.getSurfaceHeight());
        regulateScale(now);
        int w = Math.max(64, (int) Math.round(surfW * renderScale)), h = Math.max(64, (int) Math.round(surfH * renderScale));
        if (w != hdrW || h != hdrH) resizeTargets(gl, w, h);
        renderFrame(gl, w, h);
        if (photoRequest) { photoRequest = false; takePhoto(gl, surfW, surfH); }
        Consumer<BufferedImage> gr = grabRequest;
        if (gr != null) { grabRequest = null; try { gr.accept(readDefault(gl, surfW, surfH)); } catch (RuntimeException e) { System.err.println("Glacier: Bild nicht abgeholt: " + e); } }
        cpuMs = cpuMs * 0.95 + (System.nanoTime() - now) / 1e6 * 0.05;
        frame++;
        stats(now, w, h);
    }

    /** Ein ganzes Bild in Rechengröße w × h, dann ins Fenster. Bei stehender Szene ({@link #frozen}) malt das HUD gleich. */
    void renderFrame(GL4 gl, int w, int h) {
        mark(gl, 0);
        double[] sp = clock.sun();
        double[] sun = Sun.direction(sp[0], sp[1]);
        float[] proj = Mat4.perspective(fovy(), w / (double) h, 0.5, 80_000, reversedZ);
        float[] vp = Mat4.mul(proj, camera.view());
        float[] inv = Mat4.invert(vp);
        double level = wiring != null ? wiring.waterLevel.level() : 0;

        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        gl.glClearColor(0, 0, 0, 1);
        gl.glClearDepth(reversedZ ? 0 : 1);
        gl.glDepthMask(true);
        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
        gl.glBindVertexArray(emptyVao);

        // 1 Himmel: Verlauf nach der Sonnenhöhe (Platzhalter bis com.dan.sky in Phase 3), dazu das Rundumbild
        gl.glDisable(GL.GL_DEPTH_TEST);
        gl.glDisable(GL.GL_CULL_FACE);
        common(gl, skyShader, vp, inv, sun, level);
        gl.glDrawArrays(GL.GL_TRIANGLES, 0, 3);
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, panoFbo);
        gl.glViewport(0, 0, PANO_W, PANO_H);
        common(gl, skyPano, vp, inv, sun, level);
        gl.glDrawArrays(GL.GL_TRIANGLES, 0, 3);
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        mark(gl, 1);

        // 2 Wald: Bäume für das Bild wählen, Instanzen hochladen, Sonnenschatten der Bäume um den Blickpunkt
        double[] to = wiring != null ? wiring.wind.toVector() : new double[]{1, 0, 0};
        double windSpeed = wiring != null ? wiring.wind.speed() : 6.7;
        boolean forestNow = forestOk && showForest;
        sunShadow.matrix = null;
        if (forestNow) {
            forestGl.setSeason(Wiring.northernDay(dayOfYear()), 0);
            forestGl.setWind(to[0], to[2], windSpeed, wiring != null ? wiring.wind.gustiness() : 0.3);
            forest.update(camera.eye, vp, 24);
            forestGl.update(gl, forest);
        }
        boolean forestReady = forestNow && forestGl.ready();
        if (showSunShadow && sun[1] > 0.03 && forestReady) {
            sunShadow.ensure(gl, quality.shadowSize);
            double[] c = shadowCenter();
            sunShadow.matrix = sunShadow.fit(sun, c[0], c[1], c[2]);
            sunShadow.begin(gl, reversedZ);
            forestGl.drawShadow(gl, sunShadow.matrix, clock.t(), 3);
            sunShadow.end(gl, reversedZ);
            gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
            gl.glViewport(0, 0, w, h);
        }
        mark(gl, 2);

        // 3 Gelände
        double[] sl = sunLight(sp[0]), zen = skyZenith(sp[0]), hor = skyHorizon(sp[0]);
        gl.glDepthMask(true);
        gl.glDisable(GL.GL_BLEND);
        gl.glEnable(GL.GL_DEPTH_TEST);
        gl.glDepthFunc(reversedZ ? GL.GL_GREATER : GL.GL_LESS);
        common(gl, terrainShader, vp, inv, sun, level);
        lod.bind(gl, terrainShader);
        gl.glActiveTexture(GL.GL_TEXTURE10);
        gl.glBindTexture(GL.GL_TEXTURE_2D, coverTex);
        gl.glActiveTexture(GL.GL_TEXTURE13);
        gl.glBindTexture(GL.GL_TEXTURE_2D, sunShadow.matrix != null ? sunShadow.tex : 0);
        gl.glActiveTexture(GL.GL_TEXTURE0);
        terrainShader.set(gl, "uCover", 10);
        terrainShader.set(gl, "uCoverRect", (float) Terrain.X0, (float) Terrain.Z0, (float) (Terrain.N * Terrain.CELL), 1f);
        terrainShader.set(gl, "uWood", (float) (forest.radius * forest.thinFrom), (float) forest.radius, forestReady ? 1f : 0f);
        terrainShader.set(gl, "uSunRgb", sl);
        terrainShader.set(gl, "uSunAmb", zen);
        terrainShader.set(gl, "uSkyHor", hor);
        terrainShader.set(gl, "uSnowLine", (float) SNOW_LINE);
        terrainShader.set(gl, "uMarks", showMarks ? 1 : 0);
        terrainShader.set(gl, "uSunShadow", 13);
        terrainShader.mat(gl, "uSunShadowM", sunShadow.matrix != null ? sunShadow.matrix : Mat4.identity());
        terrainShader.set(gl, "uSunShadowOn", sunShadow.matrix != null ? 1 : 0);
        lod.draw(gl, terrainShader, camera.eye, vp);
        gl.glBindVertexArray(emptyVao);
        mark(gl, 3);

        // 4 Wald zeichnen (Licht wie die Halme, dazu der Sonnenschatten)
        if (forestReady) {
            ForestGl.View fv = new ForestGl.View();
            fv.viewProj = vp;
            fv.eye = camera.eye.clone();
            fv.reversedZ = reversedZ;
            ForestGl.Light fl = new ForestGl.Light();
            fl.sunDir = sun;
            fl.sunColor = sl;
            fl.skyColor = zen;
            fl.fogColor = hor;
            fl.fogDistance = FOG_DISTANCE;
            if (sunShadow.matrix != null) {
                fl.sunShadowTexture = sunShadow.tex;
                fl.sunShadowMatrix = sunShadow.matrix;
                fl.sunShadowBias = 0.0006;
            }
            forestGl.draw(gl, fv, fl, clock.t());
            gl.glBindVertexArray(emptyVao);
        }
        mark(gl, 4);

        // 5 Bodendecke um das Auge (nur zu Fuß)
        boolean groundNow = groundOk && showGround && camera.eye[1] - terrain.height(camera.eye[0], camera.eye[2]) < 25;
        if (groundOk) {
            meadow.setSeason(Wiring.northernDay(dayOfYear()), 0);
            meadow.wind.speed = (float) windSpeed;
            meadow.wind.direction = (float) Math.toDegrees(Math.atan2(to[2], to[0]));
            groundGl.update(gl, meadow, (float) (clock.t() % 3600), camera.eye[0], camera.eye[2], !groundNow);
        }
        if (groundNow) {
            GroundGl.View gv = new GroundGl.View();
            gv.viewProj = vp;
            gv.eye = camera.eye.clone();
            gv.reversedZ = reversedZ;
            GroundGl.Light gL = new GroundGl.Light();
            gL.sunDir = sun;
            gL.sunColor = sl;
            gL.skyColor = zen;
            gL.fogColor = hor;
            gL.fogDistance = FOG_DISTANCE;
            if (sunShadow.matrix != null) {
                gL.sunShadowTexture = sunShadow.tex;
                gL.sunShadowMatrix = sunShadow.matrix;
            }
            groundGl.draw(gl, gv, gL);
            gl.glBindVertexArray(emptyVao);
        }
        mark(gl, 5);

        // 6 See: rechnen (Compute), dann zeichnen; das Gelände ist sein Grund
        if (oceanOk && showWater) {
            oceanGl.update(gl, ocean);
            if (oceanCheck.isEmpty() && frame > 30) oceanCheck = oceanGl.selfCheck(gl, ocean);
            gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
            gl.glViewport(0, 0, w, h);
            OceanGl.View ov = new OceanGl.View();
            ov.viewProj = vp;
            ov.eye = camera.eye.clone();
            ov.reversedZ = reversedZ;
            OceanGl.Light ol = new OceanGl.Light();
            ol.sunDir = sun;
            ol.skyTexture = panoTex;
            ol.sunColor = sl;
            ol.fogDistance = FOG_DISTANCE;
            ol.waterColor = Ocean.LAGO_WATER;
            ol.sssColor = Ocean.LAGO_SSS;
            ol.bedTexture = lod.heightTex;
            ol.bedRect = new double[]{Terrain.X0, Terrain.Z0, Terrain.N * Terrain.CELL};
            ol.bedScale = Terrain.HMAX - Terrain.HMIN;
            ol.bedOffset = Terrain.HMIN;
            ol.bedTurbidity = 0.35;
            ol.bedColor = new double[]{0.15, 0.15, 0.14};
            gl.glDepthFunc(reversedZ ? GL.GL_GREATER : GL.GL_LESS);
            oceanGl.draw(gl, ocean, ov, ol);
            gl.glBindVertexArray(emptyVao);
        }
        mark(gl, 6);

        // 7 Halme um die Kamera: Steppe und Ufergras
        if (reedOk && showReed) {
            reedGl.update(gl, reed, camera.eye[0], camera.eye[2], vegetation, (x, z) -> terrain.height(x, z));
            ReedGl.View rv = new ReedGl.View();
            rv.viewProj = vp;
            rv.eye = camera.eye.clone();
            rv.reversedZ = reversedZ;
            ReedGl.Light rl = new ReedGl.Light();
            rl.sunDir = sun;
            rl.sunColor = sl;
            rl.skyColor = zen;
            rl.fogColor = hor;
            rl.fogDistance = FOG_DISTANCE;
            reedGl.draw(gl, reed, rv, rl, clock.t());
            gl.glBindVertexArray(emptyVao);
        }
        gl.glDisable(GL.GL_DEPTH_TEST);
        mark(gl, 7);

        // 8 Nachbearbeitung ins Fenster
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, defaultFbo);
        gl.glViewport(0, 0, surfW, surfH);
        post.use(gl);
        gl.glActiveTexture(GL.GL_TEXTURE0);
        gl.glBindTexture(GL.GL_TEXTURE_2D, hdrTex);
        post.set(gl, "uHdr", 0);
        post.set(gl, "uExposure", (float) exposure());
        post.set(gl, "uScotopic", 0f);
        gl.glBindVertexArray(emptyVao);
        gl.glDrawArrays(GL.GL_TRIANGLES, 0, 3);
        mark(gl, 8);

        // 9 HUD
        if (showHud) {
            hud.refresh(gl, 250, this::paintHud, frozen);
            hud.draw(gl, overlay, emptyVao, 12, Math.max(0, surfH - hud.height - 12), surfW, surfH);
        }
        gl.glBindVertexArray(0);
        gl.glUseProgram(0);
        mark(gl, 9);
    }

    /** Schneegrenze über dem See im Sommer (m) [G]: rund 1 430 m ü. M. an den Bergen um den Gletscher. */
    public static final double SNOW_LINE = 1250;
    /** Dunstlänge für exp(−d/L) mit dem Platzhalter-Himmel (wie common.glsl: 60 km). */
    static final double FOG_DISTANCE = 60_000;

    /** Mittelpunkt der Sonnenschattenkarte: zwischen Auge und Drehpunkt, frei fliegend ein Stück vor dem Auge. */
    private double[] shadowCenter() {
        double cx, cz;
        if (camera.mode == Camera.Mode.FREI) {
            double k = sunShadow.half * 0.7;
            double hl = Math.max(1e-6, Math.hypot(camera.fwd[0], camera.fwd[2]));
            cx = camera.eye[0] + camera.fwd[0] / hl * k;
            cz = camera.eye[2] + camera.fwd[2] / hl * k;
        } else {
            double hl = Math.max(1e-6, Math.hypot(camera.tx - camera.eye[0], camera.tz - camera.eye[2]));
            double d = Math.min(hl, sunShadow.half * 1.2) * 0.85;
            cx = camera.eye[0] + (camera.tx - camera.eye[0]) / hl * d;
            cz = camera.eye[2] + (camera.tz - camera.eye[2]) / hl * d;
        }
        return new double[]{cx, terrain.height(cx, cz) + 8, cz};
    }

    /** Wald (R), Steppe (G), Moräne (B), Fels (A) als Textur zu 25 m für das Gelände. */
    private static int coverTexture(GL4 gl, Vegetation v) {
        int m = Vegetation.M;
        ByteBuffer b = Buffers.newDirectByteBuffer(m * m * 4);
        for (int k = 0; k < m * m; k++) {
            int f = Math.min(255, (v.lenga[k] & 0xff) + (v.nire[k] & 0xff) + (v.guindo[k] & 0xff));
            b.put((byte) f).put(v.steppe[k]).put(v.moraine[k]).put(v.rock[k]);
        }
        b.flip();
        int t = Gpu.texture(gl, m, m, GL.GL_RGBA8, false);
        gl.glBindTexture(GL.GL_TEXTURE_2D, t);
        gl.glPixelStorei(GL.GL_UNPACK_ALIGNMENT, 1);
        gl.glTexSubImage2D(GL.GL_TEXTURE_2D, 0, 0, 0, m, m, GL.GL_RGBA, GL.GL_UNSIGNED_BYTE, b);
        gl.glPixelStorei(GL.GL_UNPACK_ALIGNMENT, 4);
        gl.glBindTexture(GL.GL_TEXTURE_2D, 0);
        return t;
    }

    /** Sonnenlicht nach der Sonnenhöhe (wie sunLight() in common.glsl). */
    public static double[] sunLight(double elevDeg) {
        double e = Math.sin(Math.toRadians(elevDeg));
        double vis = smooth(-0.015, 0.01, e), t = smooth(0.02, 0.35, e), f = 2.6 * vis * smooth(-0.02, 0.12, e);
        return new double[]{f, (0.55 + 0.40 * t) * f, (0.28 + 0.60 * t) * f};
    }

    /** Zenit- und Horizontfarbe des Platzhalter-Himmels (wie skyColorPlaceholder in common.glsl, ohne Sonnensaum). */
    public static double[] skyZenith(double elevDeg) { return skyPlaceholder(elevDeg, 1); }
    public static double[] skyHorizon(double elevDeg) { return skyPlaceholder(elevDeg, 0); }

    static double[] skyPlaceholder(double e, double up) {
        double b = Sun.skyBrightness(e);
        double day = smooth(-2, 12, e), night = 1 - smooth(-16, -8, e), tw = Math.max(0, Math.min(1, 1 - day - night));
        double hw = Math.pow(1 - up, 4);
        double[] zen = {0.16 * day + 0.10 * tw + 0.05 * night, 0.34 * day + 0.17 * tw + 0.08 * night, 0.72 * day + 0.42 * tw + 0.20 * night};
        double[] hor = {0.62 * day + 0.6 * tw + 0.07 * night, 0.74 * day + 0.4 * tw + 0.09 * night, 0.88 * day + 0.36 * tw + 0.18 * night};
        double[] c = new double[3];
        for (int i = 0; i < 3; i++) c[i] = (zen[i] + (hor[i] - zen[i]) * hw) * b / 0.32;
        return c;
    }

    static double smooth(double a, double b, double x) {
        double t = Math.max(0, Math.min(1, (x - a) / (b - a)));
        return t * t * (3 - 2 * t);
    }

    private void common(GL4 gl, Shader s, float[] vp, float[] inv, double[] sun, double level) {
        s.use(gl);
        s.set(gl, "uSkyMode", 0);
        s.mat(gl, "uVP", vp);
        s.mat(gl, "uInvVP", inv);
        s.set(gl, "uCam", camera.eye);
        s.set(gl, "uSun", sun);
        s.set(gl, "uTime", (float) (clock.t() % 10_000));
        s.set(gl, "uLevel", (float) level);
        s.set(gl, "uReversed", reversedZ ? 1 : 0);
    }

    private void resizeTargets(GL4 gl, int w, int h) {
        Gpu.deleteFbos(gl, hdrFbo);
        Gpu.deleteTextures(gl, hdrTex, depthTex);
        hdrTex = Gpu.texture(gl, w, h, GL.GL_RGBA16F, false);
        depthTex = Gpu.texture(gl, w, h, GL4.GL_DEPTH_COMPONENT32F, false);
        gl.glBindTexture(GL.GL_TEXTURE_2D, depthTex);
        gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_NEAREST);
        gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_NEAREST);
        gl.glBindTexture(GL.GL_TEXTURE_2D, 0);
        hdrFbo = Gpu.fbo(gl, hdrTex, depthTex);
        hdrW = w;
        hdrH = h;
    }

    // ------------------------------------------------------------------ Zeitmessung

    private void mark(GL4 gl, int i) { gl.glQueryCounter(stamp[frame & 1][i], GL4.GL_TIMESTAMP); }

    /** Liest die Zeitstempel des vorigen Bilds, sobald sie da sind (kein Warten im Bildlauf). */
    private void readMarks(GL4 gl) {
        if (frame < 2) return;
        int o = (frame - 1) & 1;
        int[] av = new int[1];
        gl.glGetQueryObjectiv(stamp[o][MARKS - 1], GL4.GL_QUERY_RESULT_AVAILABLE, av, 0);
        if (av[0] == 0) return;
        long[] t = new long[MARKS];
        for (int i = 0; i < MARKS; i++) gl.glGetQueryObjecti64v(stamp[o][i], GL4.GL_QUERY_RESULT, t, i);
        for (int i = 0; i < MARKS - 1; i++) passMs[i] = passMs[i] * 0.9 + Math.max(0, t[i + 1] - t[i]) / 1e6 * 0.1;
        gpuMs = gpuMs * 0.9 + Math.max(0, t[MARKS - 1] - t[0]) / 1e6 * 0.1;
    }

    /** „Himmel 0,10 · Bühne 0,60 · …“ in ms (gleitendes Mittel). */
    public String passTimes() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < passMs.length; i++)
            sb.append(i > 0 ? " · " : "").append(PASSES[i]).append(' ').append(String.format(Locale.GERMAN, "%.2f", passMs[i]));
        return sb.toString();
    }

    private void stats(long now, int w, int h) {
        statsFrames++;
        if (now - statsNanos < 500_000_000L) return;
        fps = statsFrames / ((now - statsNanos) / 1e9);
        statsFrames = 0;
        statsNanos = now;
        statusListener.accept(statusLine(w, h));
    }

    /** Auflösung nach der Zeit der Grafikkarte regeln (siehe {@link #autoScale}). */
    private void regulateScale(long now) {
        if (!autoScale || frame < 60 || now - scaleNanos < 1_500_000_000L) return;
        scaleNanos = now;
        double budget = 1000 / Math.max(10, targetFps), top = quality.renderScale, s = renderScale;
        double want = s * Math.sqrt(budget * 0.9 / Math.max(0.1, gpuMs));
        double next = s;
        if (gpuMs > budget * 1.05) next = Math.max(MIN_SCALE, Math.max(want, s - 0.15));
        else if (gpuMs < budget * 0.7 && s < top) next = Math.min(top, Math.min(want, s + 0.05));
        next = Math.round(next * 20) / 20.0;
        if (Math.abs(next - s) >= 0.045) { renderScale = next; scaleSteps++; }
    }

    /** Wie oft die Regelung die Auflösung geändert hat. */
    public int scaleSteps() { return scaleSteps; }

    /** Für Prüfungen: die Regelung mit vorgegebener Grafikkartenzeit und Bildnummer. */
    public void regulateForTest(double gpuMsNow, long nowNanos) {
        gpuMs = gpuMsNow;
        frame = Math.max(frame, 60);
        regulateScale(nowNanos);
    }

    public String statusLine(int w, int h) {
        String s = String.format(Locale.GERMAN, "%s · %.0f Bilder/s · Grafikkarte %.2f ms · Prozessor %.2f ms · %d×%d (%s%s) · %s",
                clock.label(), fps, gpuMs, cpuMs, w, h, quality.label, autoScale ? String.format(Locale.GERMAN, ", %.0f %%", renderScale * 100) : "", glInfo);
        if (System.currentTimeMillis() < photoMsgUntil) s = photoMsg + " · " + s;
        return s;
    }

    // ------------------------------------------------------------------ HUD

    BufferedImage paintHud() {
        String[] lines = hudFull ? hudLines() : hudShort();
        Font font = new Font(Font.MONOSPACED, Font.PLAIN, 12);
        BufferedImage probe = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
        Graphics2D pg = probe.createGraphics();
        java.awt.FontMetrics fm = pg.getFontMetrics(font);
        int tw = 0;
        for (String l : lines) tw = Math.max(tw, fm.stringWidth(l.startsWith("!") ? l.substring(1) : l));
        pg.dispose();
        int w = Math.max(200, tw + 22), lh = 17, h = 16 + lines.length * lh;
        BufferedImage im = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = im.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setColor(new Color(11, 18, 25, 180));
        g.fillRoundRect(0, 0, w - 1, h - 1, 10, 10);
        g.setColor(new Color(138, 211, 236, 220));
        g.setStroke(new BasicStroke(2f));
        g.drawLine(8, 1, 60, 1);
        g.setFont(font);
        for (int i = 0; i < lines.length; i++) {
            String l = lines[i];
            boolean warn = l.startsWith("!");
            if (warn) l = l.substring(1);
            g.setColor(i == 0 ? new Color(241, 246, 249) : warn ? new Color(224, 163, 63) : new Color(185, 200, 210));
            g.drawString(l, 10, 18 + i * lh);
        }
        g.dispose();
        return im;
    }

    /** Das kurze HUD: Tempo, Zeit und Wind, Kamera. Meldungen mit ! aus den vollen Zeilen kommen dazu. */
    String[] hudShort() {
        java.util.List<String> l = new java.util.ArrayList<>();
        String q = autoScale ? String.format(Locale.GERMAN, "%s %.0f %%", quality.label, renderScale * 100) : quality.label;
        l.add(String.format(Locale.GERMAN, "%.0f Bilder/s · Grafikkarte %.1f ms · Prozessor %.1f ms · %s %d×%d", fps, gpuMs, cpuMs, q, hdrW, hdrH));
        l.add(String.format(Locale.GERMAN, "%s · Sonne %.0f° · %s", clock.label(), clock.sun()[0], windLine()));
        l.add(String.format(Locale.GERMAN, "%s · Auge %.0f m · Blick %03.0f° · %.0f m von der Front · H: volles HUD, F1: Tasten",
                camera.modeName(), camera.eye[1], camera.heading(), camera.originDistance()));
        com.dan.glacier.camera.Fahrt fa = camera.fahrt;
        if (fa != null) l.add("Fahrt " + fa.describe() + " · Pfeiltaste oder Maus: anhalten");
        for (String s : hudLines()) if (s.startsWith("!")) l.add(s);
        if (System.currentTimeMillis() < photoMsgUntil) l.add(photoMsg);
        return l.toArray(new String[0]);
    }

    /** „Eis“, „See“, „Fels“ unter dem Auge. */
    String zone() { return "unter dem Auge: " + com.dan.glacier.camera.Ansichten.zone(camera.eye[0], camera.eye[2]); }

    String windLine() {
        if (wiring == null) return "Wind —";
        var w = wiring.wind;
        return String.format(Locale.GERMAN, "Wind %.1f m/s (Bft %d) aus %03.0f°", w.speed(), w.beaufort(), w.fromDeg());
    }

    public String[] hudLines() {
        double[] sp = clock.sun();
        ComputeProbe.Result c = compute;
        return new String[]{
                String.format(Locale.GERMAN, "%.0f Bilder/s   Grafikkarte %.2f ms   Prozessor %.2f ms   Budget %.1f ms", fps, gpuMs, cpuMs, quality.budgetMs()),
                passTimes(),
                (c == null ? "!Compute-Test läuft …" : (c.ok() ? "" : "!") + c.line()),
                String.format(Locale.GERMAN, "%s · Sonne %.1f° / %03.0f° · Belichtung %.2g", clock.label(), sp[0], sp[1], exposure()),
                windLine() + (wiring != null ? String.format(Locale.GERMAN, " · See %+.2f m · Brazo Rico %+.1f m", wiring.waterLevel.level(), wiring.waterLevel.brazoRico()) : ""),
                "Himmel: Platzhalter-Verlauf (com.dan.sky folgt in Phase 3)",
                (terrain.measured() ? "" : "!") + "Gelände " + terrain.describe() + String.format(Locale.GERMAN, " · %d Knoten, %,d Punkte", lod.nodes, lod.vertices),
                vegetation.describe() + " · " + zone(),
                oceanOk ? "See " + ocean.describe() + " · " + oceanGl.info() + (oceanCheck.isEmpty() ? "" : " · " + oceanCheck) : "!See: com.dan.ocean nicht gestartet",
                forestOk ? forestGl.info() + (sunShadow.matrix != null ? String.format(Locale.GERMAN, " · Sonnenschatten %d² über %.0f m", sunShadow.size, sunShadow.half * 2) : "") : "!Wald: com.dan.forest nicht gestartet",
                reedOk ? "Halme " + reed.describe() + " · " + reedGl.info() : "!Halme: com.dan.reed nicht gestartet",
                groundOk ? groundGl.info() : "!Bodendecke: com.dan.ground nicht gestartet",
                physik.describe(),
                wiring == null ? "Verdrahtung —" : "Verdrahtung " + wiring.summary(),
                String.format(Locale.GERMAN, "%s · Auge %.1f m · Blick %03.0f° · %.0f m von der Front · %s",
                        camera.modeName(), camera.eye[1], camera.heading(), camera.originDistance(),
                        Site.dms(Site.latLon(camera.eye[0], camera.eye[2])[0], Site.latLon(camera.eye[0], camera.eye[2])[1])),
                String.format(Locale.GERMAN, "%s · %d×%d · %s", quality.label, hdrW, hdrH, reversedZ ? "umgekehrte Tiefe" : "klassische Tiefe"),
                glInfo};
    }

    // ------------------------------------------------------------------ Bilder

    private void takePhoto(GL4 gl, int w, int h) {
        try {
            BufferedImage img = readDefault(gl, w, h);
            File dir = photoDir != null ? photoDir : new File("docs/status");
            if (!dir.isDirectory() && !dir.mkdirs()) throw new java.io.IOException("Ordner " + dir + " lässt sich nicht anlegen");
            File f = new File(dir, "Glacier_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".png");
            javax.imageio.ImageIO.write(img, "png", f);
            photoMsg = "Foto gespeichert: " + f.getPath();
            System.out.println(photoMsg);
        } catch (Exception e) {
            photoMsg = "Foto fehlgeschlagen: " + e.getMessage();
            System.err.println(photoMsg);
        }
        photoMsgUntil = System.currentTimeMillis() + 5000;
    }

    /** Liest das fertige Fensterbild (nach Nachbearbeitung und HUD). */
    BufferedImage readDefault(GL4 gl, int w, int h) {
        ByteBuffer bb = Buffers.newDirectByteBuffer(w * h * 4);
        gl.glBindFramebuffer(GL.GL_READ_FRAMEBUFFER, defaultFbo);
        gl.glReadBuffer(defaultFbo == 0 ? GL.GL_BACK : GL.GL_COLOR_ATTACHMENT0);
        gl.glPixelStorei(GL.GL_PACK_ALIGNMENT, 1);
        gl.glReadPixels(0, 0, w, h, GL.GL_RGBA, GL.GL_UNSIGNED_BYTE, bb);
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        int[] row = new int[w];
        for (int y = 0; y < h; y++) {
            int o = (h - 1 - y) * w * 4;
            for (int x = 0; x < w; x++) {
                int i = o + x * 4;
                row[x] = ((bb.get(i) & 255) << 16) | ((bb.get(i + 1) & 255) << 8) | (bb.get(i + 2) & 255);
            }
            img.setRGB(0, y, w, 1, row, 0, w);
        }
        return img;
    }

    /** Für Werkzeuge: das letzte Bild als Bild (im GL-Faden aufrufen). */
    public BufferedImage grab(GLAutoDrawable d) {
        GL4 gl = d.getGL().getGL4();
        defaultFbo = d.getContext().getDefaultDrawFramebuffer();
        return readDefault(gl, d.getSurfaceWidth(), d.getSurfaceHeight());
    }

    // ------------------------------------------------------------------ Ende

    private void fail(String msg) {
        error = msg;
        System.err.println(msg);
        errorListener.accept(msg);
    }

    @Override
    public void dispose(GLAutoDrawable d) {
        physik.stop();
        GL4 gl = d.getGL().getGL4();
        for (Shader s : all) s.dispose(gl);
        hud.dispose(gl);
        lod.dispose(gl);
        if (oceanOk) oceanGl.dispose(gl);
        if (reedOk) reedGl.dispose(gl);
        if (forestOk) forestGl.dispose(gl);
        if (groundOk) groundGl.dispose(gl);
        sunShadow.dispose(gl);
        Gpu.deleteFbos(gl, panoFbo);
        Gpu.deleteTextures(gl, panoTex, coverTex);
        Gpu.deleteFbos(gl, hdrFbo);
        Gpu.deleteTextures(gl, hdrTex, depthTex);
        if (emptyVao != 0) gl.glDeleteVertexArrays(1, new int[]{emptyVao}, 0);
        for (int[] s : stamp) if (s[0] != 0) gl.glDeleteQueries(MARKS, s, 0);
        ready = false;
    }
}
