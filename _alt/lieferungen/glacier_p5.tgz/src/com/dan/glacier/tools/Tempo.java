package com.dan.glacier.tools;

import com.dan.glacier.camera.Ansichten;
import com.dan.glacier.gl.Quality;
import com.dan.glacier.gl.Renderer;
import com.dan.glacier.scene.SceneClock;
import com.dan.glacier.wiring.Beaufort;
import com.dan.glacier.wiring.Wiring;
import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLDrawableFactory;
import com.jogamp.opengl.GLOffscreenAutoDrawable;
import com.jogamp.opengl.GLProfile;

import java.io.File;
import java.time.LocalDate;
import java.util.Locale;

/**
 * Tempo-Probe und Standbild ohne Fenster (aus Haithabu). Rechnet die Szene unsichtbar in fester Größe, misst die
 * Wanduhr je Bild bis glFinish und die Zeit jedes Durchgangs auf der Grafikkarte und schreibt auf Wunsch ein PNG. So
 * lässt sich jede Phase vorher und nachher vergleichen und im Leistungsbudget (Werkbuch, Abschnitt 10) eintragen.
 * <pre>
 * Tempo [bilder] [breite] [höhe] [png|-] [NIEDRIG|MITTEL|HOCH|ULTRA] [uhrzeit] [datum JJJJ-MM-TT] [beaufort]
 * Tempo 120 1920 1080 docs/status/Tempo_Phase1.png MITTEL 15 2026-01-16 4
 * Umgebung: OHNE_HUD, OHNE_MARKEN, ANSICHT=Name einer Ansicht (VomSteg, Südflanke, VomBoot, AufdemEis, BrazoRico, VomBerg)
 * oder „oben“, KAMERA=x,z,Richtung,Neigung,Höhe (frei stehend); seit Phase 3 WETTER=Lage der freien Regie (KLAR, FOEHN,
 * FRONT, STURM …), LENTIKULARIS=0..1, BEDECKUNG=Achtel, FIGUREN (Sternbilder einzeichnen); seit Phase 5 FAHRT=Zunge mit
 * BILDER=Zahl: Bildfolge der Fahrt „Über die Zunge“ als png_01.png, png_02.png …
 * </pre>
 */
public final class Tempo {
    private Tempo() { }

    public static void main(String[] a) throws Exception {
        int frames = a.length > 0 ? Integer.parseInt(a[0]) : 120;
        int w = a.length > 1 ? Integer.parseInt(a[1]) : 1920, h = a.length > 2 ? Integer.parseInt(a[2]) : 1080;
        File png = a.length > 3 && !a[3].equals("-") ? new File(a[3]) : null;
        Quality q = a.length > 4 ? Quality.valueOf(a[4]) : Quality.MITTEL;
        double hour = a.length > 5 ? Double.parseDouble(a[5].replace(',', '.')) : SceneClock.START_HOUR;
        LocalDate day = a.length > 6 && !a[6].equals("-") ? LocalDate.parse(a[6]) : SceneClock.START_DATE;
        int bft = a.length > 7 ? Integer.parseInt(a[7]) : 4;

        GLProfile prof = GLProfile.get(GLProfile.GL4);
        GLCapabilities caps = new GLCapabilities(prof);
        caps.setOnscreen(false);
        caps.setFBO(true);
        caps.setDepthBits(24);
        GLOffscreenAutoDrawable d = GLDrawableFactory.getFactory(prof).createOffscreenAutoDrawable(null, caps, null, w, h);
        d.setAutoSwapBufferMode(false);
        SceneClock clock = new SceneClock(day, hour);
        clock.lapse = 0;
        Wiring wiring = new Wiring(clock);
        wiring.wind.speed = Beaufort.mid(bft);
        String wetter = System.getenv("WETTER");   // Phase 3: freie Regie ab einer Lage (KLAR, FOEHN, FRONT …)
        if (wetter != null) {
            wiring.regie = true;
            wiring.startFree(com.dan.weather.Weather.Phase.valueOf(wetter.toUpperCase(Locale.ROOT)));
            if (a.length > 7) wiring.hand(com.dan.weather.Weather.Var.WIND, Beaufort.mid(bft));
        }
        String lens = System.getenv("LENTIKULARIS");
        if (lens != null) wiring.lensHand = Double.parseDouble(lens.replace(',', '.'));
        String okt = System.getenv("BEDECKUNG");
        if (okt != null) { if (wiring.regie) wiring.hand(com.dan.weather.Weather.Var.COVER, Double.parseDouble(okt)); else wiring.oktas = Double.parseDouble(okt); }
        Renderer r = new Renderer(clock, wiring);
        r.frozen = true;
        r.setQuality(q);
        r.autoScale = false;
        if (System.getenv("OHNE_HUD") != null) r.showHud = false;
        if (System.getenv("OHNE_MARKEN") != null) r.showMarks = false;
        if (System.getenv("FIGUREN") != null) r.showFigures = true;
        // Phase 5: den Gletscher gleich bauen (sonst fehlt er in den ersten Bildern)
        r.gletscherJetzt();
        String an = System.getenv("ANSICHT");
        if ("oben".equals(an)) { r.camera.lookAt(0, 0, 0, 0, 89, 9000); r.camera.snap(); }
        else if (an != null && Ansichten.byName(an) != null) Ansichten.apply(Ansichten.byName(an), r.camera, Renderer.PHASE);
        String kam = System.getenv("KAMERA");   // x,z,Richtung,Neigung,Höhe über Grund (frei)
        if (kam != null) {
            String[] k = kam.split(",");
            double kx = Double.parseDouble(k[0]), kz = Double.parseDouble(k[1]);
            r.camera.place(kx, com.dan.glacier.camera.Ansichten.ground(kx, kz) + Double.parseDouble(k[4]), kz, Double.parseDouble(k[2]), Double.parseDouble(k[3]));
        }
        d.addGLEventListener(r);
        d.display();
        if (r.error() != null) { System.err.println("FEHLER: " + r.error()); System.exit(2); }
        for (int i = 0; i < 10; i++) { r.step(1 / 60.0); d.display(); }
        // Phase 5: warten, bis die feinen Kacheln des Gletschers gebaut sind (höchstens 60 s)
        for (int i = 0; i < 3000 && r.glacierBusy(); i++) { d.display(); Thread.sleep(20); }
        String fahrt = System.getenv("FAHRT");   // Phase 5: Bildfolge einer Fahrt, FAHRT=Zunge, BILDER=Zahl
        if (fahrt != null && png != null) {
            com.dan.glacier.camera.Fahrt f = r.zungenFahrt();
            int n = Integer.parseInt(System.getenv().getOrDefault("BILDER", "8"));
            for (int k = 0; k < n; k++) {
                double[] fq = f.pose(n == 1 ? 0 : k / (double) (n - 1));
                r.camera.place(fq[0], fq[1], fq[2], fq[3], fq[4]);
                r.camera.snap();
                for (int i = 0; i < 6; i++) { r.step(1 / 60.0); d.display(); }
                for (int i = 0; i < 1500 && r.glacierBusy(); i++) { d.display(); Thread.sleep(20); }
                for (int i = 0; i < 4; i++) { r.step(1 / 60.0); d.display(); }
                File out = new File(png.getPath().replace(".png", String.format("_%02d.png", k + 1)));
                File dir = out.getAbsoluteFile().getParentFile();
                if (dir != null) dir.mkdirs();
                final java.awt.image.BufferedImage[] img = new java.awt.image.BufferedImage[1];
                d.invoke(true, x -> { img[0] = r.grab(x); return true; });
                javax.imageio.ImageIO.write(img[0], "png", out);
                System.out.println("Bild " + (k + 1) + "/" + n + ": " + out.getPath() + String.format(Locale.GERMAN, " · %.0f m, %.0f m über dem See", f.length * k / Math.max(1.0, n - 1), fq[1]));
            }
            d.destroy();
            System.exit(0);
        }
        double best = Double.MAX_VALUE, sum = 0;
        for (int i = 0; i < frames; i++) {
            long t0 = System.nanoTime();
            r.step(1 / 60.0);
            d.display();
            d.getContext().makeCurrent();
            d.getGL().glFinish();
            d.getContext().release();
            double ms = (System.nanoTime() - t0) / 1e6;
            best = Math.min(best, ms);
            sum += ms;
        }
        System.out.println(r.glInfo());
        System.out.println(r.compute() == null ? "Compute-Test: nicht gelaufen" : r.compute().line());
        System.out.printf(Locale.GERMAN, "%d×%d %s, %s: bestes Bild %.2f ms, Mittel %.2f ms (%.0f Bilder/s)%n", w, h, q.label, clock.label(), best, sum / frames, 1000 / (sum / frames));
        System.out.println("Durchgänge (ms): " + r.passTimes());
        for (String l : r.hudLines()) System.out.println("  " + l);
        if (png != null) {
            File dir = png.getAbsoluteFile().getParentFile();
            if (dir != null) dir.mkdirs();
            final java.awt.image.BufferedImage[] img = new java.awt.image.BufferedImage[1];
            d.invoke(true, x -> { img[0] = r.grab(x); return true; });
            javax.imageio.ImageIO.write(img[0], "png", png);
            System.out.println("Bild: " + png.getPath());
        }
        d.destroy();
        System.exit(0);
    }
}
