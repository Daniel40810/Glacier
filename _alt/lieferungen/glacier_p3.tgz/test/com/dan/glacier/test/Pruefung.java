package com.dan.glacier.test;

import com.dan.glacier.camera.Ansichten;
import com.dan.glacier.camera.Camera;
import com.dan.glacier.gl.ComputeProbe;
import com.dan.glacier.gl.Mat4;
import com.dan.glacier.gl.Quality;
import com.dan.glacier.gl.Renderer;
import com.dan.glacier.gl.Shader;
import com.dan.glacier.scene.Bodendecke;
import com.dan.glacier.scene.Buehne;
import com.dan.glacier.scene.Geo;
import com.dan.glacier.scene.Physik;
import com.dan.glacier.scene.SceneClock;
import com.dan.glacier.scene.Site;
import com.dan.glacier.scene.Sun;
import com.dan.glacier.scene.Terrain;
import com.dan.glacier.scene.Vegetation;
import com.dan.glacier.tools.GelaendeImport;
import com.dan.glacier.ui.AppIcon;
import com.dan.glacier.wiring.Beaufort;
import com.dan.glacier.wiring.Collider;
import com.dan.glacier.wiring.Wiring;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Locale;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Prüfprogramm der App ohne Grafikkarte und ohne Datenbank (aus Haithabu). In NetBeans: Rechtsklick → „Run File“,
 * oder Ant-Target {@code pruefung}. Endet mit „ERGEBNIS: alles in Ordnung“ oder mit der Liste der Verstöße
 * (Rückgabewert 1). Wächst mit jeder Phase. Die Packages haben zusätzlich je ihre eigene Prüfklasse in {@code .demo}.
 */
public final class Pruefung {
    private static int ok, bad;

    public static void main(String[] args) throws Exception {
        long t0 = System.nanoTime();
        mathe();
        ort();
        sonne();
        uhr();
        buehne();
        gelaende();
        vegetation();
        himmel();
        wetter();
        kamera();
        qualitaet();
        physik();
        shader();
        verdrahtung();
        symbol();
        pakete();
        isolation();
        System.out.printf(Locale.GERMAN, "%n%d Prüfungen, %d Verstöße, %.1f s%n", ok + bad, bad, (System.nanoTime() - t0) / 1e9);
        System.out.println(bad == 0 ? "ERGEBNIS: alles in Ordnung" : "ERGEBNIS: " + bad + " Verstöße");
        System.exit(bad == 0 ? 0 : 1);
    }

    static void check(boolean cond, String what) {
        if (cond) ok++; else bad++;
        System.out.println((cond ? "  ok    " : "  FEHLER ") + what);
    }

    static void mathe() {
        System.out.println("Matrizen");
        float[] v = Mat4.lookAt(10, 20, 30, 0, 14, 0);
        float[] p = Mat4.perspective(55, 16 / 9.0, 0.5, 80000, true);
        float[] vp = Mat4.mul(p, v), id = Mat4.mul(vp, Mat4.invert(vp));
        double err = 0;
        for (int i = 0; i < 16; i++) err = Math.max(err, Math.abs(id[i] - (i % 5 == 0 ? 1 : 0)));
        check(err < 1e-4, String.format(Locale.GERMAN, "Projektion·Blick mal Inverse = Einheit (Fehler %.1e)", err));
        float[] look = Mat4.lookAt(0, 0, 0, 0, 0, -1);
        double[] c = Mat4.apply(Mat4.mul(p, look), 0, 0, -100);
        check(Math.abs(c[2] / c[3] - 0.5 / 100) < 1e-6, "Umgekehrte Tiefe: Punkt in 100 m hat Tiefe Nahebene/100");
        double[] far = Mat4.apply(Mat4.mul(p, look), 0, 0, -12000);
        check(far[2] / far[3] > 0 && far[2] / far[3] < 1e-4, "Berge in 12 km liegen zwischen 0 und Nahebene, vor dem Unendlichen");
    }

    static void ort() {
        System.out.println("Ort und Maßstab");
        check(Site.dms(Site.LAT, Site.LON).equals("50°28′23″ S · 73°02′13″ W"), "Spitze der Front aus GLO-30 (Phase 2) in Grad, Minuten, Sekunden: " + Site.dms(Site.LAT, Site.LON));
        double[] xz = Site.xz(new double[]{Site.LAT, Site.LON});
        check(Math.abs(xz[0]) < 1e-6 && Math.abs(xz[1]) < 1e-6, "Ursprung der Szene liegt auf der Spitze der Front");
        double x = 1234.5, z = -987.25;
        double[] back = Site.xz(Site.latLon(x, z));
        check(Math.abs(back[0] - x) < 1e-6 && Math.abs(back[1] - z) < 1e-6, "Szene ↔ Breite/Länge hin und zurück (Südhalbkugel)");
        check(Site.lat(-1000) > Site.LAT && Site.lon(1000) > Site.LON, "Nord ist −z (Breite steigt gegen null), Ost ist +x");
        double[] u = Geo.UTM18S.forward(Site.LAT, Site.LON), ll = Geo.UTM18S.inverse(u[0], u[1]);
        check(Math.abs(ll[0] - Site.LAT) < 1e-9 && Math.abs(ll[1] - Site.LON) < 1e-9 && u[1] < 10_000_000 && u[0] > 500_000,
                String.format(Locale.GERMAN, "UTM 18 Süd hin und zurück: %.0f E, %.0f N", u[0], u[1]));
        double[] g = Site.xz(new double[]{Site.GLACIER_LAT, Site.GLACIER_LON});
        check(g[0] < -2000 && g[1] > 0, String.format(Locale.GERMAN, "Der Gletscher als Ganzes (50°30′ S 73°08′ W) liegt %.1f km westlich, %.1f km südlich der Front – oben auf der Zunge", -g[0] / 1000, g[1] / 1000));
        check(Math.abs(Site.FRONT_DRAFT - 96) < 1e-9, "Front: 74 m über Wasser, 170 m Eis, also 96 m unter dem Spiegel");
        check(Math.abs(Site.waveSpeed(100) - 31.3) < 0.1, String.format(Locale.GERMAN, "Lange Welle bei 100 m Tiefe: %.1f m/s, über 600 m Kanal in %.0f s", Site.waveSpeed(100), 600 / Site.waveSpeed(100)));
    }

    static void sonne() {
        System.out.println("Sonne (Südhalbkugel)");
        SceneClock c = new SceneClock(LocalDate.of(2026, 1, 16), 0);
        double day = c.epochMillis();
        double up = hourOf(Sun.crossing(day, Site.LAT, Site.LON, true)), down = hourOf(Sun.crossing(day, Site.LAT, Site.LON, false));
        check(up > 5.0 && up < 6.5 && down > 21.0 && down < 22.5, "16.1.2026 Aufgang " + hm(up) + ", Untergang " + hm(down) + " ART");
        double len = down - up;
        check(len > 15.5 && len < 16.8, String.format(Locale.GERMAN, "Tag im Januar %.2f h (50,5° S, Hochsommer)", len));
        double best = -90, bestH = 0;
        for (double h = 10; h < 18; h += 1 / 60.0) {
            c.set(LocalDate.of(2026, 1, 16), h);
            double e = c.sun()[0];
            if (e > best) { best = e; bestH = h; }
        }
        c.set(LocalDate.of(2026, 1, 16), bestH);
        double az = c.sun()[1];
        check((az < 5 || az > 355) && bestH > 13.5 && bestH < 14.5, String.format(Locale.GERMAN, "Höchststand %s ART bei %.1f°, Azimut %03.0f° – die Sonne steht mittags im Norden", hm(bestH), best, az));
        SceneClock dez = new SceneClock(LocalDate.of(2026, 12, 21), 0);
        double dd = hourOf(Sun.crossing(dez.epochMillis(), Site.LAT, Site.LON, false));
        check(dd > 22.0, "21.12.2026 Untergang " + hm(dd) + " ART (Werkbuch: im Dezember bis nach 22 Uhr)");
        SceneClock jul = new SceneClock(LocalDate.of(2026, 7, 16), 0);
        double ju = hourOf(Sun.crossing(jul.epochMillis(), Site.LAT, Site.LON, true)), jd = hourOf(Sun.crossing(jul.epochMillis(), Site.LAT, Site.LON, false));
        check(jd - ju < 9, String.format(Locale.GERMAN, "16.7.2026 Tag %.1f h (Winter)", jd - ju));
    }

    static void uhr() {
        System.out.println("Uhr");
        SceneClock c = new SceneClock();
        check(c.label().equals("16.1.2026 15:00 ART"), "Start: " + c.label());
        check(Math.abs(c.local().getOffset().getTotalSeconds() + 3 * 3600) < 1, "Argentinische Zeit UTC−3");
        c.lapse = 60;
        c.step(30);
        check(c.label().equals("16.1.2026 15:30 ART"), "Zeitraffer 1 min/s, 30 s → " + c.label());
        double e0 = c.epochMillis();
        c.lapse = 1e9;
        c.step(1);
        check(Math.abs(c.epochMillis() - e0 - SceneClock.MAX_LAPSE * 1000) < 1e-3, "Zeitraffer höchstens 3600-fach");
        c.set(LocalDate.of(2026, 12, 31), 23.5);
        c.lapse = 3600;
        c.step(1);
        check(c.dateLabel().equals("1.1.2027"), "Jahreswechsel: " + c.label());
        SceneClock s = new SceneClock();
        s.lapse = 0;
        s.step(2.5);
        check(Math.abs(s.t() - 2.5) < 1e-9 && s.label().equals("16.1.2026 15:00 ART"), "Uhr steht, Laufzeit läuft weiter (Wellen bewegen sich)");
    }

    static void buehne() {
        System.out.println("Bühne (Phase 1, Ersatz ohne Höhendaten)");
        check(Buehne.ice(-10, 0) && !Buehne.ice(10, 0) && !Buehne.ice(-10, 2600) && Buehne.height(-100, 0) == Site.FRONT_HEIGHT, "Eis westlich der Front, 5 km breit, 74 m hoch");
        Terrain f = Terrain.flat();
        check(!f.measured() && f.ice(-100, 0) && f.sourceAt(Buehne.TIP + 30, 20) == Terrain.FELS && f.waterDepth(200, -800) > 50,
                "Terrain.flat(): die Bühne als Gelände, falls daten/gelaende fehlt");
    }

    static Terrain terrain;

    static void gelaende() {
        System.out.println("Gelände (Phase 2, GLO-30)");
        double y = 123.456;
        check(Math.abs(Terrain.decode(Terrain.encode(y)) - y) < (Terrain.HMAX - Terrain.HMIN) / 65535.0, "Höhe in 16 bit: Stufe " + String.format(Locale.GERMAN, "%.3f m", (Terrain.HMAX - Terrain.HMIN) / 65535.0));
        boolean[] m = {false, true, false, true};
        check(Math.abs(GelaendeImport.maskAt(m, 2, 2, 0.5, 0.5) - 0.5) < 1e-9 && GelaendeImport.maskAt(m, 2, 2, 1, 0) == 1, "Masken bilinear (keine Treppen der 30-m-Zellen)");
        terrain = Terrain.load(Terrain.defaultDir());
        if (!terrain.measured()) {
            System.out.println("  (daten/gelaende fehlt – tools.GelaendeImport erst laufen lassen; Prüfungen am echten Gelände übersprungen)");
            return;
        }
        Terrain t = terrain;
        System.out.println("  " + t.describe());
        check(Math.abs(t.lakeAsl - Site.LAKE_LEVEL_ASL) < 0.5, String.format(Locale.GERMAN, "Seespiegel %.1f m ü. M. wie Site.LAKE_LEVEL_ASL", t.lakeAsl));
        check(Math.abs(Double.parseDouble(t.props.getProperty("ursprung.lat")) - Site.LAT) < 1e-6
                && Math.abs(Double.parseDouble(t.props.getProperty("ursprung.lon")) - Site.LON) < 1e-6, "Ursprung des Imports = Site.LAT/LON");
        double[] sh = t.sourceShares();
        check(sh[1] > 0.10 && sh[1] < 0.30 && sh[2] > 0.08 && sh[2] < 0.25, String.format(Locale.GERMAN, "See %.0f %%, Eis %.0f %% des Ausschnitts", sh[1] * 100, sh[2] * 100));
        double[] fs = t.frontStats();
        check(fs[0] > 3500 && fs[0] < 6500, String.format(Locale.GERMAN, "Front %.1f km lang (Lücken über %.0f m zählen nicht)", fs[0] / 1000, Terrain.FRONT_GAP));
        check(fs[1] > 20 && fs[1] < 90, String.format(Locale.GERMAN, "Oberkante im Höhenmodell im Mittel %.0f m (die echte Wand kommt in Phase 5)", fs[1]));
        boolean iceNear = false, waterNear = false;
        for (int a = 0; a < 360; a += 10)
            for (int r = 10; r <= 120; r += 10) {
                double x = r * Math.cos(Math.toRadians(a)), z = r * Math.sin(Math.toRadians(a));
                iceNear |= t.ice(x, z);
                waterNear |= t.sourceAt(x, z) == Terrain.SEE;
            }
        check(iceNear && waterNear, "am Ursprung stoßen Eis und See zusammen (Spitze der Front)");
        double sd = Math.hypot(t.steg[0], t.steg[1]);
        check(t.sourceAt(t.steg[0], t.steg[1]) == Terrain.FELS && t.steg[0] > 0 && sd >= 290 && t.steg[2] >= 24 && t.steg[2] <= 61,
                String.format(Locale.GERMAN, "Steg auf der Halbinsel: %.0f m vor der Spitze, %.0f m über dem See, Blick %03.0f°", sd, t.steg[2], t.steg[3]));
        check(Math.abs(t.height(t.steg[0], t.steg[1]) - t.steg[2]) < 3, "Höhe am Steg = Höhe im Gelände");
        double dCanal = t.waterDepth(-300, -900);
        check(dCanal > 40 && dCanal < 170, String.format(Locale.GERMAN, "Canal de los Témpanos vor der Front %.0f m tief [G]", dCanal));
        double iceBed = t.ice(-1500, 0) ? t.height(-1500, 0) - t.bed(-1500, 0) : 0;
        check(iceBed > 150 && iceBed < 450, String.format(Locale.GERMAN, "Eis 1,5 km hinter der Front %.0f m dick [G], Grund darunter modelliert", iceBed));
        double[] r = new double[2];
        t.range(-2000, -2000, 4000, r);
        check(r[0] < -40 && r[1] > 300, String.format(Locale.GERMAN, "Spanne eines Knotens 4 km um die Front: %.0f bis %.0f m", r[0], r[1]));
    }

    static void vegetation() {
        System.out.println("Vegetation (Phase 2) [G]");
        Terrain t = terrain != null && terrain.measured() ? terrain : Terrain.flat();
        Vegetation v = new Vegetation(t);
        System.out.println("  " + v.describe());
        check(Vegetation.species().size() == 3 && Vegetation.species().get(0).name.startsWith("Lenga"), "Arten: Lenga, Ñire, Guindo");
        double[] sh = v.shares();
        check(!t.measured() || sh[0] > 0.10 && sh[0] < 0.50, String.format(Locale.GERMAN, "Wald auf %.0f %% des Ausschnitts", sh[0] * 100));
        int onIce = 0, onLake = 0, high = 0, n = 0;
        for (double x = Terrain.X0 + 50; x < Terrain.X0 + Terrain.N * Terrain.CELL; x += 97)
            for (double z = Terrain.Z0 + 50; z < Terrain.Z0 + Terrain.N * Terrain.CELL; z += 97) {
                double f = v.forest(x, z);
                byte s = t.sourceAt(x, z);
                n++;
                if (f > 0.3 && s == Terrain.EIS && t.ice(x + 30, z) && t.ice(x - 30, z) && t.ice(x, z + 30) && t.ice(x, z - 30)) onIce++;
                if (f > 0.3 && s == Terrain.SEE && t.waterDepth(x, z) > 5) onLake++;
                if (f > 0.05 && t.height(x, z) > Vegetation.TREELINE + Vegetation.TREELINE_FADE + 30) high++;
            }
        check(onIce == 0 && onLake == 0, "kein Wald auf dem Eis und im See (" + n + " Stichproben)");
        check(high == 0, String.format(Locale.GERMAN, "kein Wald über der Baumgrenze (%.0f m über dem See)", Vegetation.TREELINE + Vegetation.TREELINE_FADE));
        float[] c = new float[5];
        new Bodendecke(t, v).cover(-1500, 0, c);
        check(!t.ice(-1500, 0) || c[0] + c[1] + c[2] + c[3] + c[4] == 0, "Bodendecke: nichts auf dem Eis");
        check(v.at(-1500, 0, com.dan.reed.Reed.Kind.STEPPE) == 0 || !t.ice(-1500, 0), "Steppengras nicht auf dem Eis");
        check(Wiring.northernDay(16) == 198 && Wiring.northernDay(200) == 17, "Südhalbkugel: 16. Januar ist für forest, ground, reed der 17. Juli");
        if (t.measured()) {
            double fs = v.forest(t.steg[0], t.steg[1]);
            double a = Math.toRadians(t.steg[3]), lx = t.steg[0] + Math.sin(a) * 200, lz = t.steg[1] - Math.cos(a) * 200;
            double lane = v.forest(lx, lz);
            check(fs < 0.05 && lane < 0.05, String.format(Locale.GERMAN, "Steg frei (Befund Status_Phase2): Wald am Steg %.0f %%, 200 m Richtung Front %.0f %%", fs * 100, lane * 100));
        }
    }

    /** Phase 3: der Himmel über der Front. */
    static void himmel() {
        System.out.println("Himmel (Phase 3, com.dan.sky)");
        com.dan.sky.Sky sky = new com.dan.sky.Sky();
        sky.latDeg = Site.LAT;
        sky.lonDeg = Site.LON;
        SceneClock c = new SceneClock();
        sky.epochMillis = c.epochMillis();
        com.dan.sky.Sky.State st = sky.update();
        double az = (Math.toDegrees(Math.atan2(st.sunDir[0], -st.sunDir[2])) + 360) % 360;
        check(st.sunAlt > 50 && st.sunAlt < 62 && (az > 300 || az < 30), String.format(Locale.GERMAN, "16.1.2026 15:00 ART: Sonne %.1f° hoch aus %03.0f° (über Norden)", st.sunAlt, az));
        c.set(LocalDate.of(2026, 1, 17), 1.5);
        sky.epochMillis = c.epochMillis();
        com.dan.sky.Sky.State n = sky.update();
        double crux = alt(n, 186.65, -63.10), lmc = alt(n, 80.89, -69.76), smc = alt(n, 13.19, -72.83);
        check(n.sunAlt < -12 && crux > 10 && lmc > 25 && smc > 25,
                String.format(Locale.GERMAN, "17.1. 01:30 ART: Sonne %.0f°, Acrux %.0f° hoch, Große Wolke %.0f°, Kleine Wolke %.0f° (bei 50,5° Süd nie unter der Kimm)", n.sunAlt, crux, lmc, smc));
        check(com.dan.sky.StarCatalog.get().figures.stream().anyMatch(f -> f.code().equals("Cru")) && com.dan.sky.StarCatalog.magellanic(80.9, -69.8) > 0.5,
                "Kreuz des Südens als Figur, Magellansche Wolken in der Milchstraße (Packages sky, seit Glacier Phase 3)");
    }

    /** Höhe eines Sterns (RA, Dec J2000) über dem Horizont in Grad. */
    static double alt(com.dan.sky.Sky.State st, double ra, double dec) {
        double[] d = com.dan.sky.Celestial.apply(st.eqToScene, com.dan.sky.Celestial.equatorial(ra, dec));
        return Math.toDegrees(Math.asin(Math.max(-1, Math.min(1, d[1]))));
    }

    /** Phase 3: die Wetterregie mit dem Klima Patagoniens. */
    static void wetter() {
        System.out.println("Wetter (Phase 3, Klima Patagonien) [G]");
        SceneClock c = new SceneClock();
        Wiring w = new Wiring(c);
        w.regie = true;
        w.startFree(com.dan.weather.Weather.Phase.KLAR);
        int foehn = 0, n = 0, rain = 0;
        double sx = 0, sz = 0, lensMax = 0, lensFoehn = 0;
        com.dan.cloud.Clouds cl = new com.dan.cloud.Clouds();
        c.lapse = 600;
        for (int i = 0; i < 30 * 24 * 6; i++) {
            c.step(1.0);
            w.feedWeather(0.05);
            n++;
            com.dan.weather.Weather.Snapshot s = w.weather.snapshot();
            if (s.phase() == com.dan.weather.Weather.Phase.FOEHN) { foehn++; lensFoehn += w.lens; }
            if (w.rainRate > 0.2) rain++;
            double a = Math.toRadians(w.wind.fromDeg());
            sx += Math.sin(a) * w.wind.speed();
            sz += Math.cos(a) * w.wind.speed();
            lensMax = Math.max(lensMax, w.lens);
        }
        w.feed(cl);
        double mean = (Math.toDegrees(Math.atan2(sx, sz)) + 360) % 360;
        check(foehn > n / 20 && mean > 240 && mean < 310 && rain > n / 50 && rain < n / 2,
                String.format(Locale.GERMAN, "30 Tage freie Regie: Föhnsturm %.0f %% der Zeit, Wind im Mittel aus %03.0f°, Regen %.0f %% der Zeit", foehn * 100.0 / n, mean, rain * 100.0 / n));
        check(foehn > 0 && lensFoehn / foehn > 0.5 && lensMax <= 1 && Math.abs(cl.lens - w.lens) < 1e-12 && Math.abs(cl.lensFromDeg - w.wind.fromDeg()) < 1e-9,
                String.format(Locale.GERMAN, "Lentikularis im Föhnsturm im Mittel %.0f %%, an die Wolken mit der Windrichtung", lensFoehn / Math.max(1, foehn) * 100));
        check(Wiring.lensTarget(com.dan.weather.Weather.Phase.KLAR, 3, 270, 1) == 0 && Wiring.lensTarget(com.dan.weather.Weather.Phase.FOEHN, 20, 285, 2) > 0.8
                        && Wiring.lensTarget(com.dan.weather.Weather.Phase.FOEHN, 20, 285, 8) == 0,
                "Lentikularis: keine bei Schwachwind, fast immer im Föhn, nicht sichtbar unter 8/8");
        com.dan.fog.Fog f = new com.dan.fog.Fog();
        w.fogAmount = 1;
        w.regie = false;
        w.wind.speed = 1;
        w.feed(f, -5);
        check(Math.abs(f.top - 80) < 1e-9 && f.amount > 0.9, String.format(Locale.GERMAN, "Dichter Seenebel vor Tag: bis %.0f m über dem See (die Front ragt mit gut 40 m nicht heraus)", f.top));
    }

    static void kamera() {
        System.out.println("Kamera");
        Camera cam = new Camera();
        check(cam.eye[0] > 1200 && Math.abs(cam.eye[2]) < 400 && cam.heading() > 260 && cam.heading() < 290,
                String.format(Locale.GERMAN, "Grundansicht: %.0f m vor der Front, Blick %03.0f° auf die Wand", cam.eye[0], cam.heading()));
        Terrain t = terrain != null ? terrain : Terrain.flat();
        Ansichten.use(t);
        double gi = t.height(-1500, 0);
        cam.place(-1500, 0, 0, 90, 0);
        cam.groundLevel = gi;
        cam.step(0.1);
        check(cam.eye[1] >= gi + Camera.MIN_EYE - 1e-9, String.format(Locale.GERMAN, "Frei auf dem Eis: Auge bleibt über dem Eis (%.1f m)", cam.eye[1]));
        cam.setMode(Camera.Mode.KREISEN);
        check(cam.mode == Camera.Mode.KREISEN && cam.dist > 1, "Wechsel Frei → Kreisen behält die Ansicht");
        int ready = 0;
        for (Ansichten.Ansicht a : Ansichten.ALLE) {
            Camera c = new Camera();
            if (Ansichten.apply(a, c, Renderer.PHASE)) {
                ready++;
                double ground = Ansichten.ground(c.eye[0], c.eye[2]);
                if (c.eye[1] < ground + 1) check(false, a + " liegt unter dem Gelände");
            }
        }
        check(ready == 6 && Ansichten.ALLE.size() == 7, ready + " von 7 Ansichten im Gelände; „Unter Wasser“ folgt in Phase 9");
        if (t.measured()) {
            String[][] want = {{"1", "Land"}, {"2", "Land"}, {"3", "See"}, {"4", "Eis"}, {"5", "See"}, {"6", "Land"}};
            StringBuilder sb = new StringBuilder();
            boolean all = true;
            for (String[] w : want) {
                Camera c = new Camera();
                Ansichten.apply(Ansichten.byKey(Integer.parseInt(w[0])), c, Renderer.PHASE);
                String z = Ansichten.zone(c.eye[0], c.eye[2]);
                all &= z.equals(w[1]);
                sb.append(sb.length() > 0 ? ", " : "").append(w[0]).append(' ').append(z);
            }
            check(all, "Ansichten stehen, wo sie sollen: " + sb);
            Camera c = new Camera();
            Ansichten.apply(Ansichten.byKey(1), c, Renderer.PHASE);
            check(Math.abs(c.eye[0] - t.steg[0]) < 1e-6 && Math.abs(c.eye[2] - t.steg[1]) < 1e-6, "1 Vom Steg steht am Steg aus dem Import");
        }
    }

    static void qualitaet() {
        System.out.println("Qualität");
        boolean mono = true;
        Quality[] q = Quality.values();
        for (int i = 1; i < q.length; i++) mono &= q[i].renderScale >= q[i - 1].renderScale && q[i].budgetMs() > q[i - 1].budgetMs();
        check(mono, "Stufen Niedrig → Ultra steigen an");
        check(Math.abs(Quality.MITTEL.budgetMs() - 15.7) < 1e-9 && Math.abs(Quality.HOCH.budgetMs() - 2 * 15.7) < 1e-9, "„Mittel“ hat das Budget aus Abschnitt 10: 15,7 ms, „Hoch“ das Doppelte");
        Renderer r = new Renderer();
        check(r.quality() == Quality.MITTEL, "Start auf „Mittel“ (F21 A)");
        r.regulateForTest(30, 10_000_000_000L);
        check(r.renderScale < Quality.MITTEL.renderScale, String.format(Locale.GERMAN, "Grafikkarte 30 ms: Auflösung sinkt auf %.0f %%", r.renderScale * 100));
        check(r.renderScale >= Renderer.MIN_SCALE, "nie unter " + Math.round(Renderer.MIN_SCALE * 100) + " %");
    }

    static void physik() {
        System.out.println("Faden der Physik (F21 A)");
        Physik p = new Physik();
        int[] n = {0};
        p.add((t, dt) -> n[0]++);
        p.advance(0.5);
        int steps = p.drain();
        check(steps == Physik.MAX_BEHIND && n[0] == steps, "Fester Schritt 1/120 s, höchstens " + Physik.MAX_BEHIND + " Schritte nachgeholt (" + steps + ")");
        p.advance(Physik.DT * 3.5);
        check(p.drain() == 3, "3,5 Schritte Zeit → 3 Schritte, der Rest wartet");
        p.add((t, dt) -> { throw new IllegalStateException("Probe"); });
        p.advance(Physik.DT);
        p.drain();
        check(p.aufgaben() == 1, "Eine fehlerhafte Aufgabe fällt heraus, die anderen laufen weiter");
    }

    static void shader() {
        System.out.println("Shader");
        for (String[] prog : Renderer.shaderFiles()) {
            for (String f : prog) {
                boolean found;
                String text = "";
                try {
                    text = Shader.source(f, null).text;
                    found = text.startsWith("#version 430 core");
                } catch (RuntimeException e) {
                    found = false;
                }
                check(found, "Shader " + f + " gefunden und Bausteine eingesetzt (" + text.split("\n").length + " Zeilen)");
            }
        }
        String tf = Shader.source("terrain.frag", null).text, tv = Shader.source("terrain.vert", null).text;
        check(tf.contains("iceFraction") && tf.contains("uCover") && tf.contains("uSnowLine") && tv.contains("EARTH_R"),
                "Gelände: Eis weich aus den Nachbarzellen, Bedeckung aus der Vegetation, Schneegrenze, Erdkrümmung");
        boolean half = false;
        for (String[] prog : Renderer.shaderFiles()) for (String f : prog) half |= Pattern.compile("\\bhalf\\b").matcher(Shader.source(f, null).text).find();
        check(!half, "kein reserviertes Wort „half“ in den Shadern der App (AMD-Treiber sind streng)");
        check(new File("src/com/dan/glacier/gl/shader/stage.frag").exists() == false || !new File("src").isDirectory(), "stage.frag (Bühne von Phase 1) ist abgestellt");
        check(ComputeProbe.expected(0, 63) == 64 * 65 / 2 && ComputeProbe.expected(1, 0) == 65, "Compute-Test: Erwartungswerte der Präfixsumme");
    }

    static void verdrahtung() {
        System.out.println("Verdrahtung");
        Wiring w = new Wiring(new SceneClock());
        check(w.links().size() == 20 && w.links().stream().allMatch(l -> l.phase() <= 3), "Phase 1 bis 3: " + w.summary());
        check(w.links().stream().anyMatch(l -> l.to().contains("forest") && l.phase() == 2) && w.links().stream().anyMatch(l -> l.to().contains("ocean") && l.phase() == 2),
                "Phase 2: Wind, Uhr und Gelände an ocean, forest, reed, ground");
        int found = 0;
        for (String n : Wiring.INTERFACES) {
            try {
                Class<?> c = Class.forName("com.dan.glacier.wiring." + n);
                if (c.isInterface()) found++;
            } catch (ClassNotFoundException e) { /* fehlt */ }
        }
        check(found == Wiring.INTERFACES.length && found == 15, found + " von 15 Schnittstellen aus Abschnitt 4 stehen als Interface, darunter neu Sea, Cells, Impact, Crack, Runup");
        check(Wiring.planned().stream().anyMatch(l -> l.via().startsWith("Cells") && l.phase() == 6)
                && Wiring.planned().stream().anyMatch(l -> l.via().startsWith("Impact") && l.phase() == 8), "Plan: Cells ab Phase 6, Impact ab Phase 8");
        check(Beaufort.of(w.wind.speed()) == 4, "Wind von Hand: Bft 4 (" + Beaufort.NAME[4] + ")");
        double[] to = w.wind.toVector();
        check(to[0] > 0.99, "Westwind vom Eisfeld weht nach Osten über die Front auf den Kanal");
        w.waterLevel.stau = 25;
        check(w.waterLevel.brazoRico() - w.waterLevel.level() == 25, "Stau des Brazo Rico über dem Hauptsee");
        Collider block = Collider.box(-50, 37, 0, 50, 37, 2500);
        check(block.distance(-50, 37, 0) < 0 && Math.abs(block.distance(10, 37, 0) - 10) < 1e-9, "Collider: Eisblock als Quader");
    }

    static void symbol() {
        System.out.println("Programmsymbol");
        boolean all = true;
        for (int s : AppIcon.SIZES) {
            java.awt.image.BufferedImage b = AppIcon.paint(s);
            all &= b.getWidth() == s && (b.getRGB(s / 2, s / 2) >>> 24) == 255 && (b.getRGB(0, 0) >>> 24) < 255;
        }
        check(all, "Symbol in " + AppIcon.SIZES.length + " Größen gemalt, deckend in der Mitte, runde Ecken");
    }

    /** Die 21 Element-Packages stehen im Quellordner, jedes mit README; die 7 abgestellten liegen in _alt/packages (F6 A). */
    static void pakete() {
        System.out.println("Packages");
        File base = new File("src/com/dan");
        if (!base.isDirectory()) { System.out.println("  (Quellordner nicht gefunden, übersprungen)"); return; }
        String[] wanted = {"ice", "fracture", "wave", "sky", "cloud", "weather", "rain", "fog", "lightning", "ocean", "spray", "buoyancy",
                "weathering", "flock", "forest", "ground", "river", "reed", "season", "soundscape", "store"};
        int n = 0;
        for (String w : wanted) if (new File(base, w + "/README.md").isFile()) n++;
        File[] dirs = base.listFiles(f -> f.isDirectory() && !f.getName().equals("glacier"));
        check(n == wanted.length && dirs != null && dirs.length == wanted.length, n + " von 21 Packages mit README im Build (18 aus Haithabu, 3 neu)");
        // FStyle.jar bringt ältere Kopien von forest, ground und river mit; die eigenen Klassen müssen vorn im Klassenpfad stehen
        StringBuilder shadow = new StringBuilder();
        for (Class<?> c : new Class<?>[]{com.dan.forest.Species.class, com.dan.ground.Biome.class, com.dan.reed.Reed.class, com.dan.ocean.Ocean.class}) {
            var cs = c.getProtectionDomain().getCodeSource();
            String where = cs == null || cs.getLocation() == null ? "" : cs.getLocation().toString();
            if (where.endsWith("FStyle.jar")) shadow.append(' ').append(c.getSimpleName());
        }
        check(shadow.length() == 0, shadow.length() == 0 ? "Packages kommen aus dem eigenen Build, nicht aus FStyle.jar"
                : "aus FStyle.jar statt aus dem Build:" + shadow + " – build/classes muss im Klassenpfad vor FStyle.jar stehen");
        String[] gone = {"timber", "smoke", "hearth", "herd", "longship", "road", "muster"};
        int m = 0;
        for (String g : gone) if (!new File(base, g).exists() && new File("_alt/packages/" + g).isDirectory()) m++;
        check(m == gone.length, m + " von 7 Packages nach _alt/packages abgestellt (F6 A)");
        if (new File("db").isDirectory()) check(!new File("db/Object_nach_Schema.sql").exists() && !new File("db/TableFormat.sql").exists() && new File("db/USER.sql").isFile(),
                "db/: nur USER.sql, die beiden fremden Dateien in _alt (F19 A)");
    }

    /** Kein Element-Package kennt die App (die volle Prüfung macht check-packages). */
    static void isolation() throws Exception {
        System.out.println("Isolation");
        File base = new File("src/com/dan");
        if (!base.isDirectory()) { System.out.println("  (Quellordner nicht gefunden, übersprungen)"); return; }
        Pattern p = Pattern.compile("com\\.dan\\.glacier");
        int found = 0, files = 0;
        File[] dirs = base.listFiles(f -> f.isDirectory() && !f.getName().equals("glacier"));
        if (dirs != null) for (File d : dirs) {
            try (Stream<Path> s = Files.walk(d.toPath())) {
                for (Path f : (Iterable<Path>) s.filter(x -> x.toString().endsWith(".java"))::iterator) {
                    files++;
                    if (p.matcher(Files.readString(f, StandardCharsets.UTF_8)).find()) { found++; System.out.println("    " + f); }
                }
            }
        }
        check(found == 0, files + " Dateien in " + (dirs == null ? 0 : dirs.length) + " Packages, keine nennt com.dan.glacier");
    }

    static double hourOf(double epochMs) {
        var z = Instant.ofEpochMilli((long) epochMs).atZone(SceneClock.ZONE);
        return z.getHour() + z.getMinute() / 60.0 + z.getSecond() / 3600.0;
    }

    static String hm(double h) { return String.format("%02d:%02d", (int) h, (int) Math.round((h - (int) h) * 60) % 60); }

    private Pruefung() { }
}
