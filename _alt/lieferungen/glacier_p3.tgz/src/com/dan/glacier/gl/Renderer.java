package com.dan.glacier.gl;

import com.dan.cloud.Clouds;
import com.dan.cloud.Noise;
import com.dan.cloud.gl.CloudGl;
import com.dan.fog.Fog;
import com.dan.fog.gl.FogGl;
import com.dan.glacier.camera.Camera;
import com.dan.forest.ForestField;
import com.dan.forest.gl.ForestGl;
import com.dan.glacier.scene.Bodendecke;
import com.dan.glacier.scene.Physik;
import com.dan.glacier.scene.SceneClock;
import com.dan.glacier.scene.Site;
import com.dan.glacier.scene.Sun;
import com.dan.glacier.scene.Terrain;
import com.dan.glacier.scene.Vegetation;
import com.dan.glacier.wiring.Wiring;
import com.dan.ground.Biome;
import com.dan.ground.Meadow;
import com.dan.ground.gl.GroundGl;
import com.dan.ocean.Ocean;
import com.dan.ocean.gl.OceanGl;
import com.dan.reed.Reed;
import com.dan.reed.gl.ReedGl;
import com.dan.lightning.Bolt;
import com.dan.lightning.Lightning;
import com.dan.lightning.gl.LightningGl;
import com.dan.rain.Rain;
import com.dan.rain.gl.RainGl;
import com.dan.sky.Sky;
import com.dan.sky.gl.SkyGl;
import com.jogamp.common.nio.Buffers;
import com.jogamp.opengl.GL;
import com.jogamp.opengl.GL4;
import com.jogamp.opengl.GLAutoDrawable;
import com.jogamp.opengl.GLEventListener;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.ByteBuffer;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.function.Consumer;

/**
 * Die Engine auf der Grafikkarte, übernommen aus Haithabu und entschlackt (F4 A). Je Bild:
 * <ol>
 * <li>Phase 3: der Himmel aus {@code com.dan.sky} (Streuung, Sonne über Norden, Mond, Sterne des Südhimmels mit den
 * Magellanschen Wolken) in einen HDR-Puffer (RGBA16F, umgekehrte 32F-Tiefe), vorbelichtet mit der Augenanpassung
 * (geglättet über eine Sekunde, wie Haithabu); die Wolken aus {@code com.dan.cloud} mit Lentikularis darüber, dann
 * Himmel und Wolken als kleines Rundumbild für Spiegelung und Himmelslicht. Startet {@code com.dan.sky} nicht, bleibt
 * der Verlauf aus Phase 1.</li>
 * <li>Phase 2: Sonnenschatten der Südbuchen um den Blickpunkt ({@link SunShadow}).</li>
 * <li>Phase 2: das Gelände aus Copernicus GLO-30 ({@link Terrain}, {@link TerrainLod}, {@code terrain.vert/frag}):
 * Fels, Moräne, Steppe, Waldboden und Kronendach, Schnee über der Schneegrenze, die Zunge als weiße Fläche, der
 * Seegrund; außerhalb des Rasters ein Rahmen aus Bergen.</li>
 * <li>Phase 2: Wald aus {@code com.dan.forest} (Lenga, Ñire, Guindo), Bodendecke aus {@code com.dan.ground} (nur zu
 * Fuß), der See aus {@code com.dan.ocean} (Preset „Lago“, das Gelände als Grund, Türkis vom Gletschermehl),
 * Steppengras und Ufergras aus {@code com.dan.reed}; alle im Licht von Sonne, Mond und Himmel, mit Wolkenschatten.</li>
 * <li>Phase 3: Regen ({@code com.dan.rain}), Seenebel ({@code com.dan.fog}), das Leuchten der Blitze
 * ({@code com.dan.lightning}) bis zur Szenentiefe.</li>
 * <li>Nachbearbeitung: Filmkurve, Gamma, Stäbchensehen in der Nacht; dann das HUD.</li>
 * </ol>
 * Geblieben aus Haithabu: Qualitätsstufen mit Auflösungsregelung, Zeitmessung jedes Durchgangs auf der Grafikkarte
 * (Zeitstempel, ein Bild versetzt gelesen), Compute-Test beim Start, HUD kurz/voll/aus, Foto (F12), Shader neu laden
 * (F5), Standbilder ohne Fenster ({@code tools.Tempo}). Neu: der Faden der Physik ({@link Physik}) mit festem Schritt
 * (F21 A); der Bildlauf gibt ihm nur die Zeit. Im Bildlauf werden keine Dateien gelesen.
 * <p>
 * Abgestellt gegenüber Haithabu (kommt mit der jeweiligen Phase wieder): Anpassung an helle Bildteile in der Nacht,
 * Bildfolgen, Regiebücher, Klang. Ohne Höhendaten zeichnet dasselbe Gelände die Bühne von Phase 1 ({@link Terrain#flat}).
 */
public final class Renderer implements GLEventListener {
    public static final int MIN_MAJOR = 4, MIN_MINOR = 3;
    public static final String VERSION = "Phase 3";
    /** Die Phase, die dieser Stand erfüllt (für Ansichten und HUD). */
    public static final int PHASE = 3;
    static final String[] PASSES = {"Himmel", "Wolken", "Schatten", "Gelände", "Wald", "Boden", "See", "Halme", "Regen", "Nebel", "Blitz",
            "Nachbearbeitung", "HUD"};
    private static final int MARKS = PASSES.length + 1;

    public final SceneClock clock;
    public final Wiring wiring;
    public final Camera camera = new Camera();
    /** Der Faden der Physik (Phase 1 ohne Aufgaben). */
    public final Physik physik = new Physik();
    /** Phase 2: das Gelände (aus daten/gelaende) und was darauf wächst. */
    public final Terrain terrain;
    public final Vegetation vegetation;
    private final TerrainLod lod = new TerrainLod();
    private int coverTex, panoTex, panoFbo;
    static final int PANO_W = 256, PANO_H = 128;
    /** Phase 2: der See (Preset „Lago“; die Verdrahtung gibt Wind und Spiegel). */
    public final Ocean ocean = Ocean.lago(4);
    private final OceanGl oceanGl = new OceanGl();
    private volatile boolean oceanOk;
    private volatile String oceanCheck = "";
    /** Phase 2: Steppengras und Ufergras. */
    public final Reed reed = Reed.beaufort(4);
    private final ReedGl reedGl = new ReedGl();
    private volatile boolean reedOk;
    /** Phase 2: Wald aus Lenga, Ñire, Guindo, mit Sonnenschatten. */
    public final ForestField forest;
    private final ForestGl forestGl;
    private volatile boolean forestOk;
    private final SunShadow sunShadow = new SunShadow();
    /** Phase 2: Bodendecke um das Auge (Biom Patagonien). */
    public final Meadow meadow;
    private final GroundGl groundGl = new GroundGl();
    private volatile boolean groundOk;
    public volatile boolean showWater = true, showReed = true, showForest = true, showSunShadow = true, showGround = true;

    /** Phase 3: der Himmel (Kern ohne Grafikkarte; die Uhr gibt Zeit und Ort, die Kamera die Augenhöhe). */
    public final Sky sky = new Sky();
    private final SkyGl skyGl = new SkyGl();
    private volatile boolean skyOk;
    private volatile String skyCheck = "";
    /** Sternbildfiguren (Kreuz des Südens, Zentaur …) einblenden. */
    public volatile boolean showFigures;
    /** Augenanpassung: geglättete Leuchtdichte, Leuchtdichte im Blickfeld, Zeit bis zur nächsten Messung. */
    private double adaptLum = -1, viewLum = -1, viewTimer;
    /** Anteil der Anpassung (1 = volle, 0 = keine); 0,85 lässt die Nacht Nacht bleiben (wie Haithabu). */
    public volatile double adaptation = 0.85;
    /** Phase 3: die Wolken (Bedeckung, Art, Wind in Wolkenhöhe und Lentikularis aus der Verdrahtung). */
    public final Clouds clouds = new Clouds();
    private final CloudGl cloudGl = new CloudGl();
    private volatile boolean cloudsOk;
    private volatile String cloudCheck = "";
    private double cloudShade = 1;
    public volatile boolean showClouds = true;
    /** Phase 3: Regen. */
    public final Rain rain = new Rain();
    private final RainGl rainGl = new RainGl();
    private volatile boolean rainOk;
    private volatile String rainCheck = "";
    public volatile boolean showRain = true;
    /** Deckkraft des Regens 0..2 (Bedienfeld). */
    public volatile double rainStrength = 1;
    /** Phase 3: Seenebel über dem Lago Argentino. */
    public final Fog fog = new Fog();
    private final FogGl fogGl = new FogGl();
    private volatile boolean fogOk;
    private volatile String fogCheck = "";
    public volatile boolean showFog = true;
    /** Phase 3: Gewitter (in Patagonien selten). */
    public final Lightning lightning = new Lightning();
    private final LightningGl lightningGl = new LightningGl();
    private volatile boolean lightningOk;
    private volatile String lightningCheck = "";
    private Lightning.Snapshot lightningSnap;
    public volatile boolean showLightning = true;
    /** Wie weit die Belichtung im Blitz nachgibt (1 = gar nicht); erholt sich in einer Viertelsekunde. */
    private double flashGive = 1;
    private double[] lightningSeenFrom;
    private volatile String lastBoltText = "";
    private double weatherCpuMs;
    private int depthCopyTex, depthCopyFbo, depthCopyW, depthCopyH;

    private volatile Quality quality = Quality.MITTEL;
    public volatile double renderScale = quality.renderScale;
    /**
     * Regelt die Auflösung nach der Zeit der Grafikkarte: über dem Budget von {@link #targetFps} sinkt sie in Schritten
     * bis {@link #MIN_SCALE}, mit Luft steigt sie wieder bis zur Stufe (aus Haithabu).
     */
    public volatile boolean autoScale = true;
    public volatile double targetFps = 60;
    public static final double MIN_SCALE = 0.5;
    private long scaleNanos;
    private int scaleSteps;

    public volatile boolean showHud = true, hudFull;
    /** Marken im Gelände: Raster von 1 km. */
    public volatile boolean showMarks = true;
    /** Szene anhalten (Uhr, Kamera, Physik). */
    public volatile boolean frozen;
    /** Belichtung in Blendenstufen von Hand dazu. */
    public volatile double exposureBias;
    public volatile boolean photoRequest;
    /** Das nächste fertige Fensterbild an diesen Empfänger (einmal; im GL-Faden). */
    public volatile Consumer<BufferedImage> grabRequest;
    /** Ordner für Fotos (F12); ohne Angabe {@code docs/status} im Arbeitsverzeichnis. */
    public volatile File photoDir;

    private final Shader skyShader = new Shader("Himmel", null, "fullscreen.vert", "sky.frag"),
            skyPano = new Shader("Himmelspanorama", null, "fullscreen.vert", "skypano.frag"),
            terrainShader = new Shader("Gelände", null, "terrain.vert", "terrain.frag"),
            post = new Shader("Nachbearbeitung", null, "fullscreen.vert", "post.frag"),
            overlay = new Shader("Überlagerung", null, "fullscreen.vert", "overlay.frag");
    private final Shader[] all = {skyShader, skyPano, terrainShader, post, overlay};
    private final HudOverlay hud = new HudOverlay();
    private int emptyVao, hdrTex, depthTex, hdrFbo, hdrW, hdrH, surfW = 1, surfH = 1, defaultFbo;
    private boolean reversedZ, ready;
    private final int[][] stamp = new int[2][MARKS];
    private final double[] passMs = new double[MARKS - 1];
    private int frame;
    private long lastNanos, statsNanos;
    private int statsFrames;
    private double fps, gpuMs, cpuMs, worstMs;
    private volatile String glInfo = "", error;
    private volatile ComputeProbe.Result compute;
    private volatile boolean reloadShaders;
    private Consumer<String> statusListener = s -> { };
    private Consumer<String> errorListener = s -> { };
    private volatile String photoMsg = "";
    private volatile long photoMsgUntil;

    public Renderer(SceneClock clock, Wiring wiring) { this(clock, wiring, Terrain.load(Terrain.defaultDir())); }

    public Renderer(SceneClock clock, Wiring wiring, Terrain terrain) {
        this.clock = clock;
        this.wiring = wiring;
        this.terrain = terrain;
        com.dan.glacier.camera.Ansichten.use(terrain);
        this.vegetation = new Vegetation(terrain);
        this.forestGl = new ForestGl(Vegetation.species(), 4, 2026);
        this.forest = new ForestField(3, 4, vegetation, (x, z) -> (float) terrain.height(x, z), 2026);
        forest.setHeights(forestGl.heights());
        this.meadow = new Meadow(Biome.patagonia(), new Bodendecke(terrain, vegetation));
        meadow.radius = 24;
        meadow.near = 6.5f;
        meadow.seed = 2026;
        ocean.seed = 2026;
        sky.latDeg = Site.LAT;
        sky.lonDeg = Site.LON;
        sky.epochMillis = clock.epochMillis();
        fog.seed = 2026;
        lightning.seed = 2026;
        // das Rauschen der Wolken (8 MB, 0,5 bis 3 s) schon jetzt im Hintergrund rechnen
        Thread nt = new Thread(() -> { Noise.base(); Noise.detail(); Noise.weather(); }, "cloud-noise");
        nt.setDaemon(true);
        nt.start();
        setQuality(quality);
        if (wiring != null) {
            wiring.terrain = terrain;
            wiring.feed(ocean);
            wiring.feed(sky, Site.LAKE_LEVEL_ASL + 10);
        }
        camera.groundLevel = terrain.height(camera.eye[0], camera.eye[2]);
        camera.snap();
    }

    public Renderer() { this(new SceneClock(), null, Terrain.flat()); }

    // ------------------------------------------------------------------ Zugriff
    public void setStatusListener(Consumer<String> l) { statusListener = l; }
    public void setErrorListener(Consumer<String> l) { errorListener = l; }
    public String glInfo() { return glInfo; }
    public String error() { return error; }
    public double fps() { return fps; }
    public double gpuMs() { return gpuMs; }
    public double cpuMs() { return cpuMs; }
    public boolean reversedDepth() { return reversedZ; }
    public ComputeProbe.Result compute() { return compute; }
    public Quality quality() { return quality; }
    public void requestShaderReload() { reloadShaders = true; }
    public double[] lastPassTimes() { return passMs.clone(); }
    public long frames() { return frame; }
    public double takeWorstFrameMs() { double w = worstMs; worstMs = 0; return w; }

    /** Die Programme der App (für die Prüfung). */
    public static String[][] shaderFiles() {
        return new String[][]{{"fullscreen.vert", "sky.frag"}, {"fullscreen.vert", "skypano.frag"}, {"terrain.vert", "terrain.frag"},
                {"fullscreen.vert", "post.frag"}, {"fullscreen.vert", "overlay.frag"}, {"probe.comp"}};
    }

    public void setQuality(Quality q) {
        quality = q;
        renderScale = q.renderScale;
        lod.lodRange = q.terrainRange;
        ocean.quality = q.ocean;
        reed.quality = q.reed;
        if (forest != null) forest.apply(q.forest);
        sunShadow.half = q.shadowHalf;
        if (meadow != null) meadow.radius = (float) q.groundRadius;
        clouds.quality = q.clouds;
        rain.quality = q.rain;
        fog.quality = q.fog;
        lightning.quality = q.lightning;
    }

    public TerrainLod lod() { return lod; }
    public boolean oceanRunning() { return oceanOk; }
    public String oceanCheck() { return oceanCheck; }
    public boolean forestReady() { return forestOk && forestGl.ready(); }
    public String forestInfo() { return forestOk ? forestGl.info() : "Wald: nicht gestartet"; }
    public String reedInfo() { return reedOk ? reedGl.info() : "Halme: nicht gestartet"; }

    /** Tag im Jahr (1..365) an der Front. */
    public int dayOfYear() { return clock.date().getDayOfYear(); }

    /**
     * Belichtung. Mit {@code com.dan.sky}: aus der geglätteten Anpassungsleuchtdichte mit nur teilweiser Anpassung
     * ({@link #adaptation}); im Blitz gibt sie kurz nach. Ohne: aus der Helligkeitstabelle von Phase 1.
     */
    public double exposure() {
        if (skyOk && adaptLum > 0) return Sky.State.exposureFor(adaptLum, adaptation) * Math.pow(2, exposureBias) / flashGive;
        double b = Sun.skyBrightness(clock.sun()[0]);
        return 0.6 * Math.pow(b, -0.85) * Math.pow(2, exposureBias);
    }

    public boolean skyRunning() { return skyOk; }
    public boolean cloudsRunning() { return cloudsOk; }
    public boolean rainRunning() { return rainOk; }
    public boolean fogRunning() { return fogOk; }
    public boolean lightningRunning() { return lightningOk; }
    public double cloudShade() { return cloudShade; }
    public String skyCheck() { return skyCheck; }
    public String cloudCheck() { return cloudCheck; }
    public String lastBolt() { return lastBoltText; }

    /** Der aktuelle Himmelszustand (nie null nach dem ersten Schritt). */
    public Sky.State skyState() {
        Sky.State st = sky.state();
        return st != null ? st : sky.update();
    }

    /** Augenanpassung neu (nach Sprüngen der Uhr oder der Kamera). */
    public void readapt() {
        viewLum = -1;
        adaptLum = -1;
        adapt(skyState(), 1);
    }

    /** Senkrechter Bildwinkel in Grad. */
    public double fovy() { return Camera.FOVY; }

    // ------------------------------------------------------------------ Lebenslauf

    @Override
    public void init(GLAutoDrawable d) {
        GL4 gl = d.getGL().getGL4();
        int major = d.getContext().getGLVersionNumber().getMajor(), minor = d.getContext().getGLVersionNumber().getMinor();
        String renderer = gl.glGetString(GL.GL_RENDERER), vendor = gl.glGetString(GL.GL_VENDOR), version = gl.glGetString(GL.GL_VERSION);
        glInfo = renderer + " · OpenGL " + major + "." + minor;
        System.out.println("Glacier: " + vendor + " · " + renderer + " · " + version);
        if (major < MIN_MAJOR || (major == MIN_MAJOR && minor < MIN_MINOR)) {
            fail("Die Grafikkarte meldet OpenGL " + major + "." + minor + " (" + renderer + ", Treiber " + version
                    + "). Glacier braucht OpenGL " + MIN_MAJOR + "." + MIN_MINOR + ".\nBitte den Grafiktreiber aktualisieren.");
            return;
        }
        gl.setSwapInterval(1);
        defaultFbo = d.getContext().getDefaultDrawFramebuffer();
        reversedZ = (major > 4 || minor >= 5) || gl.isExtensionAvailable("GL_ARB_clip_control");
        if (reversedZ) gl.glClipControl(GL4.GL_LOWER_LEFT, GL4.GL_ZERO_TO_ONE);
        try {
            for (Shader s : all) s.build(gl);
        } catch (RuntimeException e) {
            fail(e.getMessage());
            return;
        }
        int[] v = new int[1];
        gl.glGenVertexArrays(1, v, 0);
        emptyVao = v[0];
        for (int[] s : stamp) gl.glGenQueries(MARKS, s, 0);
        compute = ComputeProbe.run(gl);
        System.out.println("Glacier: " + compute.line());
        // Phase 2: Gelände, Bedeckung, Himmelspanorama, See, Halme, Wald, Bodendecke (jedes für sich; was nicht startet, fehlt)
        lod.upload(gl, terrain);
        coverTex = coverTexture(gl, vegetation);
        panoTex = Gpu.texture(gl, PANO_W, PANO_H, GL.GL_RGBA16F, false);
        gl.glBindTexture(GL.GL_TEXTURE_2D, panoTex);
        gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_S, GL.GL_REPEAT);
        gl.glBindTexture(GL.GL_TEXTURE_2D, 0);
        panoFbo = Gpu.fbo(gl, panoTex, 0);
        System.out.println("Glacier: Gelände " + terrain.describe());
        System.out.println("Glacier: " + vegetation.describe());
        if (compute.ok()) {
            try {
                oceanGl.init(gl);
                oceanOk = true;
                System.out.println("Glacier: See " + oceanGl.info());
            } catch (RuntimeException e) {
                System.err.println("Glacier: See nicht verfügbar: " + e.getMessage());
                errorListener.accept("Der See (com.dan.ocean) lässt sich nicht starten.\n" + e.getMessage());
            }
        }
        try {
            reedGl.init(gl);
            reedOk = true;
        } catch (RuntimeException e) {
            System.err.println("Glacier: Halme nicht verfügbar: " + e.getMessage());
            errorListener.accept("Steppe und Gras (com.dan.reed) lassen sich nicht starten.\n" + e.getMessage());
        }
        try {
            forestGl.init(gl);
            forestGl.setSeason(Wiring.northernDay(dayOfYear()), 0);
            sunShadow.ensure(gl, quality.shadowSize);
            forestOk = true;
        } catch (RuntimeException e) {
            System.err.println("Glacier: Wald nicht verfügbar: " + e.getMessage());
            errorListener.accept("Der Wald (com.dan.forest) lässt sich nicht starten.\n" + e.getMessage());
        }
        try {
            groundGl.init(gl);
            groundOk = true;
        } catch (RuntimeException e) {
            System.err.println("Glacier: Bodendecke nicht verfügbar: " + e.getMessage());
            errorListener.accept("Die Bodendecke (com.dan.ground) lässt sich nicht starten.\n" + e.getMessage());
        }
        // Phase 3: Himmel, Wolken, Regen, Nebel, Blitz (jedes für sich; was nicht startet, fehlt, der Rest läuft)
        try {
            skyGl.init(gl);
            skyOk = true;
            System.out.println("Glacier: Himmel " + skyGl.info());
        } catch (RuntimeException e) {
            System.err.println("Glacier: Himmel nicht verfügbar, Verlauf aus Phase 1: " + e.getMessage());
            errorListener.accept("Der Himmel (com.dan.sky) lässt sich nicht starten, es bleibt ein einfacher Verlauf.\n" + e.getMessage());
        }
        if (skyOk) {
            try {
                cloudGl.init(gl);
                cloudsOk = true;
                if (wiring != null) wiring.cloudsDrawn = true;
                System.out.println("Glacier: Wolken " + cloudGl.info());
            } catch (RuntimeException e) {
                System.err.println("Glacier: Wolken nicht verfügbar: " + e.getMessage());
                errorListener.accept("Die Wolken (com.dan.cloud) lassen sich nicht starten, es bleibt der Schleier des Himmels.\n" + e.getMessage());
            }
        }
        try {
            rainGl.init(gl);
            rainOk = true;
        } catch (RuntimeException e) {
            System.err.println("Glacier: Regen nicht verfügbar: " + e.getMessage());
            errorListener.accept("Der Regen (com.dan.rain) lässt sich nicht starten.\n" + e.getMessage());
        }
        try {
            fogGl.init(gl);
            fogOk = true;
        } catch (RuntimeException e) {
            System.err.println("Glacier: Nebel nicht verfügbar: " + e.getMessage());
            errorListener.accept("Der Nebel (com.dan.fog) lässt sich nicht starten.\n" + e.getMessage());
        }
        try {
            lightningGl.init(gl);
            lightningOk = true;
        } catch (RuntimeException e) {
            System.err.println("Glacier: Gewitter nicht verfügbar: " + e.getMessage());
            errorListener.accept("Das Gewitter (com.dan.lightning) lässt sich nicht starten.\n" + e.getMessage());
        }
        physik.start();
        lastNanos = System.nanoTime();
        statsNanos = lastNanos;
        camera.snap();
        ready = true;
    }

    @Override
    public void reshape(GLAutoDrawable d, int x, int y, int w, int h) {
        surfW = Math.max(1, d.getSurfaceWidth());
        surfH = Math.max(1, d.getSurfaceHeight());
    }

    /** Uhr, Physik und Kamera um dt weiterrechnen (vom Bildlauf aufgerufen; Standbilder rufen es mit festem dt). */
    public void step(double dt) {
        clock.step(dt);
        physik.advance(dt);
        long t0 = System.nanoTime();
        double level = wiring != null ? wiring.waterLevel.level() : 0;
        // Phase 3: zuerst die Wetterregie, dann bekommen alle Packages ihre Eingänge
        if (wiring != null) {
            if (wiring.regie) wiring.feedWeather(dt);
            wiring.feed(ocean);
            wiring.feed(reed, dayOfYear());
            wiring.feed(sky, camera.eye[1] - level + Site.LAKE_LEVEL_ASL);
            wiring.feed(clouds);
        } else {
            sky.epochMillis = clock.epochMillis();
        }
        sky.figures = showFigures;
        Sky.State st = sky.step(dt);
        clouds.step(dt);
        // Wolkenschatten am Auge (für Halme, Nebel, Regen; Gelände und See lesen die Schattenkarte)
        cloudShade = cloudsOk && showClouds ? Clouds.shadow(clouds.snapshot(), camera.eye[0], camera.eye[2], keyDir(st)) : 1;
        adapt(st, dt);
        if (wiring != null) {
            wiring.feed(rain, clouds, clouds.snapshot(), cloudsOk && showClouds, camera.eye.clone());
            wiring.feed(fog, st.sunAlt);
            wiring.feed(lightning, clouds.snapshot(), cloudsOk && showClouds, camera.eye);
        }
        if (!showRain) rain.rate = 0;
        rain.step(dt);
        fog.step(dt);
        stepLightning(dt);
        weatherCpuMs = weatherCpuMs * 0.95 + (System.nanoTime() - t0) / 1e6 * 0.05;
        ocean.step(dt);
        camera.groundLevel = terrain.height(camera.eye[0], camera.eye[2]);
        camera.targetGround = terrain.height(camera.tx, camera.tz);
        camera.waterLevel = ocean.waterLevel;
        camera.step(dt);
    }

    @Override
    public void display(GLAutoDrawable d) {
        GL4 gl = d.getGL().getGL4();
        if (!ready) {
            gl.glClearColor(0.04f, 0.07f, 0.10f, 1);
            gl.glClear(GL.GL_COLOR_BUFFER_BIT);
            return;
        }
        if (reloadShaders) {
            reloadShaders = false;
            try {
                for (Shader s : all) s.build(gl);
                System.out.println("Shader neu geladen.");
            } catch (RuntimeException e) {
                System.err.println(e.getMessage());
                errorListener.accept(e.getMessage());
            }
        }
        defaultFbo = d.getContext().getDefaultDrawFramebuffer();
        readMarks(gl);
        long now = System.nanoTime();
        double rawMs = (now - lastNanos) / 1e6;
        if (frame > 2 && rawMs > worstMs) worstMs = rawMs;
        double dt = Math.min(0.1, (now - lastNanos) / 1e9);
        lastNanos = now;
        if (!frozen) step(dt);

        surfW = Math.max(1, d.getSurfaceWidth());
        surfH = Math.max(1, d.getSurfaceHeight());
        regulateScale(now);
        int w = Math.max(64, (int) Math.round(surfW * renderScale)), h = Math.max(64, (int) Math.round(surfH * renderScale));
        if (w != hdrW || h != hdrH) resizeTargets(gl, w, h);
        renderFrame(gl, w, h);
        if (photoRequest) { photoRequest = false; takePhoto(gl, surfW, surfH); }
        Consumer<BufferedImage> gr = grabRequest;
        if (gr != null) { grabRequest = null; try { gr.accept(readDefault(gl, surfW, surfH)); } catch (RuntimeException e) { System.err.println("Glacier: Bild nicht abgeholt: " + e); } }
        cpuMs = cpuMs * 0.95 + (System.nanoTime() - now) / 1e6 * 0.05;
        frame++;
        stats(now, w, h);
    }

    /** Ein ganzes Bild in Rechengröße w × h, dann ins Fenster. Bei stehender Szene ({@link #frozen}) malt das HUD gleich. */
    void renderFrame(GL4 gl, int w, int h) {
        mark(gl, 0);
        Sky.State st = skyState();
        if (adaptLum <= 0) adapt(st, 1);
        double pre = skyOk ? exposure() : 1;
        double[] sp = clock.sun();
        double[] sun = skyOk ? st.sunDir : Sun.direction(sp[0], sp[1]);
        float[] proj = Mat4.perspective(fovy(), w / (double) h, NEAR, FAR, reversedZ);
        float[] vp = Mat4.mul(proj, camera.view());
        float[] inv = Mat4.invert(vp);
        double level = wiring != null ? wiring.waterLevel.level() : 0;

        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        gl.glClearColor(0, 0, 0, 1);
        gl.glClearDepth(reversedZ ? 0 : 1);
        gl.glDepthMask(true);
        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
        gl.glBindVertexArray(emptyVao);

        // 1 Himmel: com.dan.sky (Streuung, Sonne über Norden, Mond, Südhimmel), sonst der Verlauf aus Phase 1
        gl.glDisable(GL.GL_DEPTH_TEST);
        gl.glDisable(GL.GL_CULL_FACE);
        if (skyOk) {
            skyGl.update(gl, st);
            gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
            gl.glViewport(0, 0, w, h);
            SkyGl.View sv = new SkyGl.View();
            sv.viewProj = vp;
            sv.invViewProj = inv;
            sv.reversedZ = reversedZ;
            sv.width = w;
            sv.height = h;
            sv.fovyDeg = fovy();
            sv.preExposure = pre;
            sv.time = clock.t();
            skyGl.draw(gl, st, sv);
            if (skyCheck.isEmpty() && frame > 30) skyCheck = skyGl.selfCheck(gl, st);
            gl.glBindVertexArray(emptyVao);
        } else {
            common(gl, skyShader, vp, inv, sun, level);
            gl.glDrawArrays(GL.GL_TRIANGLES, 0, 3);
        }
        mark(gl, 1);

        // Blitze übernehmen (neue Kanäle hochladen, Lichtpunkte für Wolken, See, Gelände)
        if (lightningOk) {
            lightningSnap = lightning.snapshot();
            lightningGl.update(gl, lightningSnap);
        }
        boolean flashNow = lightningOk && showLightning && lightningGl.active();
        double[] air = lightningAir();

        // 2 Wolken (mit Lentikularis) über den Himmel, Kanäle der Blitze, dann das Rundumbild (Spiegelung, Himmelslicht)
        boolean cloudsNow = cloudsOk && showClouds;
        Clouds.Snapshot cs = clouds.snapshot();
        CloudGl.Light cl = cloudsNow ? cloudLight(st, pre) : null;
        if (cloudsNow) {
            cloudGl.update(gl, cs, cl, camera.eye.clone());
            gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
            gl.glViewport(0, 0, w, h);
            CloudGl.View cv = new CloudGl.View();
            cv.viewProj = vp;
            cv.invViewProj = inv;
            cv.eye = camera.eye.clone();
            cv.reversedZ = reversedZ;
            cv.width = w;
            cv.height = h;
            cloudGl.draw(gl, cs, cl, cv);
            if (cloudCheck.isEmpty() && frame > 40) cloudCheck = cloudGl.selfCheck(gl, cs, cl);
            gl.glBindVertexArray(emptyVao);
        }
        if (flashNow) {
            lightningGl.drawChannels(gl, lightningView(vp, inv, w, h, pre, air));
            gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
            gl.glViewport(0, 0, w, h);
            gl.glBindVertexArray(emptyVao);
        }
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, panoFbo);
        gl.glViewport(0, 0, PANO_W, PANO_H);
        if (skyOk) {
            skyGl.drawPanorama(gl, st, pre);
            if (cloudsNow) cloudGl.drawPanorama(gl, cs, cl, camera.eye.clone());
            if (flashNow) lightningGl.drawPanorama(gl, PANO_W, PANO_H, camera.eye.clone(), pre, air[0], air[1], cloudsNow ? clouds.type.base : lightning.cloudBase);
            gl.glBindVertexArray(emptyVao);
        } else {
            common(gl, skyPano, vp, inv, sun, level);
            gl.glDrawArrays(GL.GL_TRIANGLES, 0, 3);
        }
        if (rainOk) {
            rainGl.update(gl, rain.snapshot());
            if (rainCheck.isEmpty() && rain.rate > 0 && frame > 60) rainCheck = rainGl.selfCheck(gl, rain.snapshot());
        }
        if (flashNow && lightningCheck.isEmpty()) {
            for (Bolt b : lightningSnap.bolts())
                if (b.kind == Bolt.Kind.CLOUD_GROUND && lightningSnap.time() > b.t0 + b.leaderTime) {
                    lightningCheck = lightningGl.selfCheck(gl, lightningSnap);
                    lightningGl.update(gl, lightningSnap);
                    break;
                }
        }
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        mark(gl, 2);

        // 3 Wald: Bäume für das Bild wählen, Instanzen hochladen, Sonnenschatten der Bäume um den Blickpunkt
        double[] to = wiring != null ? wiring.wind.toVector() : new double[]{1, 0, 0};
        double windSpeed = wiring != null ? (wiring.regie ? wiring.gustNow : wiring.wind.speed()) : 6.7;
        boolean forestNow = forestOk && showForest;
        sunShadow.matrix = null;
        if (forestNow) {
            forestGl.setSeason(Wiring.northernDay(dayOfYear()), 0);
            forestGl.setWind(to[0], to[2], windSpeed, wiring != null ? wiring.wind.gustiness() : 0.3);
            forest.update(camera.eye, vp, 24);
            forestGl.update(gl, forest);
        }
        boolean forestReady = forestNow && forestGl.ready();
        if (showSunShadow && sun[1] > 0.03 && forestReady) {
            sunShadow.ensure(gl, quality.shadowSize);
            double[] c = shadowCenter();
            sunShadow.matrix = sunShadow.fit(sun, c[0], c[1], c[2]);
            sunShadow.begin(gl, reversedZ);
            forestGl.drawShadow(gl, sunShadow.matrix, clock.t(), 3);
            sunShadow.end(gl, reversedZ);
            gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
            gl.glViewport(0, 0, w, h);
        }
        mark(gl, 3);

        // 4 Gelände (Wolkenschatten aus der Karte, Mond, Blitzlicht; ohne com.dan.sky der Verlauf aus Phase 2)
        double[] sl = sunLight(sp[0]), zen = skyZenith(sp[0]), hor = skyHorizon(sp[0]);
        double[][] L = ambientLight(st, pre);
        double[][] fla = flashLight(skyOk ? pre : 1);
        double wet = Math.min(1, rain.rate * (showRain ? 1 : 0) / 3);
        gl.glDepthMask(true);
        gl.glDisable(GL.GL_BLEND);
        gl.glEnable(GL.GL_DEPTH_TEST);
        gl.glDepthFunc(reversedZ ? GL.GL_GREATER : GL.GL_LESS);
        common(gl, terrainShader, vp, inv, sun, level);
        lod.bind(gl, terrainShader);
        gl.glActiveTexture(GL.GL_TEXTURE10);
        gl.glBindTexture(GL.GL_TEXTURE_2D, coverTex);
        gl.glActiveTexture(GL.GL_TEXTURE12);
        gl.glBindTexture(GL.GL_TEXTURE_2D, cloudsNow ? cloudGl.shadowTexture() : 0);
        gl.glActiveTexture(GL.GL_TEXTURE13);
        gl.glBindTexture(GL.GL_TEXTURE_2D, sunShadow.matrix != null ? sunShadow.tex : 0);
        gl.glActiveTexture(GL.GL_TEXTURE0);
        terrainShader.set(gl, "uCover", 10);
        terrainShader.set(gl, "uCoverRect", (float) Terrain.X0, (float) Terrain.Z0, (float) (Terrain.N * Terrain.CELL), 1f);
        terrainShader.set(gl, "uWood", (float) (forest.radius * forest.thinFrom), (float) forest.radius, forestReady ? 1f : 0f);
        terrainShader.set(gl, "uSunRgb", sl);
        terrainShader.set(gl, "uSunAmb", zen);
        terrainShader.set(gl, "uSkyHor", hor);
        terrainShader.set(gl, "uSnowLine", (float) SNOW_LINE);
        terrainShader.set(gl, "uMarks", showMarks ? 1 : 0);
        terrainShader.set(gl, "uCloudShadow", 12);
        double[] sr = cloudsNow ? cloudGl.shadowRect() : new double[]{0, 0, 1};
        terrainShader.set(gl, "uCloudRect", (float) sr[0], (float) sr[1], (float) Math.max(1, sr[2]), cloudsNow ? 1f : 0f);
        terrainShader.set(gl, "uFlashDir", fla != null ? fla[0] : new double[]{0, 1, 0});
        terrainShader.set(gl, "uFlashRgb", fla != null ? fla[1] : new double[]{0, 0, 0});
        terrainShader.set(gl, "uWet", (float) wet);
        terrainShader.set(gl, "uSunShadow", 13);
        terrainShader.mat(gl, "uSunShadowM", sunShadow.matrix != null ? sunShadow.matrix : Mat4.identity());
        terrainShader.set(gl, "uSunShadowOn", sunShadow.matrix != null ? 1 : 0);
        lod.draw(gl, terrainShader, camera.eye, vp);
        gl.glBindVertexArray(emptyVao);
        mark(gl, 4);

        // 5 Wald zeichnen (Licht wie die Halme, dazu Sonnen- und Wolkenschatten)
        if (forestReady) {
            ForestGl.View fv = new ForestGl.View();
            fv.viewProj = vp;
            fv.eye = camera.eye.clone();
            fv.reversedZ = reversedZ;
            ForestGl.Light fl = new ForestGl.Light();
            fl.sunDir = sun;
            fl.fogColor = L[3];
            fl.skyColor = L[2];
            fl.wetness = wet;
            if (skyOk) {
                fl.skyTexture = panoTex;
                fl.sunColor = scale(st.sunColor, pre);
                fl.moonDir = st.moonDir;
                fl.moonColor = scale(st.moonColor, pre);
                fl.skyWeight = 1.15;
                fl.fogDistance = fogDistance(st);
                if (cloudsNow) {
                    fl.shadowTexture = cloudGl.shadowTexture();
                    fl.shadowRect = cloudGl.shadowRect();
                }
            } else {
                fl.sunColor = sl;
                fl.skyColor = zen;
                fl.fogColor = hor;
                fl.fogDistance = FOG_DISTANCE;
            }
            if (sunShadow.matrix != null) {
                fl.sunShadowTexture = sunShadow.tex;
                fl.sunShadowMatrix = sunShadow.matrix;
                fl.sunShadowBias = 0.0006;
            }
            forestGl.draw(gl, fv, fl, clock.t());
            gl.glBindVertexArray(emptyVao);
        }
        mark(gl, 5);

        // 6 Bodendecke um das Auge (nur zu Fuß)
        boolean groundNow = groundOk && showGround && camera.eye[1] - terrain.height(camera.eye[0], camera.eye[2]) < 25;
        if (groundOk) {
            meadow.setSeason(Wiring.northernDay(dayOfYear()), 0);
            meadow.wind.speed = (float) windSpeed;
            meadow.wind.direction = (float) Math.toDegrees(Math.atan2(to[2], to[0]));
            groundGl.update(gl, meadow, (float) (clock.t() % 3600), camera.eye[0], camera.eye[2], !groundNow);
        }
        if (groundNow) {
            GroundGl.View gv = new GroundGl.View();
            gv.viewProj = vp;
            gv.eye = camera.eye.clone();
            gv.reversedZ = reversedZ;
            GroundGl.Light gL = new GroundGl.Light();
            gL.sunDir = sun;
            gL.fogColor = L[3];
            gL.skyColor = L[2];
            if (skyOk) {
                gL.skyTexture = panoTex;
                gL.sunColor = scale(st.sunColor, pre);
                gL.moonDir = st.moonDir;
                gL.moonColor = scale(st.moonColor, pre);
                gL.skyWeight = 1.2;
                gL.fogDistance = fogDistance(st);
                if (cloudsNow) {
                    gL.shadowTexture = cloudGl.shadowTexture();
                    gL.shadowRect = cloudGl.shadowRect();
                }
            } else {
                gL.sunColor = sl;
                gL.skyColor = zen;
                gL.fogColor = hor;
                gL.fogDistance = FOG_DISTANCE;
            }
            if (sunShadow.matrix != null) {
                gL.sunShadowTexture = sunShadow.tex;
                gL.sunShadowMatrix = sunShadow.matrix;
            }
            groundGl.draw(gl, gv, gL);
            gl.glBindVertexArray(emptyVao);
        }
        mark(gl, 6);

        // 7 See: rechnen (Compute), dann zeichnen; das Gelände ist sein Grund, die Wolken werfen Schatten
        if (oceanOk && showWater) {
            oceanGl.update(gl, ocean);
            if (oceanCheck.isEmpty() && frame > 30) oceanCheck = oceanGl.selfCheck(gl, ocean);
            gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
            gl.glViewport(0, 0, w, h);
            OceanGl.View ov = new OceanGl.View();
            ov.viewProj = vp;
            ov.eye = camera.eye.clone();
            ov.reversedZ = reversedZ;
            OceanGl.Light ol = new OceanGl.Light();
            ol.sunDir = sun;
            ol.skyTexture = panoTex;
            if (skyOk) {
                ol.sunColor = scale(st.sunColor, pre);
                ol.moonDir = st.moonDir;
                ol.moonColor = scale(st.moonColor, pre);
                ol.fogDistance = fogDistance(st);
                if (cloudsNow) {
                    ol.shadowTexture = cloudGl.shadowTexture();
                    ol.shadowRect = cloudGl.shadowRect();
                }
            } else {
                ol.sunColor = sl;
                ol.fogDistance = FOG_DISTANCE;
            }
            if (rainOk && showRain && rain.rate > 0) {
                ol.detailTexture = rainGl.rippleTexture();
                ol.detailTile = rainGl.rippleTile();
                ol.detailStrength = rainGl.rippleStrength() * Math.min(1, rainStrength);
                ol.detailRange = 60;
            }
            if (flashNow) {
                int n = lightningGl.lightCount();
                ol.flashCount = n;
                for (int i = 0; i < n; i++) {
                    double[] lp = lightningGl.lightPos(i), lr = lightningGl.lightRgb(i);
                    for (int k = 0; k < 4; k++) ol.flashPos[i * 4 + k] = (float) lp[k];
                    for (int k = 0; k < 3; k++) ol.flashRgb[i * 4 + k] = (float) (lr[k] * (skyOk ? pre : 1));
                }
                ol.pointSigma = air[0];
            }
            ol.waterColor = Ocean.LAGO_WATER;
            ol.sssColor = Ocean.LAGO_SSS;
            ol.bedTexture = lod.heightTex;
            ol.bedRect = new double[]{Terrain.X0, Terrain.Z0, Terrain.N * Terrain.CELL};
            ol.bedScale = Terrain.HMAX - Terrain.HMIN;
            ol.bedOffset = Terrain.HMIN;
            ol.bedTurbidity = 0.35;
            ol.bedColor = new double[]{0.15, 0.15, 0.14};
            gl.glDepthFunc(reversedZ ? GL.GL_GREATER : GL.GL_LESS);
            oceanGl.draw(gl, ocean, ov, ol);
            gl.glBindVertexArray(emptyVao);
        }
        mark(gl, 7);

        // 8 Halme um die Kamera: Steppe und Ufergras
        if (reedOk && showReed) {
            reedGl.update(gl, reed, camera.eye[0], camera.eye[2], vegetation, (x, z) -> terrain.height(x, z));
            ReedGl.View rv = new ReedGl.View();
            rv.viewProj = vp;
            rv.eye = camera.eye.clone();
            rv.reversedZ = reversedZ;
            ReedGl.Light rl = new ReedGl.Light();
            rl.sunDir = sun;
            rl.fogColor = L[3];
            if (skyOk) {
                // Sonne und Mond ohne den Schatten am Auge: jeder Halm liest die Wolkenschatten selbst
                rl.sunColor = scale(st.sunColor, pre);
                rl.moonDir = st.moonDir;
                rl.moonColor = scale(st.moonColor, pre);
                rl.skyColor = L[2];
                rl.skyWeight = 1.3;
                rl.fogDistance = fogDistance(st);
                if (cloudsNow) {
                    rl.shadowTexture = cloudGl.shadowTexture();
                    rl.shadowRect = cloudGl.shadowRect();
                }
            } else {
                rl.sunColor = sl;
                rl.skyColor = zen;
                rl.fogColor = hor;
                rl.fogDistance = FOG_DISTANCE;
            }
            reedGl.draw(gl, reed, rv, rl, clock.t());
            gl.glBindVertexArray(emptyVao);
        }
        mark(gl, 8);

        // 9 Regen über die Szene (Tiefe als Kopie)
        boolean rainNow = rainOk && showRain && rain.rate > 0;
        boolean fogNow = fogOk && showFog && fog.snapshot().any();
        boolean copied = false;
        if (rainNow || fogNow || flashNow) { copyDepth(gl, w, h); copied = true; }
        if (rainNow) drawRain(gl, st, vp, inv, w, h, pre, L);
        mark(gl, 9);

        // 10 Seenebel bis zur Szenentiefe
        if (fogNow) drawFog(gl, st, inv, w, h, L);
        mark(gl, 10);

        // 11 Blitz: das Leuchten der Luft um die Kanäle
        if (flashNow && copied) {
            LightningGl.View lv = lightningView(vp, inv, w, h, pre, air);
            lv.depthTexture = depthCopyTex;
            lightningGl.drawGlow(gl, lv);
            gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
            gl.glViewport(0, 0, w, h);
            gl.glBindVertexArray(emptyVao);
        }
        gl.glDisable(GL.GL_DEPTH_TEST);
        mark(gl, 11);

        // 12 Nachbearbeitung ins Fenster (mit com.dan.sky ist das Bild schon vorbelichtet)
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, defaultFbo);
        gl.glViewport(0, 0, surfW, surfH);
        post.use(gl);
        gl.glActiveTexture(GL.GL_TEXTURE0);
        gl.glBindTexture(GL.GL_TEXTURE_2D, hdrTex);
        post.set(gl, "uHdr", 0);
        post.set(gl, "uExposure", skyOk ? 1f : (float) exposure());
        post.set(gl, "uScotopic", (float) (skyOk ? scotopic(st) : 0));
        gl.glBindVertexArray(emptyVao);
        gl.glDrawArrays(GL.GL_TRIANGLES, 0, 3);
        mark(gl, 12);

        // 13 HUD
        if (showHud) {
            hud.refresh(gl, 250, this::paintHud, frozen);
            hud.draw(gl, overlay, emptyVao, 12, Math.max(0, surfH - hud.height - 12), surfW, surfH);
        }
        gl.glBindVertexArray(0);
        gl.glUseProgram(0);
        mark(gl, 13);
    }

    // ------------------------------------------------------------------ Phase 3: Licht, Auge, Gewitter

    /**
     * Augenanpassung (wie Haithabu): alle 0,2 s die Leuchtdichte im Blickfeld messen (auf dem Prozessor), mit der des
     * ganzen Himmels mitteln und über eine Sekunde glätten (logarithmisch, wie das Auge). Unter Wolken dunkler.
     */
    private void adapt(Sky.State st, double dt) {
        viewTimer -= dt;
        if (viewLum <= 0 || viewTimer <= 0) {
            viewLum = st.viewLuminance(camera.fwd.clone(), new double[]{0, 1, 0}, fovy(), surfW / (double) Math.max(1, surfH));
            viewTimer = 0.2;
        }
        double target = Math.sqrt(Math.max(1e-14, st.adaptation) * Math.max(1e-14, viewLum)) * (cloudsOk && showClouds ? clouds.brightnessFactor() : 1);
        if (adaptLum <= 0 || frozen || dt > 0.5) adaptLum = target;
        else adaptLum = Math.exp(Math.log(adaptLum) + (Math.log(target) - Math.log(adaptLum)) * Math.min(1, dt / 1.0));
    }

    /** Das Gewitter in Szenenzeit weiter, Sichtbarkeit neu nach großen Sprüngen des Auges, Nachgeben der Belichtung. */
    private void stepLightning(double dt) {
        double sceneDt = dt * Math.max(0, clock.lapse);
        int before = lightning.flashes();
        lightning.step(Math.min(sceneDt, 1.0));
        double[] e = camera.eye;
        if (lightningSeenFrom == null || Math.hypot(e[0] - lightningSeenFrom[0], e[2] - lightningSeenFrom[2]) > 300 || Math.abs(e[1] - lightningSeenFrom[1]) > 100) {
            lightning.updateVisibility();
            lightningGl.invalidate();
            lightningSeenFrom = e.clone();
        }
        if (lightning.flashes() != before && !lightning.bolts().isEmpty()) lastBoltText = boltText(lightning.bolts().get(lightning.bolts().size() - 1));
        double base = exposure() * flashGive;
        double lf = showLightning ? lightning.snapshot().flashLuminance(e[0], e[1], e[2], lightning.cloudBase) : 0;
        double give = 1 + base * lf / 1.5;
        flashGive = frozen ? give : Math.max(give, flashGive * Math.exp(-Math.max(0, dt) / 0.25));
    }

    /** „Erdblitz 3,4 km NW, 31 kA“ */
    private String boltText(Bolt b) {
        double[] e = camera.eye;
        double d = Math.hypot(b.hitX - e[0], b.hitZ - e[2]), az = (Math.toDegrees(Math.atan2(b.hitX - e[0], -(b.hitZ - e[2]))) + 360) % 360;
        String[] dirs = {"N", "NO", "O", "SO", "S", "SW", "W", "NW"};
        String kind = switch (b.kind) {
            case CLOUD_GROUND -> "Erdblitz";
            case INTRA_CLOUD -> "Wolkenblitz";
            case SPIDER -> "Spinnenblitz";
            case SHEET -> "Wetterleuchten";
        };
        double ka = 0;
        for (double k : b.strokeKA) ka = Math.max(ka, k);
        return String.format(Locale.GERMAN, "%s %.1f km %s, %.0f kA", kind, d / 1000, dirs[(int) Math.round(az / 45) % 8], ka);
    }

    /** Auslöschung und Streuung der Luft für das Licht der Blitze (Dunst, Regen, Nebel am Auge), 1/m. */
    private double[] lightningAir() {
        double haze = wiring != null ? wiring.hazePerM() : 4e-5;
        double[] e = camera.eye;
        double r = rainOk && showRain ? rain.scatter(e[0], e[1], e[2]) * 3e-3 : 0;
        double f = fogOk && showFog ? fog.density(e[0], e[1], e[2]) : 0;
        return new double[]{haze + r + f, haze * 0.9 + r * 0.98 + f};
    }

    /** Einen Blitz von Hand auslösen (Bedienfeld): Erdblitz in 1,5 bis 4 km in Blickrichtung. */
    public Bolt triggerLightning(Bolt.Kind kind) {
        if (wiring != null) wiring.feed(lightning, clouds.snapshot(), cloudsOk && showClouds, camera.eye);
        double[] e = camera.eye, f = camera.fwd;
        double h = Math.hypot(f[0], f[2]), fx = h > 1e-6 ? f[0] / h : 0, fz = h > 1e-6 ? f[2] / h : -1, r = 1500 + Math.random() * 2500;
        return kind == Bolt.Kind.CLOUD_GROUND ? lightning.strike(e[0] + fx * r, e[2] + fz * r) : lightning.discharge(kind, e[0] + fx * r, e[2] + fz * r);
    }

    static boolean sunIsKey(Sky.State st) { return st.sunAlt > -4; }

    static double[] keyDir(Sky.State st) { return sunIsKey(st) ? st.sunDirTrue : st.moonDirTrue; }

    /** Licht für die Wolken aus dem Himmelszustand, vorbelichtet (wie Haithabu); von unten See, Wald und Eis. */
    CloudGl.Light cloudLight(Sky.State st, double pre) {
        CloudGl.Light l = new CloudGl.Light();
        boolean sun = sunIsKey(st);
        l.dir = keyDir(st);
        for (int i = 0; i < 8; i++) l.colorAt[i] = scale(sun ? st.sunColorAt(CloudGl.LIGHT_HEIGHTS[i]) : st.moonColorAt(CloudGl.LIGHT_HEIGHTS[i]), pre);
        double[] e = st.skyIrradiance;
        l.ambTop = scale(e, pre / Math.PI);
        double s = Math.max(0, st.sunDir[1]), m = Math.max(0, st.moonDir[1]);
        l.ambBot = new double[3];
        for (int c = 0; c < 3; c++) l.ambBot[c] = (e[c] + st.sunColor[c] * s + st.moonColor[c] * m) * 0.15 / Math.PI * pre;
        l.haze = st.groundExtinction;
        l.flash = new double[]{st.flashDir[0] * 5000, st.flashDir[1] * 5000, st.flashDir[2] * 5000, st.flash * pre};
        l.flashCount = 0;
        if (lightningOk && showLightning && lightningGl.active()) {
            int n = lightningGl.cloudLightCount();
            for (int i = 0; i < n; i++) {
                double[] c = lightningGl.cloudLight(i);
                for (int k = 0; k < 3; k++) {
                    l.flashPos[i * 4 + k] = (float) c[k];
                    l.flashRgb[i * 4 + k] = (float) (c[3] * Lightning.CHANNEL_RGB[k] * pre);
                }
            }
            l.flashCount = n;
        }
        return l;
    }

    /** Licht für Wald, Boden, Halme, Nebel und Regen: {Sonne, Mond, Himmel oben, Himmel am Horizont}, vorbelichtet. */
    private double[][] ambientLight(Sky.State st, double pre) {
        if (skyOk) {
            double[] hor = new double[3];
            for (int i = 0; i < 6; i++) {
                double a = Math.PI * i / 3;
                double[] h = st.radiance(norm3(new double[]{Math.sin(a), 0.08, -Math.cos(a)}));
                for (int k = 0; k < 3; k++) hor[k] += h[k] / 6;
            }
            // oben: das Himmelslicht als Bestrahlung/π (der tiefblaue Zenit allein gäbe nur ein Viertel davon)
            return new double[][]{scale(st.sunColor, pre * cloudShade), scale(st.moonColor, pre * cloudShade), scale(st.skyIrradiance, pre / Math.PI), scale(hor, pre)};
        }
        double[] sp = clock.sun();
        return new double[][]{sunLight(sp[0]), {0, 0, 0}, skyZenith(sp[0]), skyHorizon(sp[0])};
    }

    /** Das stärkste Blitzlicht als Richtung und Bestrahlung am Auge (vorbelichtet), oder null. */
    private double[][] flashLight(double pre) {
        if (!lightningOk || !showLightning || !lightningGl.active() || lightningGl.lightCount() == 0) return null;
        double[] e = camera.eye, dir = null;
        double bestL = 0;
        double[] tot = new double[3];
        for (int i = 0; i < lightningGl.lightCount(); i++) {
            double[] p = lightningGl.lightPos(i), c = lightningGl.lightRgb(i);
            double dx = p[0] - e[0], dy = p[1] - e[1], dz = p[2] - e[2], d2 = dx * dx + dy * dy + dz * dz + p[3] * p[3], d = Math.sqrt(dx * dx + dy * dy + dz * dz + 1);
            double el = (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / d2;
            for (int k = 0; k < 3; k++) tot[k] += c[k] / d2 * pre;
            if (el > bestL) { bestL = el; dir = new double[]{dx / d, dy / d, dz / d}; }
        }
        return dir == null ? null : new double[][]{dir, tot};
    }

    /** Dunstlänge für exp(−d/L) aus der Sichtweite (Koschmieder). */
    static double fogDistance(Sky.State st) { return st.visibilityKm * 1000 / 3.912; }

    static double[] scale(double[] v, double k) { return new double[]{v[0] * k, v[1] * k, v[2] * k}; }

    static double[] norm3(double[] v) { double l = Math.max(1e-12, Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])); return new double[]{v[0] / l, v[1] / l, v[2] / l}; }

    private LightningGl.View lightningView(float[] vp, float[] inv, int w, int h, double pre, double[] air) {
        LightningGl.View v = new LightningGl.View();
        v.viewProj = vp;
        v.invViewProj = inv;
        v.eye = camera.eye.clone();
        v.reversedZ = reversedZ;
        v.width = w;
        v.height = h;
        v.fovyDeg = fovy();
        v.targetFbo = hdrFbo;
        v.preExposure = skyOk ? pre : 1;
        v.extinction = air[0];
        v.scatter = air[1];
        v.ceiling = cloudsOk && showClouds ? clouds.type.base : lightning.cloudBase;
        return v;
    }

    /** Die Tiefe der Szene als Kopie (Regen, Nebel und Blitz lesen sie für weiche Ränder und ihre Weglänge). */
    private void copyDepth(GL4 gl, int w, int h) {
        if (depthCopyTex == 0 || depthCopyW != w || depthCopyH != h) {
            Gpu.deleteFbos(gl, depthCopyFbo);
            Gpu.deleteTextures(gl, depthCopyTex);
            depthCopyTex = Gpu.texture(gl, w, h, GL4.GL_DEPTH_COMPONENT32F, false);
            gl.glBindTexture(GL.GL_TEXTURE_2D, depthCopyTex);
            gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_NEAREST);
            gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_NEAREST);
            gl.glBindTexture(GL.GL_TEXTURE_2D, 0);
            depthCopyFbo = Gpu.depthFbo(gl, depthCopyTex);
            depthCopyW = w;
            depthCopyH = h;
        }
        gl.glBindFramebuffer(GL4.GL_READ_FRAMEBUFFER, hdrFbo);
        gl.glBindFramebuffer(GL4.GL_DRAW_FRAMEBUFFER, depthCopyFbo);
        gl.glBlitFramebuffer(0, 0, w, h, 0, 0, w, h, GL.GL_DEPTH_BUFFER_BIT, GL.GL_NEAREST);
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
    }

    private void drawRain(GL4 gl, Sky.State st, float[] vp, float[] inv, int w, int h, double pre, double[][] L) {
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        RainGl.View v = new RainGl.View();
        v.viewProj = vp;
        v.invViewProj = inv;
        v.eye = camera.eye.clone();
        v.forward = camera.fwd.clone();
        v.reversedZ = reversedZ;
        v.near = NEAR;
        v.far = FAR;
        v.fovyDeg = fovy();
        v.width = w;
        v.height = h;
        v.depthTexture = depthCopyTex;
        RainGl.Light l = new RainGl.Light();
        l.sunDir = skyOk ? st.sunDir : Sun.direction(clock.sun()[0], clock.sun()[1]);
        l.sunColor = L[0];
        l.moonDir = skyOk ? st.moonDir : new double[]{0, -1, 0};
        l.moonColor = L[1];
        double[][] fl = flashLight(pre);
        if (fl != null && fl[1][1] > l.moonColor[1]) { l.moonDir = fl[0]; l.moonColor = fl[1]; }
        // unter der Wolke: Licht von oben nur, so weit sie es durchlässt
        double under = cloudsOk && showClouds ? Math.min(1, clouds.type.overcastBrightness * 1.6) : 1;
        l.skyTop = skyOk ? scale(st.skyIrradiance, pre / Math.PI * under) : L[2];
        l.skyHorizon = L[3];
        l.fogDistance = skyOk ? fogDistance(st) : FOG_DISTANCE;
        gl.glDepthFunc(reversedZ ? GL.GL_GREATER : GL.GL_LESS);
        rainGl.draw(gl, v, l, rainStrength);
        gl.glDisable(GL.GL_BLEND);
        gl.glDepthMask(true);
    }

    private void drawFog(GL4 gl, Sky.State st, float[] inv, int w, int h, double[][] L) {
        Fog.Snapshot s = fog.snapshot();
        fogGl.update(gl, s, camera.eye.clone());
        if (fogCheck.isEmpty() && frame > 100) fogCheck = fogGl.selfCheck(gl, fog, camera.eye.clone());
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        FogGl.View v = new FogGl.View();
        v.invViewProj = inv;
        v.eye = camera.eye.clone();
        v.reversedZ = reversedZ;
        v.width = w;
        v.height = h;
        v.depthTexture = depthCopyTex;
        v.jitter = frozen ? 0.5 : -1;
        v.frame = frame;
        FogGl.Light l = new FogGl.Light();
        l.sunDir = skyOk ? st.sunDir : Sun.direction(clock.sun()[0], clock.sun()[1]);
        l.sunColor = L[0];
        if (skyOk) l.moonDir = st.moonDir;
        l.moonColor = L[1];
        l.ambientTop = L[2];
        l.ambientHorizon = L[3];
        fogGl.draw(gl, s, v, l);
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        gl.glBindVertexArray(emptyVao);
    }

    /** Anteil des Stäbchensehens (nachts farblos und bläulich), aus der Anpassung des Himmels. */
    private static double scotopic(Sky.State st) {
        double l = Math.log10(Math.max(1e-12, st.adaptation * Sky.CD_PER_UNIT));
        double t = Math.max(0, Math.min(1, (l - Math.log10(0.003)) / (Math.log10(3) - Math.log10(0.003))));
        return 1 - t * t * (3 - 2 * t);
    }

    /** Schneegrenze über dem See im Sommer (m) [G]: rund 1 430 m ü. M. an den Bergen um den Gletscher. */
    public static final double SNOW_LINE = 1250;
    /** Dunstlänge für exp(−d/L) mit dem Platzhalter-Himmel (wie common.glsl: 60 km). */
    static final double FOG_DISTANCE = 60_000;
    /** Nah- und Fernebene der Projektion (m). */
    static final double NEAR = 0.5, FAR = 80_000;

    /** Mittelpunkt der Sonnenschattenkarte: zwischen Auge und Drehpunkt, frei fliegend ein Stück vor dem Auge. */
    private double[] shadowCenter() {
        double cx, cz;
        if (camera.mode == Camera.Mode.FREI) {
            double k = sunShadow.half * 0.7;
            double hl = Math.max(1e-6, Math.hypot(camera.fwd[0], camera.fwd[2]));
            cx = camera.eye[0] + camera.fwd[0] / hl * k;
            cz = camera.eye[2] + camera.fwd[2] / hl * k;
        } else {
            double hl = Math.max(1e-6, Math.hypot(camera.tx - camera.eye[0], camera.tz - camera.eye[2]));
            double d = Math.min(hl, sunShadow.half * 1.2) * 0.85;
            cx = camera.eye[0] + (camera.tx - camera.eye[0]) / hl * d;
            cz = camera.eye[2] + (camera.tz - camera.eye[2]) / hl * d;
        }
        return new double[]{cx, terrain.height(cx, cz) + 8, cz};
    }

    /** Wald (R), Steppe (G), Moräne (B), Fels (A) als Textur zu 25 m für das Gelände. */
    private static int coverTexture(GL4 gl, Vegetation v) {
        int m = Vegetation.M;
        ByteBuffer b = Buffers.newDirectByteBuffer(m * m * 4);
        for (int k = 0; k < m * m; k++) {
            int f = Math.min(255, (v.lenga[k] & 0xff) + (v.nire[k] & 0xff) + (v.guindo[k] & 0xff));
            b.put((byte) f).put(v.steppe[k]).put(v.moraine[k]).put(v.rock[k]);
        }
        b.flip();
        int t = Gpu.texture(gl, m, m, GL.GL_RGBA8, false);
        gl.glBindTexture(GL.GL_TEXTURE_2D, t);
        gl.glPixelStorei(GL.GL_UNPACK_ALIGNMENT, 1);
        gl.glTexSubImage2D(GL.GL_TEXTURE_2D, 0, 0, 0, m, m, GL.GL_RGBA, GL.GL_UNSIGNED_BYTE, b);
        gl.glPixelStorei(GL.GL_UNPACK_ALIGNMENT, 4);
        gl.glBindTexture(GL.GL_TEXTURE_2D, 0);
        return t;
    }

    /** Sonnenlicht nach der Sonnenhöhe (wie sunLight() in common.glsl). */
    public static double[] sunLight(double elevDeg) {
        double e = Math.sin(Math.toRadians(elevDeg));
        double vis = smooth(-0.015, 0.01, e), t = smooth(0.02, 0.35, e), f = 2.6 * vis * smooth(-0.02, 0.12, e);
        return new double[]{f, (0.55 + 0.40 * t) * f, (0.28 + 0.60 * t) * f};
    }

    /** Zenit- und Horizontfarbe des Platzhalter-Himmels (wie skyColorPlaceholder in common.glsl, ohne Sonnensaum). */
    public static double[] skyZenith(double elevDeg) { return skyPlaceholder(elevDeg, 1); }
    public static double[] skyHorizon(double elevDeg) { return skyPlaceholder(elevDeg, 0); }

    static double[] skyPlaceholder(double e, double up) {
        double b = Sun.skyBrightness(e);
        double day = smooth(-2, 12, e), night = 1 - smooth(-16, -8, e), tw = Math.max(0, Math.min(1, 1 - day - night));
        double hw = Math.pow(1 - up, 4);
        double[] zen = {0.16 * day + 0.10 * tw + 0.05 * night, 0.34 * day + 0.17 * tw + 0.08 * night, 0.72 * day + 0.42 * tw + 0.20 * night};
        double[] hor = {0.62 * day + 0.6 * tw + 0.07 * night, 0.74 * day + 0.4 * tw + 0.09 * night, 0.88 * day + 0.36 * tw + 0.18 * night};
        double[] c = new double[3];
        for (int i = 0; i < 3; i++) c[i] = (zen[i] + (hor[i] - zen[i]) * hw) * b / 0.32;
        return c;
    }

    static double smooth(double a, double b, double x) {
        double t = Math.max(0, Math.min(1, (x - a) / (b - a)));
        return t * t * (3 - 2 * t);
    }

    private void common(GL4 gl, Shader s, float[] vp, float[] inv, double[] sun, double level) {
        s.use(gl);
        // Phase 3: mit com.dan.sky Himmel aus dem Rundumbild, Sonne und Mond vorbelichtet, Dunst aus der Sicht
        boolean sm = skyOk && s != skyShader && s != skyPano;
        s.set(gl, "uSkyMode", sm ? 1 : 0);
        if (sm) {
            Sky.State st = skyState();
            double pre = exposure();
            gl.glActiveTexture(GL.GL_TEXTURE7);
            gl.glBindTexture(GL.GL_TEXTURE_2D, panoTex);
            gl.glActiveTexture(GL.GL_TEXTURE0);
            s.set(gl, "uPano", 7);
            s.set(gl, "uSunColor", scale(st.sunColor, pre));
            s.set(gl, "uMoonColor", scale(st.moonColor, pre));
            s.set(gl, "uMoonDir", st.moonDir);
            s.set(gl, "uFogDist", (float) fogDistance(st));
            s.set(gl, "uPre", (float) pre);
            s.set(gl, "uSkyAmb", scale(st.skyIrradiance, pre / Math.PI));
        }
        s.mat(gl, "uVP", vp);
        s.mat(gl, "uInvVP", inv);
        s.set(gl, "uCam", camera.eye);
        s.set(gl, "uSun", sun);
        s.set(gl, "uTime", (float) (clock.t() % 10_000));
        s.set(gl, "uLevel", (float) level);
        s.set(gl, "uReversed", reversedZ ? 1 : 0);
    }

    private void resizeTargets(GL4 gl, int w, int h) {
        Gpu.deleteFbos(gl, hdrFbo);
        Gpu.deleteTextures(gl, hdrTex, depthTex);
        hdrTex = Gpu.texture(gl, w, h, GL.GL_RGBA16F, false);
        depthTex = Gpu.texture(gl, w, h, GL4.GL_DEPTH_COMPONENT32F, false);
        gl.glBindTexture(GL.GL_TEXTURE_2D, depthTex);
        gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_NEAREST);
        gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_NEAREST);
        gl.glBindTexture(GL.GL_TEXTURE_2D, 0);
        hdrFbo = Gpu.fbo(gl, hdrTex, depthTex);
        hdrW = w;
        hdrH = h;
    }

    // ------------------------------------------------------------------ Zeitmessung

    private void mark(GL4 gl, int i) { gl.glQueryCounter(stamp[frame & 1][i], GL4.GL_TIMESTAMP); }

    /** Liest die Zeitstempel des vorigen Bilds, sobald sie da sind (kein Warten im Bildlauf). */
    private void readMarks(GL4 gl) {
        if (frame < 2) return;
        int o = (frame - 1) & 1;
        int[] av = new int[1];
        gl.glGetQueryObjectiv(stamp[o][MARKS - 1], GL4.GL_QUERY_RESULT_AVAILABLE, av, 0);
        if (av[0] == 0) return;
        long[] t = new long[MARKS];
        for (int i = 0; i < MARKS; i++) gl.glGetQueryObjecti64v(stamp[o][i], GL4.GL_QUERY_RESULT, t, i);
        for (int i = 0; i < MARKS - 1; i++) passMs[i] = passMs[i] * 0.9 + Math.max(0, t[i + 1] - t[i]) / 1e6 * 0.1;
        gpuMs = gpuMs * 0.9 + Math.max(0, t[MARKS - 1] - t[0]) / 1e6 * 0.1;
    }

    /** „Himmel 0,10 · Bühne 0,60 · …“ in ms (gleitendes Mittel). */
    public String passTimes() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < passMs.length; i++)
            sb.append(i > 0 ? " · " : "").append(PASSES[i]).append(' ').append(String.format(Locale.GERMAN, "%.2f", passMs[i]));
        return sb.toString();
    }

    private void stats(long now, int w, int h) {
        statsFrames++;
        if (now - statsNanos < 500_000_000L) return;
        fps = statsFrames / ((now - statsNanos) / 1e9);
        statsFrames = 0;
        statsNanos = now;
        statusListener.accept(statusLine(w, h));
    }

    /** Auflösung nach der Zeit der Grafikkarte regeln (siehe {@link #autoScale}). */
    private void regulateScale(long now) {
        if (!autoScale || frame < 60 || now - scaleNanos < 1_500_000_000L) return;
        scaleNanos = now;
        double budget = 1000 / Math.max(10, targetFps), top = quality.renderScale, s = renderScale;
        double want = s * Math.sqrt(budget * 0.9 / Math.max(0.1, gpuMs));
        double next = s;
        if (gpuMs > budget * 1.05) next = Math.max(MIN_SCALE, Math.max(want, s - 0.15));
        else if (gpuMs < budget * 0.7 && s < top) next = Math.min(top, Math.min(want, s + 0.05));
        next = Math.round(next * 20) / 20.0;
        if (Math.abs(next - s) >= 0.045) { renderScale = next; scaleSteps++; }
    }

    /** Wie oft die Regelung die Auflösung geändert hat. */
    public int scaleSteps() { return scaleSteps; }

    /** Für Prüfungen: die Regelung mit vorgegebener Grafikkartenzeit und Bildnummer. */
    public void regulateForTest(double gpuMsNow, long nowNanos) {
        gpuMs = gpuMsNow;
        frame = Math.max(frame, 60);
        regulateScale(nowNanos);
    }

    public String statusLine(int w, int h) {
        String s = String.format(Locale.GERMAN, "%s · %.0f Bilder/s · Grafikkarte %.2f ms · Prozessor %.2f ms · %d×%d (%s%s) · %s",
                clock.label(), fps, gpuMs, cpuMs, w, h, quality.label, autoScale ? String.format(Locale.GERMAN, ", %.0f %%", renderScale * 100) : "", glInfo);
        if (System.currentTimeMillis() < photoMsgUntil) s = photoMsg + " · " + s;
        return s;
    }

    // ------------------------------------------------------------------ HUD

    BufferedImage paintHud() {
        String[] lines = hudFull ? hudLines() : hudShort();
        Font font = new Font(Font.MONOSPACED, Font.PLAIN, 12);
        BufferedImage probe = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
        Graphics2D pg = probe.createGraphics();
        java.awt.FontMetrics fm = pg.getFontMetrics(font);
        int tw = 0;
        for (String l : lines) tw = Math.max(tw, fm.stringWidth(l.startsWith("!") ? l.substring(1) : l));
        pg.dispose();
        int w = Math.max(200, tw + 22), lh = 17, h = 16 + lines.length * lh;
        BufferedImage im = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = im.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setColor(new Color(11, 18, 25, 180));
        g.fillRoundRect(0, 0, w - 1, h - 1, 10, 10);
        g.setColor(new Color(138, 211, 236, 220));
        g.setStroke(new BasicStroke(2f));
        g.drawLine(8, 1, 60, 1);
        g.setFont(font);
        for (int i = 0; i < lines.length; i++) {
            String l = lines[i];
            boolean warn = l.startsWith("!");
            if (warn) l = l.substring(1);
            g.setColor(i == 0 ? new Color(241, 246, 249) : warn ? new Color(224, 163, 63) : new Color(185, 200, 210));
            g.drawString(l, 10, 18 + i * lh);
        }
        g.dispose();
        return im;
    }

    /** Das kurze HUD: Tempo, Zeit und Wind, Kamera. Meldungen mit ! aus den vollen Zeilen kommen dazu. */
    String[] hudShort() {
        java.util.List<String> l = new java.util.ArrayList<>();
        String q = autoScale ? String.format(Locale.GERMAN, "%s %.0f %%", quality.label, renderScale * 100) : quality.label;
        l.add(String.format(Locale.GERMAN, "%.0f Bilder/s · Grafikkarte %.1f ms · Prozessor %.1f ms · %s %d×%d", fps, gpuMs, cpuMs, q, hdrW, hdrH));
        l.add(String.format(Locale.GERMAN, "%s · Sonne %.0f° · %s", clock.label(), clock.sun()[0], windLine()));
        l.add(String.format(Locale.GERMAN, "%s · Auge %.0f m · Blick %03.0f° · %.0f m von der Front · H: volles HUD, F1: Tasten",
                camera.modeName(), camera.eye[1], camera.heading(), camera.originDistance()));
        com.dan.glacier.camera.Fahrt fa = camera.fahrt;
        if (fa != null) l.add("Fahrt " + fa.describe() + " · Pfeiltaste oder Maus: anhalten");
        for (String s : hudLines()) if (s.startsWith("!")) l.add(s);
        if (System.currentTimeMillis() < photoMsgUntil) l.add(photoMsg);
        return l.toArray(new String[0]);
    }

    /** „Eis“, „See“, „Fels“ unter dem Auge. */
    String zone() { return "unter dem Auge: " + com.dan.glacier.camera.Ansichten.zone(camera.eye[0], camera.eye[2]); }

    /** „Himmel com.dan.sky · Sonne 58,1° · Mond 45 % · Sicht 70 km · Belichtung …“ */
    public String skyLine() {
        if (!skyOk) return "!Himmel: einfacher Verlauf (com.dan.sky nicht gestartet)";
        Sky.State st = skyState();
        return String.format(Locale.GERMAN, "Himmel %s · Sonne %.1f° · Mond %.0f %% · Sicht %.0f km · Belichtung %.3g · Stäbchen %.0f %%%s", skyGl.info(), st.sunAlt,
                st.moonFraction * 100, st.visibilityKm, exposure(), scotopic(st) * 100, skyCheck.isEmpty() ? "" : " · " + skyCheck);
    }

    public String cloudLine() {
        if (!cloudsOk) return "!Wolken: com.dan.cloud nicht gestartet";
        return String.format(Locale.GERMAN, "Wolken %s · Sonne am Auge %.0f %% · %s%s", clouds.describe(), cloudShade * 100, cloudGl.info(), cloudCheck.isEmpty() ? "" : " · " + cloudCheck);
    }

    String weatherLine2() {
        if (wiring == null) return "Wetter —";
        return wiring.weatherLine() + String.format(Locale.GERMAN, " · %.1f °C · %.0f hPa · Sicht %.0f km · Regen %.1f mm/h · Nebel %.0f %%",
                wiring.airTempC, wiring.pressureHPa, wiring.visibilityKm, wiring.rainRate, wiring.fogAmount * 100);
    }

    public String lightningLine() {
        if (!lightningOk) return "!Gewitter: com.dan.lightning nicht gestartet";
        if (lightning.level() == Lightning.Level.OFF && lightning.flashes() == 0) return "Gewitter: keines";
        return String.format(Locale.GERMAN, "Gewitter %s · %d Blitze, %d Erdblitze%s%s", lightning.level().name().toLowerCase(Locale.ROOT), lightning.flashes(),
                lightning.groundFlashes(), lastBoltText.isEmpty() ? "" : " · zuletzt " + lastBoltText, lightningCheck.isEmpty() ? "" : " · " + lightningCheck);
    }

    String windLine() {
        if (wiring == null) return "Wind —";
        var w = wiring.wind;
        return String.format(Locale.GERMAN, "Wind %.1f m/s (Bft %d) aus %03.0f°", w.speed(), w.beaufort(), w.fromDeg());
    }

    public String[] hudLines() {
        double[] sp = clock.sun();
        ComputeProbe.Result c = compute;
        return new String[]{
                String.format(Locale.GERMAN, "%.0f Bilder/s   Grafikkarte %.2f ms   Prozessor %.2f ms   Budget %.1f ms", fps, gpuMs, cpuMs, quality.budgetMs()),
                passTimes(),
                (c == null ? "!Compute-Test läuft …" : (c.ok() ? "" : "!") + c.line()),
                String.format(Locale.GERMAN, "%s · Sonne %.1f° / %03.0f° · Belichtung %.2g", clock.label(), sp[0], sp[1], exposure()),
                windLine() + (wiring != null ? String.format(Locale.GERMAN, " · See %+.2f m · Brazo Rico %+.1f m", wiring.waterLevel.level(), wiring.waterLevel.brazoRico()) : ""),
                skyLine(),
                cloudLine(),
                weatherLine2(),
                rainOk ? rainGl.info() + (rainCheck.isEmpty() ? "" : " · " + rainCheck) + String.format(Locale.GERMAN, " · Wetter auf dem Prozessor %.2f ms", weatherCpuMs) : "!Regen: com.dan.rain nicht gestartet",
                fogOk ? "Nebel " + fog.describe() + " · " + fogGl.info() + (fogCheck.isEmpty() ? "" : " · " + fogCheck) : "!Nebel: com.dan.fog nicht gestartet",
                lightningLine(),
                (terrain.measured() ? "" : "!") + "Gelände " + terrain.describe() + String.format(Locale.GERMAN, " · %d Knoten, %,d Punkte", lod.nodes, lod.vertices),
                vegetation.describe() + " · " + zone(),
                oceanOk ? "See " + ocean.describe() + " · " + oceanGl.info() + (oceanCheck.isEmpty() ? "" : " · " + oceanCheck) : "!See: com.dan.ocean nicht gestartet",
                forestOk ? forestGl.info() + (sunShadow.matrix != null ? String.format(Locale.GERMAN, " · Sonnenschatten %d² über %.0f m", sunShadow.size, sunShadow.half * 2) : "") : "!Wald: com.dan.forest nicht gestartet",
                reedOk ? "Halme " + reed.describe() + " · " + reedGl.info() : "!Halme: com.dan.reed nicht gestartet",
                groundOk ? groundGl.info() : "!Bodendecke: com.dan.ground nicht gestartet",
                physik.describe(),
                wiring == null ? "Verdrahtung —" : "Verdrahtung " + wiring.summary(),
                String.format(Locale.GERMAN, "%s · Auge %.1f m · Blick %03.0f° · %.0f m von der Front · %s",
                        camera.modeName(), camera.eye[1], camera.heading(), camera.originDistance(),
                        Site.dms(Site.latLon(camera.eye[0], camera.eye[2])[0], Site.latLon(camera.eye[0], camera.eye[2])[1])),
                String.format(Locale.GERMAN, "%s · %d×%d · %s", quality.label, hdrW, hdrH, reversedZ ? "umgekehrte Tiefe" : "klassische Tiefe"),
                glInfo};
    }

    // ------------------------------------------------------------------ Bilder

    private void takePhoto(GL4 gl, int w, int h) {
        try {
            BufferedImage img = readDefault(gl, w, h);
            File dir = photoDir != null ? photoDir : new File("docs/status");
            if (!dir.isDirectory() && !dir.mkdirs()) throw new java.io.IOException("Ordner " + dir + " lässt sich nicht anlegen");
            File f = new File(dir, "Glacier_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".png");
            javax.imageio.ImageIO.write(img, "png", f);
            photoMsg = "Foto gespeichert: " + f.getPath();
            System.out.println(photoMsg);
        } catch (Exception e) {
            photoMsg = "Foto fehlgeschlagen: " + e.getMessage();
            System.err.println(photoMsg);
        }
        photoMsgUntil = System.currentTimeMillis() + 5000;
    }

    /** Liest das fertige Fensterbild (nach Nachbearbeitung und HUD). */
    BufferedImage readDefault(GL4 gl, int w, int h) {
        ByteBuffer bb = Buffers.newDirectByteBuffer(w * h * 4);
        gl.glBindFramebuffer(GL.GL_READ_FRAMEBUFFER, defaultFbo);
        gl.glReadBuffer(defaultFbo == 0 ? GL.GL_BACK : GL.GL_COLOR_ATTACHMENT0);
        gl.glPixelStorei(GL.GL_PACK_ALIGNMENT, 1);
        gl.glReadPixels(0, 0, w, h, GL.GL_RGBA, GL.GL_UNSIGNED_BYTE, bb);
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        int[] row = new int[w];
        for (int y = 0; y < h; y++) {
            int o = (h - 1 - y) * w * 4;
            for (int x = 0; x < w; x++) {
                int i = o + x * 4;
                row[x] = ((bb.get(i) & 255) << 16) | ((bb.get(i + 1) & 255) << 8) | (bb.get(i + 2) & 255);
            }
            img.setRGB(0, y, w, 1, row, 0, w);
        }
        return img;
    }

    /** Für Werkzeuge: das letzte Bild als Bild (im GL-Faden aufrufen). */
    public BufferedImage grab(GLAutoDrawable d) {
        GL4 gl = d.getGL().getGL4();
        defaultFbo = d.getContext().getDefaultDrawFramebuffer();
        return readDefault(gl, d.getSurfaceWidth(), d.getSurfaceHeight());
    }

    // ------------------------------------------------------------------ Ende

    private void fail(String msg) {
        error = msg;
        System.err.println(msg);
        errorListener.accept(msg);
    }

    @Override
    public void dispose(GLAutoDrawable d) {
        physik.stop();
        GL4 gl = d.getGL().getGL4();
        for (Shader s : all) s.dispose(gl);
        hud.dispose(gl);
        lod.dispose(gl);
        if (oceanOk) oceanGl.dispose(gl);
        if (reedOk) reedGl.dispose(gl);
        if (forestOk) forestGl.dispose(gl);
        if (groundOk) groundGl.dispose(gl);
        if (skyOk) skyGl.dispose(gl);
        if (cloudsOk) cloudGl.dispose(gl);
        if (rainOk) rainGl.dispose(gl);
        if (fogOk) fogGl.dispose(gl);
        if (lightningOk) lightningGl.dispose(gl);
        Gpu.deleteFbos(gl, depthCopyFbo);
        Gpu.deleteTextures(gl, depthCopyTex);
        sunShadow.dispose(gl);
        Gpu.deleteFbos(gl, panoFbo);
        Gpu.deleteTextures(gl, panoTex, coverTex);
        Gpu.deleteFbos(gl, hdrFbo);
        Gpu.deleteTextures(gl, hdrTex, depthTex);
        if (emptyVao != 0) gl.glDeleteVertexArrays(1, new int[]{emptyVao}, 0);
        for (int[] s : stamp) if (s[0] != 0) gl.glDeleteQueries(MARKS, s, 0);
        ready = false;
    }
}
