# com.dan.glacier – die App

Glacier – Weißer Donner: der Perito-Moreno-Gletscher am Lago Argentino als 3D-Echtzeitszene. Die App verdrahtet die Element-Packages und zeichnet; sie selbst enthält keine Physik der Elemente.

**Stand: Phase 3 (Himmel und Wetter: com.dan.sky mit Südhimmel, Wolken mit Lentikularis, Regen, Seenebel, Gewitter, Wetterregie mit dem Klima Patagoniens).**

| Paket | Inhalt |
|---|---|
| `app` | `GlacierApp`: Startbild, FFrame maximiert, Szene, Bedienfeld, Statuszeile, Fehlerdatei `daten/fehler.txt` |
| `gl` | Engine aus Haithabu, entschlackt: `Renderer` (Himmel aus com.dan.sky, Wolken, Rundumbild, Augenanpassung, Gelände, Wald mit Sonnenschatten, Bodendecke, See, Halme, Regen, Seenebel, Blitz, Nachbearbeitung, HUD, Zeitmessung je Durchgang, Auflösungsregelung, Foto F12, Shader neu F5), `SceneView`, `Shader`, `Gpu`, `Mat4`, `HudOverlay`, `ComputeProbe`, `Quality`, `TerrainLod` (CDLOD aus Haithabu), `SunShadow` |
| `gl/shader` | `common.glsl` (Platzhalter-Himmel), `sky.frag`, `skypano.frag`, `terrain.vert`, `terrain_height.glsl`, `terrain.frag`, `post.frag`, `overlay.frag`, `probe.comp` |
| `camera` | `Camera` (Kreisen, Frei, Fahrt, Mitfahrt), `Fahrt`, `Ansichten` 1–7 |
| `scene` | `Site` (Ort und Maße, Abschnitt 2), `Geo` (transversale Mercator, UTM 18 Süd), `Sun`, `SceneClock` (ART, UTC−3), `Terrain` (Gelände 12,8 km zu 6,25 m), `Vegetation` (Karten zu 25 m), `Bodendecke`, `Buehne` (Ersatz ohne Höhendaten), `Physik` (eigener Faden, fester Schritt 1/120 s) |
| `wiring` | 15 Schnittstellen und `Wiring` – siehe [wiring/README.md](wiring/README.md) |
| `ui` | `ControlPanel` (ZEIT, WETTER, SEE, KAMERA, BILD, TECHNIK), `Startbild`, `AppIcon`, `Theme` |
| `tools` | `Tempo`: Tempo-Probe und Standbild ohne Fenster; `GelaendeImport` und `GeoTiff`: Höhendaten einlesen |

## Gelände (Phase 2)

`tools.GelaendeImport` liest das Höhenmodell Copernicus GLO-30 (GeoTIFF, auch LZW) und schreibt `daten/gelaende`:

```
java -cp build/classes com.dan.glacier.tools.GelaendeImport templates/rasters_COP30/output_hh.tif daten/gelaende docs/status/Gelaende_Import.png
```

- Raster 2048² zu 6,25 m (12,8 km), Höhen über dem See in 16 bit; Ursprung die Spitze der Front.
- Doppelte Spalten fallen weg (GLO-30 hat hier 1,5″ in der Länge). Seespiegel = häufigster Wert (178,5 m ü. M.).
- Eis = die größte glatte Fläche am Wasser, Masken bilinear (keine 30-m-Treppen); der Fuß der Front wird See.
- Seegrund und Grund unter dem Eis sind modelliert [G] (Tiefe 160 m · (1 − e^(−s/350 m)), Eis 170 → 380 m).
- Die Stege: auf der Halbinsel 25 bis 60 m über dem See, gut 300 m vor der Spitze.
- Fehlt `daten/gelaende`, zeigt die App die Bühne von Phase 1 (`Terrain.flat()`).

Wo was wächst, steht in `scene.Vegetation` [G]: Lenga bis 700 m über dem See, Guindo unten am feuchten Südhang und
nahe am Eis, Ñire an den trockenen Rändern nach Osten, Steppe auf offenen Hängen nach Osten hin, Ufergras, Moräne
neben dem Eis. Die Packages bekommen den Tag im Jahr um ein halbes Jahr versetzt (Südhalbkugel).

## Himmel und Wetter (Phase 3)

- Die Wetterregie (`com.dan.weather`) läuft frei mit dem Klima Patagoniens (`Wiring.PATAGONIA`): klar, aufziehend,
  Front, Sturm, selten Gewitter, abklingend, aufklarend, Seenebel am Morgen und der Föhnsturm im Lee der Anden [G].
  Im Bedienfeld (WETTER) frei ab einer Lage oder von Hand; Handregler halten eine Größe, bis „Regie weiter“.
- Lentikularis: im Föhnsturm fast immer, vor einer Front oft, sonst nach Stärke des Westwinds; von Hand mit dem Regler.
- Der Himmel (`com.dan.sky`) kennt den Südhimmel: Kreuz des Südens, Zentaur, Kiel des Schiffs, Südliches Dreieck
  (ZEIT → „Sternbilder einzeichnen“) und die Magellanschen Wolken.
- Die Augenanpassung folgt dem Himmel im Blickfeld (wie Haithabu); nachts sieht das Auge farblos und bläulich.
- `Tempo` kennt `WETTER=FOEHN`, `LENTIKULARIS=0..1`, `BEDECKUNG=Achtel`, `FIGUREN`.

## Raum und Zeit

- 1 Einheit = 1 m, x Ost, y oben, z Süd (Nord = −z), Ursprung an der Spitze der Front auf dem Seespiegel (50°28′23″ S, 73°02′13″ W); Lage in SRID 8307.
- Die Uhr zählt argentinische Zeit (UTC−3). Start 16. Januar 2026, 15:00 Uhr [G]. Die Sonne steht mittags im Norden, gegen 14 Uhr.

## Schalter

`-Dglacier.splash=false` ohne Startbild · `-Dglacier.gljpanel=true` leichter GL-Rückfall · `-Dglacier.shaders=<ordner>` Shader von der Platte (F5 lädt neu) · `-Dglacier.daten=<ordner>` statt `daten/`.

## Prüfen

- `ant pruefung` (oder `com.dan.glacier.test.Pruefung` mit „Run File“) endet mit „ERGEBNIS: alles in Ordnung“.
- `ant check-packages` übersetzt jedes Element-Package einzeln; läuft nach jedem Übersetzen.
