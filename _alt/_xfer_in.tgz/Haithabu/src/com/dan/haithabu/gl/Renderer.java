package com.dan.haithabu.gl;

import com.dan.haithabu.camera.Camera;
import com.dan.haithabu.scene.SceneClock;
import com.dan.haithabu.scene.Brook;
import com.dan.haithabu.scene.Site;
import com.dan.haithabu.scene.Sun;
import com.dan.haithabu.scene.Terrain;
import com.dan.haithabu.scene.Vegetation;
import com.dan.cloud.Clouds;
import com.dan.cloud.Noise;
import com.dan.cloud.gl.CloudGl;
import com.dan.fog.Fog;
import com.dan.fog.gl.FogGl;
import com.dan.lightning.Bolt;
import com.dan.lightning.Lightning;
import com.dan.lightning.gl.LightningGl;
import com.dan.ocean.Ocean;
import com.dan.ocean.gl.OceanGl;
import com.dan.rain.Rain;
import com.dan.rain.gl.RainGl;
import com.dan.season.Year;
import com.dan.season.gl.IceGl;
import com.dan.season.gl.SeasonGl;
import com.dan.season.gl.SnowfallGl;
import com.dan.sky.Sky;
import com.dan.sky.gl.SkyGl;
import com.dan.forest.ForestField;
import com.dan.haithabu.scene.Siedlung;
import com.dan.haithabu.scene.Flotte;
import com.dan.haithabu.scene.Feuer;
import com.dan.smoke.Smoke;
import com.dan.smoke.gl.RoomSmokeGl;
import com.dan.smoke.gl.SmokeGl;
import com.dan.hearth.gl.HearthGl;
import com.dan.longship.gl.LongshipGl;
import com.dan.spray.gl.SprayGl;
import com.dan.timber.Timber;
import com.dan.timber.gl.TimberGl;
import com.dan.weathering.Weathering;
import com.dan.forest.gl.ForestGl;
import com.dan.ground.Biome;
import com.dan.ground.Meadow;
import com.dan.ground.gl.GroundGl;
import com.dan.reed.Reed;
import com.dan.reed.gl.ReedGl;
import com.dan.haithabu.wiring.Beaufort;
import com.dan.haithabu.wiring.Wiring;
import com.jogamp.common.nio.Buffers;
import com.jogamp.opengl.GL;
import com.jogamp.opengl.GL4;
import com.jogamp.opengl.GLAutoDrawable;
import com.jogamp.opengl.GLEventListener;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.ByteBuffer;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.function.Consumer;

/**
 * Die Engine auf der Grafikkarte, übernommen aus Lighthouse und entschlackt (F5 A). Je Bild:
 * <ol>
 * <li>Phase 3: der Himmel aus {@code com.dan.sky} (Streuung, Sonne, Mond, Sterne und Planeten von 950) in einen
 * HDR-Puffer (RGBA16F, umgekehrte 32F-Tiefe), dazu als kleines Rundumbild für Spiegelung und Himmelslicht. Alle
 * Helligkeiten tragen schon die Vorbelichtung aus der Augenanpassung (halb an den Himmel, halb ans Blickfeld, über
 * eine Sekunde geglättet, wie Lighthouse). Startet {@code com.dan.sky} nicht, bleibt der Verlauf aus Phase 1.</li>
 * <li>Phase 3: die Wolken aus {@code com.dan.cloud} über den Himmel und ins Rundumbild; ihre Schattenkarte liegt auf
 * Gelände und Noor. Blitze aus {@code com.dan.lightning}: Kanäle über Himmel und Wolken, Lichtpunkte auf Wolken, Noor
 * und Gelände, das Leuchten der Luft zuletzt.</li>
 * <li>Phase 2: das Gelände aus den Höhendaten ({@link Terrain}, {@link TerrainLod}, {@code terrain.vert/frag}): Gras,
 * offene Flanken, Ufer von 950, Grund des Noors, Bachbett, Schilf als Farbe in der Ferne.</li>
 * <li>Phase 2: das Noor aus {@code com.dan.ocean} (Preset „Noor“: Streichlänge 1,5 km, 3 m tief, keine Dünung) –
 * erst rechnen (Compute-Shader), dann zeichnen; mit dem Gelände als Grund (Uferdämpfung, Grundsicht, Schaumsaum).
 * Der Bach: {@code com.dan.river} rechnet die Strömung, das Gelände zeichnet sein Wasser mit treibenden Mustern.</li>
 * <li>Phase 2: Schilf, Binsen und Gras aus {@code com.dan.reed} um die Kamera.</li>
 * <li>Phase 3: Regen aus {@code com.dan.rain} (Vorhänge, Streifen, Ringe auf dem Noor) und Strahlungsnebel aus
 * {@code com.dan.fog} über die fertige Szene (Tiefe als Kopie).</li>
 * <li>Nachbearbeitung: Belichtung, Filmkurve, Gamma; dann das HUD.</li>
 * </ol>
 * Geblieben aus Lighthouse: Qualitätsstufen mit Auflösungsregelung, Zeitmessung jedes Durchgangs auf der Grafikkarte
 * (Zeitstempel, ein Bild versetzt gelesen), Compute-Test beim Start, HUD kurz/voll/aus, Foto (F12), Shader neu laden
 * (F5), Standbilder ohne Fenster ({@code tools.Tempo}). Im Bildlauf werden keine Dateien gelesen.
 */
public final class Renderer implements GLEventListener {
    public static final int MIN_MAJOR = 4, MIN_MINOR = 3;
    public static final String VERSION = "Phase 16";
    // Phase 11: Feuer, Rauch und Haus als eigene Posten (in Phase 10 steckten sie im Posten „Regen“, Befund Phase 10)
    static final String[] PASSES = {"Himmel", "Wolken", "Schatten", "Gelände", "Wald", "Noor", "Halme, Tiere", "Feuer", "Rauch", "Haus", "Regen", "Nebel", "Blitz", "Nachbearbeitung", "HUD"};
    private static final int MARKS = PASSES.length + 1;

    public final SceneClock clock;
    public final Wiring wiring;
    public final Camera camera = new Camera();
    /** Phase 2: das Gelände (aus daten/gelaende) und was darauf wächst. */
    public final Terrain terrain;
    public final Vegetation vegetation;
    /** Phase 2: der Haithabu-Bach ({@code com.dan.river}); null ohne Lauf. */
    public final Brook brook;
    private int brookTex;
    private final TerrainLod lod = new TerrainLod();
    /** Phase 2: das Noor (Kern ohne Grafikkarte; die Verdrahtung gibt Wind und Wasserstand). */
    public final Ocean ocean = Ocean.noor(3);
    private final OceanGl oceanGl = new OceanGl();
    private volatile boolean oceanOk;
    private volatile String oceanCheck = "";
    /** Phase 2: Schilf, Binsen, Gras (Kern ohne Grafikkarte; die Verdrahtung gibt Wind und Jahreszeit). */
    public final Reed reed = Reed.breeze();
    private final ReedGl reedGl = new ReedGl();
    private volatile boolean reedOk;
    public volatile boolean showWater = true, showReed = true;
    /** Phase 2b: Wald und Erlenbruch aus {@code com.dan.forest} (wo, sagt {@link Vegetation}), Sonnenschatten. */
    public final ForestField forest;
    private final ForestGl forestGl;
    private volatile boolean forestOk;
    public volatile boolean showForest = true, showSunShadow = true;
    private final SunShadow sunShadow = new SunShadow();
    /** Phase 5: die sieben Häuser am Ufer mit Wegen, Zäunen, Brunnen, Fischgestellen und Booten ({@code com.dan.timber}). */
    /** Die Siedlung (Phase 6: neu würfelbar; {@link #setSiedlung} tauscht sie im nächsten Bild). */
    public volatile Siedlung siedlung;
    private volatile Siedlung nextSiedlung;
    /** Szenenzeit beim letzten Schritt der Feuer (NaN: noch keiner). */
    private double lastClockMs = Double.NaN;
    public final Timber timber = new Timber();
    private final TimberGl timberGl = new TimberGl();
    private volatile boolean timberOk;
    public volatile boolean showHouses = true;
    /**
     * Phase 9: die Schiffe im Hafen ({@code com.dan.longship}), schwimmend mit {@code com.dan.buoyancy}, Kielwasser ins
     * Noor, Riemenspritzer aus {@code com.dan.spray} (F22).
     */
    public volatile Flotte flotte;
    private final LongshipGl longshipGl = new LongshipGl();
    private final SprayGl sprayGl = new SprayGl();
    private volatile boolean shipsOk, sprayOk;
    public volatile boolean showShips = true;
    private double shipsCpuMs;
    /**
     * Phase 10: Herde, Essen, Fackeln und die Feuerstelle ({@code com.dan.hearth}) und der Rauch aus den Rauchlöchern
     * ({@code com.dan.smoke}); die Feuer leuchten auf Häuser, Gelände und Rauch.
     */
    public volatile Feuer feuer;
    /** Phase 13: Vögel ({@code com.dan.flock}) und Haustiere ({@code com.dan.herd}). */
    public volatile com.dan.haithabu.scene.Leben leben;
    private final com.dan.flock.gl.FlockGl flockGl = new com.dan.flock.gl.FlockGl();
    private final com.dan.herd.gl.HerdGl herdGl = new com.dan.herd.gl.HerdGl();
    private volatile boolean birdsOk, animalsOk;
    public volatile boolean showBirds = true, showAnimals = true;
    private double lifeCpuMs;
    private volatile String flockCheck = "";
    /**
     * Phase 14: der Klang ({@code com.dan.soundscape}): ein Klang für die ganze Sitzung, über den Lautsprecher in einem
     * eigenen Faden; {@link #klang} hängt die Szene daran und wird mit der Siedlung neu gebaut.
     */
    public final com.dan.soundscape.Soundscape sound = new com.dan.soundscape.Soundscape();
    public volatile com.dan.haithabu.scene.Klang klang;
    private final com.dan.soundscape.AudioOut audio = new com.dan.soundscape.AudioOut(sound);
    private volatile boolean soundOn;
    private double soundCpuMs;
    private com.dan.haithabu.camera.Ansichten.Ansicht gasseView;
    /** Phase 15: Regiebücher und Tagesregie (die Knorr läuft am Nachmittag aus und am Morgen ein). */
    public final com.dan.haithabu.scene.Regie regie = new com.dan.haithabu.scene.Regie();
    public volatile boolean tagesregie = true;
    private double lastHourTR = Double.NaN;
    private final RegieCtx regieCtx = new RegieCtx();
    private final java.util.List<BufferedImage> album = new java.util.ArrayList<>();
    private final java.util.List<String> albumCaps = new java.util.ArrayList<>();
    private volatile String captureCaption, sheetName;
    private double albumGpu, albumFps;
    private int albumSamples;
    private volatile String regieMsg = "";
    private double brandCpuMs;
    public final Smoke smoke = new Smoke();
    private final SmokeGl smokeGl = new SmokeGl();
    private final HearthGl hearthGl = new HearthGl();
    private volatile boolean smokeOk, hearthOk;
    public volatile boolean showSmoke = true, showFire = true;
    public volatile double smokeStrength = 1;
    private volatile String smokeCheck = "";
    private double fireCpuMs;
    /** Feuerlicht dieses Bilds: Ort und Größe, Lichtstärke RGB (vorbelichtet, Einheit der Sonne · m²), Zahl. */
    private final float[] firePos = new float[32], fireRgb = new float[32];
    private int fireN;
    /**
     * Phase 11: das Versammlungshaus innen. Der Rauch im Haus als Volumen ({@code com.dan.smoke.RoomSmoke},
     * {@code gl/RoomSmokeGl}) mit Lichtstrahlen durch Tür und Rauchloch; die Lichter im Haus (Herd, Glut, Lampen)
     * gelten nur innen, draußen leuchten nur die Türen.
     */
    private final RoomSmokeGl roomSmokeGl = new RoomSmokeGl();
    private volatile boolean roomSmokeOk;
    public volatile boolean showRoomSmoke = true;
    public volatile double roomSmokeStrength = 1;
    private final float[] roomPos = new float[16], roomRgb = new float[16];
    private int roomN;
    /** Steht das Auge im Versammlungshaus? (je Bild) */
    private volatile boolean eyeInHall;
    /** Leuchtdichte der Feuer um das Auge und im Haus für die Augenanpassung (Einheiten von com.dan.sky). */
    private double fireLum, hallLum;
    private com.dan.haithabu.scene.Versammlungshaus uploadedHall;
    /** Phase 5: Nässe nach Regen, die langsam trocknet ({@code com.dan.weathering}); Häuser und Bäume lesen sie. */
    public final Weathering weathering = Weathering.calm();
    /** Phase 2b: Bodendecke aus {@code com.dan.ground} um das Auge, nur zu Fuß (Auge höchstens 25 m über Grund). */
    public final Meadow meadow;
    private final GroundGl groundGl = new GroundGl();
    private volatile boolean groundOk;
    public volatile boolean showGround = true;
    static final int PANO_W = 256, PANO_H = 128;
    private int panoTex, panoFbo, reedTex, yardTex;

    /** Phase 3: der Himmel (Kern ohne Grafikkarte; die Uhr gibt Zeit und Ort, die Kamera die Augenhöhe). */
    public final Sky sky = new Sky();
    private final SkyGl skyGl = new SkyGl();
    private volatile boolean skyOk;
    private volatile String skyCheck = "";
    /** Augenanpassung: geglättete Leuchtdichte, Leuchtdichte im Blickfeld, Zeit bis zur nächsten Messung. */
    private double adaptLum = -1, viewLum = -1, viewTimer;
    /** Anteil der Anpassung (1 = volle, 0 = keine); 0,85 lässt die Nacht Nacht bleiben (wie Lighthouse). */
    public volatile double adaptation = 0.85;
    /** Phase 3: die Wolken (die Verdrahtung gibt Bedeckung, Art und Wind in Wolkenhöhe). */
    public final Clouds clouds = new Clouds();
    private final CloudGl cloudGl = new CloudGl();
    private volatile boolean cloudsOk;
    private volatile String cloudCheck = "";
    private double cloudShade = 1;
    public volatile boolean showClouds = true;
    /** Phase 3: Regen. */
    public final Rain rain = new Rain();
    private final RainGl rainGl = new RainGl();
    private volatile boolean rainOk;
    private volatile String rainCheck = "";
    public volatile boolean showRain = true;
    /** Deckkraft des Regens 0..2 (Bedienfeld). */
    public volatile double rainStrength = 1;
    /** Phase 12: Schneefall um das Auge und Eis auf dem Noor (com.dan.season). */
    private final SnowfallGl snowfallGl = new SnowfallGl();
    private final IceGl iceGl = new IceGl();
    private volatile boolean snowOk, iceOk;
    public volatile boolean showSnow = true, showIce = true;
    /** Ein Jahr für Werkzeuge ohne Verdrahtung (nur die Pflanzen nach dem Datum). */
    private static final Year BARE_YEAR = new Year();
    private double lastEpochMs = Double.NaN;
    /** Phase 3: Strahlungsnebel über Noor und Niederung. */
    public final Fog fog = new Fog();
    private final FogGl fogGl = new FogGl();
    private volatile boolean fogOk;
    private volatile String fogCheck = "";
    public volatile boolean showFog = true;
    /** Phase 3: das Gewitter. */
    public final Lightning lightning = new Lightning();
    private final LightningGl lightningGl = new LightningGl();
    private volatile boolean lightningOk;
    private volatile String lightningCheck = "";
    private Lightning.Snapshot lightningSnap;
    public volatile boolean showLightning = true;
    /** Wie weit die Belichtung im Blitz nachgibt (1 = gar nicht); erholt sich in einer Viertelsekunde. */
    private double flashGive = 1;
    private double[] lightningSeenFrom;
    private volatile String lastBoltText = "";
    private double weatherCpuMs;
    private int depthCopyTex, depthCopyFbo, depthCopyW, depthCopyH;

    private volatile Quality quality = Quality.MITTEL;
    public volatile double renderScale = quality.renderScale;
    /**
     * Die Auflösung regelt sich selbst (aus Lighthouse, Phase 16 dort). Liegt die Grafikkarte über dem Budget für
     * {@link #targetFps}, sinkt {@link #renderScale} bis auf {@link #MIN_SCALE}; hat sie Luft, steigt er wieder bis zur
     * Stufe. Geregelt wird höchstens alle 1,5 s in Schritten von 5 %.
     */
    public volatile boolean autoScale = true;
    public volatile double targetFps = 60;
    public static final double MIN_SCALE = 0.5;
    private long scaleNanos;
    private int scaleSteps;
    /** HUD: kurz (drei Zeilen), voll oder aus; H schaltet kurz → voll → aus → kurz. */
    public volatile boolean showHud = true, hudFull;
    /** Marken auf der Bühne (Noor, Wall, Bach, Hochburg, Raster). */
    public volatile boolean showMarks = false;
    /** Uhr und Kamera stehen (Standbilder schalten selbst weiter). */
    public volatile boolean frozen;
    /** Belichtungskorrektur in Blendenstufen. */
    public volatile double exposureBias;
    /**
     * Phase 17: wie stark sich das Auge nachts an helle Bildteile anpasst (0 aus, 1 ganz). 0,5 zieht die Belichtung
     * auf das geometrische Mittel zwischen Nacht und Bild.
     */
    public volatile double bildAnpassung = 0.5;
    private volatile double frameLum = -1, bildZiel;
    private int lumPbo, lumN = 1;
    private double lumPre = 1;
    private long lumLast;
    private boolean lumPending, lumBroken;
    public volatile boolean photoRequest;
    /** Das nächste fertige Fensterbild an diesen Empfänger (einmal; im GL-Faden), etwa für die Vorschau einer gemerkten Ansicht. */
    public volatile java.util.function.Consumer<BufferedImage> grabRequest;
    /** Phase 7: die Kamerafahrt „Über den Wall“ auf dem Wehrgang (null ohne Höhendaten). */
    public final com.dan.haithabu.camera.Fahrt fahrtWall;
    /** Phase 11: die Kamerafahrt „Durch die Gasse“ am Bach ins Versammlungshaus (null ohne Haus). */
    public volatile com.dan.haithabu.camera.Fahrt fahrtGasse;
    private volatile com.dan.haithabu.camera.Fahrt pendingBf;
    private volatile int pendingBfN;
    private com.dan.haithabu.camera.Fahrt bf;
    private int bfN, bfIndex, bfWait;
    private BufferedImage[] bfFrames;
    private String[] bfCaps;
    private boolean bfHud;
    private double bfGpuSum, bfFpsSum;
    private int bfSamples;
    /** Phase 12: Bildfolge „Jahr“ — dieselbe Ansicht an mehreren Daten (null = eine Fahrt). */
    private java.time.LocalDate[] bfDates, pendingDates;
    /** Phase 13: Bildfolge über benannte Ansichten zu einer Uhrzeit (null = keine). */
    private java.util.List<com.dan.haithabu.camera.Ansichten.Ansicht> bfViews, pendingViews;
    private double bfViewHour;
    private double[] bfViewHours;
    private double[] bfPose;
    private java.time.LocalDate bfOldDate;
    private double bfOldHour;
    /** Ordner für Fotos (F12); ohne Angabe {@code docs/status} im Arbeitsverzeichnis (Werkbuch, Abschnitt 7). */
    public volatile File photoDir;

    private final Shader skyShader = new Shader("Himmel", null, "fullscreen.vert", "sky.frag"),
            skyPano = new Shader("Himmelspanorama", null, "fullscreen.vert", "skypano.frag"),
            terrainShader = new Shader("Gelände", null, "terrain.vert", "terrain.frag"),
            post = new Shader("Nachbearbeitung", null, "fullscreen.vert", "post.frag"),
            overlay = new Shader("Überlagerung", null, "fullscreen.vert", "overlay.frag");
    private final Shader[] all = {skyShader, skyPano, terrainShader, post, overlay};
    private final HudOverlay hud = new HudOverlay();
    private int emptyVao, hdrTex, depthTex, hdrFbo, hdrW, hdrH, surfW = 1, surfH = 1, defaultFbo;
    private boolean reversedZ, ready;
    private final int[][] stamp = new int[2][MARKS];
    private final double[] passMs = new double[MARKS - 1];
    private int frame;
    private long lastNanos, statsNanos;
    private int statsFrames;
    private double fps, gpuMs, cpuMs, worstMs;
    private volatile String glInfo = "", error;
    private volatile ComputeProbe.Result compute;
    private volatile boolean reloadShaders;
    private Consumer<String> statusListener = s -> { };
    private Consumer<String> errorListener = s -> { };
    private volatile String photoMsg = "";
    private volatile long photoMsgUntil;

    public Renderer(SceneClock clock, Wiring wiring) { this(clock, wiring, Terrain.load(Terrain.defaultDir())); }

    public Renderer(SceneClock clock, Wiring wiring, Terrain terrain) {
        this.clock = clock;
        this.wiring = wiring;
        this.terrain = terrain;
        this.vegetation = new Vegetation(terrain);
        this.forestGl = new ForestGl(Vegetation.species(), 4, 950);
        this.forest = new ForestField(4, 4, vegetation, vegetation.forestGround(), 950);
        forest.setHeights(forestGl.heights());
        this.siedlung = siedlungsLader.apply(terrain);
        vegetation.siedlung = siedlung;
        ocean.obstacleField = siedlung.hafen != null ? siedlung.hafen.feld : null;   // Phase 8: Brandungsring an den Pfählen
        this.flotte = Flotte.of(terrain, siedlung.hafen);                            // Phase 9: Schiffe
        this.feuer = Feuer.of(terrain, siedlung);                                    // Phase 10: Feuer und Rauch
        this.leben = com.dan.haithabu.scene.Leben.of(terrain, siedlung);             // Phase 13: Vögel und Haustiere
        sound.volume = 0.8;
        this.klang = com.dan.haithabu.scene.Klang.into(sound, terrain, siedlung, feuer, leben, flotte, vegetation);   // Phase 14: Klang
        lightning.onThunder = th -> { com.dan.haithabu.scene.Klang k = klang; if (k != null) k.thunder(th); };
        this.fahrtWall = terrain.befestigung != null ? new com.dan.haithabu.camera.Fahrt("Über den Wall", terrain.befestigung.fahrt(), 150, 32, 5) : null;
        hallViews(siedlung);
        weathering.salt = 0;
        weathering.algae = 0;
        weathering.rust = 0;
        this.meadow = new Meadow(Biome.schlei(), new com.dan.haithabu.scene.Bodendecke(terrain, vegetation));
        meadow.radius = 24;
        meadow.near = 6.5f;
        meadow.seed = 950;
        this.brook = Brook.of(terrain);
        sky.latDeg = Site.LAT;
        sky.lonDeg = Site.LON;
        sky.epochMillis = clock.epochMillis();
        fog.seed = 950;
        lightning.seed = 950;
        // das Rauschen der Wolken (8 MB, 0,5 bis 3 s) schon jetzt im Hintergrund rechnen
        Thread nt = new Thread(() -> { Noise.base(); Noise.detail(); Noise.weather(); }, "cloud-noise");
        nt.setDaemon(true);
        nt.start();
        setQuality(quality);
        if (wiring != null) {
            wiring.terrain = terrain;
            wiring.feed(ocean);
            wiring.feed(reed);
            wiring.feed(sky, 10);
        }
        camera.groundLevel = terrain.height(camera.eye[0], camera.eye[2]);
        camera.snap();
    }

    public Renderer() { this(new SceneClock(), null, Terrain.flat()); }

    // ------------------------------------------------------------------ Zugriff
    public void setStatusListener(Consumer<String> l) { statusListener = l; }
    public void setErrorListener(Consumer<String> l) { errorListener = l; }
    public String glInfo() { return glInfo; }
    public String error() { return error; }
    public double fps() { return fps; }
    public double gpuMs() { return gpuMs; }
    public double cpuMs() { return cpuMs; }
    public boolean reversedDepth() { return reversedZ; }
    public ComputeProbe.Result compute() { return compute; }
    public Quality quality() { return quality; }
    public void requestShaderReload() { reloadShaders = true; }
    public double[] lastPassTimes() { return passMs.clone(); }
    public long frames() { return frame; }
    public double takeWorstFrameMs() { double w = worstMs; worstMs = 0; return w; }
    /** Die Programme der App (für die Prüfung). */
    public static String[][] shaderFiles() {
        return new String[][]{{"fullscreen.vert", "sky.frag"}, {"fullscreen.vert", "skypano.frag"}, {"terrain.vert", "terrain.frag"},
                {"fullscreen.vert", "post.frag"}, {"fullscreen.vert", "overlay.frag"}, {"probe.comp"}};
    }

    public void setQuality(Quality q) {
        quality = q;
        renderScale = q.renderScale;
        lod.lodRange = q.terrainRange;
        ocean.quality = q.ocean;
        reed.quality = q.reed;
        clouds.quality = q.clouds;
        rain.quality = q.rain;
        fog.quality = q.fog;
        lightning.quality = q.lightning;
        if (forest != null) forest.apply(q.forest);
        timber.quality = q.timber;
        sunShadow.half = q.shadowHalf;
        stufenNachziehen();
    }

    /**
     * Phase 17: die Stufen der Teile, die mit einer neuen Siedlung neu entstehen (Flotte, Leben), und der Bodendecke;
     * je Bild aufgerufen, damit auch eine neu geladene Siedlung die Stufe trägt.
     */
    private void stufenNachziehen() {
        Quality q = quality;
        smoke.quality = q.smoke;
        Flotte fl = flotte;
        if (fl != null) fl.spray.quality = q.spray;
        var lb = leben;
        if (lb != null) lb.flock.quality = q.flock;
        if (meadow != null && meadow.radius != (float) q.groundRadius) meadow.radius = (float) q.groundRadius;
        if (sound.quality != q.sound) sound.quality = q.sound;
        if (weathering.quality != q.weathering) weathering.quality = q.weathering;
    }

    public boolean oceanRunning() { return oceanOk; }
    public String oceanCheck() { return oceanCheck; }
    public String reedInfo() { return reedGl.info(); }
    public String forestInfo() { return forestOk ? forestGl.info() : "Wald: nicht gestartet"; }
    public boolean forestReady() { return forestOk && forestGl.ready(); }
    public String housesInfo() {
        return timberOk ? siedlung.describe() + (terrain.befestigung != null ? "<br>" + terrain.befestigung.describe() : "") + (siedlung.hafen != null ? "<br>" + siedlung.hafen.describe() : "") + "<br>" + timberGl.info() + String.format(Locale.GERMAN, " · Nässe %.0f %%", weathering.snapshot().rainWet() * 100) : "Häuser: nicht gestartet";
    }
    public TerrainLod lod() { return lod; }

    /**
     * Belichtung. Mit {@code com.dan.sky}: aus der geglätteten Anpassungsleuchtdichte mit nur teilweiser Anpassung
     * ({@link #adaptation}); im Blitz gibt sie kurz nach. Ohne: aus der Helligkeitstabelle von Phase 1.
     */
    public double exposure() {
        if (skyOk && adaptLum > 0) return Sky.State.exposureFor(adaptLum, adaptation) * Math.pow(2, exposureBias) / flashGive;
        double b = Sun.skyBrightness(clock.sun()[0]);
        return 0.6 * Math.pow(b, -0.85) * Math.pow(2, exposureBias);
    }

    public boolean skyRunning() { return skyOk; }
    public boolean cloudsRunning() { return cloudsOk; }
    public boolean rainRunning() { return rainOk; }
    public boolean fogRunning() { return fogOk; }
    public boolean lightningRunning() { return lightningOk; }
    public double cloudShade() { return cloudShade; }
    public String skyCheck() { return skyCheck; }
    public String cloudCheck() { return cloudCheck; }

    /** Der aktuelle Himmelszustand (nie null nach dem ersten Schritt). */
    public Sky.State skyState() {
        Sky.State st = sky.state();
        return st != null ? st : sky.update();
    }

    /** Augenanpassung neu (nach Sprüngen der Uhr oder der Kamera). */
    public void readapt() {
        viewLum = -1;
        adaptLum = -1;
        adapt(skyState(), 1);
    }

    /** Senkrechter Bildwinkel in Grad. */
    public double fovy() { return Camera.FOVY; }

    // ------------------------------------------------------------------ Lebenslauf

    @Override
    public void init(GLAutoDrawable d) {
        GL4 gl = d.getGL().getGL4();
        int major = d.getContext().getGLVersionNumber().getMajor(), minor = d.getContext().getGLVersionNumber().getMinor();
        String renderer = gl.glGetString(GL.GL_RENDERER), vendor = gl.glGetString(GL.GL_VENDOR), version = gl.glGetString(GL.GL_VERSION);
        glInfo = renderer + " · OpenGL " + major + "." + minor;
        System.out.println("Haithabu: " + vendor + " · " + renderer + " · " + version);
        if (major < MIN_MAJOR || (major == MIN_MAJOR && minor < MIN_MINOR)) {
            fail("Die Grafikkarte meldet OpenGL " + major + "." + minor + " (" + renderer + ", Treiber " + version
                    + "). Haithabu braucht OpenGL " + MIN_MAJOR + "." + MIN_MINOR + ".\nBitte den Grafiktreiber aktualisieren.");
            return;
        }
        gl.setSwapInterval(1);
        defaultFbo = d.getContext().getDefaultDrawFramebuffer();
        reversedZ = (major > 4 || minor >= 5) || gl.isExtensionAvailable("GL_ARB_clip_control");
        if (reversedZ) gl.glClipControl(GL4.GL_LOWER_LEFT, GL4.GL_ZERO_TO_ONE);
        try {
            for (Shader s : all) s.build(gl);
        } catch (RuntimeException e) {
            fail(e.getMessage());
            return;
        }
        int[] v = new int[1];
        gl.glGenVertexArrays(1, v, 0);
        emptyVao = v[0];
        for (int[] s : stamp) gl.glGenQueries(MARKS, s, 0);
        compute = ComputeProbe.run(gl);
        System.out.println("Haithabu: " + compute.line());
        // Phase 2: Gelände, Schilfkarte, Himmelspanorama, Noor, Halme
        lod.upload(gl, terrain);
        reedTex = reedTexture(gl, vegetation);
        if (brook != null) {
            brookTex = Gpu.texture(gl, brook.nx, brook.nz, GL.GL_RGBA16F, false);
            gl.glBindTexture(GL.GL_TEXTURE_2D, brookTex);
            gl.glTexSubImage2D(GL.GL_TEXTURE_2D, 0, 0, 0, brook.nx, brook.nz, GL.GL_RGBA, GL.GL_FLOAT, Buffers.newDirectFloatBuffer(brook.data));
            gl.glBindTexture(GL.GL_TEXTURE_2D, 0);
        }
        panoTex = Gpu.texture(gl, PANO_W, PANO_H, GL.GL_RGBA16F, false);
        gl.glBindTexture(GL.GL_TEXTURE_2D, panoTex);
        gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_S, GL.GL_REPEAT);
        gl.glBindTexture(GL.GL_TEXTURE_2D, 0);
        panoFbo = Gpu.fbo(gl, panoTex, 0);
        System.out.println("Haithabu: Gelände " + terrain.describe());
        if (compute.ok()) {
            try {
                oceanGl.init(gl);
                oceanOk = true;
                System.out.println("Haithabu: Noor " + oceanGl.info());
            } catch (RuntimeException e) {
                System.err.println("Haithabu: Noor nicht verfügbar: " + e.getMessage());
                errorListener.accept("Das Noor (com.dan.ocean) lässt sich nicht starten.\n" + e.getMessage());
            }
        }
        try {
            reedGl.init(gl);
            reedOk = true;
        } catch (RuntimeException e) {
            System.err.println("Haithabu: Halme nicht verfügbar: " + e.getMessage());
            errorListener.accept("Schilf und Gras (com.dan.reed) lassen sich nicht starten.\n" + e.getMessage());
        }
        // Phase 2b: Wald (die Netze werden im Hintergrund für den Tag gebacken) und Sonnenschatten
        try {
            forestGl.init(gl);
            forestGl.setSeason(yearNow().doy(), Math.round(yearNow().treeSnow() * 4) / 4f);   // Phase 12: in Vierteln, damit der Wald nicht dauernd neu backt
            sunShadow.ensure(gl, quality.shadowSize);
            forestOk = true;
        } catch (RuntimeException e) {
            System.err.println("Haithabu: Wald nicht verfügbar: " + e.getMessage());
            errorListener.accept("Der Wald (com.dan.forest) lässt sich nicht starten.\n" + e.getMessage());
        }
        try {
            timberGl.init(gl, timber);
            uploadSiedlung(gl, siedlung);
            uploadHall(gl);
            timberOk = true;
            System.out.println("Haithabu: " + siedlung.describe());
        } catch (RuntimeException e) {
            System.err.println("Haithabu: Häuser nicht verfügbar: " + e.getMessage());
            errorListener.accept("Die Häuser (com.dan.timber) lassen sich nicht starten.\n" + e.getMessage());
        }
        try {
            longshipGl.init(gl);
            shipsOk = true;
        } catch (RuntimeException e) {
            System.err.println("Haithabu: Schiffe nicht verfügbar: " + e.getMessage());
            errorListener.accept("Die Schiffe (com.dan.longship) lassen sich nicht starten.\n" + e.getMessage());
        }
        try {
            sprayGl.init(gl);
            sprayOk = true;
        } catch (RuntimeException e) {
            System.err.println("Haithabu: Spritzer nicht verfügbar: " + e.getMessage());
        }
        // Phase 13: Vögel und Haustiere
        try {
            flockGl.init(gl);
            birdsOk = true;
        } catch (RuntimeException e) {
            System.err.println("Haithabu: Vögel nicht verfügbar: " + e.getMessage());
            errorListener.accept("Die Vögel (com.dan.flock) lassen sich nicht starten.\n" + e.getMessage());
        }
        try {
            herdGl.init(gl);
            animalsOk = true;
        } catch (RuntimeException e) {
            System.err.println("Haithabu: Haustiere nicht verfügbar: " + e.getMessage());
            errorListener.accept("Die Haustiere (com.dan.herd) lassen sich nicht starten.\n" + e.getMessage());
        }
        try {
            smokeGl.init(gl);
            smokeOk = true;
        } catch (RuntimeException e) {
            System.err.println("Haithabu: Rauch nicht verfügbar: " + e.getMessage());
            errorListener.accept("Der Rauch (com.dan.smoke) lässt sich nicht starten.\n" + e.getMessage());
        }
        try {
            roomSmokeGl.init(gl);
            roomSmokeOk = true;
        } catch (RuntimeException e) {
            System.err.println("Haithabu: Rauch im Haus nicht verfügbar: " + e.getMessage());
            errorListener.accept("Der Rauch im Versammlungshaus (com.dan.smoke.RoomSmoke) lässt sich nicht starten.\n" + e.getMessage());
        }
        try {
            hearthGl.init(gl);
            hearthOk = true;
        } catch (RuntimeException e) {
            System.err.println("Haithabu: Feuer nicht verfügbar: " + e.getMessage());
            errorListener.accept("Das Feuer (com.dan.hearth) lässt sich nicht starten.\n" + e.getMessage());
        }
        try {
            groundGl.init(gl);
            groundOk = true;
        } catch (RuntimeException e) {
            System.err.println("Haithabu: Bodendecke nicht verfügbar: " + e.getMessage());
            errorListener.accept("Die Bodendecke (com.dan.ground) lässt sich nicht starten.\n" + e.getMessage());
        }
        // Phase 3: Himmel, Wolken, Regen, Nebel, Blitz (jedes für sich; was nicht startet, fehlt, der Rest läuft)
        try {
            skyGl.init(gl);
            skyOk = true;
            System.out.println("Haithabu: Himmel " + skyGl.info());
        } catch (RuntimeException e) {
            System.err.println("Haithabu: Himmel nicht verfügbar, Verlauf aus Phase 1: " + e.getMessage());
            errorListener.accept("Der Himmel (com.dan.sky) lässt sich nicht starten, es bleibt ein einfacher Verlauf.\n" + e.getMessage());
        }
        if (skyOk) {
            try {
                cloudGl.init(gl);
                cloudsOk = true;
                if (wiring != null) wiring.cloudsDrawn = true;
                System.out.println("Haithabu: Wolken " + cloudGl.info());
            } catch (RuntimeException e) {
                System.err.println("Haithabu: Wolken nicht verfügbar: " + e.getMessage());
                errorListener.accept("Die Wolken (com.dan.cloud) lassen sich nicht starten, es bleibt der Schleier des Himmels.\n" + e.getMessage());
            }
        }
        try {
            rainGl.init(gl);
            rainOk = true;
        } catch (RuntimeException e) {
            System.err.println("Haithabu: Regen nicht verfügbar: " + e.getMessage());
            errorListener.accept("Der Regen (com.dan.rain) lässt sich nicht starten.\n" + e.getMessage());
        }
        // Phase 12: Schneefall und Eis
        try {
            snowfallGl.init(gl);
            snowOk = true;
            iceGl.init(gl);
            iceOk = true;
        } catch (RuntimeException e) {
            System.err.println("Haithabu: Schnee oder Eis nicht verfügbar: " + e.getMessage());
            errorListener.accept("Schneefall oder Eis (com.dan.season) lassen sich nicht starten.\n" + e.getMessage());
        }
        try {
            fogGl.init(gl);
            fogOk = true;
        } catch (RuntimeException e) {
            System.err.println("Haithabu: Nebel nicht verfügbar: " + e.getMessage());
            errorListener.accept("Der Nebel (com.dan.fog) lässt sich nicht starten.\n" + e.getMessage());
        }
        try {
            lightningGl.init(gl);
            lightningOk = true;
        } catch (RuntimeException e) {
            System.err.println("Haithabu: Gewitter nicht verfügbar: " + e.getMessage());
            errorListener.accept("Das Gewitter (com.dan.lightning) lässt sich nicht starten.\n" + e.getMessage());
        }
        lastNanos = System.nanoTime();
        statsNanos = lastNanos;
        camera.snap();
        ready = true;
    }

    @Override
    public void reshape(GLAutoDrawable d, int x, int y, int w, int h) {
        surfW = Math.max(1, d.getSurfaceWidth());
        surfH = Math.max(1, d.getSurfaceHeight());
    }

    /** Uhr und Kamera um dt weiterrechnen (vom Bildlauf aufgerufen; Standbilder rufen es mit festem dt). */
    public void step(double dt) {
        stufenNachziehen();
        clock.step(dt);
        // Phase 15: Regiebuch und Tagesregie
        regie.step(dt, regieCtx);
        double hNow = clock.hour();
        if (tagesregie && !regie.running() && !Double.isNaN(lastHourTR)) com.dan.haithabu.scene.Regie.tagesregie(lastHourTR, hNow, flotte, regieCtx);
        lastHourTR = hNow;
        if (regie.running()) { albumGpu += gpuMs; albumFps += fps; albumSamples++; }
        // Phase 5: Nässe nach Regen für Häuser und Bäume (trocknet mit Wind und Sonne)
        weathering.rainRate = showRain ? rain.rate : 0;
        weathering.windSpeed = wiring != null ? wiring.wind.speed() : 4;
        weathering.sun = Math.max(0, Math.min(1, clock.sun()[0] / 25.0)) * cloudShade;
        weathering.step(dt * Math.max(0, clock.lapse));
        long t0 = System.nanoTime();
        double level = wiring != null ? wiring.waterLevel.level() : 0;
        // Phase 3: zuerst die Wetterregie, dann bekommen alle Packages ihre Eingänge
        if (wiring != null) {
            if (wiring.regie) wiring.feedWeather(dt);
            // Phase 12: das Jahr (Szenenzeit seit dem letzten Bild; ein Sprung im Kalender rechnet vor)
            double em = clock.epochMillis();
            if (wiring.yearOn) wiring.feedYear(Double.isNaN(lastEpochMs) ? 0 : (em - lastEpochMs) / 1000, clock.sun()[0]);
            lastEpochMs = em;
            wiring.feed(ocean);
            wiring.feed(reed);
            wiring.feed(sky, camera.eye[1] - level);
            wiring.feed(clouds);
        } else {
            sky.epochMillis = clock.epochMillis();
        }
        Sky.State st = sky.step(dt);
        clouds.step(dt);
        // Wolkenschatten am Auge (für Halme, Nebel, Regen; Gelände und Noor lesen die Schattenkarte)
        cloudShade = cloudsOk && showClouds ? Clouds.shadow(clouds.snapshot(), camera.eye[0], camera.eye[2], keyDir(st)) : 1;
        adapt(st, dt);
        if (wiring != null) {
            wiring.feed(rain, clouds, clouds.snapshot(), cloudsOk && showClouds, camera.eye.clone());
            wiring.feed(fog, st.sunAlt);
            wiring.feed(lightning, clouds.snapshot(), cloudsOk && showClouds, camera.eye);
        }
        if (!showRain) rain.rate = 0;
        rain.step(dt);
        fog.step(dt);
        stepLightning(dt);
        weatherCpuMs = weatherCpuMs * 0.95 + (System.nanoTime() - t0) / 1e6 * 0.05;
        ocean.step(dt);
        // Phase 9: die Schiffe (Wind der Regie, am Noor abgeschwächt) und ihre Umrisse für das Wasser
        Flotte fl = flotte;
        if (fl != null) {
            long ts = System.nanoTime();
            double wf = wiring != null ? wiring.wind.fromDeg() : 245, ws = (wiring != null ? wiring.wind.speed() : Beaufort.mid(3)) * Wiring.LAND_WIND;
            fl.step(dt, ocean, wf, ws);
            if (!showShips) ocean.hulls = java.util.List.of();
            shipsCpuMs = shipsCpuMs * 0.95 + (System.nanoTime() - ts) / 1e6 * 0.05;
        } else ocean.hulls = java.util.List.of();
        // Phase 10: Herde nach dem Tagesgang, Rauch mit dem Wind am Noor und der Stabilität der Luft (Abendinversion)
        Feuer fe = feuer;
        if (fe != null) {
            long tf = System.nanoTime();
            // Phase 11: in Szenenzeit (Zeitraffer), damit Glut und Rauch im Haus mit der Uhr gehen
            // Phase 16 (Befund Phase 15): springt die Uhr, stehen die Feuer gleich auf der neuen Stunde
            double nowMs = clock.epochMillis(), soll = lastClockMs + dt * Math.max(0, clock.lapse) * 1000;
            if (!Double.isNaN(lastClockMs) && Math.abs(nowMs - soll) > 15 * 60_000) fe.springen(clock.hour(), st.sunAlt);
            else fe.step(dt * Math.max(0, Math.min(SceneClock.MAX_LAPSE, clock.lapse)), clock.hour(), st.sunAlt);
            lastClockMs = nowMs;
            smoke.windFromDeg = wiring != null ? wiring.wind.fromDeg() : 245;
            smoke.windSpeed = (wiring != null ? wiring.wind.speed() : Beaufort.mid(3)) * Wiring.LAND_WIND;
            smoke.stability = Smoke.stability(st.sunAlt, smoke.windSpeed, st.cloudCover);
            com.dan.haithabu.scene.Brand br = fe.brand;
            if (br != null) {
                long tb = System.nanoTime();
                br.eye = camera.eye.clone();
                br.step(dt, smoke.windFromDeg, smoke.windSpeed, Math.min(1, weathering.snapshot().rainWet()));
                brandCpuMs = brandCpuMs * 0.95 + (System.nanoTime() - tb) / 1e6 * 0.05;
            }
            smoke.setSources(fe.sources());
            smoke.step(dt);
            fireCpuMs = fireCpuMs * 0.95 + (System.nanoTime() - tf) / 1e6 * 0.05;
        }
        // Phase 13: Vögel und Haustiere in Szenenzeit; das Auge, die Hunde und fahrende Schiffe stören die Vögel
        com.dan.haithabu.scene.Leben lb = leben;
        if (lb != null) {
            long tl = System.nanoTime();
            Year.State ys = yearNow();
            double lux = (st.skyIrradiance[1] + st.sunColor[1] * Math.max(0, st.sunDir[1])) * com.dan.sky.Sky.CD_PER_UNIT;
            java.util.List<double[]> boats = new java.util.ArrayList<>();
            Flotte fl2 = flotte;
            if (fl2 != null && showShips) for (com.dan.longship.Longship sh : fl2.drawn()) if (sh.mode != com.dan.longship.Longship.Mode.FEST) boats.add(new double[]{sh.x, 0.5, sh.z});
            lb.waterHeight = (x, z) -> ocean.heightAt(x, z);
            double lapseDt = dt * Math.max(0, Math.min(SceneClock.MAX_LAPSE, clock.lapse));
            lb.step(Math.min(3, lapseDt), camera.eye.clone(), st.sunAlt, lux, wiring != null ? wiring.wind.speed() : 4, wiring != null ? wiring.wind.fromDeg() : 245,
                    wiring != null ? wiring.rainRate : 0, ys.snowDepth() * ys.snowCover(), ys.doy(), level, ys.iceDepth(), boats);
            lifeCpuMs = lifeCpuMs * 0.95 + (System.nanoTime() - tl) / 1e6 * 0.05;
        }
        // Phase 14: der Klang bekommt Ohr, Wetter, Wasser und Uhrzeit (in echter Zeit; Rufe und Ruder kommen von selbst)
        com.dan.haithabu.scene.Klang kl = klang;
        if (kl != null) {
            long tk = System.nanoTime();
            Year.State ys = yearNow();
            Ocean.State os = ocean.state();
            double ws = (wiring != null ? wiring.wind.speed() : Beaufort.mid(3)) * Wiring.LAND_WIND;
            kl.feed(dt, camera.eye.clone(), camera.heading(), eyeInHall, clock.hour(), st.sunAlt, ws, wiring != null ? wiring.wind.fromDeg() : 245,
                    wiring != null ? wiring.wind.gustiness() : 0.2, wiring != null && showRain ? wiring.rainRate : 0, wiring != null ? wiring.airTempC : 11,
                    os.totalHs(), os.peakPeriod, level, ys.iceDepth() > 1.5);
            soundCpuMs = soundCpuMs * 0.95 + (System.nanoTime() - tk) / 1e6 * 0.05;
        }
        camera.groundLevel = terrain.height(camera.eye[0], camera.eye[2]);
        camera.targetGround = terrain.height(camera.tx, camera.tz);
        camera.waterLevel = ocean.waterLevel;
        camera.step(dt);
    }

    /**
     * Augenanpassung (wie Lighthouse): alle 0,2 s die Leuchtdichte im Blickfeld messen (auf dem Prozessor), mit der
     * des ganzen Himmels mitteln und über eine Sekunde glätten (logarithmisch, wie das Auge). Im Nebel wird es grauer,
     * aber nicht heller: die Anpassung bleibt beim Himmel darüber.
     */
    private void adapt(Sky.State st, double dt) {
        viewTimer -= dt;
        if (viewLum <= 0 || viewTimer <= 0) {
            viewLum = st.viewLuminance(camera.fwd.clone(), new double[]{0, 1, 0}, fovy(), surfW / (double) Math.max(1, surfH));
            viewTimer = 0.2;
        }
        double target = Math.sqrt(Math.max(1e-14, st.adaptation) * Math.max(1e-14, viewLum)) * (cloudsOk && showClouds ? clouds.brightnessFactor() : 1);
        // Phase 11 (Befund Phase 10): nachts bei Fackeln und Feuern passt sich das Auge an deren Licht an; im
        // Versammlungshaus an das Licht im Haus (Herd, Glut, Tageslicht durch die Öffnungen)
        lightAdapt(st);
        target = eyeInHall ? hallLum : target + fireLum;
        // Phase 17 (Befund 15b): nachts passt sich das Auge auch an das an, was im Bild hell ist, etwa einen fernen
        // Brand, dessen Licht das Auge nicht erreicht (von der Hochburg war der Rauch eine weiße Fläche)
        double nacht = nachtAnteil(st), fl = frameLum;
        if (!eyeInHall) target = bildZiel(target, fl, bildAnpassung, nacht);
        bildZiel = target;
        if (adaptLum <= 0 || frozen || dt > 0.5) adaptLum = target;
        else adaptLum = Math.exp(Math.log(adaptLum) + (Math.log(target) - Math.log(adaptLum)) * Math.min(1, dt / 1.0));
    }

    /**
     * Phase 11: Leuchtdichte, an die sich das Auge zusätzlich anpasst. Draußen die Flächen um das Auge im Licht der
     * Feuer (Beleuchtungsstärke am Auge mal Rückstrahlung 0,12 / π), im Haus die Leuchtdichte des Raums.
     */
    private void lightAdapt(Sky.State st) {
        Feuer fe = feuer;
        com.dan.haithabu.scene.Versammlungshaus h = fe != null ? fe.hall : null;
        double[] e = camera.eye;
        eyeInHall = h != null && h.contains(e[0], e[1], e[2]);
        double cdu = com.dan.sky.Sky.CD_PER_UNIT;
        if (h != null && h.distance(e[0], e[2]) < 40) {
            double horiz = st.skyIrradiance[1] + st.sunColor[1] * Math.max(0, st.sunDir[1]);
            hallLum = h.interiorLuminance(horiz, cdu, clock.t()) + st.sunColor[1] * h.sunPatch(st.sunDir) / h.room.surface() * 0.15 / Math.PI;
        }
        double ill = 0;
        if (fe != null && showFire) {
            for (double[] f : fe.lights(e[0], e[1], e[2], 8, 120)) {
                double d2 = sq(f[0] - e[0]) + sq(f[1] - e[1]) + sq(f[2] - e[2]) + 4;
                ill += (0.2126 * f[4] + 0.7152 * f[5] + 0.0722 * f[6]) / d2;
            }
        }
        fireLum = ill / cdu * 0.12 / Math.PI;
    }

    private static double sq(double v) { return v * v; }

    /**
     * Phase 17: das Ziel der Anpassung mit dem gemessenen Bild. Erst wenn das Bild mehr als dreimal so hell ist wie das
     * Ziel aus Himmel und Feuern am Auge, rückt das Ziel zum Bild hin: um den Anteil {@code anpassung}, gewichtet mit
     * der Nacht (0 am Tag). Ohne Messung (frameLum ≤ 0) bleibt es.
     */
    public static double bildZiel(double target, double frameLum, double anpassung, double nacht) {
        if (frameLum <= 3 * target || anpassung <= 0 || nacht <= 0 || target <= 0) return target;
        return target * Math.pow(frameLum / target, Math.min(1, anpassung) * Math.min(1, nacht));
    }

    /**
     * Phase 17: wie weit das Auge auf Nacht steht, nur aus Himmel und Sternen (0 am Tag, 1 in der Nacht); Grundlage
     * dafür, ob helle Bildteile die Anpassung ziehen dürfen.
     */
    static double nachtAnteil(Sky.State st) {
        double l = Math.log10(Math.max(1e-12, st.adaptation * com.dan.sky.Sky.CD_PER_UNIT));
        double t = Math.max(0, Math.min(1, (l - Math.log10(0.01)) / (Math.log10(10) - Math.log10(0.01))));
        return 1 - t * t * (3 - 2 * t);
    }

    /**
     * Phase 17 (Befund 15b): die mittlere Leuchtdichte des Bilds, viermal je Sekunde aus einer kleinen Mip-Stufe des
     * HDR-Bilds (etwa 16 × 10 Punkte), ohne auf die Grafikkarte zu warten: gelesen wird über einen Pufferspeicher erst
     * beim nächsten Mal. Die hellsten 3 % der Punkte zählen nicht, damit die Sonne allein nichts verstellt.
     */
    private void bildMessen(GL4 gl, int w, int h, double pre) {
        if (bildAnpassung <= 0 || lumBroken) { frameLum = -1; return; }
        long now = System.nanoTime();
        if (now - lumLast < 250_000_000L) return;
        lumLast = now;
        final int pack = com.jogamp.opengl.GL2ES3.GL_PIXEL_PACK_BUFFER;
        try {
            if (lumPbo == 0) {
                int[] b = new int[1];
                gl.glGenBuffers(1, b, 0);
                lumPbo = b[0];
                gl.glBindBuffer(pack, lumPbo);
                gl.glBufferData(pack, 64 * 64 * 16, null, com.jogamp.opengl.GL2ES3.GL_STREAM_READ);
                gl.glBindBuffer(pack, 0);
            }
            gl.glBindBuffer(pack, lumPbo);
            if (lumPending) {
                ByteBuffer m = gl.glMapBufferRange(pack, 0, (long) lumN * 16, GL.GL_MAP_READ_BIT);
                if (m != null) {
                    java.nio.FloatBuffer f = m.order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer();
                    double[] l = new double[lumN];
                    for (int i = 0; i < lumN; i++) l[i] = Math.max(0, 0.2126 * f.get(i * 4) + 0.7152 * f.get(i * 4 + 1) + 0.0722 * f.get(i * 4 + 2));
                    gl.glUnmapBuffer(pack);
                    java.util.Arrays.sort(l);
                    int n = Math.max(1, (int) Math.floor(lumN * 0.97));
                    double sum = 0;
                    for (int i = 0; i < n; i++) sum += l[i];
                    if (Double.isFinite(sum)) frameLum = sum / n / Math.max(1e-30, lumPre);
                } else gl.glUnmapBuffer(pack);
                lumPending = false;
            }
            gl.glActiveTexture(GL.GL_TEXTURE0);
            gl.glBindTexture(GL.GL_TEXTURE_2D, hdrTex);
            gl.glGenerateMipmap(GL.GL_TEXTURE_2D);
            int lv = 0, lw = w, lh = h;
            while (Math.max(lw, lh) > 16) { lv++; lw = Math.max(1, lw >> 1); lh = Math.max(1, lh >> 1); }
            gl.glPixelStorei(GL.GL_PACK_ALIGNMENT, 4);
            gl.glGetTexImage(GL.GL_TEXTURE_2D, lv, GL.GL_RGBA, GL.GL_FLOAT, 0L);
            gl.glBindBuffer(pack, 0);
            lumN = lw * lh;
            lumPre = pre;
            lumPending = true;
        } catch (RuntimeException e) {
            lumBroken = true;
            frameLum = -1;
            gl.glBindBuffer(pack, 0);
            System.err.println("Haithabu: Bild nicht messbar, Augenanpassung wie bisher: " + e.getMessage());
        }
    }

    /** „Bild 0,012 · Anpassung 0,004“ (HUD): gemessene mittlere Leuchtdichte und das Ziel des Auges. */
    public String bildLine() {
        return frameLum < 0 ? "Bild: nicht gemessen" : String.format(Locale.GERMAN, "Bild %.3g cd/m² · Auge auf %.3g cd/m²", frameLum * com.dan.sky.Sky.CD_PER_UNIT, bildZiel * com.dan.sky.Sky.CD_PER_UNIT);
    }

    /**
     * Anteil des Stäbchensehens wie {@code Sky.State#scotopic}, aber aus der Anpassung mit dem Licht der Feuer und im
     * Haus (Befund Phase 10: am Fackellicht war alles farblos blau).
     */
    private double scotopic(Sky.State st) {
        double a = st.adaptation;
        if (eyeInHall) a = Math.max(a * 1e-3, hallLum);
        else a += fireLum;
        double l = Math.log10(Math.max(1e-12, a * com.dan.sky.Sky.CD_PER_UNIT));
        double t = Math.max(0, Math.min(1, (l - Math.log10(0.003)) / (Math.log10(3) - Math.log10(0.003))));
        return 1 - t * t * (3 - 2 * t);
    }

    /** Das Gewitter in Szenenzeit weiter, Sichtbarkeit neu nach großen Sprüngen des Auges, Nachgeben der Belichtung. */
    private void stepLightning(double dt) {
        double sceneDt = dt * Math.max(0, clock.lapse);
        int before = lightning.flashes();
        lightning.step(Math.min(sceneDt, 1.0));
        double[] e = camera.eye;
        if (lightningSeenFrom == null || Math.hypot(e[0] - lightningSeenFrom[0], e[2] - lightningSeenFrom[2]) > 300 || Math.abs(e[1] - lightningSeenFrom[1]) > 100) {
            lightning.updateVisibility();
            lightningGl.invalidate();
            lightningSeenFrom = e.clone();
        }
        if (lightning.flashes() != before && !lightning.bolts().isEmpty()) lastBoltText = boltText(lightning.bolts().get(lightning.bolts().size() - 1));
        double base = exposure() * flashGive;
        double lf = showLightning ? lightning.snapshot().flashLuminance(e[0], e[1], e[2], lightning.cloudBase) : 0;
        double give = 1 + base * lf / 1.5;
        flashGive = frozen ? give : Math.max(give, flashGive * Math.exp(-Math.max(0, dt) / 0.25));
    }

    /** „Erdblitz 3,4 km NW, 31 kA, 4 Schläge“ */
    private String boltText(Bolt b) {
        double[] e = camera.eye;
        double d = Math.hypot(b.hitX - e[0], b.hitZ - e[2]), az = (Math.toDegrees(Math.atan2(b.hitX - e[0], -(b.hitZ - e[2]))) + 360) % 360;
        String[] dirs = {"N", "NO", "O", "SO", "S", "SW", "W", "NW"};
        String kind = switch (b.kind) {
            case CLOUD_GROUND -> "Erdblitz";
            case INTRA_CLOUD -> "Wolkenblitz";
            case SPIDER -> "Spinnenblitz";
            case SHEET -> "Wetterleuchten";
        };
        double ka = 0;
        for (double k : b.strokeKA) ka = Math.max(ka, k);
        return String.format(Locale.GERMAN, "%s %.1f km %s, %.0f kA", kind, d / 1000, dirs[(int) Math.round(az / 45) % 8], ka);
    }

    /** Auslöschung und Streuung der Luft für das Licht der Blitze (Dunst, Regen, Nebel am Auge), 1/m. */
    private double[] lightningAir() {
        double haze = wiring != null ? wiring.hazePerM() : 1.2e-4;
        double[] e = camera.eye;
        double r = rainOk && showRain ? rain.scatter(e[0], e[1], e[2]) * 3e-3 : 0;
        double f = fogOk && showFog ? fog.density(e[0], e[1], e[2]) : 0;
        return new double[]{haze + r + f, haze * 0.9 + r * 0.98 + f};
    }

    /** Einen Blitz von Hand auslösen (Bedienfeld): Erdblitz in 1,5 bis 4 km in Blickrichtung. */
    public Bolt triggerLightning(Bolt.Kind kind) {
        if (wiring != null) wiring.feed(lightning, clouds.snapshot(), cloudsOk && showClouds, camera.eye);
        double[] e = camera.eye, f = camera.fwd;
        double h = Math.hypot(f[0], f[2]), fx = h > 1e-6 ? f[0] / h : 0, fz = h > 1e-6 ? f[2] / h : -1, r = 1500 + Math.random() * 2500;
        return kind == Bolt.Kind.CLOUD_GROUND ? lightning.strike(e[0] + fx * r, e[2] + fz * r) : lightning.discharge(kind, e[0] + fx * r, e[2] + fz * r);
    }

    static boolean sunIsKey(Sky.State st) { return st.sunAlt > -4; }

    static double[] keyDir(Sky.State st) { return sunIsKey(st) ? st.sunDirTrue : st.moonDirTrue; }

    /** Licht für die Wolken aus dem Himmelszustand, vorbelichtet (wie Lighthouse). */
    CloudGl.Light cloudLight(Sky.State st, double pre) {
        CloudGl.Light l = new CloudGl.Light();
        boolean sun = sunIsKey(st);
        l.dir = keyDir(st);
        for (int i = 0; i < 8; i++) l.colorAt[i] = scale(sun ? st.sunColorAt(CloudGl.LIGHT_HEIGHTS[i]) : st.moonColorAt(CloudGl.LIGHT_HEIGHTS[i]), pre);
        double[] e = st.skyIrradiance;
        l.ambTop = scale(e, pre / Math.PI);
        double s = Math.max(0, st.sunDir[1]), m = Math.max(0, st.moonDir[1]);
        l.ambBot = new double[3];
        for (int c = 0; c < 3; c++) l.ambBot[c] = (e[c] + st.sunColor[c] * s + st.moonColor[c] * m) * 0.10 / Math.PI * pre;   // Wiesen statt See
        l.haze = st.groundExtinction;
        l.flash = new double[]{st.flashDir[0] * 5000, st.flashDir[1] * 5000, st.flashDir[2] * 5000, st.flash * pre};
        l.flashCount = 0;
        if (lightningOk && showLightning && lightningGl.active()) {
            int n = lightningGl.cloudLightCount();
            for (int i = 0; i < n; i++) {
                double[] c = lightningGl.cloudLight(i);
                for (int k = 0; k < 3; k++) {
                    l.flashPos[i * 4 + k] = (float) c[k];
                    l.flashRgb[i * 4 + k] = (float) (c[3] * Lightning.CHANNEL_RGB[k] * pre);
                }
            }
            l.flashCount = n;
        }
        return l;
    }

    /** Licht für Halme, Nebel und Regen: {Sonne, Mond, Himmel oben, Himmel am Horizont}, vorbelichtet. */
    private double[][] ambientLight(Sky.State st, double pre) {
        if (skyOk) {
            double[] top = st.radiance(new double[]{0, 1, 0}), hor = new double[3];
            for (int i = 0; i < 6; i++) {
                double a = Math.PI * i / 3;
                double[] h = st.radiance(norm3(new double[]{Math.sin(a), 0.08, -Math.cos(a)}));
                for (int k = 0; k < 3; k++) hor[k] += h[k] / 6;
            }
            // oben: das Himmelslicht als Bestrahlung/π (der tiefblaue Zenit allein gäbe nur ein Viertel davon)
            return new double[][]{scale(st.sunColor, pre * cloudShade), scale(st.moonColor, pre * cloudShade), scale(st.skyIrradiance, pre / Math.PI), scale(hor, pre)};
        }
        double[] sp = clock.sun();
        double[] sl = sunLight(sp[0]);
        return new double[][]{sl, {0, 0, 0}, skyZenith(sp[0]), skyHorizon(sp[0])};
    }

    /** Das stärkste Blitzlicht als Richtung und Bestrahlung am Auge (vorbelichtet), oder null (wie Lighthouse). */
    private double[][] flashLight(double pre) {
        if (!lightningOk || !showLightning || !lightningGl.active() || lightningGl.lightCount() == 0) return null;
        double[] e = camera.eye, dir = null;
        double bestL = 0;
        double[] tot = new double[3];
        for (int i = 0; i < lightningGl.lightCount(); i++) {
            double[] p = lightningGl.lightPos(i), c = lightningGl.lightRgb(i);
            double dx = p[0] - e[0], dy = p[1] - e[1], dz = p[2] - e[2], d2 = dx * dx + dy * dy + dz * dz + p[3] * p[3], d = Math.sqrt(dx * dx + dy * dy + dz * dz + 1);
            double el = (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / d2;
            for (int k = 0; k < 3; k++) tot[k] += c[k] / d2 * pre;
            if (el > bestL) { bestL = el; dir = new double[]{dx / d, dy / d, dz / d}; }
        }
        return dir == null ? null : new double[][]{dir, tot};
    }

    /** Dunstlänge für exp(−d/L) aus der Sichtweite (Koschmieder). */
    static double fogDistance(Sky.State st) { return st.visibilityKm * 1000 / 3.912; }

    static double[] scale(double[] v, double k) { return new double[]{v[0] * k, v[1] * k, v[2] * k}; }

    static double[] norm3(double[] v) { double l = Math.max(1e-12, Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])); return new double[]{v[0] / l, v[1] / l, v[2] / l}; }

    /** Schilf (R), Binsen (G), Wald (B) und Erlenbruch (A, Phase 2b) als Textur zu 2 m für das Gelände. */
    private static int reedTexture(GL4 gl, Vegetation v) {
        int m = Vegetation.M;
        java.nio.ByteBuffer b = Buffers.newDirectByteBuffer(m * m * 4);
        for (int k = 0; k < m * m; k++) b.put(v.reed[k]).put(v.rush[k]).put(v.wood[k]).put(v.alder[k]);
        b.flip();
        int t = Gpu.texture(gl, m, m, GL.GL_RGBA8, false);
        gl.glBindTexture(GL.GL_TEXTURE_2D, t);
        gl.glPixelStorei(GL.GL_UNPACK_ALIGNMENT, 1);
        gl.glTexSubImage2D(GL.GL_TEXTURE_2D, 0, 0, 0, m, m, GL.GL_RGBA, GL.GL_UNSIGNED_BYTE, b);
        gl.glPixelStorei(GL.GL_UNPACK_ALIGNMENT, 4);
        gl.glBindTexture(GL.GL_TEXTURE_2D, 0);
        return t;
    }

    /** Phase 6: eine neue Siedlung (Startwert, geladen) übernehmen; die Karten und Bauwerke lädt das nächste Bild hoch. */
    public void setSiedlung(Siedlung s) { nextSiedlung = s; }

    /** Ob eine neue Siedlung auf das nächste Bild wartet (dann sind Flotte, Feuer und Leben noch die alten). */
    public boolean siedlungWartet() { return nextSiedlung != null; }

    /** Eine kurze Meldung im Bild (4 s), wie nach einem Foto. */
    public void hudMeldung(String m) { photoMsg = m; photoMsgUntil = System.currentTimeMillis() + 4000; }

    /** Phase 11: Ansicht „Im Haus“ und Fahrt „Durch die Gasse“ zum Versammlungshaus der Siedlung. */
    private void hallViews(Siedlung s) {
        Feuer fe = feuer;
        com.dan.haithabu.scene.Versammlungshaus h = fe != null ? fe.hall : null;
        com.dan.haithabu.camera.Ansichten.imHaus = h != null ? h.imHaus() : null;
        if (h == null) { fahrtGasse = null; gasseView = null; return; }
        // Phase 14: „Gasse“ für die Bildfolge „Klang“: auf dem Bohlenweg zwischen Versammlungshaus und Kammmacher, Blick nach Osten
        double[][] g = h.gasse(s, terrain);
        double[] best = g[0];
        for (double[] q : g) if (Math.abs(q[0] + 95) < Math.abs(best[0] + 95)) best = q;
        gasseView = new com.dan.haithabu.camera.Ansichten.Ansicht(0, "Gasse", best[0], best[2], 88, 2, 1.7, false, 0);
        com.dan.haithabu.camera.Fahrt f = new com.dan.haithabu.camera.Fahrt("Durch die Gasse", h.gasse(s, terrain), 75, 0, 3);
        f.endHeading = h.imHaus()[3];
        f.endTurn = 6;
        fahrtGasse = f;
    }

    /** Phase 11: das Versammlungshaus mit offenen Türen, Rauchlöchern und Einrichtung als eigenes Netz für timber. */
    private void uploadHall(GL4 gl) {
        Feuer fe = feuer;
        com.dan.haithabu.scene.Versammlungshaus h = fe != null ? fe.hall : null;
        if (h == uploadedHall) return;
        timberGl.setSpecial(gl, h != null ? h.house : null, h != null ? h.mesh : null, 0);
        uploadedHall = h;
    }

    /** Das Versammlungshaus (Phase 11), oder null. */
    public com.dan.haithabu.scene.Versammlungshaus hall() {
        Feuer fe = feuer;
        return fe != null ? fe.hall : null;
    }

    /** Steht das Auge im Versammlungshaus? */
    public boolean eyeInHall() { return eyeInHall; }

    /** Bauwerke als Kacheln und die Bodenkarte (r Hof, g Lehmboden, b Garten) auf die Grafikkarte. */
    private void uploadSiedlung(GL4 gl, Siedlung s) {
        timberGl.setStructures(gl, s.bauwerke, 0.5);
        java.nio.ByteBuffer yb = Buffers.newDirectByteBuffer(Siedlung.NX * Siedlung.NZ * 4);
        for (int k = 0; k < Siedlung.NX * Siedlung.NZ; k++) yb.put(s.yard[k]).put(s.floor[k]).put(s.garden[k]).put((byte) 0);
        yb.flip();
        if (yardTex == 0) yardTex = Gpu.texture(gl, Siedlung.NX, Siedlung.NZ, GL.GL_RGBA8, false);
        gl.glBindTexture(GL.GL_TEXTURE_2D, yardTex);
        gl.glTexSubImage2D(GL.GL_TEXTURE_2D, 0, 0, 0, Siedlung.NX, Siedlung.NZ, GL.GL_RGBA, GL.GL_UNSIGNED_BYTE, yb);
        gl.glBindTexture(GL.GL_TEXTURE_2D, 0);
    }

    @Override
    public void display(GLAutoDrawable d) {
        GL4 gl = d.getGL().getGL4();
        if (!ready) {
            gl.glClearColor(0.06f, 0.075f, 0.07f, 1);
            gl.glClear(GL.GL_COLOR_BUFFER_BIT);
            return;
        }
        Siedlung ns = nextSiedlung;
        if (ns != null && timberOk) {
            nextSiedlung = null;
            try {
                uploadSiedlung(gl, ns);
                siedlung = ns;
                vegetation.siedlung = ns;
                ocean.obstacleField = ns.hafen != null ? ns.hafen.feld : null;
                camera.mitfahrt = null;
                flotte = Flotte.of(terrain, ns.hafen);
                feuer = Feuer.of(terrain, ns);
                leben = com.dan.haithabu.scene.Leben.of(terrain, ns);
                klang = com.dan.haithabu.scene.Klang.into(sound, terrain, ns, feuer, leben, flotte, vegetation);
                timber.burn = null;
                regie.stop();
                uploadHall(gl);
                hallViews(ns);
                meadow.clear();
                reedGl.invalidate();
                System.out.println("Haithabu: " + ns.describe());
            } catch (RuntimeException e) {
                System.err.println("Haithabu: neue Siedlung nicht geladen: " + e.getMessage());
            }
        }
        if (reloadShaders) {
            reloadShaders = false;
            try {
                for (Shader s : all) s.build(gl);
                System.out.println("Shader neu geladen.");
            } catch (RuntimeException e) {
                System.err.println(e.getMessage());
                errorListener.accept(e.getMessage());
            }
        }
        defaultFbo = d.getContext().getDefaultDrawFramebuffer();
        readMarks(gl);
        long now = System.nanoTime();
        double rawMs = (now - lastNanos) / 1e6;
        if (frame > 2 && rawMs > worstMs) worstMs = rawMs;
        double dt = Math.min(0.1, (now - lastNanos) / 1e9);
        lastNanos = now;
        com.dan.haithabu.camera.Fahrt pb = pendingBf;
        if (pb != null) {
            pendingBf = null;
            bf = pb;
            bfN = Math.max(2, pendingBfN);
            bfIndex = 0;
            bfFrames = new BufferedImage[bfN];
            bfCaps = new String[bfN];
            bfHud = showHud;
            showHud = false;
            bfGpuSum = bfFpsSum = 0;
            bfSamples = 0;
            bfDates = pendingDates;
            pendingDates = null;
            bfViews = pendingViews;
            pendingViews = null;
            if (bfViews != null) {
                bfN = bfViews.size();
                bfFrames = new BufferedImage[bfN];
                bfCaps = new String[bfN];
                bfOldDate = clock.date();
                bfOldHour = clock.hour();
                clock.setHour(bfViewHours != null ? bfViewHours[0] : bfViewHour);
            }
            if (bfDates != null) {
                bfN = bfDates.length;
                bfFrames = new BufferedImage[bfN];
                bfCaps = new String[bfN];
                bfPose = new double[]{camera.eye[0], camera.eye[1], camera.eye[2], camera.heading(), Math.toDegrees(Math.asin(Math.max(-1, Math.min(1, camera.fwd[1]))))};
                bfOldDate = clock.date();
                bfOldHour = clock.hour();
            }
            camera.stopFahrt();
            bildfolgePose();
        }
        if (!frozen) step(dt);

        surfW = Math.max(1, d.getSurfaceWidth());
        surfH = Math.max(1, d.getSurfaceHeight());
        regulateScale(now);
        int w = Math.max(64, (int) Math.round(surfW * renderScale)), h = Math.max(64, (int) Math.round(surfH * renderScale));
        if (w != hdrW || h != hdrH) resizeTargets(gl, w, h);
        renderFrame(gl, w, h);
        if (photoRequest) { photoRequest = false; takePhoto(gl, surfW, surfH); }
        java.util.function.Consumer<BufferedImage> gr = grabRequest;
        if (gr != null) { grabRequest = null; try { gr.accept(readDefault(gl, surfW, surfH)); } catch (RuntimeException e) { System.err.println("Haithabu: Bild nicht abgeholt: " + e); } }
        // Phase 15: Fotos eines Regiebuchs und das Blatt am Ende
        String cap = captureCaption;
        if (cap != null) {
            captureCaption = null;
            album.add(readDefault(gl, surfW, surfH));
            albumCaps.add(clock.timeLabel() + " · " + cap + "\nteuer: " + topPasses(3));
        }
        String sn = sheetName;
        if (sn != null) { sheetName = null; writeSheet(sn); }
        if (bf != null) bildfolgeStep(gl);
        cpuMs = cpuMs * 0.95 + (System.nanoTime() - now) / 1e6 * 0.05;
        frame++;
        stats(now, w, h);
    }

    /** Ein ganzes Bild in Rechengröße w × h, dann ins Fenster. */
    void renderFrame(GL4 gl, int w, int h) {
        mark(gl, 0);
        Sky.State st = skyState();
        if (adaptLum <= 0) adapt(st, 1);
        double pre = skyOk ? exposure() : 1;
        double[] sp = clock.sun();
        double[] sun = skyOk ? st.sunDir : Sun.direction(sp[0], sp[1]);
        float[] proj = Mat4.perspective(fovy(), w / (double) h, 0.2, 60_000, reversedZ);
        float[] vp = Mat4.mul(proj, camera.view());
        float[] inv = Mat4.invert(vp);
        double level = wiring != null ? wiring.waterLevel.level() : 0;
        fireLights(pre);

        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        gl.glClearColor(0, 0, 0, 1);
        gl.glClearDepth(reversedZ ? 0 : 1);
        gl.glDepthMask(true);
        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
        gl.glBindVertexArray(emptyVao);

        // 1 Himmel: com.dan.sky (Streuung, Sonne, Mond, Sterne von 950), sonst der Verlauf aus Phase 1
        gl.glDisable(GL.GL_DEPTH_TEST);
        gl.glDisable(GL.GL_CULL_FACE);
        if (skyOk) {
            skyGl.update(gl, st);
            gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
            gl.glViewport(0, 0, w, h);
            SkyGl.View sv = new SkyGl.View();
            sv.viewProj = vp;
            sv.invViewProj = inv;
            sv.reversedZ = reversedZ;
            sv.width = w;
            sv.height = h;
            sv.fovyDeg = fovy();
            sv.preExposure = pre;
            sv.time = clock.t();
            skyGl.draw(gl, st, sv);
            if (skyCheck.isEmpty() && frame > 30) skyCheck = skyGl.selfCheck(gl, st);
            gl.glBindVertexArray(emptyVao);
        } else {
            common(gl, skyShader, vp, inv, sun, level);
            gl.glDrawArrays(GL.GL_TRIANGLES, 0, 3);
        }
        mark(gl, 1);

        // Blitze übernehmen (neue Kanäle hochladen, Lichtpunkte für Wolken, Noor, Gelände)
        if (lightningOk) {
            lightningSnap = lightning.snapshot();
            lightningGl.update(gl, lightningSnap);
        }
        boolean flashNow = lightningOk && showLightning && lightningGl.active();
        double[] air = lightningAir();

        // 2 Wolken über den Himmel, Kanäle der Blitze, dann das Rundumbild (Spiegelung, Himmelslicht)
        boolean cloudsNow = cloudsOk && showClouds;
        Clouds.Snapshot cs = clouds.snapshot();
        CloudGl.Light cl = cloudsNow ? cloudLight(st, pre) : null;
        if (cloudsNow) {
            cloudGl.update(gl, cs, cl, camera.eye.clone());
            gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
            gl.glViewport(0, 0, w, h);
            CloudGl.View cv = new CloudGl.View();
            cv.viewProj = vp;
            cv.invViewProj = inv;
            cv.eye = camera.eye.clone();
            cv.reversedZ = reversedZ;
            cv.width = w;
            cv.height = h;
            cloudGl.draw(gl, cs, cl, cv);
            if (cloudCheck.isEmpty() && frame > 40) cloudCheck = cloudGl.selfCheck(gl, cs, cl);
            gl.glBindVertexArray(emptyVao);
        }
        if (flashNow) {
            lightningGl.drawChannels(gl, lightningView(vp, inv, w, h, pre, air));
            gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
            gl.glViewport(0, 0, w, h);
            gl.glBindVertexArray(emptyVao);
        }
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, panoFbo);
        gl.glViewport(0, 0, PANO_W, PANO_H);
        if (skyOk) {
            skyGl.drawPanorama(gl, st, pre);
            if (cloudsNow) cloudGl.drawPanorama(gl, cs, cl, camera.eye.clone());
            if (flashNow) lightningGl.drawPanorama(gl, PANO_W, PANO_H, camera.eye.clone(), pre, air[0], air[1], cloudsNow ? clouds.type.base : lightning.cloudBase);
            gl.glBindVertexArray(emptyVao);
        } else {
            common(gl, skyPano, vp, inv, sun, level);
            gl.glDrawArrays(GL.GL_TRIANGLES, 0, 3);
        }
        if (rainOk) {
            rainGl.update(gl, rain.snapshot());
            if (rainCheck.isEmpty() && rain.rate > 0 && frame > 60) rainCheck = rainGl.selfCheck(gl, rain.snapshot());
        }
        if (flashNow && lightningCheck.isEmpty()) {
            for (Bolt b : lightningSnap.bolts())
                if (b.kind == Bolt.Kind.CLOUD_GROUND && lightningSnap.time() > b.t0 + b.leaderTime) {
                    lightningCheck = lightningGl.selfCheck(gl, lightningSnap);
                    lightningGl.update(gl, lightningSnap);
                    break;
                }
        }
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        mark(gl, 2);

        // 2b Wald: Bäume für das Bild wählen, Instanzen hochladen, Sonnenschatten der Bäume um den Blickpunkt
        double[] to = wiring != null ? wiring.wind.toVector() : new double[]{0.9, 0, -0.4};
        double windSpeed = wiring != null ? wiring.wind.speed() : Beaufort.mid(3);
        boolean forestNow = forestOk && showForest;
        sunShadow.matrix = null;
        if (forestNow) {
            forestGl.setSeason(yearNow().doy(), Math.round(yearNow().treeSnow() * 4) / 4f);   // Phase 12: in Vierteln, damit der Wald nicht dauernd neu backt
            forestGl.setWind(to[0], to[2], windSpeed, 0.5);
            forest.update(camera.eye, vp, 24);
            forestGl.update(gl, forest);
        }
        boolean housesNow = timberOk && showHouses;
        boolean forestReady = forestNow && forestGl.ready();
        if (showSunShadow && sun[1] > 0.03 && (forestReady || housesNow)) {
            sunShadow.ensure(gl, quality.shadowSize);
            double[] c = shadowCenter();
            sunShadow.matrix = sunShadow.fit(sun, c[0], c[1], c[2]);
            sunShadow.begin(gl, reversedZ);
            if (forestReady) forestGl.drawShadow(gl, sunShadow.matrix, clock.t(), 3);
            if (housesNow) timberGl.drawShadow(gl, timber, siedlung.houses, sunShadow.matrix, c[0], c[2], sunShadow.half * 1.5);
            sunShadow.end(gl, reversedZ);
            gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
            gl.glViewport(0, 0, w, h);
        }
        mark(gl, 3);

        // 3 Gelände (Wolkenschatten aus der Karte, Mond, Blitzlicht). Himmel und Wolken lassen das Schreiben der Tiefe
        // aus; ohne sie hätten Nebel, Regen und Blitz keine Szenentiefe (Befund Phase 3).
        gl.glDepthMask(true);
        gl.glDisable(GL.GL_BLEND);
        gl.glEnable(GL.GL_DEPTH_TEST);
        gl.glDepthFunc(reversedZ ? GL.GL_GREATER : GL.GL_LESS);
        double[][] fl = flashLight(skyOk ? pre : 1);
        common(gl, terrainShader, vp, inv, sun, level);
        lod.bind(gl, terrainShader);
        gl.glActiveTexture(GL.GL_TEXTURE10);
        gl.glBindTexture(GL.GL_TEXTURE_2D, reedTex);
        gl.glActiveTexture(GL.GL_TEXTURE11);
        gl.glBindTexture(GL.GL_TEXTURE_2D, brookTex);
        gl.glActiveTexture(GL.GL_TEXTURE12);
        gl.glBindTexture(GL.GL_TEXTURE_2D, cloudsNow ? cloudGl.shadowTexture() : 0);
        gl.glActiveTexture(GL.GL_TEXTURE0);
        terrainShader.set(gl, "uReedMap", 10);
        terrainShader.set(gl, "uBrook", 11);
        terrainShader.set(gl, "uCloudShadow", 12);
        double[] sr = cloudsNow ? cloudGl.shadowRect() : new double[]{0, 0, 1};
        terrainShader.set(gl, "uCloudRect", (float) sr[0], (float) sr[1], (float) Math.max(1, sr[2]), cloudsNow ? 1f : 0f);
        terrainShader.set(gl, "uFlashDir", fl != null ? fl[0] : new double[]{0, 1, 0});
        terrainShader.set(gl, "uFlashRgb", fl != null ? fl[1] : new double[]{0, 0, 0});
        terrainShader.set(gl, "uFireN", fireN);
        terrainShader.vec4Array(gl, "uFirePos", firePos);
        terrainShader.vec4Array(gl, "uFireRgb", fireRgb);
        if (brook != null) terrainShader.set(gl, "uBrookRect", (float) brook.x0, (float) brook.z0, (float) (brook.nx * Brook.CELL), (float) (brook.nz * Brook.CELL));
        else terrainShader.set(gl, "uBrookRect", 0f, 0f, 0f, 0f);
        terrainShader.set(gl, "uReed", (float) (reedOk && showReed ? reed.range(Reed.Kind.SCHILF) * 0.85 : 0), reedOk && showReed ? 1f : 0f);
        terrainShader.set(gl, "uMarks", showMarks ? 1 : 0);
        terrainShader.set(gl, "uWindTo", (float) to[0], (float) to[2]);
        terrainShader.set(gl, "uWindSpeed", (float) windSpeed);
        terrainShader.set(gl, "uWet", (float) Math.min(1, rain.rate * (showRain ? 1 : 0) / 3));
        terrainShader.set(gl, "uWood", (float) (forest.radius * forest.thinFrom), (float) forest.radius, forestNow && forestGl.ready() ? 1f : 0f);
        gl.glActiveTexture(GL.GL_TEXTURE13);
        gl.glBindTexture(GL.GL_TEXTURE_2D, sunShadow.matrix != null ? sunShadow.tex : 0);
        gl.glActiveTexture(GL.GL_TEXTURE0);
        terrainShader.set(gl, "uSunShadow", 13);
        terrainShader.mat(gl, "uSunShadowM", sunShadow.matrix != null ? sunShadow.matrix : Mat4.identity());
        terrainShader.set(gl, "uSunShadowOn", sunShadow.matrix != null ? 1 : 0);
        gl.glActiveTexture(GL.GL_TEXTURE14);
        gl.glBindTexture(GL.GL_TEXTURE_2D, yardTex);
        gl.glActiveTexture(GL.GL_TEXTURE0);
        terrainShader.set(gl, "uYard", 14);
        terrainShader.set(gl, "uYardRect", (float) Siedlung.X0, (float) Siedlung.Z0, (float) (Siedlung.NX * Siedlung.CELL), yardTex != 0 && showHouses ? 1f : 0f);
        Siedlung sw = siedlung;
        float[] wr = new float[180];
        for (int i = 0; i < 180; i++) wr[i] = (float) sw.wallR[i];
        terrainShader.vec4Array(gl, "uWallR", wr);
        terrainShader.set(gl, "uWall", (float) Siedlung.WALL_CX, (float) Siedlung.WALL_CZ, 520f, showHouses ? 1f : 0f);
        // Phase 7: auf der Hochburg und an ihren Hängen keine Felder (Grabhügel)
        terrainShader.set(gl, "uNoField", (float) com.dan.haithabu.scene.Befestigung.HB_X, (float) com.dan.haithabu.scene.Befestigung.HB_Z, 170f, 0f);
        // Phase 11: im Versammlungshaus liegt der Lehmboden des Hauses; das Gelände darunter fällt weg
        com.dan.haithabu.scene.Versammlungshaus hh = housesNow ? hall() : null;
        if (hh != null) {
            terrainShader.set(gl, "uHole", (float) hh.house.x(), (float) hh.house.z(), (float) Math.toRadians(hh.house.headingDeg()), 1f);
            terrainShader.set(gl, "uHoleSize", (float) (hh.room.hx() + 0.05), (float) (hh.room.hz() + 0.05));
        } else terrainShader.set(gl, "uHole", 0f, 0f, 0f, 0f);
        // Phase 12: das Jahr am Boden
        Year.State ys = yearNow();
        terrainShader.set(gl, "uSeason", (float) ys.grassLush(), (float) ys.doy(), (float) ys.foliage(), (float) ys.autumn());
        terrainShader.set(gl, "uSnow", (float) (ys.snowDepth() * ys.snowCover()), (float) ys.snowWet(), (float) ys.frost(), (float) ys.reedSeason());
        terrainShader.set(gl, "uYear2", (float) ys.treeSnow(), 0f, 0f, 0f);
        lod.draw(gl, terrainShader, camera.eye, vp);
        mark(gl, 4);

        // 3b Wald zeichnen (Licht wie die Halme, dazu der Sonnenschatten)
        if (forestNow && forestGl.ready()) {
            double[][] La = ambientLight(st, pre);
            ForestGl.View fv = new ForestGl.View();
            fv.viewProj = vp;
            fv.eye = camera.eye.clone();
            fv.reversedZ = reversedZ;
            ForestGl.Light fl2 = new ForestGl.Light();
            fl2.sunDir = sun;
            fl2.fogColor = La[3];
            fl2.skyColor = La[2];
            fl2.wetness = weathering.snapshot().rainWet();
            if (skyOk) {
                // Dunst aus dem Rundumbild wie beim Gelände (der Mittelwert über den Horizont enthielte den Hof um die
                // tiefe Sonne und tauchte den fernen Wald in helles Beige; Befund Phase 2b)
                fl2.skyTexture = panoTex;
                fl2.sunColor = scale(st.sunColor, pre);
                fl2.moonDir = st.moonDir;
                fl2.moonColor = scale(st.moonColor, pre);
                fl2.skyWeight = 1.15;
                fl2.fogDistance = fogDistance(st);
                if (cloudsNow) {
                    fl2.shadowTexture = cloudGl.shadowTexture();
                    fl2.shadowRect = cloudGl.shadowRect();
                }
            } else {
                fl2.sunColor = La[0];
                fl2.fogDistance = 25_000;
            }
            if (sunShadow.matrix != null) {
                fl2.sunShadowTexture = sunShadow.tex;
                fl2.sunShadowMatrix = sunShadow.matrix;
                fl2.sunShadowBias = 0.0006;
            }
            forestGl.draw(gl, fv, fl2, clock.t());
            gl.glBindVertexArray(emptyVao);
        }
        // Phase 5: Häuser und Bauwerke am Bach (Licht wie der Wald, Nässe aus com.dan.weathering)
        if (housesNow) {
            double[][] Lh = ambientLight(st, pre);
            TimberGl.View tv = new TimberGl.View();
            tv.viewProj = vp;
            tv.eye = camera.eye.clone();
            tv.forward = camera.fwd.clone();
            tv.fovyDeg = fovy();
            tv.aspect = w / (double) h;
            tv.reversedZ = reversedZ;
            TimberGl.Light tl = new TimberGl.Light();
            tl.sunDir = sun;
            tl.fogColor = Lh[3];
            tl.skyColor = Lh[2];
            tl.wetness = weathering.snapshot().rainWet();
            tl.waterLevel = ocean.waterLevel;                                     // Phase 8: Algenlinie an den Pfählen
            tl.pointCount = fireN;                                                // Phase 10: Feuerschein
            System.arraycopy(firePos, 0, tl.pointPos, 0, 32);
            System.arraycopy(fireRgb, 0, tl.pointRgb, 0, 32);
            hallLight(tl, st, pre, sun);                                          // Phase 11: das Versammlungshaus innen
            Year.State yt = yearNow();                                            // Phase 12: Schnee auf Dächern und Bohlen, Reif
            tl.roofSnow = yt.roofSnow();
            tl.groundSnow = yt.snowDepth() * yt.snowCover();
            tl.snowWet = yt.snowWet();
            tl.frost = yt.frost();
            if (skyOk) {
                tl.skyTexture = panoTex;
                tl.sunColor = scale(st.sunColor, pre);
                tl.moonDir = st.moonDir;
                tl.moonColor = scale(st.moonColor, pre);
                tl.skyWeight = 1.15;
                tl.fogDistance = fogDistance(st);
                if (cloudsNow) {
                    tl.shadowTexture = cloudGl.shadowTexture();
                    tl.shadowRect = cloudGl.shadowRect();
                }
            } else {
                tl.sunColor = Lh[0];
                tl.fogDistance = 25_000;
            }
            if (sunShadow.matrix != null) {
                tl.sunShadowTexture = sunShadow.tex;
                tl.sunShadowMatrix = sunShadow.matrix;
                tl.sunShadowBias = 0.0008;
            }
            timberGl.draw(gl, timber, siedlung.houses, tv, tl);
            gl.glDisable(GL.GL_CULL_FACE);
            gl.glBindVertexArray(emptyVao);
        }
        // Phase 9: Schiffe im selben Licht wie die Häuser, vor dem Wasser (ihr Umriss hält es aus den Booten)
        Flotte flt = flotte;
        if (shipsOk && showShips && flt != null) {
            double[][] Ls = ambientLight(st, pre);
            LongshipGl.View sv = new LongshipGl.View();
            sv.viewProj = vp;
            sv.eye = camera.eye.clone();
            LongshipGl.Light sl = new LongshipGl.Light();
            sl.sunDir = sun;
            sl.fogColor = Ls[3];
            sl.skyColor = Ls[2];
            sl.wetness = weathering.snapshot().rainWet();
            sl.waterY = ocean.waterLevel;
            if (skyOk) {
                sl.skyTexture = panoTex;
                sl.sunColor = scale(st.sunColor, pre);
                sl.moonDir = st.moonDir;
                sl.moonColor = scale(st.moonColor, pre);
                sl.skyWeight = 1.15;
                sl.fogDistance = fogDistance(st);
            } else {
                sl.sunColor = Ls[0];
                sl.fogDistance = 25_000;
            }
            gl.glDepthFunc(reversedZ ? GL.GL_GREATER : GL.GL_LESS);
            longshipGl.draw(gl, flt.drawn(), sv, sl);
            gl.glBindVertexArray(emptyVao);
        }
        // Bodendecke um das Auge (nur zu Fuß), im selben Licht
        boolean groundNow = groundOk && showGround && camera.eye[1] - terrain.height(camera.eye[0], camera.eye[2]) < 25;
        if (groundOk) {
            meadow.setSeason(yearNow().doy(), Math.round(yearNow().snowCover() * 10) / 10f);
            meadow.wind.speed = (float) windSpeed;
            meadow.wind.direction = (float) Math.toDegrees(Math.atan2(to[2], to[0]));
            groundGl.update(gl, meadow, (float) (clock.t() % 3600), camera.eye[0], camera.eye[2], !groundNow);
        }
        if (groundNow) {
            double[][] Lg = ambientLight(st, pre);
            GroundGl.View gv = new GroundGl.View();
            gv.viewProj = vp;
            gv.eye = camera.eye.clone();
            gv.reversedZ = reversedZ;
            GroundGl.Light gl2 = new GroundGl.Light();
            gl2.sunDir = sun;
            gl2.fogColor = Lg[3];
            gl2.skyColor = Lg[2];
            if (skyOk) {
                gl2.skyTexture = panoTex;
                gl2.sunColor = scale(st.sunColor, pre);
                gl2.moonDir = st.moonDir;
                gl2.moonColor = scale(st.moonColor, pre);
                gl2.skyWeight = 1.2;
                gl2.fogDistance = fogDistance(st);
                if (cloudsNow) {
                    gl2.shadowTexture = cloudGl.shadowTexture();
                    gl2.shadowRect = cloudGl.shadowRect();
                }
            } else {
                gl2.sunColor = Lg[0];
                gl2.fogDistance = 25_000;
            }
            if (sunShadow.matrix != null) {
                gl2.sunShadowTexture = sunShadow.tex;
                gl2.sunShadowMatrix = sunShadow.matrix;
            }
            groundGl.draw(gl, gv, gl2);
            gl.glBindVertexArray(emptyVao);
        }
        mark(gl, 5);

        // 4 Noor: rechnen (Compute), dann zeichnen; das Gelände ist sein Grund, die Wolken werfen Schatten
        double[][] L = ambientLight(st, pre);
        if (oceanOk && showWater) {
            oceanGl.update(gl, ocean);
            if (oceanCheck.isEmpty() && frame > 30) oceanCheck = oceanGl.selfCheck(gl, ocean);
            gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
            gl.glViewport(0, 0, w, h);
            OceanGl.View ov = new OceanGl.View();
            ov.viewProj = vp;
            ov.eye = camera.eye.clone();
            ov.reversedZ = reversedZ;
            OceanGl.Light ol = new OceanGl.Light();
            ol.sunDir = sun;
            ol.skyTexture = panoTex;
            if (skyOk) {
                ol.sunColor = scale(st.sunColor, pre);
                ol.moonDir = st.moonDir;
                ol.moonColor = scale(st.moonColor, pre);
                ol.fogDistance = fogDistance(st);
                if (cloudsNow) {
                    ol.shadowTexture = cloudGl.shadowTexture();
                    ol.shadowRect = cloudGl.shadowRect();
                }
            } else {
                ol.sunColor = sunLight(sp[0]);
                ol.fogDistance = 25_000;
            }
            if (rainOk && showRain && rain.rate > 0) {
                ol.detailTexture = rainGl.rippleTexture();
                ol.detailTile = rainGl.rippleTile();
                ol.detailStrength = rainGl.rippleStrength() * Math.min(1, rainStrength);
                ol.detailRange = 60;
            }
            if (flashNow) {
                int n = lightningGl.lightCount();
                ol.flashCount = n;
                for (int i = 0; i < n; i++) {
                    double[] lp = lightningGl.lightPos(i), lr = lightningGl.lightRgb(i);
                    for (int k = 0; k < 4; k++) ol.flashPos[i * 4 + k] = (float) lp[k];
                    for (int k = 0; k < 3; k++) ol.flashRgb[i * 4 + k] = (float) (lr[k] * (skyOk ? pre : 1));
                }
                ol.pointSigma = air[0];
            }
            ol.waterColor = new double[]{0.020, 0.050, 0.036};
            ol.sssColor = new double[]{0.04, 0.17, 0.11};
            ol.bedTexture = lod.heightTex;
            ol.bedRect = new double[]{Terrain.X0, Terrain.Z0, Terrain.N * Terrain.CELL};
            ol.bedScale = Terrain.HMAX - Terrain.HMIN;
            ol.bedOffset = Terrain.HMIN;
            ol.bedTurbidity = 0.9;
            ol.bedColor = new double[]{0.13, 0.115, 0.085};
            oceanGl.draw(gl, ocean, ov, ol);
            gl.glBindVertexArray(emptyVao);
            // Phase 12: Eis im flachen Wasser, knapp über dem Spiegel
            Year.State yi = yearNow();
            if (iceOk && showIce && yi.ice() >= 0.005) {
                IceGl.Input in = new IceGl.Input();
                in.bedTexture = lod.heightTex;
                in.bedRect = ol.bedRect;
                in.bedScale = ol.bedScale;
                in.bedOffset = ol.bedOffset;
                in.waterLevel = ocean.waterLevel;
                in.thickness = yi.ice();
                in.iceDepth = yi.iceDepth();
                in.snow = yi.snowCover() * 0.6 * (1 - yi.snowWet() * 0.5);     // der Wind fegt das Eis zum Teil frei
                in.frost = yi.frost();
                double[] wt = wiring != null ? wiring.wind.toVector() : new double[]{1, 0, 0};
                in.windTo = new double[]{wt[0], wt[2]};
                gl.glDepthFunc(reversedZ ? GL.GL_GREATER : GL.GL_LESS);
                iceGl.draw(gl, seasonView(vp, w, h), seasonLight(st, pre, sun, cloudsNow), in);
                gl.glBindVertexArray(emptyVao);
            }
        }
        mark(gl, 6);

        // 5 Halme um die Kamera
        if (reedOk && showReed) {
            reedGl.update(gl, reed, camera.eye[0], camera.eye[2], vegetation, vegetation);
            ReedGl.View rv = new ReedGl.View();
            rv.viewProj = vp;
            rv.eye = camera.eye.clone();
            rv.reversedZ = reversedZ;
            ReedGl.Light rl = new ReedGl.Light();
            rl.sunDir = sun;
            rl.fogColor = L[3];
            if (skyOk) {
                // Sonne und Mond ohne den Schatten am Auge: jeder Halm liest die Wolkenschatten selbst
                rl.sunColor = scale(st.sunColor, pre);
                rl.moonDir = st.moonDir;
                rl.moonColor = scale(st.moonColor, pre);
                rl.skyColor = L[2];
                rl.skyWeight = 1.3;
                rl.fogDistance = fogDistance(st);
                if (cloudsNow) {
                    rl.shadowTexture = cloudGl.shadowTexture();
                    rl.shadowRect = cloudGl.shadowRect();
                }
            } else {
                rl.sunColor = L[0];
                rl.skyColor = L[2];
                rl.fogDistance = 25_000;
            }
            reedGl.draw(gl, reed, rv, rl, clock.t());
            gl.glBindVertexArray(emptyVao);
        }
        // Phase 13: Haustiere und Vögel (nach dem Noor: was schwimmt, steckt halb im Wasser)
        com.dan.haithabu.scene.Leben lbd = leben;
        if (lbd != null && (animalsOk && showAnimals || birdsOk && showBirds)) drawLife(gl, lbd, st, vp, w, h, pre, sun, cloudsNow);
        mark(gl, 7);

        // 6 Feuer, Rauch, Rauch im Haus, Regen über die Szene (Tiefe als Kopie). Phase 11: im Haus regnet es nicht
        boolean rainNow = rainOk && showRain && rain.rate > 0 && !eyeInHall;
        boolean fogNow = fogOk && showFog && fog.snapshot().any();
        boolean copied = false;
        boolean sprayNow = sprayOk && showShips && flt != null && !flt.spray.parcels().isEmpty();
        Feuer fe = feuer;
        boolean fireNow = hearthOk && showFire && fe != null, smokeNow = smokeOk && showSmoke && fe != null;
        com.dan.haithabu.scene.Versammlungshaus hall = fe != null ? fe.hall : null;
        boolean roomNow = roomSmokeOk && showRoomSmoke && hall != null && housesNow && hall.distance(camera.eye[0], camera.eye[2]) < 35 && hall.smoke.sigma() > 1e-3;
        if (rainNow || fogNow || flashNow || sprayNow || fireNow || smokeNow || roomNow) { copyDepth(gl, w, h); copied = true; }
        if (sprayNow) drawSpray(gl, flt, st, vp, w, h, pre, L);
        if (fireNow) drawFlames(gl, fe, vp, w, h, pre, L, st);
        mark(gl, 8);
        if (smokeNow) drawSmoke(gl, fe, st, vp, w, h, pre, L);
        mark(gl, 9);
        if (roomNow) drawRoomSmoke(gl, hall, st, inv, w, h, pre, sun);
        mark(gl, 10);
        if (rainNow) drawRain(gl, st, vp, inv, w, h, pre, L);
        // Phase 12: Schneefall um das Auge (nicht im Haus)
        double snowRate = wiring != null ? wiring.snowRate : 0;
        if (snowOk && showSnow && snowRate > 0.01 && !eyeInHall) {
            gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
            gl.glViewport(0, 0, w, h);
            gl.glDepthFunc(reversedZ ? GL.GL_GREATER : GL.GL_LESS);
            double[] wt = wiring.wind.toVector();
            snowfallGl.draw(gl, seasonView(vp, w, h), seasonLight(st, pre, sun, false), snowRate, new double[]{wt[0], wt[2]},
                    wiring.regie ? wiring.gustNow : wiring.wind.speed(), clock.t());
            gl.glBindVertexArray(emptyVao);
        }
        mark(gl, 11);

        // 7 Nebel über Noor und Niederung, bis zur Szenentiefe
        if (fogNow) drawFog(gl, st, inv, w, h, L);
        mark(gl, 12);

        // 8 Blitz: das Leuchten der Luft um die Kanäle
        if (flashNow && copied) {
            LightningGl.View lv = lightningView(vp, inv, w, h, pre, air);
            lv.depthTexture = depthCopyTex;
            lightningGl.drawGlow(gl, lv);
            gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
            gl.glViewport(0, 0, w, h);
            gl.glBindVertexArray(emptyVao);
        }
        mark(gl, 13);

        bildMessen(gl, w, h, pre);
        // 9 Nachbearbeitung ins Fenster (mit com.dan.sky ist das Bild schon vorbelichtet)
        gl.glDisable(GL.GL_DEPTH_TEST);
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, defaultFbo);
        gl.glViewport(0, 0, surfW, surfH);
        post.use(gl);
        gl.glActiveTexture(GL.GL_TEXTURE0);
        gl.glBindTexture(GL.GL_TEXTURE_2D, hdrTex);
        post.set(gl, "uHdr", 0);
        post.set(gl, "uExposure", skyOk ? 1f : (float) exposure());
        post.set(gl, "uScotopic", (float) (skyOk ? scotopic(st) : 0));
        gl.glBindVertexArray(emptyVao);
        gl.glDrawArrays(GL.GL_TRIANGLES, 0, 3);
        mark(gl, 14);

        // 10 HUD
        if (showHud) {
            hud.refresh(gl, 250, this::paintHud, frozen);
            hud.draw(gl, overlay, emptyVao, 12, surfH - hud.height - 12, surfW, surfH);
        }
        gl.glBindVertexArray(0);
        gl.glUseProgram(0);
        mark(gl, 15);
    }

    /** Phase 11: Raum, Rauchschicht, Rückstrahlung und Lichter des Versammlungshauses für timber. */
    private void hallLight(TimberGl.Light tl, Sky.State st, double pre, double[] sun) {
        com.dan.haithabu.scene.Versammlungshaus h = hall();
        if (h == null || h.distance(camera.eye[0], camera.eye[2]) > 120) return;
        tl.room = h.room.pack();
        com.dan.smoke.RoomSmoke rs = h.smoke;
        double str = showRoomSmoke ? roomSmokeStrength : 0;
        tl.roomSmoke = new double[]{rs.layerBottom(), rs.sigma() * str, rs.sigmaLow() * str, com.dan.smoke.RoomSmoke.blend()};
        // Himmel wie die Flächen draußen (Bestrahlung / π · 1,15, siehe ambientLight), Sonne als Bestrahlung
        double[] sunIrr = skyOk ? scale(st.sunColor, pre) : new double[]{0, 0, 0};
        double[] skyIrr = skyOk ? scale(st.skyIrradiance, pre / Math.PI * 1.15) : new double[]{0, 0, 0};
        tl.roomBounce = h.bounce(sunIrr, sun[1] > 0 ? h.sunPatch(sun) : 0, skyIrr);
        tl.roomLightCount = roomN;
        System.arraycopy(roomPos, 0, tl.roomLightPos, 0, 16);
        System.arraycopy(roomRgb, 0, tl.roomLightRgb, 0, 16);
    }

    /** Blick für die Blitze (Ziel ist das HDR-Bild; die Szene verdeckt später). */
    private LightningGl.View lightningView(float[] vp, float[] inv, int w, int h, double pre, double[] air) {
        LightningGl.View v = new LightningGl.View();
        v.viewProj = vp;
        v.invViewProj = inv;
        v.eye = camera.eye.clone();
        v.reversedZ = reversedZ;
        v.width = w;
        v.height = h;
        v.fovyDeg = fovy();
        v.targetFbo = hdrFbo;
        v.preExposure = skyOk ? pre : 1;
        v.extinction = air[0];
        v.scatter = air[1];
        v.ceiling = cloudsOk && showClouds ? clouds.type.base : lightning.cloudBase;
        return v;
    }

    /** Die Tiefe der Szene als Kopie (Regen, Nebel und Blitz lesen sie für weiche Ränder und ihre Weglänge). */
    private void copyDepth(GL4 gl, int w, int h) {
        if (depthCopyTex == 0 || depthCopyW != w || depthCopyH != h) {
            Gpu.deleteFbos(gl, depthCopyFbo);
            Gpu.deleteTextures(gl, depthCopyTex);
            depthCopyTex = Gpu.texture(gl, w, h, GL4.GL_DEPTH_COMPONENT32F, false);
            gl.glBindTexture(GL.GL_TEXTURE_2D, depthCopyTex);
            gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_NEAREST);
            gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_NEAREST);
            gl.glBindTexture(GL.GL_TEXTURE_2D, 0);
            depthCopyFbo = Gpu.depthFbo(gl, depthCopyTex);
            depthCopyW = w;
            depthCopyH = h;
        }
        gl.glBindFramebuffer(GL4.GL_READ_FRAMEBUFFER, hdrFbo);
        gl.glBindFramebuffer(GL4.GL_DRAW_FRAMEBUFFER, depthCopyFbo);
        gl.glBlitFramebuffer(0, 0, w, h, 0, 0, w, h, GL.GL_DEPTH_BUFFER_BIT, GL.GL_NEAREST);
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
    }

    /**
     * Phase 10: die acht hellsten Feuer am Auge als Punktlichter für Häuser, Gelände und Rauch, in den Einheiten der
     * Sonne (Lichtstärke / Sky.CD_PER_UNIT, vorbelichtet).
     */
    private void fireLights(double pre) {
        java.util.Arrays.fill(firePos, 0);
        java.util.Arrays.fill(fireRgb, 0);
        fireN = 0;
        roomN = 0;
        Feuer fe = feuer;
        if (fe == null || !showFire) return;
        double k = pre / com.dan.sky.Sky.CD_PER_UNIT;
        java.util.List<double[]> l = fe.lights(camera.eye[0], camera.eye[1], camera.eye[2], 8, 900);
        for (double[] f : l) {
            for (int c = 0; c < 4; c++) firePos[fireN * 4 + c] = (float) f[c];
            for (int c = 0; c < 3; c++) fireRgb[fireN * 4 + c] = (float) (f[4 + c] * k);
            fireN++;
        }
        // Phase 11: die Lichter im Versammlungshaus (nur für Flächen und Rauch innen)
        java.util.Arrays.fill(roomPos, 0);
        java.util.Arrays.fill(roomRgb, 0);
        roomN = 0;
        if (fe.hall != null)
            for (double[] f : fe.hall.lights(clock.t())) {
                if (roomN >= 4) break;
                for (int c = 0; c < 4; c++) roomPos[roomN * 4 + c] = (float) f[c];
                for (int c = 0; c < 3; c++) roomRgb[roomN * 4 + c] = (float) (f[4 + c] * k);
                roomN++;
            }
    }

    /** Phase 10: Flammen, Glut und Funken, wie der Regen über die Szene mit der Tiefenkopie. */
    private void drawFlames(GL4 gl, Feuer fe, float[] vp, int w, int h, double pre, double[][] L, Sky.State st) {
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        gl.glDepthFunc(reversedZ ? GL.GL_GREATER : GL.GL_LESS);
        double[] to = smoke.windTo();
        double fog = skyOk ? fogDistance(st) : 25_000;
        hearthGl.update(gl, fe.flames());
        HearthGl.View v = new HearthGl.View();
        v.viewProj = vp;
        v.eye = camera.eye.clone();
        v.reversedZ = reversedZ;
        v.near = 0.2;
        v.far = 60_000;
        v.depthTexture = depthCopyTex;
        HearthGl.Light l = new HearthGl.Light();
        l.lumScale = pre / com.dan.sky.Sky.CD_PER_UNIT;
        l.skyTop = L[2];
        l.skyHorizon = L[3];
        l.fogColor = L[3];
        l.fogDistance = fog;
        // im Haus weht kein Wind
        l.windX = to[0];
        l.windZ = to[1];
        l.windSpeed = eyeInHall ? 0.3 : smoke.windSpeed;
        hearthGl.draw(gl, v, l, clock.t());
        gl.glDisable(GL.GL_BLEND);
        gl.glDepthMask(true);
        gl.glBindVertexArray(emptyVao);
    }

    /** Phase 10: der Rauch der Herde und Feuer als Fahnen aus weichen Bällen. */
    private void drawSmoke(GL4 gl, Feuer fe, Sky.State st, float[] vp, int w, int h, double pre, double[][] L) {
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        double fog = skyOk ? fogDistance(st) : 25_000;
        smoke.quality = quality.smoke;
        smoke.select(camera.eye[0], camera.eye[1], camera.eye[2]);
        smokeGl.update(gl, smoke);
        if (smokeCheck.isEmpty() && frame > 90 && smoke.nearCount() > 0) smokeCheck = smokeGl.selfCheck(gl, smoke);
        SmokeGl.View v = new SmokeGl.View();
        v.viewProj = vp;
        v.eye = camera.eye.clone();
        v.reversedZ = reversedZ;
        v.near = 0.2;
        v.far = 60_000;
        v.depthTexture = depthCopyTex;
        SmokeGl.Light l = new SmokeGl.Light();
        l.sunDir = skyOk ? st.sunDir : Sun.direction(clock.sun()[0], clock.sun()[1]);
        l.sunColor = L[0];
        l.moonDir = skyOk ? st.moonDir : new double[]{0, -1, 0};
        l.moonColor = L[1];
        l.skyTop = skyOk ? scale(st.skyIrradiance, pre / Math.PI) : L[2];
        l.skyHorizon = L[3];
        l.fogColor = L[3];
        l.fogDistance = fog;
        l.fireCount = fireN;
        System.arraycopy(firePos, 0, l.firePos, 0, 32);
        System.arraycopy(fireRgb, 0, l.fireRgb, 0, 32);
        gl.glDepthFunc(reversedZ ? GL.GL_GREATER : GL.GL_LESS);
        smokeGl.draw(gl, v, l, smokeStrength, smoke.time());
        gl.glDisable(GL.GL_BLEND);
        gl.glDepthMask(true);
        gl.glBindVertexArray(emptyVao);
    }

    /** Phase 11: der Rauch im Versammlungshaus als Volumen mit den Lichtstrahlen durch Tür und Rauchloch. */
    private void drawRoomSmoke(GL4 gl, com.dan.haithabu.scene.Versammlungshaus hall, Sky.State st, float[] inv, int w, int h, double pre, double[] sun) {
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        RoomSmokeGl.View v = new RoomSmokeGl.View();
        v.invViewProj = inv;
        v.eye = camera.eye.clone();
        v.forward = camera.fwd.clone();
        v.width = w;
        v.height = h;
        v.reversedZ = reversedZ;
        v.near = 0.2;
        v.far = 60_000;
        v.depthTexture = depthCopyTex;
        v.room = hall.room.pack();
        v.steps = quality.roomSteps;
        RoomSmokeGl.Light l = new RoomSmokeGl.Light();
        if (skyOk) {
            l.sunDir = st.sunDir;
            l.sunColor = scale(st.sunColor, pre);
            l.moonDir = st.moonDir;
            l.moonColor = scale(st.moonColor, pre);
            double[] skyIrr = scale(st.skyIrradiance, pre / Math.PI * 1.15), sunIrr = scale(st.sunColor, pre);
            double[] b = hall.bounce(sunIrr, sun[1] > 0 ? hall.sunPatch(sun) : 0, skyIrr);
            double df = hall.room.daylightFactor(0.15);
            for (int c = 0; c < 3; c++) l.ambient[c] = b[c] + skyIrr[c] * df;
        }
        l.lightCount = roomN;
        System.arraycopy(roomPos, 0, l.lightPos, 0, 16);
        System.arraycopy(roomRgb, 0, l.lightRgb, 0, 16);
        roomSmokeGl.draw(gl, v, l, hall.smoke, roomSmokeStrength, clock.t());
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        gl.glDepthFunc(reversedZ ? GL.GL_GREATER : GL.GL_LESS);
        gl.glBindVertexArray(emptyVao);
    }

    /** „Haus: Herd brennt (12 kW) · Schicht ab 2,4 m … · im Haus“ */
    public String hallLine() {
        com.dan.haithabu.scene.Versammlungshaus h = hall();
        if (h == null) return "Versammlungshaus: keins";
        if (!roomSmokeOk) return "!Versammlungshaus: Rauch im Haus nicht gestartet";
        return "Versammlungshaus " + h.describe() + (eyeInHall ? " · Auge im Haus" : String.format(Locale.GERMAN, " · %.0f m entfernt", h.distance(camera.eye[0], camera.eye[2])));
    }

    /** „Feuer: Herde 140 von 467 … · 142 Fahnen (24 nah) … · 0,4 ms“ */
    public String fireLine() {
        Feuer fe = feuer;
        if (fe == null) return "Feuer: keine";
        if (!smokeOk || !hearthOk) return "!Feuer/Rauch: " + (!smokeOk ? "com.dan.smoke " : "") + (!hearthOk ? "com.dan.hearth " : "") + "nicht gestartet";
        return "Feuer " + fe.describe() + " · " + fireN + " Lichter · " + hearthGl.info();
    }

    public String smokeLine() {
        if (!smokeOk) return "!Rauch: com.dan.smoke nicht gestartet";
        return "Rauch " + smoke.describe() + String.format(Locale.GERMAN, " · %.2f ms", fireCpuMs) + (smokeCheck.isEmpty() ? "" : " · " + smokeCheck.replace("Grafikkarte = Prozessor: Rauch", "GPU = CPU"));
    }

    /** Phase 9 (F22): Spritzer der Riemen, wie der Regen über die Szene mit der Tiefenkopie. */
    private void drawSpray(GL4 gl, Flotte fl, Sky.State st, float[] vp, int w, int h, double pre, double[][] L) {
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        sprayGl.update(gl, fl.spray);
        SprayGl.View v = new SprayGl.View();
        v.viewProj = vp;
        v.eye = camera.eye.clone();
        v.forward = camera.fwd.clone();
        v.reversedZ = reversedZ;
        v.near = 0.2;
        v.far = 60_000;
        v.fovyDeg = fovy();
        v.width = w;
        v.height = h;
        v.depthTexture = depthCopyTex;
        SprayGl.Light l = new SprayGl.Light();
        l.sunDir = skyOk ? st.sunDir : Sun.direction(clock.sun()[0], clock.sun()[1]);
        l.sunColor = L[0];
        l.moonDir = skyOk ? st.moonDir : new double[]{0, -1, 0};
        l.moonColor = L[1];
        l.skyTop = skyOk ? scale(st.skyIrradiance, pre / Math.PI) : L[2];
        l.skyHorizon = L[3];
        l.fogDistance = skyOk ? fogDistance(st) : 25_000;
        gl.glDepthFunc(reversedZ ? GL.GL_GREATER : GL.GL_LESS);
        sprayGl.draw(gl, v, l, 1);
        gl.glDisable(GL.GL_BLEND);
        gl.glDepthMask(true);
        gl.glBindVertexArray(emptyVao);
    }

    /** Phase 13: Haustiere und Vögel im Licht der Szene. */
    private void drawLife(GL4 gl, com.dan.haithabu.scene.Leben lb, Sky.State st, float[] vp, int w, int h, double pre, double[] sun, boolean cloudsNow) {
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        SeasonGl.Light sl = seasonLight(st, pre, sun, cloudsNow);
        if (animalsOk && showAnimals) {
            com.dan.herd.gl.HerdGl.View hv = new com.dan.herd.gl.HerdGl.View();
            hv.viewProj = vp;
            hv.eye = camera.eye.clone();
            hv.reversedZ = reversedZ;
            hv.range = 700;
            com.dan.herd.gl.HerdGl.Light hl = new com.dan.herd.gl.HerdGl.Light();
            hl.sunDir = sl.sunDir; hl.sunColor = sl.sunColor; hl.moonDir = sl.moonDir; hl.moonColor = sl.moonColor;
            hl.sky = sl.sky; hl.fogColor = sl.fogColor; hl.fogDistance = sl.fogDistance; hl.cloudShadow = sl.cloudShadow; hl.cloudRect = sl.cloudRect;
            herdGl.draw(gl, lb.herd, hv, hl);
        }
        if (birdsOk && showBirds) {
            com.dan.flock.gl.FlockGl.View fv = new com.dan.flock.gl.FlockGl.View();
            fv.viewProj = vp;
            fv.eye = camera.eye.clone();
            fv.reversedZ = reversedZ;
            com.dan.flock.gl.FlockGl.Light fl = new com.dan.flock.gl.FlockGl.Light();
            double[][] L = ambientLight(st, pre);
            fl.sunDir = sl.sunDir; fl.sunColor = sl.sunColor; fl.moonDir = sl.moonDir; fl.moonColor = sl.moonColor;
            // gull.frag: Himmel als Strahldichte oben und am Horizont
            fl.skyTop = scale(L[2], 1.15);
            fl.skyHorizon = L[3];
            fl.fogDistance = sl.fogDistance;
            flockGl.draw(gl, lb.flock, fv, fl);
            if (flockCheck.isEmpty() && frame > 120) flockCheck = flockGl.selfCheck(gl, lb.flock);
            gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
            gl.glViewport(0, 0, w, h);
        }
        gl.glBindVertexArray(emptyVao);
    }

    /** Kurz für Bildunterschriften: Vögel und Tiere im Umkreis von 150 m um das Auge. */
    String lifeSummary() {
        com.dan.haithabu.scene.Leben lb = leben;
        if (lb == null) return "";
        int birds = 0, swim = 0, perch = 0, animals = 0;
        double[] e = camera.eye;
        for (com.dan.flock.Flock.Gull g : lb.flock.gulls()) {
            if (g.state == com.dan.flock.Flock.State.AWAY || Math.hypot(g.pos[0] - e[0], g.pos[2] - e[2]) > 150) continue;
            birds++;
            if (g.state == com.dan.flock.Flock.State.SWIM) swim++;
            if (g.state == com.dan.flock.Flock.State.PERCH) perch++;
        }
        for (com.dan.herd.Herd.Animal a : lb.herd.animals()) if (a.state != com.dan.herd.Herd.State.AWAY && Math.hypot(a.pos[0] - e[0], a.pos[2] - e[2]) < 150) animals++;
        return String.format(Locale.GERMAN, "in 150 m: %d Vögel (%d schwimmen, %d sitzen), %d Haustiere", birds, swim, perch, animals);
    }

    /** „Vögel 16 Möwen … · Haustiere …“ */
    public String lifeLine() {
        com.dan.haithabu.scene.Leben lb = leben;
        if (lb == null) return "Tiere: keine Siedlung";
        return lb.birdLine() + (birdsOk ? " · " + flockGl.info() + " · " + flockGl.drawn() + " gezeichnet" : " · !Vögel nicht gestartet")
                + (flockCheck.isEmpty() ? "" : " · " + flockCheck);
    }

    public String herdLine() {
        com.dan.haithabu.scene.Leben lb = leben;
        if (lb == null) return "";
        return lb.animalLine() + (animalsOk ? " · " + herdGl.info() : " · !Haustiere nicht gestartet") + String.format(Locale.GERMAN, " · Prozessor %.2f ms", lifeCpuMs);
    }

    /** Phase 12: Stand des Jahrs (aus der Verdrahtung, sonst nur die Pflanzen nach dem Datum). */
    public Year.State yearNow() {
        Year.State s = wiring != null && wiring.yearOn ? wiring.yearState : null;
        if (s != null) return s;
        return (wiring != null ? wiring.year : BARE_YEAR).bare(Math.min(365, clock.date().getDayOfYear()));
    }

    private SeasonGl.View seasonView(float[] vp, int w, int h) {
        SeasonGl.View v = new SeasonGl.View();
        v.viewProj = vp;
        v.eye = camera.eye.clone();
        v.reversedZ = reversedZ;
        v.width = w;
        v.height = h;
        v.fovyDeg = fovy();
        return v;
    }

    private SeasonGl.Light seasonLight(Sky.State st, double pre, double[] sun, boolean cloudsNow) {
        double[][] L = ambientLight(st, pre);
        SeasonGl.Light l = new SeasonGl.Light();
        l.sunDir = sun;
        l.fogColor = L[3];
        l.sky = scale(L[2], 1.15);
        if (skyOk) {
            l.sunColor = scale(st.sunColor, pre);
            l.moonDir = st.moonDir;
            l.moonColor = scale(st.moonColor, pre);
            l.fogDistance = fogDistance(st);
            if (cloudsNow) {
                l.cloudShadow = cloudGl.shadowTexture();
                l.cloudRect = cloudGl.shadowRect();
            }
        } else {
            l.sunColor = L[0];
            l.fogDistance = 25_000;
        }
        return l;
    }

    /** „Jahr: Schnee 31 cm · Eis 9 cm … · Gras 15 % · Schilf Winter · Schneefall …“ */
    public String yearLine() {
        Year.State y = yearNow();
        String src = wiring != null && wiring.yearOn ? "Jahr" : "Jahr (nur Pflanzen, ohne Wetter)";
        return String.format(Locale.GERMAN, "%s %s · Gras %.0f %% · Laub %.0f %% · Herbst %.0f %% · Kronen %.0f %% Schnee · Dach %.0f cm · %s", src, y.describe(),
                y.grassLush() * 100, y.foliage() * 100, y.autumn() * 100, y.treeSnow() * 100, y.roofSnow() * 100, snowInfo());
    }

    /** „Schneefall 1,2 mm/h · 80 000 Flocken“ für die Anzeige. */
    public String snowInfo() { return snowOk ? snowfallGl.info() + " · " + iceGl.info() : "Schnee und Eis aus"; }

    private void drawRain(GL4 gl, Sky.State st, float[] vp, float[] inv, int w, int h, double pre, double[][] L) {
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        RainGl.View v = new RainGl.View();
        v.viewProj = vp;
        v.invViewProj = inv;
        v.eye = camera.eye.clone();
        v.forward = camera.fwd.clone();
        v.reversedZ = reversedZ;
        v.near = 0.2;
        v.far = 60_000;
        v.fovyDeg = fovy();
        v.width = w;
        v.height = h;
        v.depthTexture = depthCopyTex;
        RainGl.Light l = new RainGl.Light();
        l.sunDir = skyOk ? st.sunDir : Sun.direction(clock.sun()[0], clock.sun()[1]);
        l.sunColor = L[0];
        l.moonDir = skyOk ? st.moonDir : new double[]{0, -1, 0};
        l.moonColor = L[1];
        double[][] fl = flashLight(pre);
        if (fl != null && fl[1][1] > l.moonColor[1]) { l.moonDir = fl[0]; l.moonColor = fl[1]; }
        // unter der Wolke: Licht von oben nur, so weit sie es durchlässt
        double under = cloudsOk && showClouds ? Math.min(1, clouds.type.overcastBrightness * 1.6) : 1;
        l.skyTop = skyOk ? scale(st.skyIrradiance, pre / Math.PI * under) : L[2];
        l.skyHorizon = L[3];
        l.fogDistance = skyOk ? fogDistance(st) : 25_000;
        gl.glDepthFunc(reversedZ ? GL.GL_GREATER : GL.GL_LESS);
        rainGl.draw(gl, v, l, rainStrength);
        gl.glDisable(GL.GL_BLEND);
        gl.glDepthMask(true);
    }

    private void drawFog(GL4 gl, Sky.State st, float[] inv, int w, int h, double[][] L) {
        Fog.Snapshot s = fog.snapshot();
        fogGl.update(gl, s, camera.eye.clone());
        if (fogCheck.isEmpty() && frame > 100) fogCheck = fogGl.selfCheck(gl, fog, camera.eye.clone());
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        FogGl.View v = new FogGl.View();
        v.invViewProj = inv;
        v.eye = camera.eye.clone();
        v.reversedZ = reversedZ;
        v.width = w;
        v.height = h;
        v.depthTexture = depthCopyTex;
        v.jitter = frozen ? 0.5 : -1;
        v.frame = frame;
        FogGl.Light l = new FogGl.Light();
        l.sunDir = skyOk ? st.sunDir : Sun.direction(clock.sun()[0], clock.sun()[1]);
        l.sunColor = L[0];
        if (skyOk) l.moonDir = st.moonDir;
        l.moonColor = L[1];
        l.ambientTop = L[2];
        l.ambientHorizon = L[3];
        fogGl.draw(gl, s, v, l);
        gl.glBindFramebuffer(GL.GL_FRAMEBUFFER, hdrFbo);
        gl.glViewport(0, 0, w, h);
        gl.glBindVertexArray(emptyVao);
    }

    /**
     * Farbe des Sonnenlichts nach der Sonnenhöhe in Grad, wie sunLight() in common.glsl (aus Lighthouse): weiß am Tag,
     * golden und schwächer tief am Himmel, aus unter der Kimm.
     */
    public static double[] sunLight(double elevDeg) {
        double e = Math.sin(Math.toRadians(elevDeg));
        double vis = smooth(-0.015, 0.01, e), t = smooth(0.02, 0.35, e), f = 2.6 * vis * smooth(-0.02, 0.12, e);
        return new double[]{f, (0.55 + 0.40 * t) * f, (0.28 + 0.60 * t) * f};
    }

    /** Zenit- und Horizontfarbe des Platzhalter-Himmels (wie skyColorPlaceholder in common.glsl, ohne Sonnensaum). */
    public static double[] skyZenith(double elevDeg) { return skyPlaceholder(elevDeg, 1); }
    public static double[] skyHorizon(double elevDeg) { return skyPlaceholder(elevDeg, 0); }

    static double[] skyPlaceholder(double e, double up) {
        double b = Sun.skyBrightness(e);
        double day = smooth(-2, 12, e), night = 1 - smooth(-16, -8, e), tw = Math.max(0, Math.min(1, 1 - day - night));
        double hw = Math.pow(1 - up, 4);
        double[] zen = {0.16 * day + 0.10 * tw + 0.05 * night, 0.34 * day + 0.17 * tw + 0.08 * night, 0.72 * day + 0.42 * tw + 0.20 * night};
        double[] hor = {0.62 * day + 0.6 * tw + 0.07 * night, 0.74 * day + 0.4 * tw + 0.09 * night, 0.88 * day + 0.36 * tw + 0.18 * night};
        double[] c = new double[3];
        for (int i = 0; i < 3; i++) c[i] = (zen[i] + (hor[i] - zen[i]) * hw) * b / 0.32;
        return c;
    }

    static double smooth(double a, double b, double x) {
        double t = Math.max(0, Math.min(1, (x - a) / (b - a)));
        return t * t * (3 - 2 * t);
    }

    /** Mittelpunkt der Sonnenschattenkarte: zwischen Auge und Kreismittelpunkt, frei fliegend ein Stück vor dem Auge. */
    private double[] shadowCenter() {
        double cx, cz;
        if (camera.mode == Camera.Mode.FREI) {
            double k = sunShadow.half * 0.7;
            double hl = Math.max(1e-6, Math.hypot(camera.fwd[0], camera.fwd[2]));
            cx = camera.eye[0] + camera.fwd[0] / hl * k;
            cz = camera.eye[2] + camera.fwd[2] / hl * k;
        } else {
            double hl = Math.max(1e-6, Math.hypot(camera.tx - camera.eye[0], camera.tz - camera.eye[2]));
            double d = Math.min(hl, sunShadow.half * 1.2) * 0.85;
            cx = camera.eye[0] + (camera.tx - camera.eye[0]) / hl * d;
            cz = camera.eye[2] + (camera.tz - camera.eye[2]) / hl * d;
        }
        return new double[]{cx, terrain.height(cx, cz) + 8, cz};
    }

    private void common(GL4 gl, Shader s, float[] vp, float[] inv, double[] sun, double level) {
        s.use(gl);
        // Phase 3: mit com.dan.sky Himmel aus dem Rundumbild, Sonne und Mond vorbelichtet (die Wolkenschatten liest
        // das Gelände selbst aus der Karte), Dunst aus der Sicht
        boolean sm = skyOk && s != skyShader && s != skyPano;
        s.set(gl, "uSkyMode", sm ? 1 : 0);
        if (sm) {
            Sky.State st = skyState();
            double pre = exposure();
            gl.glActiveTexture(GL.GL_TEXTURE7);
            gl.glBindTexture(GL.GL_TEXTURE_2D, panoTex);
            gl.glActiveTexture(GL.GL_TEXTURE0);
            s.set(gl, "uPano", 7);
            s.set(gl, "uSunColor", scale(st.sunColor, pre));
            s.set(gl, "uMoonColor", scale(st.moonColor, pre));
            s.set(gl, "uMoonDir", st.moonDir);
            s.set(gl, "uFogDist", (float) fogDistance(st));
            s.set(gl, "uPre", (float) pre);
            s.set(gl, "uSkyAmb", scale(st.skyIrradiance, pre / Math.PI));
        }
        s.mat(gl, "uVP", vp);
        s.mat(gl, "uInvVP", inv);
        s.set(gl, "uCam", camera.eye);
        s.set(gl, "uSun", sun);
        s.set(gl, "uTime", (float) (clock.t() % 10_000));
        s.set(gl, "uLevel", (float) level);
        s.set(gl, "uReversed", reversedZ ? 1 : 0);
    }

    private void resizeTargets(GL4 gl, int w, int h) {
        Gpu.deleteFbos(gl, hdrFbo);
        Gpu.deleteTextures(gl, hdrTex, depthTex);
        // Phase 17: mit Mip-Stufen für die Messung des Bilds (Augenanpassung); gezeichnet wird nur aus Stufe 0
        hdrTex = Gpu.texture(gl, w, h, GL.GL_RGBA16F, true);
        gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR);
        lumPending = false;
        depthTex = Gpu.texture(gl, w, h, GL4.GL_DEPTH_COMPONENT32F, false);
        gl.glBindTexture(GL.GL_TEXTURE_2D, depthTex);
        gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_NEAREST);
        gl.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_NEAREST);
        gl.glBindTexture(GL.GL_TEXTURE_2D, 0);
        hdrFbo = Gpu.fbo(gl, hdrTex, depthTex);
        hdrW = w;
        hdrH = h;
    }

    // ------------------------------------------------------------------ Zeitmessung

    private void mark(GL4 gl, int i) { gl.glQueryCounter(stamp[frame & 1][i], GL4.GL_TIMESTAMP); }

    /** Liest die Zeitstempel des vorigen Bilds, sobald sie da sind (kein Warten im Bildlauf). */
    private void readMarks(GL4 gl) {
        if (frame < 2) return;
        int o = (frame - 1) & 1;
        int[] av = new int[1];
        gl.glGetQueryObjectiv(stamp[o][MARKS - 1], GL4.GL_QUERY_RESULT_AVAILABLE, av, 0);
        if (av[0] == 0) return;
        long[] t = new long[MARKS];
        for (int i = 0; i < MARKS; i++) gl.glGetQueryObjecti64v(stamp[o][i], GL4.GL_QUERY_RESULT, t, i);
        for (int i = 0; i < MARKS - 1; i++) passMs[i] = passMs[i] * 0.9 + Math.max(0, t[i + 1] - t[i]) / 1e6 * 0.1;
        gpuMs = gpuMs * 0.9 + Math.max(0, t[MARKS - 1] - t[0]) / 1e6 * 0.1;
    }

    /** „Himmel 0,10 · Bühne 0,60 · …“ in ms (gleitendes Mittel). */
    public String passTimes() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < passMs.length; i++)
            sb.append(i > 0 ? " · " : "").append(PASSES[i]).append(' ').append(String.format(Locale.GERMAN, "%.2f", passMs[i]));
        return sb.toString();
    }

    private void stats(long now, int w, int h) {
        statsFrames++;
        if (now - statsNanos < 500_000_000L) return;
        fps = statsFrames / ((now - statsNanos) / 1e9);
        statsFrames = 0;
        statsNanos = now;
        statusListener.accept(statusLine(w, h));
    }

    /** Auflösung nach der Zeit der Grafikkarte regeln (siehe {@link #autoScale}). */
    private void regulateScale(long now) {
        if (!autoScale || frame < 60 || now - scaleNanos < 1_500_000_000L) return;
        scaleNanos = now;
        double budget = 1000 / Math.max(10, targetFps), top = quality.renderScale, s = renderScale;
        double want = s * Math.sqrt(budget * 0.9 / Math.max(0.1, gpuMs));
        double next = s;
        if (gpuMs > budget * 1.05) next = Math.max(MIN_SCALE, Math.max(want, s - 0.15));
        else if (gpuMs < budget * 0.7 && s < top) next = Math.min(top, Math.min(want, s + 0.05));
        next = Math.round(next * 20) / 20.0;
        if (Math.abs(next - s) >= 0.045) { renderScale = next; scaleSteps++; }
    }

    /** Wie oft die Regelung die Auflösung geändert hat. */
    public int scaleSteps() { return scaleSteps; }

    /** Für Prüfungen: die Regelung mit vorgegebener Grafikkartenzeit und Bildnummer. */
    public void regulateForTest(double gpuMsNow, long nowNanos) {
        gpuMs = gpuMsNow;
        frame = Math.max(frame, 60);
        regulateScale(nowNanos);
    }

    public String statusLine(int w, int h) {
        String s = String.format(Locale.GERMAN, "%s · %.0f Bilder/s · Grafikkarte %.2f ms · Prozessor %.2f ms · %d×%d (%s%s) · %s",
                clock.label(), fps, gpuMs, cpuMs, w, h, quality.label, autoScale ? String.format(Locale.GERMAN, ", %.0f %%", renderScale * 100) : "", glInfo);
        if (System.currentTimeMillis() < photoMsgUntil) s = photoMsg + " · " + s;
        return s;
    }

    // ------------------------------------------------------------------ HUD

    BufferedImage paintHud() {
        String[] lines = hudFull ? hudLines() : hudShort();
        Font font = new Font(Font.MONOSPACED, Font.PLAIN, 12);
        BufferedImage probe = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
        Graphics2D pg = probe.createGraphics();
        java.awt.FontMetrics fm = pg.getFontMetrics(font);
        int tw = 0;
        for (String l : lines) tw = Math.max(tw, fm.stringWidth(l.startsWith("!") ? l.substring(1) : l));
        pg.dispose();
        int w = Math.max(200, tw + 22), lh = 17, h = 16 + lines.length * lh;
        BufferedImage im = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = im.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setColor(new Color(12, 16, 14, 175));
        g.fillRoundRect(0, 0, w - 1, h - 1, 10, 10);
        g.setColor(new Color(226, 122, 46, 210));
        g.setStroke(new BasicStroke(2f));
        g.drawLine(8, 1, 60, 1);
        g.setFont(font);
        for (int i = 0; i < lines.length; i++) {
            String l = lines[i];
            boolean warn = l.startsWith("!");
            if (warn) l = l.substring(1);
            g.setColor(i == 0 ? new Color(240, 236, 226) : warn ? new Color(240, 170, 80) : new Color(190, 200, 192));
            g.drawString(l, 10, 18 + i * lh);
        }
        g.dispose();
        return im;
    }

    /** Das kurze HUD: Tempo, Zeit und Wetter, Kamera. Meldungen mit ! aus den vollen Zeilen kommen dazu. */
    String[] hudShort() {
        java.util.List<String> l = new java.util.ArrayList<>();
        String q = autoScale ? String.format(Locale.GERMAN, "%s %.0f %%", quality.label, renderScale * 100) : quality.label;
        l.add(String.format(Locale.GERMAN, "%.0f Bilder/s · Grafikkarte %.1f ms · Prozessor %.1f ms · %s %d×%d", fps, gpuMs, cpuMs, q, hdrW, hdrH));
        l.add(String.format(Locale.GERMAN, "%s · %s", clock.label(), windLine()));
        l.add(String.format(Locale.GERMAN, "%s · Auge %.0f m · Blick %03.0f° · Bachmund %.0f m · H: volles HUD, F1: Tasten", camera.modeName(), camera.eye[1], camera.heading(), camera.originDistance()));
        com.dan.haithabu.camera.Fahrt fa = camera.fahrt;
        if (fa != null) l.add("Fahrt " + fa.describe() + " · Pfeiltaste oder Maus: anhalten");
        for (String s : hudLines()) if (s.startsWith("!")) l.add(s);
        if (System.currentTimeMillis() < photoMsgUntil) l.add(photoMsg);
        return l.toArray(new String[0]);
    }

    String windLine() {
        if (wiring == null) return "Wind —";
        return wiring.weatherLine();
    }

    /** „Himmel com.dan.sky · Sonne 12,3° · Mond 45 % · Sicht 25 km · GPU = CPU …“ */
    public String skyLine() {
        if (!skyOk) return "!Himmel: einfacher Verlauf (com.dan.sky nicht gestartet)";
        Sky.State st = skyState();
        return String.format(Locale.GERMAN, "Himmel %s · Sonne %.1f° · Mond %.0f %% · Sicht %.0f km · Belichtung %.3g%s", skyGl.info(), st.sunAlt,
                st.moonFraction * 100, st.visibilityKm, exposure(), (frameLum > 0 ? " · " + bildLine() : "") + (skyCheck.isEmpty() ? "" : " · " + skyCheck));
    }

    /** „Wolken Cumulus 3/8 · hohe Schicht 10 % · Schatten am Auge 100 % · …“ */
    public String cloudLine() {
        if (!cloudsOk) return skyOk ? "!Wolken: com.dan.cloud nicht gestartet (Schleier des Himmels)" : "Wolken —";
        return String.format(Locale.GERMAN, "Wolken %s %.1f/8 · hohe Schicht %.0f %% · Sonne am Auge %.0f %% · %s%s", clouds.type.label, clouds.oktas,
                clouds.highCover * 100, cloudShade * 100, cloudGl.info(), cloudCheck.isEmpty() ? "" : " · " + cloudCheck);
    }

    public String rainLine() {
        if (!rainOk) return "!Regen: com.dan.rain nicht gestartet";
        return rain.rate <= 0 ? "Regen: trocken" : String.format(Locale.GERMAN, "Regen %.1f mm/h · am Auge %.1f mm/h%s", rain.rate,
                rain.snapshot().rateAt(camera.eye[0], camera.eye[2]), rainCheck.isEmpty() ? "" : " · " + rainCheck);
    }

    public String fogLine() {
        if (!fogOk) return "!Nebel: com.dan.fog nicht gestartet";
        if (!fog.snapshot().any()) return "Nebel: keiner";
        double[] e = camera.eye;
        return String.format(Locale.GERMAN, "Nebel %.0f %% · Sicht in der Bank %.0f m · %.0f bis %.0f m über dem Noor · Sicht am Auge %s%s", fog.amount * 100,
                fog.visibilityM, wiring != null ? wiring.fogBase : 0, fog.top, fmtDist(fog.visibilityAt(e[0], e[1], e[2])), fogCheck.isEmpty() ? "" : " · " + fogCheck);
    }

    static String fmtDist(double m) { return m >= 1e5 ? "frei" : m >= 1000 ? String.format(Locale.GERMAN, "%.1f km", m / 1000) : String.format(Locale.GERMAN, "%.0f m", m); }

    public String lightningLine() {
        if (!lightningOk) return "!Blitz: com.dan.lightning nicht gestartet";
        if (lightning.level() == Lightning.Level.OFF && lightning.flashes() == 0) return "Gewitter: keines";
        return String.format(Locale.GERMAN, "Gewitter %s · %d Blitze, %d Erdblitze%s%s", lightning.level().name().toLowerCase(Locale.ROOT), lightning.flashes(),
                lightning.groundFlashes(), lastBoltText.isEmpty() ? "" : " · zuletzt " + lastBoltText, lightningCheck.isEmpty() ? "" : " · " + lightningCheck);
    }

    /** Alle Zeilen des vollen HUD (auch für den Block TECHNIK). */
    public String[] hudLines() {
        double[] sp = clock.sun();
        ComputeProbe.Result c = compute;
        return new String[]{
                String.format(Locale.GERMAN, "%.0f Bilder/s   Grafikkarte %.2f ms   Prozessor %.2f ms", fps, gpuMs, cpuMs),
                passTimes(),
                (c == null ? "!Compute-Test läuft …" : (c.ok() ? "" : "!") + c.line()),
                String.format(Locale.GERMAN, "%s · Sonne %.1f° / %03.0f° · Belichtung %.2g", clock.label(), sp[0], sp[1], exposure()),
                windLine(),
                skyLine(),
                cloudLine(),
                rainLine(),
                yearLine(),
                fogLine(),
                lightningLine(),
                String.format(Locale.GERMAN, "Wetter auf dem Prozessor %.2f ms", weatherCpuMs),
                "Gelände " + terrain.describe() + String.format(Locale.GERMAN, " · %d Knoten, %,d Punkte", lod.nodes, lod.vertices),
                oceanLine(),
                brook == null ? "!Bach: kein Lauf im Gelände" : brook.describe(),
                reedOk ? "Halme " + reed.describe() + " · " + reedGl.info() : "!Halme: com.dan.reed nicht gestartet",
                groundOk ? groundGl.info() : "!Bodendecke: com.dan.ground nicht gestartet",
                timberOk ? "Häuser " + timberGl.info() + String.format(Locale.GERMAN, " · Nässe %.0f %%", weathering.snapshot().rainWet() * 100) : "!Häuser: com.dan.timber nicht gestartet",
                siedlung.hafen != null ? siedlung.hafen.describe() : "Hafen: keiner (flache Bühne)",
                shipLine(),
                fireLine(),
                smokeLine(),
                lifeLine(),
                herdLine(),
                soundLine(),
                regieLine(),
                hallLine(),
                terrain.befestigung != null ? terrain.befestigung.describe() + (camera.fahrt != null ? " · Fahrt " + camera.fahrt.describe() : "") : "Wall: flache Bühne, keine Befestigung",
                forestOk ? forestGl.info() + (sunShadow.matrix != null ? String.format(Locale.GERMAN, " · Sonnenschatten %d² über %.0f m", sunShadow.size, sunShadow.half * 2) : "") : "!Wald: com.dan.forest nicht gestartet",
                wiring == null ? "Verdrahtung —" : "Verdrahtung " + wiring.summary(),
                String.format(Locale.GERMAN, "%s · Auge %.1f m · Blick %03.0f° · Bachmund %.0f m · %s",
                        camera.modeName(), camera.eye[1], camera.heading(), camera.originDistance(), Site.dms(Site.lat(camera.eye[2]), Site.lon(camera.eye[0]))),
                String.format(Locale.GERMAN, "%s · %d×%d · %s", quality.label, hdrW, hdrH, reversedZ ? "umgekehrte Tiefe" : "klassische Tiefe"),
                glInfo};
    }

    /** „Schiffe: 4 · Knorr segelt an (2,9 m/s, Segel 100 %) · 4 Schiffe · 31 000 Dreiecke · 0,5 ms“ */
    public String shipLine() {
        Flotte fl = flotte;
        if (fl == null) return "Schiffe: keine (kein Hafen)";
        if (!shipsOk) return "!Schiffe: com.dan.longship nicht gestartet";
        return fl.describe() + " · " + longshipGl.info() + String.format(Locale.GERMAN, " · Spritzer %d · %.2f ms", fl.spray.parcels().size(), shipsCpuMs)
                + (camera.mitfahrt != null ? " · Mitfahrt" : "");
    }

    /** Phase 9: die Knorr von draußen hereinholen (Bedienfeld, Taste 9). */
    public void knorrEinlaufen() {
        Flotte fl = flotte;
        if (fl == null) return;
        fl.einlaufen(wiring != null ? wiring.wind.fromDeg() : 245, (wiring != null ? wiring.wind.speed() : Beaufort.mid(3)) * Wiring.LAND_WIND);
    }

    /** Die Knorr läuft aus dem Hafen aus (Block HAFEN, wie „auslaufen“ im Regiebuch). */
    public void knorrAuslaufen() {
        Flotte fl = flotte;
        if (fl == null) return;
        fl.auslaufen(wiring != null ? wiring.wind.fromDeg() : 245, (wiring != null ? wiring.wind.speed() : 4) * Wiring.LAND_WIND);
    }

    /** Der Brander von 1050 (Block HAFEN, wie „brander“ im Regiebuch): ein brennendes Schiff treibt mit dem Wind in den Hafen. */
    public void branderLos() {
        Flotte fl = flotte;
        Feuer fe = feuer;
        if (fl == null || fe == null) return;
        com.dan.haithabu.scene.Brand br = com.dan.haithabu.scene.Brand.of(siedlung, fl, 1050);
        fe.brand = br;
        timber.burn = br::burnOf;
        fl.branderStart();
    }

    /** Phase 9: Mitfahrt auf der einlaufenden Knorr an und aus (Taste 9); beim Anschalten läuft sie ein, wenn sie liegt. */
    public boolean toggleMitfahrt() {
        Flotte fl = flotte;
        if (camera.mitfahrt != null || fl == null) { camera.stopMitfahrt(); return false; }
        camera.stopFahrt();
        if (!fl.arriving()) knorrEinlaufen();
        camera.startMitfahrt(fl::mitfahrt);
        return true;
    }

    /** „Noor Bft 3 · Hs 0,09 m · Tp 1,0 s · FFT 3 × 256² · GPU = CPU ± 0,1 mm“ */
    public String oceanLine() {
        if (!oceanOk) return "!Noor: nicht gestartet (Compute-Shader fehlen)";
        Ocean.State st = ocean.state();
        String chk = oceanCheck.isEmpty() ? "Abgleich folgt" : oceanCheck.replace("Grafikkarte = Prozessor: größte Abweichung", "GPU = CPU ±").replaceAll(" \\(.*\\)", "");
        return String.format(Locale.GERMAN, "Noor Bft %d · Hs %.2f m · Tp %.1f s · Spiegel %+.2f m · %s · %s",
                Beaufort.of(ocean.windSpeed), st.totalHs(), st.peakPeriod, ocean.waterLevel, oceanGl.info().replaceAll(", Ringgitter.*", ""), chk);
    }

    // ------------------------------------------------------------------ Bildfolge (Phase 7)

    /** Eine Fahrt als Bildfolge aus n Bildern in gleichen Abständen; das Ergebnis landet als ein Bild in docs/status. */
    public void requestBildfolge(com.dan.haithabu.camera.Fahrt f, int n) {
        if (f == null) return;
        pendingBfN = n;
        pendingBf = f;
    }

    /**
     * Phase 12: Bildfolge „Jahr“ — die jetzige Ansicht zur jetzigen Uhrzeit am 16. Januar, April, Juli und Oktober
     * des laufenden Jahrs (Abnahme Phase 12); danach stehen Datum und Uhrzeit wieder wie vorher.
     */
    public void requestJahr() {
        int y = clock.date().getYear();
        java.time.LocalDate[] d = {java.time.LocalDate.of(y, 1, 16), java.time.LocalDate.of(y, 4, 16), java.time.LocalDate.of(y, 7, 16), java.time.LocalDate.of(y, 10, 16)};
        double[] e = camera.eye;
        double hd = Math.toRadians(camera.heading());
        pendingDates = d;
        pendingBfN = d.length;
        pendingBf = new com.dan.haithabu.camera.Fahrt("Jahr", new double[][]{{e[0], e[1], e[2]}, {e[0] + Math.sin(hd), e[1], e[2] - Math.cos(hd)}}, 1, 0, 0);
    }

    /**
     * Phase 13: Bildfolge „Tiere“ — Hafen, Vom Wall, Am Bach und Gegenufer um 10 Uhr (Abnahme: Vögel auf Wasser und
     * Pfählen, Ziegen am Hang); danach stehen Datum und Uhrzeit wieder wie vorher.
     */
    public void requestTiere() {
        java.util.List<com.dan.haithabu.camera.Ansichten.Ansicht> v = new java.util.ArrayList<>();
        for (String n : new String[]{"Hafen", "Vom Wall", "Am Bach", "Gegenufer"}) {
            com.dan.haithabu.camera.Ansichten.Ansicht a = com.dan.haithabu.camera.Ansichten.byName(n);
            if (a != null) v.add(a);
        }
        if (v.isEmpty()) return;
        bfViewHour = 10;
        bfViewHours = null;
        pendingViews = v;
        pendingBfN = v.size();
        double[] e = camera.eye;
        pendingBf = new com.dan.haithabu.camera.Fahrt("Tiere", new double[][]{{e[0], e[1], e[2]}, {e[0] + 1, e[1], e[2]}}, 1, 0, 0);
    }

    /**
     * Phase 14: Bildfolge „Klang“ — Hafen um 7:30, Gasse und Vom Wall um 11:30 (vor der Mittagspause), im Haus um 19 Uhr; unter jedem
     * Bild die Pegel am Ohr und die drei teuersten Posten der Grafikkarte (Befund Phase 13: der Posten „Haus“ fehlte).
     */
    public void requestKlang() {
        java.util.List<com.dan.haithabu.camera.Ansichten.Ansicht> v = new java.util.ArrayList<>();
        java.util.List<Double> hours = new java.util.ArrayList<>();
        Object[][] plan = {{"Hafen", 7.5}, {"Gasse", 11.5}, {"Vom Wall", 11.5}, {"Im Haus", 19.0}};
        for (Object[] p : plan) {
            com.dan.haithabu.camera.Ansichten.Ansicht a = p[0].equals("Gasse") ? gasseView : com.dan.haithabu.camera.Ansichten.byName((String) p[0]);
            if (a == null || !com.dan.haithabu.camera.Ansichten.ready(a)) continue;
            v.add(a);
            hours.add((Double) p[1]);
        }
        if (v.isEmpty()) return;
        bfViewHours = hours.stream().mapToDouble(Double::doubleValue).toArray();
        pendingViews = v;
        pendingBfN = v.size();
        double[] e = camera.eye;
        pendingBf = new com.dan.haithabu.camera.Fahrt("Klang", new double[][]{{e[0], e[1], e[2]}, {e[0] + 1, e[1], e[2]}}, 1, 0, 0);
    }

    /** Die drei teuersten Posten der Grafikkarte jetzt: „Haus 3,1 · Rauch 1,4 · Noor 1,1 ms“. */
    public String topPasses(int n) {
        double[] t = passMs.clone();
        StringBuilder b = new StringBuilder();
        for (int k = 0; k < n; k++) {
            int best = -1;
            for (int i = 0; i < t.length; i++) if (best < 0 || t[i] > t[best]) best = i;
            if (best < 0 || t[best] <= 0) break;
            b.append(k > 0 ? " · " : "").append(PASSES[best]).append(' ').append(String.format(Locale.GERMAN, "%.1f", t[best]));
            t[best] = -1;
        }
        return b.append(" ms").toString();
    }

    /** Für die Bildfolge „Klang“: „am Ohr 58 dB · Wind 44 · Feuer 39 · …“ (die lautesten vier Teile). */
    private String soundSummary() {
        double[] l = sound.levels();
        String[] names = com.dan.soundscape.Soundscape.PARTS;
        StringBuilder b = new StringBuilder(String.format(Locale.GERMAN, "am Ohr %.0f dB", l[l.length - 1]));
        boolean[] used = new boolean[l.length];
        for (int k = 0; k < 4; k++) {
            int best = -1;
            for (int i = 0; i < l.length - 1; i++) if (!used[i] && l[i] > 25 && (best < 0 || l[i] > l[best])) best = i;
            if (best < 0) break;
            used[best] = true;
            b.append(String.format(Locale.GERMAN, " · %s %.0f", names[best], l[best]));
        }
        return b.toString();
    }

    /** Phase 14: Ton an oder aus (eigener Faden mit javax.sound). */
    public void setSound(boolean on) {
        soundOn = on;
        if (on) audio.start(); else audio.stop();
    }

    public boolean soundOn() { return soundOn; }

    /** Lautstärke 0..2. */
    public void setVolume(double v) { sound.volume = Math.max(0, Math.min(2, v)); }

    /** „Klang: am Ohr 58 dB … · Puffer 93 ms · 41 ms Rechnen je s“ für das HUD. */
    public String soundLine() {
        com.dan.haithabu.scene.Klang k = klang;
        if (k == null) return "Klang: —";
        String out = !soundOn ? "Ton aus" : !audio.error().isEmpty() ? "!" + audio.error()
                : String.format(Locale.GERMAN, "Puffer %.0f ms · %.0f ms Rechnen je s", audio.bufferMs(), sound.msPerSecond());
        return "Klang " + k.describe() + " · " + out + String.format(Locale.GERMAN, " · Szene %.2f ms", soundCpuMs);
    }

    // ------------------------------------------------------------------ Phase 15: Regiebücher

    /** Ein Regiebuch starten (null = anhalten). */
    public void startRegie(com.dan.haithabu.scene.Regie.Book b) {
        if (b == null) { regie.stop(); return; }
        album.clear();
        albumCaps.clear();
        albumGpu = albumFps = 0;
        albumSamples = 0;
        regie.start(b, regieCtx);
    }

    /** „Ein Handelstag · Die Knorr läuft ein · 2:10 von 14:00“ und der Brand, wenn einer läuft. */
    public String regieLine() {
        Feuer fe = feuer;
        com.dan.haithabu.scene.Brand br = fe != null ? fe.brand : null;
        String b = br != null ? " · " + br.describe() + String.format(Locale.GERMAN, " · %.2f ms", brandCpuMs) : "";
        return "Regie " + regie.describe() + (tagesregie && !regie.running() ? " · Tagesregie an" : "") + b + (regieMsg.isEmpty() ? "" : " · " + regieMsg);
    }

    /** Den Brand beenden (Häuser wieder heil, Brander fort). */
    public void clearBrand() {
        Feuer fe = feuer;
        if (fe != null) fe.brand = null;
        timber.burn = null;
        Flotte fl = flotte;
        if (fl != null) fl.branderOn = false;
    }

    /** Phase 16 (F33): ein Regiebuch an der Stelle t (s) fortsetzen, ohne die Stichworte davor zu wiederholen. */
    public void regieFortsetzen(com.dan.haithabu.scene.Regie.Book b, double t) {
        album.clear();
        albumCaps.clear();
        albumGpu = albumFps = 0;
        albumSamples = 0;
        regie.fortsetzen(b, t);
    }

    /** Phase 16 (F33): einen gesicherten Brand herstellen (Häuser aus der aktiven Siedlung, Brander wie gesichert). */
    public void brandHerstellen(String state) {
        Flotte fl = flotte;
        Feuer fe = feuer;
        if (fl == null || fe == null || siedlung == null) return;
        com.dan.haithabu.scene.Brand br = com.dan.haithabu.scene.Brand.of(siedlung, fl, 1050);
        br.setState(state);
        fe.brand = br;
        timber.burn = br::burnOf;
    }

    /** Phase 16: woher die Siedlung beim Start kommt (die App setzt das auf die Datenbank oder daten/). */
    public static volatile java.util.function.Function<Terrain, Siedlung> siedlungsLader = Siedlung::startup;

    /** Was die Regiebücher in der App tun. */
    private final class RegieCtx implements com.dan.haithabu.scene.Regie.Ctx {
        @Override public void time(java.time.LocalDate date, double hour) { clock.set(date, hour); readapt(); }
        @Override public void lapse(double x) { clock.lapse = x; }
        @Override public void weather(com.dan.weather.Scenario s) {
            if (wiring == null) return;
            wiring.regie = true;
            wiring.start(s);
        }
        @Override public void weatherFree(com.dan.weather.Weather.Phase p, double bft, double fromDeg) {
            if (wiring == null) return;
            wiring.regie = true;
            wiring.startFree(p);
            if (!Double.isNaN(bft)) wiring.hand(com.dan.weather.Weather.Var.WIND, Beaufort.mid((int) Math.round(bft)) / Wiring.LAND_WIND);
            if (!Double.isNaN(fromDeg)) wiring.hand(com.dan.weather.Weather.Var.DIRECTION, fromDeg);
            wiring.hand(com.dan.weather.Weather.Var.RAIN, 0);
            wiring.hand(com.dan.weather.Weather.Var.COVER, 1);
            wiring.hand(com.dan.weather.Weather.Var.FOG, 0);
        }
        @Override public void view(String name) {
            camera.stopFahrt();
            camera.stopMitfahrt();
            com.dan.haithabu.camera.Ansichten.Ansicht a = name.equals("Gasse") ? gasseView : com.dan.haithabu.camera.Ansichten.byName(name);
            if (a == null || !com.dan.haithabu.camera.Ansichten.ready(a)) return;
            if (a.orbit()) { camera.home(); camera.setMode(com.dan.haithabu.camera.Camera.Mode.KREISEN); }
            else if (com.dan.haithabu.camera.Ansichten.apply(a, camera, terrain)) camera.setMode(com.dan.haithabu.camera.Camera.Mode.FREI);
            readapt();
        }
        @Override public void fahrt(String name) {
            com.dan.haithabu.camera.Fahrt f = name.equals("Durch die Gasse") ? fahrtGasse : fahrtWall;
            if (f == null) return;
            camera.stopMitfahrt();
            camera.startFahrt(f);
            camera.setMode(com.dan.haithabu.camera.Camera.Mode.FREI);
        }
        @Override public void einlaufen() {
            Flotte fl = flotte;
            if (fl == null) return;
            knorrEinlaufen();
            fl.knorrAway = false;
        }
        @Override public void auslaufen() {
            Flotte fl = flotte;
            if (fl == null) return;
            fl.auslaufen(wiring != null ? wiring.wind.fromDeg() : 245, (wiring != null ? wiring.wind.speed() : 4) * Wiring.LAND_WIND);
        }
        @Override public void brander() {
            Flotte fl = flotte;
            Feuer fe = feuer;
            if (fl == null || fe == null) return;
            com.dan.haithabu.scene.Brand br = com.dan.haithabu.scene.Brand.of(siedlung, fl, 1050);
            fe.brand = br;
            timber.burn = br::burnOf;
            fl.branderStart();
        }
        @Override public void igniteNearBrander() {
            Flotte fl = flotte;
            Feuer fe = feuer;
            com.dan.haithabu.scene.Brand br = fe != null ? fe.brand : null;
            if (br == null || fl == null) return;
            // Funken und brennende Teile fliegen ans Ufer: die drei nächsten Häuser fangen Feuer
            br.igniteNear(fl.brander.x, fl.brander.z, 3);
        }
        @Override public void capture(String caption) { captureCaption = caption; }
        @Override public void sheet(String name) { sheetName = name; }
        @Override public void say(String text) { regieMsg = text; }
    }

    /** Die Fotos des Regiebuchs als ein Blatt nach docs/status (zwei Spalten, Unterschrift in zwei Zeilen). */
    private void writeSheet(String name) {
        if (album.isEmpty()) return;
        try {
            int n = album.size(), cols = 2, rows = (n + 1) / 2, cw = 960, ch = (int) Math.round(album.get(0).getHeight() * cw / (double) album.get(0).getWidth()), cap = 50, head = 44;
            BufferedImage out = new BufferedImage(cols * cw, head + rows * (ch + cap), BufferedImage.TYPE_INT_RGB);
            java.awt.Graphics2D g = out.createGraphics();
            g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION, java.awt.RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.setRenderingHint(java.awt.RenderingHints.KEY_TEXT_ANTIALIASING, java.awt.RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setColor(new java.awt.Color(16, 22, 19));
            g.fillRect(0, 0, out.getWidth(), out.getHeight());
            g.setColor(new java.awt.Color(232, 230, 222));
            g.setFont(new java.awt.Font(java.awt.Font.SANS_SERIF, java.awt.Font.BOLD, 20));
            g.drawString(String.format(Locale.GERMAN, "Haithabu · Regiebuch „%s“ · %s · %s · Ø %.0f Bilder/s · Grafikkarte Ø %.2f ms · %s", name, clock.dateLabel(), quality.label,
                    albumFps / Math.max(1, albumSamples), albumGpu / Math.max(1, albumSamples), glInfo.replaceAll(" ·.*", "")), 14, 29);
            g.setFont(new java.awt.Font(java.awt.Font.MONOSPACED, java.awt.Font.PLAIN, 16));
            for (int i = 0; i < n; i++) {
                int cx = (i % cols) * cw, cy = head + (i / cols) * (ch + cap);
                g.drawImage(album.get(i), cx, cy, cw, ch, null);
                g.setColor(new java.awt.Color(152, 162, 154));
                String[] ln = albumCaps.get(i).split("\n");
                for (int k = 0; k < ln.length; k++) g.drawString(ln[k], cx + 10, cy + ch + 21 + 20 * k);
            }
            g.dispose();
            File dir = photoDir != null ? photoDir : new File("docs/status");
            if (!dir.isDirectory() && !dir.mkdirs()) throw new java.io.IOException("Ordner " + dir + " lässt sich nicht anlegen");
            String fn = "Regiebuch_" + name.replace("ü", "ue").replace("ö", "oe").replace("ä", "ae").replace(' ', '_') + "_"
                    + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".png";
            File f = new File(dir, fn);
            javax.imageio.ImageIO.write(out, "png", f);
            photoMsg = "Regiebuch gespeichert: " + f.getPath();
            System.out.println(photoMsg);
        } catch (Exception e) {
            photoMsg = "Blatt des Regiebuchs fehlgeschlagen: " + e.getMessage();
            System.err.println(photoMsg);
        }
        photoMsgUntil = System.currentTimeMillis() + 6000;
    }

    /** Läuft gerade eine Bildfolge? */
    public boolean bildfolgeRunning() { return bf != null || pendingBf != null; }

    private void bildfolgePose() {
        if (bfViews != null) {
            if (bfViewHours != null) clock.setHour(bfViewHours[bfIndex]);
            com.dan.haithabu.camera.Ansichten.apply(bfViews.get(bfIndex), camera, terrain);
            readapt();
            // Phase 14: beim Klang länger warten (das Ohr passt sich in 4 s an, die Werkstätten kommen in Takt)
            bfWait = bfViewHours != null ? 420 : 150;
            return;
        }
        if (bfDates != null) {
            // dieselbe Ansicht, ein anderes Datum: lange warten (Wald backt das Laub neu, das Jahr rechnet vor, Augen passen sich an)
            clock.set(bfDates[bfIndex], bfOldHour);
            camera.place(bfPose[0], bfPose[1], bfPose[2], bfPose[3], bfPose[4]);
            readapt();
            bfWait = 160;
            return;
        }
        double[] q = bf.pose(bfIndex / (double) (bfN - 1));
        camera.place(q[0], q[1], q[2], q[3], q[4]);
        readapt();
        bfWait = 75;          // Phase 8: länger warten, bis die Wolken nach dem Sprung wieder ausgerechnet sind (Streifen in der ersten Bildfolge)
    }

    private void bildfolgeStep(GL4 gl) {
        if (bfWait < 20) { bfGpuSum += gpuMs; bfFpsSum += fps; bfSamples++; }
        if (--bfWait > 0) return;
        bfFrames[bfIndex] = readDefault(gl, surfW, surfH);
        double sm = bfIndex / (double) (bfN - 1) * bf.length;
        String near = "";
        if (terrain.befestigung != null) {
            double best = 1e9;
            for (com.dan.haithabu.scene.Befestigung.Tor tr : terrain.befestigung.tore) {
                double d = Math.hypot(tr.gate().x() - camera.eye[0], tr.gate().z() - camera.eye[2]);
                if (d < best) { best = d; near = String.format(Locale.GERMAN, " · %s %.0f m", tr.name(), d); }
            }
        }
        bfCaps[bfIndex] = bfViews != null && bfViewHours != null
                ? String.format(Locale.GERMAN, "%s · %s · %s\nteuer: %s", bfViews.get(bfIndex).name(), clock.timeLabel(), soundSummary(), topPasses(3))
                : bfViews != null
                ? String.format(Locale.GERMAN, "%s · %s · %s\nteuer: %s", bfViews.get(bfIndex).name(), clock.timeLabel(), lifeSummary(), topPasses(3))
                : bfDates != null
                ? String.format(Locale.GERMAN, "%s · %.1f °C · %s", clock.label(), wiring != null ? wiring.airTempC : 0, yearNow().describe())
                : String.format(Locale.GERMAN, "%d/%d · %,.0f m · Auge %.1f m · Blick %03.0f°%s", bfIndex + 1, bfN, sm, camera.eye[1], camera.heading(), near);
        bfIndex++;
        if (bfIndex < bfN) { bildfolgePose(); return; }
        try {
            int cols = 2, rows = (bfN + 1) / 2, cw = 960, ch = (int) Math.round(surfH * cw / (double) surfW), head = 44;
            boolean two = false;
            for (String c : bfCaps) two |= c != null && c.contains("\n");
            int cap = two ? 50 : 30;
            BufferedImage out = new BufferedImage(cols * cw, head + rows * (ch + cap), BufferedImage.TYPE_INT_RGB);
            java.awt.Graphics2D g = out.createGraphics();
            g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION, java.awt.RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.setRenderingHint(java.awt.RenderingHints.KEY_TEXT_ANTIALIASING, java.awt.RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setColor(new java.awt.Color(16, 22, 19));
            g.fillRect(0, 0, out.getWidth(), out.getHeight());
            g.setColor(new java.awt.Color(232, 230, 222));
            g.setFont(new java.awt.Font(java.awt.Font.SANS_SERIF, java.awt.Font.BOLD, 20));
            g.drawString(String.format(Locale.GERMAN, "Haithabu · Bildfolge „%s“ · %s · %s · Ø %.0f Bilder/s · Grafikkarte Ø %.2f ms · %s",
                    bf.name, clock.label(), quality.label, bfFpsSum / Math.max(1, bfSamples), bfGpuSum / Math.max(1, bfSamples), glInfo.replaceAll(" ·.*", "")), 14, 29);
            g.setFont(new java.awt.Font(java.awt.Font.MONOSPACED, java.awt.Font.PLAIN, 16));
            for (int i = 0; i < bfN; i++) {
                int cx = (i % cols) * cw, cy = head + (i / cols) * (ch + cap);
                g.drawImage(bfFrames[i], cx, cy, cw, ch, null);
                g.setColor(new java.awt.Color(152, 162, 154));
                // Phase 14 (Befund): zwei Zeilen, damit die Unterschriften nebeneinander nicht übereinander laufen
                String[] ln = bfCaps[i] == null ? new String[]{""} : bfCaps[i].split("\n");
                for (int k = 0; k < ln.length; k++) g.drawString(ln[k], cx + 10, cy + ch + 21 + 20 * k);
            }
            g.dispose();
            File dir = photoDir != null ? photoDir : new File("docs/status");
            if (!dir.isDirectory() && !dir.mkdirs()) throw new java.io.IOException("Ordner " + dir + " lässt sich nicht anlegen");
            File f = new File(dir, "Bildfolge_" + bf.name.replace("Ü", "Ue").replace("ü", "ue").replace(' ', '_') + "_"
                    + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".png");
            javax.imageio.ImageIO.write(out, "png", f);
            photoMsg = "Bildfolge gespeichert: " + f.getPath();
            System.out.println(photoMsg);
        } catch (Exception e) {
            photoMsg = "Bildfolge fehlgeschlagen: " + e.getMessage();
            System.err.println(photoMsg);
        }
        photoMsgUntil = System.currentTimeMillis() + 6000;
        showHud = bfHud;
        if (bfDates != null) { clock.set(bfOldDate, bfOldHour); bfDates = null; }
        if (bfViews != null) { clock.set(bfOldDate, bfOldHour); bfViews = null; bfViewHours = null; }
        bf = null;
        bfFrames = null;
    }

    // ------------------------------------------------------------------ Foto

    private void takePhoto(GL4 gl, int w, int h) {
        try {
            BufferedImage img = readDefault(gl, w, h);
            File dir = photoDir != null ? photoDir : new File("docs/status");
            if (!dir.isDirectory() && !dir.mkdirs()) throw new java.io.IOException("Ordner " + dir + " lässt sich nicht anlegen");
            File f = new File(dir, "Haithabu_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".png");
            javax.imageio.ImageIO.write(img, "png", f);
            photoMsg = "Foto gespeichert: " + f.getPath();
            System.out.println(photoMsg);
        } catch (Exception e) {
            photoMsg = "Foto fehlgeschlagen: " + e.getMessage();
            System.err.println(photoMsg);
        }
        photoMsgUntil = System.currentTimeMillis() + 5000;
    }

    /** Liest das fertige Fensterbild (nach Nachbearbeitung und HUD). */
    BufferedImage readDefault(GL4 gl, int w, int h) {
        ByteBuffer bb = Buffers.newDirectByteBuffer(w * h * 4);
        gl.glBindFramebuffer(GL.GL_READ_FRAMEBUFFER, defaultFbo);
        gl.glReadBuffer(defaultFbo == 0 ? GL.GL_BACK : GL.GL_COLOR_ATTACHMENT0);
        gl.glPixelStorei(GL.GL_PACK_ALIGNMENT, 1);
        gl.glReadPixels(0, 0, w, h, GL.GL_RGBA, GL.GL_UNSIGNED_BYTE, bb);
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        int[] row = new int[w];
        for (int y = 0; y < h; y++) {
            int o = (h - 1 - y) * w * 4;
            for (int x = 0; x < w; x++) {
                int i = o + x * 4;
                row[x] = ((bb.get(i) & 255) << 16) | ((bb.get(i + 1) & 255) << 8) | (bb.get(i + 2) & 255);
            }
            img.setRGB(0, y, w, 1, row, 0, w);
        }
        return img;
    }

    /** Für Werkzeuge: das letzte Bild als Bild (im GL-Faden aufrufen). */
    public BufferedImage grab(GLAutoDrawable d) {
        GL4 gl = d.getGL().getGL4();
        defaultFbo = d.getContext().getDefaultDrawFramebuffer();
        return readDefault(gl, d.getSurfaceWidth(), d.getSurfaceHeight());
    }

    // ------------------------------------------------------------------ Ende

    private void fail(String msg) {
        error = msg;
        System.err.println(msg);
        errorListener.accept(msg);
    }

    @Override
    public void dispose(GLAutoDrawable d) {
        audio.stop();
        GL4 gl = d.getGL().getGL4();
        for (Shader s : all) s.dispose(gl);
        hud.dispose(gl);
        lod.dispose(gl);
        if (oceanOk) oceanGl.dispose(gl);
        if (reedOk) reedGl.dispose(gl);
        if (skyOk) skyGl.dispose(gl);
        if (cloudsOk) cloudGl.dispose(gl);
        if (rainOk) rainGl.dispose(gl);
        if (snowOk) snowfallGl.dispose(gl);
        if (iceOk) iceGl.dispose(gl);
        if (fogOk) fogGl.dispose(gl);
        if (lightningOk) lightningGl.dispose(gl);
        if (forestOk) forestGl.dispose(gl);
        if (timberOk) timberGl.dispose(gl);
        if (shipsOk) longshipGl.dispose(gl);
        if (sprayOk) sprayGl.dispose(gl);
        if (birdsOk) flockGl.dispose(gl);
        if (animalsOk) herdGl.dispose(gl);
        if (smokeOk) smokeGl.dispose(gl);
        if (hearthOk) hearthGl.dispose(gl);
        if (groundOk) groundGl.dispose(gl);
        sunShadow.dispose(gl);
        Gpu.deleteFbos(gl, depthCopyFbo);
        Gpu.deleteTextures(gl, depthCopyTex);
        Gpu.deleteFbos(gl, panoFbo);
        Gpu.deleteTextures(gl, panoTex, reedTex, brookTex, yardTex);
        Gpu.deleteFbos(gl, hdrFbo);
        Gpu.deleteTextures(gl, hdrTex, depthTex);
        if (emptyVao != 0) gl.glDeleteVertexArrays(1, new int[]{emptyVao}, 0);
        for (int[] s : stamp) if (s[0] != 0) gl.glDeleteQueries(MARKS, s, 0);
        ready = false;
    }
}
