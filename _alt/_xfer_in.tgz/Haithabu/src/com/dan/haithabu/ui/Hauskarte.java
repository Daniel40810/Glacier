package com.dan.haithabu.ui;

import com.dan.fbutton.FButton;
import com.dan.fcombobox.FComboBox;
import com.dan.fslider.FSlider;
import com.dan.foptionpane.FOptionPane;
import com.dan.haithabu.camera.Camera;
import com.dan.haithabu.data.Daten;
import com.dan.haithabu.data.Datenseite;
import com.dan.haithabu.data.Speicher;
import com.dan.haithabu.data.Startdaten;
import com.dan.haithabu.gl.Renderer;
import com.dan.haithabu.scene.Siedlung;
import com.dan.store.Ablage;
import com.dan.store.Dienst;
import com.dan.store.Protokoll;
import com.dan.timber.House;
import com.dan.timber.HouseType;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Window;
import java.util.Locale;

/**
 * Die Hauskarte (F28 A): ein Klick auf ein Haus in der Szene zeigt Name, Rolle, Typ mit Maßen, Zustand, ob das Haus
 * von Hand geändert ist, und den Befund zum Haustyp. Typ und Zustand lassen sich ändern, das Haus lässt sich
 * entfernen; verschieben und drehen nicht. Eine mitgelieferte Siedlung wird beim ersten Ändern als „… (bearbeitet)“
 * gespeichert und aktiv gesetzt; danach wird die Siedlung aus dem Speicher neu gebaut.
 */
public final class Hauskarte {
    private Hauskarte() { }

    /** Das Haus unter dem Bildpunkt (px, py) eines Bilds w × h, oder null. Der Strahl trifft Quader bis zum First. */
    public static Siedlung.Haus treffer(Renderer r, int px, int py, int w, int h) {
        Siedlung s = r.siedlung;
        if (s == null || w <= 0 || h <= 0) return null;
        double[] d = strahl(r.camera, px, py, w, h), e = r.camera.eye;
        Siedlung.Haus best = null;
        double bt = 3000;
        for (Siedlung.Haus sh : s.haeuser) {
            House o = sh.house();
            double t = quader(e, d, o);
            if (t > 0 && t < bt) { bt = t; best = sh; }
        }
        return best;
    }

    /** Richtung des Sehstrahls durch einen Bildpunkt (Einheitsvektor). */
    static double[] strahl(Camera c, int px, int py, int w, int h) {
        double[] f = c.fwd;
        double[] up = {0, 1, 0};
        double[] ri = norm(cross(f, up));
        double[] u = cross(ri, f);
        double th = Math.tan(Math.toRadians(Camera.FOVY) / 2), asp = w / (double) h;
        double nx = (2.0 * (px + 0.5) / w - 1) * th * asp, ny = (1 - 2.0 * (py + 0.5) / h) * th;
        return norm(new double[]{f[0] + ri[0] * nx + u[0] * ny, f[1] + ri[1] * nx + u[1] * ny, f[2] + ri[2] * nx + u[2] * ny});
    }

    /** Abstand bis zum Quader des Hauses (Grundriss mit Dachüberstand, Höhe bis über den First), oder −1. */
    static double quader(double[] e, double[] d, House o) {
        HouseType t = o.type();
        double[] ax = o.axisX(), az = o.axisZ();
        double hl = t.outerHalfLength() + (o.length() - t.length) / 2, hw = t.outerHalfWidth() + (o.width() - t.width) / 2;
        double ex = e[0] - o.x(), ez = e[2] - o.z();
        // in örtliche Achsen: a längs, b quer
        double ea = ex * ax[0] + ez * ax[1], eb = ex * az[0] + ez * az[1], ey = e[1] - o.y();
        double da = d[0] * ax[0] + d[2] * ax[1], db = d[0] * az[0] + d[2] * az[1], dy = d[1];
        double lo = 0, hi = 1e9;
        double[][] slab = {{ea, da, -hl, hl}, {eb, db, -hw, hw}, {ey, dy, -t.sunk - 0.2, t.height()}};
        for (double[] s : slab) {
            if (Math.abs(s[1]) < 1e-12) { if (s[0] < s[2] || s[0] > s[3]) return -1; continue; }
            double t1 = (s[2] - s[0]) / s[1], t2 = (s[3] - s[0]) / s[1];
            lo = Math.max(lo, Math.min(t1, t2));
            hi = Math.min(hi, Math.max(t1, t2));
            if (lo > hi) return -1;
        }
        return lo;
    }

    private static double[] cross(double[] a, double[] b) { return new double[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]}; }
    private static double[] norm(double[] v) { double l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); return l < 1e-12 ? v : new double[]{v[0] / l, v[1] / l, v[2] / l}; }

    /** Zeigt die Karte zu einem Haus (aus dem Swing-Faden). */
    public static void zeigen(Component owner, Renderer r, Siedlung.Haus sh) {
        Window w = owner == null ? null : SwingUtilities.getWindowAncestor(owner);
        JDialog d = new JDialog(w, "Hauskarte · " + sh.name(), java.awt.Dialog.ModalityType.MODELESS);
        House o = sh.house();
        String sname = Datenseite.siedlungName;
        Daten.Haus zeile = null;
        try { if (sname != null) zeile = Datenseite.zeile(sname, sh); } catch (Ablage.Fehler e) { /* ohne Zeile */ }
        JPanel p = new JPanel();
        p.setBackground(Theme.bg());
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createEmptyBorder(14, 16, 14, 16));
        JLabel kopf = ControlPanel.label("<html><b>" + sh.name() + "</b> · " + sh.rolle() + (sh.museum() ? " · Museumshaus" : "") + "</html>");
        p.add(links(kopf));
        p.add(links(ControlPanel.small(String.format(Locale.GERMAN, "<html><body style='width:380px'>%s, %.1f × %.1f m, First %.1f m über dem Boden, Richtung %03.0f°, "
                        + "Lage x %.1f m, z %.1f m (vom Bachmund). Siedlung „%s“%s%s</body></html>",
                o.type().label, o.length(), o.width(), o.type().ridgeY(), o.headingDeg(), o.x(), o.z(), sname == null ? "neu gewürfelt, nicht gespeichert" : sname,
                zeile != null && zeile.vonHand() ? " · von Hand geändert" : "", zeile != null && zeile.bemerkung() != null ? "<br>Bemerkung: " + zeile.bemerkung() : ""))));
        Daten.Befund b = Startdaten.befund(o.type().label);
        if (b != null) p.add(links(ControlPanel.small("<html><body style='width:380px'><br><b>" + b.befund() + "</b>: " + b.text()
                + (b.quellen().isEmpty() ? "" : " (" + String.join(", ", b.quellen()) + ")") + "</body></html>")));
        p.add(links(ControlPanel.label(" ")));
        p.add(links(ControlPanel.label("Typ")));
        HouseType[] typen = HouseType.values();
        String[] namen = new String[typen.length];
        for (int i = 0; i < typen.length; i++) namen[i] = typen[i].label + String.format(Locale.GERMAN, " (%.1f × %.1f m)", typen[i].length, typen[i].width);
        FComboBox typ = new FComboBox(namen);
        typ.setSelectedIndex(o.type().ordinal());
        p.add(links(typ));
        JLabel zl = ControlPanel.label("");
        FSlider zs = new FSlider(0, 100, (int) Math.round(o.state() * 100));
        Runnable zt = () -> zl.setText(String.format(Locale.GERMAN, "Zustand %.2f (0 neu, 1 alt: graues Reet, Moos, dunkles Holz)", zs.getValue() / 100.0));
        zt.run();
        zs.addChangeListener(e -> zt.run());
        p.add(links(zl));
        p.add(links(zs));
        p.add(links(ControlPanel.label("Bemerkung")));
        com.dan.ftextfield.FTextfield bem = new com.dan.ftextfield.FTextfield();
        if (zeile != null && zeile.bemerkung() != null) bem.setText(zeile.bemerkung());
        p.add(links(bem));
        JLabel note = ControlPanel.small(sname == null || isMitgeliefert(sname)
                ? "<html><body style='width:380px'>Die Siedlung wird beim ersten Ändern als „" + Datenseite.bearbeitet(sname == null ? "Startwert " + r.siedlung.seed : sname) + "“ gespeichert; die mitgelieferte bleibt.</body></html>" : " ");
        p.add(links(note));
        JPanel knoepfe = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        knoepfe.setOpaque(false);
        FButton weg = new FButton("Entfernen"), ok = new FButton("Übernehmen"), zu = new FButton("Schließen");
        knoepfe.add(weg);
        knoepfe.add(zu);
        knoepfe.add(ok);
        knoepfe.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(links(ControlPanel.label(" ")));
        p.add(knoepfe);
        zu.addActionListener(e -> d.dispose());
        ok.addActionListener(e -> {
            HouseType nt = typen[Math.max(0, typ.getSelectedIndex())];
            double nz = zs.getValue() / 100.0;
            String nb = bem.getText().isBlank() ? null : bem.getText().strip();
            d.dispose();
            aendern(owner, r, sh, nt, nz, nb, false);
        });
        weg.addActionListener(e -> {
            if (FOptionPane.showConfirmDialog(d, "„" + sh.name() + "“ aus der Siedlung entfernen?", "Hauskarte", FOptionPane.YES_NO_OPTION) != FOptionPane.YES_OPTION) return;
            d.dispose();
            aendern(owner, r, sh, null, 0, null, true);
        });
        d.setContentPane(p);
        d.pack();
        d.setLocationRelativeTo(owner);
        AppIcon.install(d);
        d.setVisible(true);
    }

    private static boolean isMitgeliefert(String name) {
        try {
            for (Daten.Siedlung s : Datenseite.speicher().siedlungen()) if (s.name().equals(name)) return Daten.MITGELIEFERT.equals(s.herkunft());
        } catch (Ablage.Fehler e) { /* unbekannt */ }
        return true;
    }

    private static JComponentRow links(Component c) { return new JComponentRow(c); }

    /** Eine linksbündige Zeile. */
    private static final class JComponentRow extends JPanel {
        JComponentRow(Component c) {
            super(new BorderLayout());
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));
            add(c, BorderLayout.CENTER);
            setAlignmentX(Component.LEFT_ALIGNMENT);
        }
        @Override public java.awt.Dimension getMaximumSize() { return new java.awt.Dimension(Integer.MAX_VALUE, getPreferredSize().height); }
    }

    /** Ändern oder entfernen, im Faden der Daten; danach die Siedlung neu bauen. */
    static void aendern(Component owner, Renderer r, Siedlung.Haus sh, HouseType typ, double zustand, String bemerkung, boolean entfernen) {
        Dienst.spaeter(() -> {
            try {
                Speicher sp = Datenseite.speicher();
                String name = Datenseite.bearbeitbar(r.siedlung);
                Daten.Haus z = Datenseite.zeile(name, sh);
                if (z == null) throw new Ablage.Fehler("Das Haus steht nicht in „" + name + "“");
                if (entfernen) {
                    sp.entfernen(name, z.nr());
                    Protokoll.info("Hauskarte", "„" + sh.name() + "“ aus „" + name + "“ entfernt");
                } else {
                    sp.aendern(name, new Daten.Haus(z.nr(), z.name(), typ.name(), z.rolle(), z.x(), z.y(), z.z(), z.richtungGrad(), z.laengeFaktor(), z.breiteFaktor(),
                            zustand, z.zufall(), z.museum(), true, bemerkung));
                    Protokoll.info("Hauskarte", "„" + sh.name() + "“ in „" + name + "“: " + typ.label + String.format(Locale.GERMAN, ", Zustand %.2f", zustand));
                }
                r.setSiedlung(Datenseite.laden(r.terrain));
            } catch (Ablage.Fehler | RuntimeException ex) {
                Protokoll.fehler("Hauskarte", "Nicht geändert: " + ex.getMessage(), ex instanceof RuntimeException ? ex : null);
                SwingUtilities.invokeLater(() -> FOptionPane.showMessageDialog(owner, "Nicht geändert:\n" + ex.getMessage(), "Hauskarte", FOptionPane.ERROR_MESSAGE));
            }
        });
    }
}
