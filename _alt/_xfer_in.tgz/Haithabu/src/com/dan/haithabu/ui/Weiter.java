package com.dan.haithabu.ui;

import com.dan.haithabu.data.Zustand;
import com.dan.haithabu.gl.Quality;
import com.dan.haithabu.gl.Renderer;
import com.dan.store.Protokoll;

import javax.swing.Timer;
import java.awt.Component;
import java.util.List;
import java.util.Map;

/**
 * „Weiter wie zuletzt“ (F33 A): einen gesicherten Zustand herstellen, sobald die Siedlung der Sitzung in der Szene
 * steht (eine neue Siedlung übernimmt der Renderer erst mit dem nächsten Bild und baut dabei Flotte und Feuer neu).
 */
final class Weiter {
    private Weiter() { }

    static void anwenden(Component owner, Renderer r, Map<String, String> z, Runnable danach) {
        long bis = System.currentTimeMillis() + 15_000;
        Timer t = new Timer(100, null);
        t.addActionListener(e -> {
            if (r.siedlungWartet() && System.currentTimeMillis() < bis) return;
            t.stop();
            jetzt(r, z);
            if (danach != null) danach.run();
        });
        t.start();
    }

    /** Sofort herstellen (die Siedlung steht schon). */
    static void jetzt(Renderer r, Map<String, String> z) {
        Quality q = Zustand.qualitaet(z);
        if (q != null && q != r.quality()) r.setQuality(q);
        if (z.containsKey("app.ton")) r.setSound(Boolean.parseBoolean(z.get("app.ton")));
        List<String> f = Zustand.anwenden(r, z);
        Protokoll.info("Sitzung", "Weiter wie zuletzt: " + z.size() + " Werte" + (f.isEmpty() ? "" : ", nicht hergestellt: " + String.join(", ", f)));
        r.hudMeldung("Weiter wie zuletzt · " + z.getOrDefault("uhr.datum", "") + (z.containsKey("regiebuch.name") ? " · " + z.get("regiebuch.name") : ""));
    }
}
