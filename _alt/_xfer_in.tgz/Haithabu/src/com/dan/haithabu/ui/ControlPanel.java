package com.dan.haithabu.ui;

import com.dan.fbutton.FButton;
import com.dan.fcheckbox.FCheckBox;
import com.dan.fcollapsiblepanel.FCollapsiblePanel;
import com.dan.fcombobox.FComboBox;
import com.dan.fslider.FSlider;
import com.dan.haithabu.camera.Camera;
import com.dan.haithabu.gl.ComputeProbe;
import com.dan.haithabu.gl.Quality;
import com.dan.haithabu.gl.Renderer;
import com.dan.haithabu.gl.SceneView;
import com.dan.haithabu.scene.SceneClock;
import com.dan.haithabu.scene.Sun;
import com.dan.haithabu.wiring.Beaufort;
import com.dan.haithabu.wiring.Wiring;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Locale;
import java.util.prefs.Preferences;

/**
 * Das Bedienfeld rechts als Klappblöcke (aus Lighthouse): ZEIT mit den Regiebüchern, WETTER mit Regie, Handreglern und
 * Wetterlagen, KAMERA mit Ansichten, gemerkten Ansichten (V) und Fahrten (Aufnahme mit P), SIEDLUNG mit Siedlungen und
 * der Hauskarte (Klick auf ein Haus), HAFEN mit Schiffen, Knorr und Brander, FEUER mit Herden, Versammlungshaus und
 * Brand, LEBEN mit Noor, Schilf, Wald, Tieren und Klang, BILD, DATEN mit Speicherort, Verbindung, Einrichter, „Weiter
 * wie zuletzt“, Presets und Protokoll, TECHNIK mit Leistung, Packages, Verdrahtung und „Was ist belegt?“ (F35 A).
 * Offen bleibt, was zuletzt offen war (je Rechner gemerkt). Jeder Regler schreibt direkt in die öffentlichen Felder
 * von Uhr, Kamera, Verdrahtung und Renderer; es gibt keinen zweiten Zustand.
 */
public final class ControlPanel extends JPanel implements javax.swing.Scrollable {
    private final SceneView view;
    private final Renderer r;
    private final SceneClock clock;
    private final Wiring wiring;
    private final JLabel dateLbl = label(""), timeLbl = label(""), sunLbl = small(""), windLbl = label(""), dirLbl = label(""),
            camLbl = small(""), perfLbl = small(""), computeLbl = small(""), glLbl = small(""), linksLbl = small(""), hudLbl = small(""),
            scaleLbl = label(""), qualLbl = small(""), pkgLbl = small(""), levelLbl = label(""), noorLbl = small(""), reedLbl = small(""),
            densLbl = label(""), groundLbl = small(""), regieLbl = small(""), coverLbl = label(""), rainLbl = label(""), fogLbl = label(""),
            visLbl = label(""), skyLbl = small(""), yearLbl = small(""), birdLbl = small(""), herdLbl = small(""), soundLbl = small(""), probenLbl = small(""), bookLbl = small("");
    private final FSlider time = new FSlider(0, 24 * 60 - 1, 17 * 60 + 30), wind = new FSlider(0, 12, 3), windDir = new FSlider(0, 359, 245),
            scaleSl = new FSlider(50, 100, 85), level = new FSlider(-40, 60, 0), reedDens = new FSlider(0, 150, 100),
            cover = new FSlider(0, 80, 30), rainSl = new FSlider(0, 200, 0), fogSl = new FSlider(0, 100, 0), visSl = new FSlider(2, 60, 25);
    private final FCheckBox free = new FCheckBox("Frei fliegen (F)"), orbit = new FCheckBox("Von selbst kreisen (R)"),
            marks = new FCheckBox("Marken (Raster, Bachmund, Modelliertes)"), autoBox = new FCheckBox("Auflösung selbst regeln"),
            water = new FCheckBox("Noor zeigen"), reedBox = new FCheckBox("Schilf, Binsen und Gras"),
            cloudBox = new FCheckBox("Wolken"), rainBox = new FCheckBox("Regen"), fogBox = new FCheckBox("Nebel"), boltBox = new FCheckBox("Blitze"),
            housesBox = new FCheckBox("Häuser, Wege, Zäune, Boote"),
            forestBox = new FCheckBox("Wald und Erlenbruch"), shadowBox = new FCheckBox("Sonnenschatten der Bäume"), groundBox = new FCheckBox("Bodendecke (zu Fuß)");
    private final JLabel forestLbl = small(""), housesLbl = small(""), seedLbl = small(""), shipLbl = small(""), fireLbl = small(""), smokeLbl = small(""), hallLbl = small("");
    private volatile String seedNote = "";
    private volatile boolean rolling;

    /** Baut die Siedlung mit dem Startwert neu (im Hintergrund, gut eine halbe Sekunde) und gibt sie dem Renderer. */
    private void regenerate(long seed) {
        if (rolling) return;
        rolling = true;
        seedNote = "würfle Startwert " + seed + " …";
        labels();
        Thread th = new Thread(() -> {
            try {
                com.dan.haithabu.scene.Siedlung s = com.dan.haithabu.scene.Siedlung.haithabu(r.terrain, seed);
                r.setSiedlung(s);
                com.dan.haithabu.data.Datenseite.siedlungName = null;
                seedNote = "neu gewürfelt, nicht gespeichert";
            } catch (RuntimeException ex) {
                seedNote = "Fehler: " + ex.getMessage();
            } finally {
                rolling = false;
                javax.swing.SwingUtilities.invokeLater(this::labels);
            }
        }, "Siedlung");
        th.setDaemon(true);
        th.start();
        view.requestFocusInWindow();
    }
    private FComboBox lapseBox, qualBox, hudBox, regieBox, thunderBox;
    private boolean fromScene;
    private int ticks;
    private JPanel target = this;
    private static final Preferences PREFS = prefs();
    private final java.util.List<Object[]> bloecke = new java.util.ArrayList<>();
    private final java.util.List<FCollapsiblePanel> zu = new java.util.ArrayList<>();
    private static final double[] LAPSE = {0, 1, 10, 60, 240, 600, 3600};
    /** Phase 3: die Wahl der Regie (Index wie {@link #regieBox}). */
    static final String[] REGIE = {"Von Hand", "Freie Regie", "Ein Nebelmorgen im Herbst", "Ein Nebeltag", "Ein Sturmtag"};

    /** Die kopierten Element-Packages (Werkbuch, Abschnitt 4) mit Stand. */
    public static final String[] PAKETE = {"ocean (Noor, verdrahtet)", "reed (neu, verdrahtet)", "river (Bach, verdrahtet)", "sky (verdrahtet)", "cloud (verdrahtet)",
            "weather (verdrahtet)", "rain (verdrahtet)", "fog (verdrahtet)", "lightning (verdrahtet)", "weathering (Nässe, verdrahtet)", "buoyancy (Schiffe, verdrahtet)", "flock (Vögel, verdrahtet)", "herd (Haustiere, verdrahtet)", "soundscape (Klang, verdrahtet)", "spray (Riemenspritzer, verdrahtet)", "longship (neu, verdrahtet)", "smoke (neu, verdrahtet)", "hearth (neu, verdrahtet)",
            "forest (Wald, verdrahtet)", "ground (Bodendecke, verdrahtet)", "road", "muster", "timber (Höfe am Bach, verdrahtet)", "season (Jahr, neu, verdrahtet)"};

    private static Preferences prefs() {
        try { return Preferences.userRoot().node("com/dan/haithabu/bedienfeld"); } catch (RuntimeException | Error e) { return null; }
    }

    public ControlPanel(SceneView view, Wiring wiring) {
        this.view = view;
        this.r = view.renderer();
        this.clock = r.clock;
        this.wiring = wiring;
        setBackground(Theme.bg());
        setOpaque(true);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBorder(BorderFactory.createEmptyBorder(10, 8, 16, 10));

        // ============================================================== ZEIT
        block("ZEIT", true);
        put(dateLbl);
        JPanel days = grid(3);
        FButton minus = new FButton("− Tag"), heute = new FButton("16.10.950"), plus = new FButton("+ Tag");
        minus.addActionListener(e -> { clock.shiftDays(-1); syncFromScene(); view.requestFocusInWindow(); });
        plus.addActionListener(e -> { clock.shiftDays(1); syncFromScene(); view.requestFocusInWindow(); });
        heute.setToolTipText("Zurück zum Start der Szene: 16. Oktober 950, 17:30 Uhr");
        heute.addActionListener(e -> { clock.set(SceneClock.START_DATE, SceneClock.START_HOUR); syncFromScene(); view.requestFocusInWindow(); });
        days.add(minus); days.add(heute); days.add(plus);
        put(days);
        // Phase 12: in einen Monat springen (der 16., gleiche Uhrzeit); das Jahr rechnet den Winter vor
        FComboBox monthBox = new FComboBox(new Object[]{"Monat springen …", "16. Januar", "16. Februar", "16. März", "16. April", "16. Mai", "16. Juni",
                "16. Juli", "16. August", "16. September", "16. Oktober", "16. November", "16. Dezember"});
        monthBox.setToolTipText("<html>Zum 16. eines Monats im laufenden Jahr, gleiche Uhrzeit. Schnee, Eis und Reif rechnet com.dan.season<br>"
                + "aus einem gewürfelten Jahr ab dem 1. September des Vorjahrs vor.</html>");
        monthBox.addActionListener(e -> {
            int i = monthBox.getSelectedIndex();
            if (i <= 0) return;
            clock.set(LocalDate.of(clock.date().getYear(), i, 16), clock.hour());
            monthBox.setSelectedIndex(0);
            syncFromScene();
            view.requestFocusInWindow();
        });
        put(monthBox);
        put(yearLbl);
        FButton yearSeq = new FButton("Bildfolge Jahr");
        yearSeq.setToolTipText("Dieselbe Ansicht am 16. Januar, April, Juli und Oktober ; danach wieder das jetzige Datum");
        yearSeq.addActionListener(e -> { r.requestJahr(); view.requestFocusInWindow(); });
        JPanel ys = grid(1);
        ys.add(yearSeq);
        put(ys);
        FCheckBox snowBox = new FCheckBox("Schneefall"), iceBox = new FCheckBox("Eis auf dem Noor");
        snowBox.setSelected(r.showSnow);
        iceBox.setSelected(r.showIce);
        snowBox.addActionListener(e -> { r.showSnow = snowBox.isSelected(); view.requestFocusInWindow(); });
        iceBox.addActionListener(e -> { r.showIce = iceBox.isSelected(); view.requestFocusInWindow(); });
        put(snowBox);
        put(iceBox);
        put(timeLbl);
        put(time);
        time.addChangeListener(e -> { if (!fromScene) clock.setHour(time.getValue() / 60.0); labels(); });
        put(label("Zeitraffer"));
        lapseBox = new FComboBox(new Object[]{"Uhr steht", "Echtzeit", "10-fach", "1 min/s", "4 min/s", "10 min/s", "1 h/s"});
        lapseBox.setSelectedIndex(1);
        lapseBox.addActionListener(e -> { clock.lapse = LAPSE[Math.max(0, lapseBox.getSelectedIndex())]; view.requestFocusInWindow(); });
        put(lapseBox);
        put(sunLbl);
        put(small("<html><body style='width:215px'>MEZ ohne Sommerzeit, Kalender gregorianisch rückgerechnet (F21). "
                + "Sonne, Mond, Planeten und Sterne stehen wie 950 (com.dan.sky, mit Präzession). Das Jahr (com.dan.season) nach dem Klima von Schleswig — "
                + "Laub, Gras, Felder und Schilf nach dem Tag, Schnee auf Boden, Dächern und Bäumen, Eis im flachen Noor, Reif in klaren Nächten; die Wetterregie kennt die Jahreszeit.</body></html>"));

        // ============================================================== WETTER
        regiebuecher();

        block("WETTER", true);
        put(label("Regie"));
        regieBox = new FComboBox(REGIE);
        regieBox.setSelectedIndex(wiring.regie ? 1 : 0);
        regieBox.addActionListener(e -> { if (!fromScene) regie(regieBox.getSelectedIndex()); view.requestFocusInWindow(); });
        put(regieBox);
        put(regieLbl);
        FButton weiter = new FButton("Regie weiter");
        weiter.setToolTipText("Alle Handregler lösen; die Größen gleiten mit ihrer Trägheit zurück zur Regie");
        weiter.addActionListener(e -> { wiring.resumeRegie(); view.requestFocusInWindow(); });
        put(weiter);
        put(windLbl);
        put(wind);
        put(dirLbl);
        put(windDir);
        // Handregler: mit Regie überschreiben sie eine Größe (Werte der Regie gelten über See, daher geteilt durch den Landanteil)
        wind.addChangeListener(e -> {
            if (fromScene) return;
            if (wiring.regie) wiring.hand(com.dan.weather.Weather.Var.WIND, Beaufort.mid(wind.getValue()) / Wiring.LAND_WIND);
            else wiring.wind.speed = Beaufort.mid(wind.getValue());
            labels();
        });
        windDir.addChangeListener(e -> {
            if (fromScene) return;
            if (wiring.regie) wiring.hand(com.dan.weather.Weather.Var.DIRECTION, windDir.getValue());
            else wiring.wind.fromDeg = windDir.getValue();
            labels();
        });
        sub("Himmel");
        put(skyLbl);
        put(coverLbl);
        put(cover);
        cover.addChangeListener(e -> { if (!fromScene) hand(com.dan.weather.Weather.Var.COVER, cover.getValue() / 10.0); labels(); });
        put(rainLbl);
        put(rainSl);
        rainSl.addChangeListener(e -> { if (!fromScene) hand(com.dan.weather.Weather.Var.RAIN, rainMm(rainSl.getValue())); labels(); });
        put(fogLbl);
        put(fogSl);
        fogSl.addChangeListener(e -> { if (!fromScene) hand(com.dan.weather.Weather.Var.FOG, fogSl.getValue() / 100.0); labels(); });
        put(visLbl);
        put(visSl);
        visSl.addChangeListener(e -> { if (!fromScene) hand(com.dan.weather.Weather.Var.VISIBILITY, visSl.getValue()); labels(); });
        put(label("Gewitter"));
        thunderBox = new FComboBox(new Object[]{"keines", "fern", "nah", "heftig", "über uns"});
        thunderBox.addActionListener(e -> { if (!fromScene) hand(com.dan.weather.Weather.Var.THUNDER, thunderBox.getSelectedIndex()); view.requestFocusInWindow(); });
        put(thunderBox);
        JPanel shows = new JPanel(new java.awt.GridLayout(0, 2, 6, 2));
        shows.setOpaque(false);
        cloudBox.setSelected(r.showClouds);
        cloudBox.addActionListener(e -> { r.showClouds = cloudBox.isSelected(); view.requestFocusInWindow(); });
        rainBox.setSelected(r.showRain);
        rainBox.addActionListener(e -> { r.showRain = rainBox.isSelected(); view.requestFocusInWindow(); });
        fogBox.setSelected(r.showFog);
        fogBox.addActionListener(e -> { r.showFog = fogBox.isSelected(); view.requestFocusInWindow(); });
        boltBox.setSelected(r.showLightning);
        boltBox.addActionListener(e -> { r.showLightning = boltBox.isSelected(); view.requestFocusInWindow(); });
        shows.add(cloudBox); shows.add(rainBox); shows.add(fogBox); shows.add(boltBox);
        put(shows);
        FButton bolt = new FButton("Blitz in Blickrichtung");
        bolt.setToolTipText("Ein Erdblitz in 1,5 bis 4 km vor der Kamera (auch ohne Gewitter)");
        bolt.addActionListener(e -> { r.triggerLightning(com.dan.lightning.Bolt.Kind.CLOUD_GROUND); view.requestFocusInWindow(); });
        put(bolt);
        sub("Noor");
        put(noorLbl);
        put(levelLbl);
        put(level);
        level.addChangeListener(e -> { if (!fromScene) wiring.waterLevel.level = level.getValue() / 100.0; labels(); });
        put(small("<html><body style='width:215px'>Das Noor hat keine Tide; Wind aus Ost staut es am Westufer bei Haithabu "
                + "auf, Westwind senkt es ab (von Hand, in cm über dem Mittel von 950). Wellen höchstens Bft 7 (F7). Die Regie "
                + "rechnet mit Wind über See; am Noor weht er mit 80 % [G].</body></html>"));
        wetterlagen();

        // ============================================================== KAMERA
        block("KAMERA", true);
        put(camLbl);
        free.addActionListener(e -> { view.setMode(free.isSelected() ? Camera.Mode.FREI : Camera.Mode.KREISEN); view.requestFocusInWindow(); });
        orbit.addActionListener(e -> { view.setAutoOrbit(orbit.isSelected()); view.requestFocusInWindow(); });
        view.setModeListener(m -> javax.swing.SwingUtilities.invokeLater(() -> free.setSelected(m == Camera.Mode.FREI)));
        view.setOrbitListener(b -> javax.swing.SwingUtilities.invokeLater(() -> orbit.setSelected(b)));
        put(free);
        put(orbit);
        sub("Ansichten (Tasten 1–7)");
        JPanel views = new JPanel(new java.awt.GridLayout(0, 2, 6, 4));
        views.setOpaque(false);
        for (com.dan.haithabu.camera.Ansichten.Ansicht a : com.dan.haithabu.camera.Ansichten.ALLE) {
            FButton b = new FButton(a.key() + " " + a.name());
            b.setEnabled(com.dan.haithabu.camera.Ansichten.ready(a));
            b.setToolTipText(com.dan.haithabu.camera.Ansichten.describe(a, r.terrain));
            b.addActionListener(e -> { ansicht(a); view.requestFocusInWindow(); });
            views.add(b);
            view.setKeyAction(java.awt.event.KeyEvent.VK_0 + a.key(), () -> javax.swing.SwingUtilities.invokeLater(() -> ansicht(a)));
            view.setKeyAction(java.awt.event.KeyEvent.VK_NUMPAD0 + a.key(), () -> javax.swing.SwingUtilities.invokeLater(() -> ansicht(a)));
        }
        FButton top = new FButton("Von oben");
        top.setToolTipText("Senkrecht über dem Bachmund, Norden oben");
        top.addActionListener(e -> { view.setMode(Camera.Mode.KREISEN); r.camera.lookAt(-100, 0, -100, 0, 89, 2600); view.requestFocusInWindow(); });
        views.add(top);
        put(views);
        sub("Fahrten (Tasten 0, 8 und 9)");
        JPanel rides = new JPanel(new java.awt.GridLayout(0, 2, 6, 4));
        rides.setOpaque(false);
        FButton wallRide = new FButton("8 Über den Wall");
        wallRide.setEnabled(r.fahrtWall != null);
        wallRide.setToolTipText(r.fahrtWall != null ? "<html>" + r.fahrtWall.describe() + "<br>auf dem Wehrgang vom Südende am Noor bis zum Nordende; noch einmal: anhalten</html>" : "ohne Höhendaten kein Wall");
        wallRide.addActionListener(e -> { fahrtWall(); view.requestFocusInWindow(); });
        FButton seq = new FButton("Bildfolge");
        seq.setEnabled(r.fahrtWall != null);
        seq.setToolTipText("Die Fahrt „Über den Wall“ als sechs Bilder in gleichen Abständen, zusammen ein Bild in docs/status");
        seq.addActionListener(e -> { r.requestBildfolge(r.fahrtWall, 6); view.requestFocusInWindow(); });
        rides.add(wallRide);
        rides.add(seq);
        // Phase 11: durch die Gasse am Bach ins Versammlungshaus
        FButton gasse = new FButton("0 Durch die Gasse");
        gasse.setEnabled(r.fahrtGasse != null);
        gasse.setToolTipText(r.fahrtGasse != null ? "<html>" + r.fahrtGasse.describe() + "<br>auf dem Bohlenweg am Bach, durch den Hof und die Osttür ins Versammlungshaus bis an sein Südende; noch einmal: anhalten</html>" : "kein Versammlungshaus");
        gasse.addActionListener(e -> { fahrtGasse(); view.requestFocusInWindow(); });
        FButton seqG = new FButton("Bildfolge Gasse");
        seqG.setEnabled(r.fahrtGasse != null);
        seqG.setToolTipText("Die Fahrt „Durch die Gasse“ als sechs Bilder in gleichen Abständen, zusammen ein Bild in docs/status");
        seqG.addActionListener(e -> { r.requestBildfolge(r.fahrtGasse, 6); view.requestFocusInWindow(); });
        rides.add(gasse);
        rides.add(seqG);
        // Phase 14: die Bildfolgen der Abnahmen auch hier (der Block LEBEN ist lang)
        FButton seqT = new FButton("Bildfolge Tiere"), seqK = new FButton("F9 Bildfolge Klang");
        seqT.setToolTipText("Hafen, Vom Wall, Am Bach und Gegenufer um 10 Uhr");
        seqT.addActionListener(e -> { r.requestTiere(); view.requestFocusInWindow(); });
        seqK.setToolTipText("Hafen um 7:30, Gasse und Vom Wall um 11:30, im Haus um 19 Uhr; unter jedem Bild Pegel und teuerste Posten, dauert gut 30 s");
        seqK.addActionListener(e -> { r.requestKlang(); view.requestFocusInWindow(); });
        rides.add(seqT);
        rides.add(seqK);
        put(rides);
        view.setKeyAction(java.awt.event.KeyEvent.VK_9, () -> javax.swing.SwingUtilities.invokeLater(this::mitfahrt));
        view.setKeyAction(java.awt.event.KeyEvent.VK_NUMPAD9, () -> javax.swing.SwingUtilities.invokeLater(this::mitfahrt));
        view.setKeyAction(java.awt.event.KeyEvent.VK_0, () -> javax.swing.SwingUtilities.invokeLater(this::fahrtGasse));
        view.setKeyAction(java.awt.event.KeyEvent.VK_NUMPAD0, () -> javax.swing.SwingUtilities.invokeLater(this::fahrtGasse));
        view.setKeyAction(java.awt.event.KeyEvent.VK_8, () -> javax.swing.SwingUtilities.invokeLater(this::fahrtWall));
        view.setKeyAction(java.awt.event.KeyEvent.VK_NUMPAD8, () -> javax.swing.SwingUtilities.invokeLater(this::fahrtWall));
        put(small("<html><body style='width:215px'>Hafen steht auf der Plattform an der Wurzel einer Landebrücke. "
                + "Im Haus steht am Südende des Versammlungshauses; die Fahrt Durch die Gasse endet dort. Während einer Fahrt "
                + "halten Pfeiltasten, W A S D oder Ziehen mit der Maus sie an; bei der Mitfahrt schaut Ziehen umher, W A S D steigt aus.</body></html>"));
        gemerkt();
        fahrten();

        siedlung();
        hafen();

        // ============================================================== FEUER
        block("FEUER", false);
        put(fireLbl);
        JPanel fireBoxes = grid(2);
        FCheckBox smokeBox = new FCheckBox("Rauch"), fireBox = new FCheckBox("Flammen und Licht");
        smokeBox.setSelected(r.showSmoke);
        fireBox.setSelected(r.showFire);
        smokeBox.addActionListener(e -> { r.showSmoke = smokeBox.isSelected(); view.requestFocusInWindow(); });
        fireBox.addActionListener(e -> { r.showFire = fireBox.isSelected(); view.requestFocusInWindow(); });
        fireBoxes.add(smokeBox);
        fireBoxes.add(fireBox);
        put(fireBoxes);
        JLabel herdLbl = small("Herde wie im Tagesgang (100 %)");
        FSlider herdSl = new FSlider(0, 200, 100);
        herdSl.setToolTipText("Wie viele Herde brennen, gemessen am Tagesgang (Kochen am Morgen und Abend, nachts Glut)");
        herdSl.addChangeListener(e -> { if (r.feuer != null) r.feuer.herdShare = herdSl.getValue() / 100.0; herdLbl.setText("Herde " + herdSl.getValue() + " % des Tagesgangs"); });
        put(herdLbl);
        put(herdSl);
        FComboBox torchBox = new FComboBox(new Object[]{"Fackeln nachts", "Fackeln an", "Fackeln aus"});
        torchBox.addActionListener(e -> { if (r.feuer != null) r.feuer.torchMode = switch (torchBox.getSelectedIndex()) { case 1 -> 1; case 2 -> 0; default -> -1; }; view.requestFocusInWindow(); });
        put(torchBox);
        put(smokeLbl);
        FButton brandOff = new FButton("Brand löschen");
        brandOff.setToolTipText("Die Häuser wieder heil, der Brander fort (nach der Nacht von 1050)");
        brandOff.addActionListener(e -> { r.clearBrand(); view.requestFocusInWindow(); });
        JPanel bo = grid(1);
        bo.add(brandOff);
        put(bo);
        put(small("<html><body style='width:215px'>Jedes Haus mit Rauchloch hat einen Herd; morgens und abends brennen die meisten, nachts glimmt nur noch wenig. "
                + "Der Rauch steigt mit seiner Wärme, knickt im Wind ab und legt sich in der windstillen Abendluft flach über die Dächer (Inversion). "
                + "Schmiede, Glasmacher und Bronzegießer arbeiten am Tag an offenen Essen. Am Strand des Fischers brennt abends ein Feuer, "
                + "an den Toren und Brückenköpfen stecken nachts Fackeln; ihr Licht fällt auf Häuser, Boden und Rauch. Ein Brand kommt mit dem Regiebuch „Die Nacht von 1050“ "
                + "oder dem Brander im Block HAFEN (com.dan.hearth).</body></html>"));
        sub("Versammlungshaus");
        put(hallLbl);
        FComboBox herdBox = new FComboBox(new Object[]{"Herd nach der Tageszeit", "Herd brennt", "Herd nur Glut"});
        herdBox.setToolTipText("<html>Nach der Tageszeit: Feuer 6:30–9:30, 11:30–13:30 und 16:30–22:30, dazwischen und nachts Glut unter der Asche</html>");
        herdBox.addActionListener(e -> {
            var h = r.hall();
            if (h != null) h.herdMode = switch (herdBox.getSelectedIndex()) { case 1 -> 1; case 2 -> 0; default -> -1; };
            view.requestFocusInWindow();
        });
        put(herdBox);
        FCheckBox roomBox = new FCheckBox("Rauch und Lichtstrahlen im Haus");
        roomBox.setSelected(r.showRoomSmoke);
        roomBox.addActionListener(e -> { r.showRoomSmoke = roomBox.isSelected(); view.requestFocusInWindow(); });
        put(roomBox);
        JLabel roomStrLbl = small("Rauch im Haus 100 %");
        FSlider roomSl = new FSlider(0, 150, 100);
        roomSl.setToolTipText("Dichte des Rauchs im Haus gegenüber der Rechnung (Zwei-Zonen-Modell)");
        roomSl.addChangeListener(e -> { r.roomSmokeStrength = roomSl.getValue() / 100.0; roomStrLbl.setText("Rauch im Haus " + roomSl.getValue() + " %"); });
        put(roomStrLbl);
        put(roomSl);
        put(small("<html><body style='width:215px'>Im Versammlungshaus brennt das Langfeuer in der Mitte; sein Rauch sammelt sich unter dem Dach als Schicht "
                + "und zieht durch die Rauchlöcher in den Giebeln ab (Zwei-Zonen-Modell: die Fahne über dem Feuer trägt so viel hinein, wie oben hinausgeht). "
                + "Durch Tür und Rauchloch fällt das Licht als Strahl in den Rauch. Nachts bleibt nur die Glut. Taste 7 stellt sich ans Südende der Halle.</body></html>"));

        // ============================================================== LEBEN
        block("LEBEN", false);
        put(reedLbl);
        reedBox.setSelected(r.showReed);
        reedBox.addActionListener(e -> { r.showReed = reedBox.isSelected(); view.requestFocusInWindow(); });
        put(reedBox);
        put(densLbl);
        put(reedDens);
        reedDens.addChangeListener(e -> { if (!fromScene) r.reed.density = reedDens.getValue() / 100.0; labels(); });
        water.setSelected(r.showWater);
        water.addActionListener(e -> { r.showWater = water.isSelected(); view.requestFocusInWindow(); });
        put(water);
        put(forestLbl);
        forestBox.setSelected(r.showForest);
        forestBox.addActionListener(e -> { r.showForest = forestBox.isSelected(); view.requestFocusInWindow(); });
        put(forestBox);
        shadowBox.setSelected(r.showSunShadow);
        shadowBox.addActionListener(e -> { r.showSunShadow = shadowBox.isSelected(); view.requestFocusInWindow(); });
        put(shadowBox);
        groundBox.setSelected(r.showGround);
        groundBox.addActionListener(e -> { r.showGround = groundBox.isSelected(); view.requestFocusInWindow(); });
        put(groundBox);
        put(small("<html><body style='width:215px'>Schilfgürtel am Ufer von 950, Binsen auf dem nassen Saum, Wiese auf dem Land "
                + "(com.dan.reed). Eichen-Buchen-Wald am Gegenufer und draußen vor den Feldern, Schwarzerlen im Bruch "
                + "(com.dan.forest), im Wall gerodet; Adlerfarn, Schafgarbe, Steine und Findlinge um das Auge (com.dan.ground). "
                + "Das Laub färbt sich mit dem Datum.</body></html>"));
        sub("Tiere");
        put(birdLbl);
        put(herdLbl);
        FCheckBox birdsBox = new FCheckBox("Vögel"), animalsBox = new FCheckBox("Haustiere");
        birdsBox.setSelected(r.showBirds);
        animalsBox.setSelected(r.showAnimals);
        birdsBox.addActionListener(e -> { r.showBirds = birdsBox.isSelected(); view.requestFocusInWindow(); });
        animalsBox.addActionListener(e -> { r.showAnimals = animalsBox.isSelected(); view.requestFocusInWindow(); });
        put(birdsBox);
        put(animalsBox);
        FButton tiere = new FButton("Bildfolge Tiere");
        tiere.setToolTipText("Hafen, Vom Wall, Am Bach und Gegenufer um 10 Uhr; danach wieder die jetzige Zeit");
        tiere.addActionListener(e -> { r.requestTiere(); view.requestFocusInWindow(); });
        JPanel tp = grid(1);
        tp.add(tiere);
        put(tp);
        put(small("<html><body style='width:215px'>Möwen über dem Hafen, auf den Pfählen der Palisade und im Becken; Kormorane trocknen dort "
                + "die Flügel und tauchen; Stockenten und Höckerschwäne im flachen Wasser, wo kein Eis liegt; Krähen auf den Feldern und Firsten, "
                + "Schwalben im Sommer tief über dem Wasser (com.dan.flock). Hühner in den Höfen am Bach, Ziegen am Hang unter dem Wall, Schweine "
                + "in Pferchen am oberen Rand, ein Hund am Hafen und einer in den Gassen (com.dan.herd). Wer zu nahe kommt, scheucht sie auf; "
                + "der Hund kommt näher und setzt sich. An den Brücken dümpeln drei Fischerboote.</body></html>"));
        sub("Klang");
        put(soundLbl);
        FCheckBox tonBox = new FCheckBox("Ton");
        boolean tonAn = PREFS == null || PREFS.getBoolean("ton", true);
        tonBox.setSelected(tonAn);
        r.setSound(tonAn);
        tonBox.addActionListener(e -> {
            r.setSound(tonBox.isSelected());
            if (PREFS != null) try { PREFS.putBoolean("ton", tonBox.isSelected()); } catch (RuntimeException ex) { /* nicht gemerkt */ }
            view.requestFocusInWindow();
        });
        put(tonBox);
        int vol0 = PREFS == null ? 80 : PREFS.getInt("lautstaerke", 80);
        JLabel volLbl = small("Lautstärke " + vol0 + " %");
        FSlider volSl = new FSlider(0, 200, vol0);
        r.setVolume(vol0 / 100.0);
        volSl.addChangeListener(e -> {
            r.setVolume(volSl.getValue() / 100.0);
            volLbl.setText("Lautstärke " + volSl.getValue() + " %");
            if (!volSl.getValueIsAdjusting() && PREFS != null) try { PREFS.putInt("lautstaerke", volSl.getValue()); } catch (RuntimeException ex) { /* nicht gemerkt */ }
        });
        put(volLbl);
        put(volSl);
        FButton klangBf = new FButton("Bildfolge Klang"), proben = new FButton("Hörproben schreiben");
        klangBf.setToolTipText("Hafen um 7:30, Gasse und Vom Wall um 11:30, im Haus um 19 Uhr; unter jedem Bild die Pegel am Ohr und die teuersten Posten");
        klangBf.addActionListener(e -> { r.requestKlang(); view.requestFocusInWindow(); });
        proben.setToolTipText("Die vier Hörproben der Abnahme als WAV nach docs/hoerproben (Hafen am Morgen, Gasse am Mittag, im Haus am Abend, die Nacht von 1050); dauert gut eine Minute");
        proben.addActionListener(e -> {
            proben.setEnabled(false);
            Thread th = new Thread(() -> {
                try {
                    java.io.File dir = new java.io.File(r.photoDir != null ? r.photoDir.getParentFile() : new java.io.File("docs"), "hoerproben");
                    com.dan.haithabu.tools.Hoerproben.write(r.terrain, r.siedlung, r.vegetation, dir, m -> javax.swing.SwingUtilities.invokeLater(() -> probenLbl.setText(
                            "<html><body style='width:215px'>" + m + "</body></html>")));
                    javax.swing.SwingUtilities.invokeLater(() -> probenLbl.setText("<html><body style='width:215px'>Hörproben geschrieben: " + dir.getPath() + "</body></html>"));
                } catch (Exception ex) {
                    javax.swing.SwingUtilities.invokeLater(() -> probenLbl.setText("Hörproben fehlgeschlagen: " + ex.getMessage()));
                } finally {
                    javax.swing.SwingUtilities.invokeLater(() -> proben.setEnabled(true));
                }
            }, "Hörproben");
            th.setDaemon(true);
            th.setPriority(Thread.MIN_PRIORITY);
            th.start();
        });
        JPanel kp = grid(1);
        kp.add(klangBf);
        kp.add(proben);
        put(kp);
        put(probenLbl);
        put(small("<html><body style='width:215px'>Alles erzeugt, ohne Aufnahmen (com.dan.soundscape). Wind, Wellen an den Pfählen, Schilf und Reet; "
                + "Möwen, Krähen, Enten, Schwalben, die Schwingen der Schwäne; Hühner, der Hahn in der Dämmerung, Ziegen, Schweine, Hunde; "
                + "Ruderschläge der Schiffe; Schmiede und Bronzegießer am Wall, der Kammmacher sägt Geweih, Zimmerleute und ein Bootsbauer am Strand; "
                + "der Markt am Umschlagplatz nach der Tageszeit; Feuer knistern, im Versammlungshaus nah und gedämpft von draußen; Donner vom Kanal des Blitzes.</body></html>"));

        // ============================================================== BILD
        block("BILD", false);
        put(label("Qualität"));
        qualBox = new FComboBox(Quality.values());
        qualBox.setSelectedItem(r.quality());
        qualBox.addActionListener(e -> { r.setQuality((Quality) qualBox.getSelectedItem()); view.requestFocusInWindow(); });
        put(qualBox);
        put(qualLbl);
        autoBox.setSelected(r.autoScale);
        autoBox.addActionListener(e -> { r.autoScale = autoBox.isSelected(); if (!r.autoScale) r.renderScale = scaleSl.getValue() / 100.0; view.requestFocusInWindow(); });
        put(autoBox);
        put(scaleLbl);
        put(scaleSl);
        scaleSl.addChangeListener(e -> {
            if (fromScene) return;
            r.autoScale = false;
            autoBox.setSelected(false);
            r.renderScale = scaleSl.getValue() / 100.0;
        });
        put(label("HUD"));
        hudBox = new FComboBox(new Object[]{"kurz", "voll", "aus"});
        hudBox.addActionListener(e -> {
            int i = hudBox.getSelectedIndex();
            r.showHud = i != 2;
            r.hudFull = i == 1;
            view.requestFocusInWindow();
        });
        put(hudBox);
        marks.setSelected(r.showMarks);
        marks.addActionListener(e -> { r.showMarks = marks.isSelected(); view.requestFocusInWindow(); });
        put(marks);
        JLabel anpLbl = small("");
        FSlider anpSl = new FSlider(0, 100, (int) Math.round(r.bildAnpassung * 100));
        Runnable anpT = () -> anpLbl.setText("<html><body style='width:215px'>Nachts an helle Bildteile anpassen: " + anpSl.getValue() + " % (ein ferner Brand blendet sonst weiß)</body></html>");
        anpT.run();
        anpSl.setToolTipText("0: das Auge bleibt auf die Nacht eingestellt; 100: es stellt sich ganz auf das mittlere Bild ein");
        anpSl.addChangeListener(e -> { r.bildAnpassung = anpSl.getValue() / 100.0; anpT.run(); });
        put(anpLbl);
        put(anpSl);
        JPanel pic = grid(2);
        FButton photo = new FButton("Foto (F12)"), shaders = new FButton("Shader neu (F5)");
        photo.addActionListener(e -> { r.photoRequest = true; view.requestFocusInWindow(); });
        shaders.addActionListener(e -> { r.requestShaderReload(); view.requestFocusInWindow(); });
        pic.add(photo); pic.add(shaders);
        put(pic);

        daten();

        // ============================================================== TECHNIK
        block("TECHNIK", false);
        put(perfLbl);
        put(computeLbl);
        put(glLbl);
        sub("Gelände");
        put(groundLbl);
        sub("Packages");
        put(pkgLbl);
        sub("Verdrahtung");
        put(linksLbl);
        sub("Alle Zeilen des HUD");
        put(hudLbl);
        sub("Befunde");
        put(small("<html><body style='width:215px'>Was in der Szene belegt, gemessen oder gestaltet ist, mit Quellen (HB_BEFUND).</body></html>"));
        FButton beleg = new FButton("Was ist belegt?");
        beleg.addActionListener(e -> Dialoge.befunde(this));
        JPanel bl = grid(1);
        bl.add(beleg);
        put(bl);

        for (Object[] b : bloecke) ((FCollapsiblePanel) b[0]).setBodyComponent((JComponent) b[1]);
        for (FCollapsiblePanel p : zu) p.setExpanded(false, false);
        add(Box.createVerticalGlue());
        view.setKeyAction(java.awt.event.KeyEvent.VK_F1, () -> javax.swing.SwingUtilities.invokeLater(this::tasten));
        view.setKeyAction(java.awt.event.KeyEvent.VK_V, () -> javax.swing.SwingUtilities.invokeLater(this::merken));
        view.setKeyAction(java.awt.event.KeyEvent.VK_P, () -> javax.swing.SwingUtilities.invokeLater(this::stuetzpunkt));
        view.setClickListener((x, y, w, h) -> {
            com.dan.haithabu.scene.Siedlung.Haus hh = Hauskarte.treffer(r, x, y, w, h);
            if (hh != null) javax.swing.SwingUtilities.invokeLater(() -> Hauskarte.zeigen(this, r, hh));
        });
        view.setKeyAction(java.awt.event.KeyEvent.VK_SPACE, () -> javax.swing.SwingUtilities.invokeLater(() ->
                lapseBox.setSelectedIndex(clock.lapse == 0 ? 1 : 0)));
        syncFromScene();
        new Timer(500, e -> syncFromScene()).start();
    }

    // ============================================================== Phase 16: Daten im Bedienfeld

    private FComboBox bookBox, lageBox, fahrtBox, siedBox, paketBox, presetBox;
    private java.util.List<com.dan.haithabu.data.Daten.Regiebuch> buecher = java.util.List.of();
    private java.util.List<com.dan.haithabu.data.Daten.Wetterlage> lagen = java.util.List.of();
    private java.util.List<com.dan.haithabu.data.Daten.Fahrt> fahrtListe = java.util.List.of();
    private java.util.List<com.dan.haithabu.data.Daten.Siedlung> siedListe = java.util.List.of();
    private java.util.List<com.dan.haithabu.data.Daten.PaketPreset> presetListe = java.util.List.of();
    private final JPanel gemerktPanel = new JPanel(new java.awt.GridLayout(0, 1, 0, 4));
    private final JLabel lageLbl = small(""), aufLbl = small(""), siedLbl = small(""), datenLbl = small(""), protLbl = small(""), presetLbl = small(""), hafenLbl = small("");
    private final java.util.List<com.dan.haithabu.data.Daten.Stuetzpunkt> aufnahme = new java.util.ArrayList<>();
    private long aufnahmeBeginn = -1;
    private volatile String datenNote = "";

    private static com.dan.haithabu.data.Speicher sp() { return com.dan.haithabu.data.Datenseite.speicher(); }

    /** Eine Combo neu füllen, ohne dass ihr Hörer feuert; die Auswahl bleibt, wenn es den Namen noch gibt. */
    private void fuellen(FComboBox box, java.util.List<?> l, String wahl) {
        fromScene = true;
        try {
            box.removeAllItems();
            int k = -1;
            for (int i = 0; i < l.size(); i++) { box.addItem(l.get(i)); if (l.get(i).toString().equals(wahl)) k = i; }
            if (k >= 0) box.setSelectedIndex(k); else if (!l.isEmpty()) box.setSelectedIndex(l.size() - 1);
        } finally { fromScene = false; }
    }

    private String gewaehlt(FComboBox box) { Object o = box.getSelectedItem(); return o == null ? null : o.toString(); }

    /** Im Faden der Daten arbeiten, danach auf dem Swing-Faden weiter; Fehler landen im Protokoll und in einer Meldung. */
    private <T> void hinten(String was, java.util.concurrent.Callable<T> arbeit, java.util.function.Consumer<T> danach) {
        com.dan.store.Dienst.spaeter(() -> {
            try {
                T t = arbeit.call();
                javax.swing.SwingUtilities.invokeLater(() -> danach.accept(t));
            } catch (Exception ex) {
                com.dan.store.Protokoll.fehler("Bedienfeld", was + ": " + ex.getMessage(), ex instanceof RuntimeException ? ex : null);
                Dialoge.fehler(this, "Haithabu · " + was, was + " ging nicht:\n" + ex.getMessage());
            }
        });
    }

    // ------------------------------------------------------------ ZEIT: Regiebücher

    private void regiebuecher() {
        sub("Regiebücher");
        bookBox = new FComboBox();
        put(bookBox);
        listeRegiebuecher("Die Nacht von 1050");
        FButton bookGo = new FButton("Starten"), bookStop = new FButton("Anhalten"), edit = new FButton("Bearbeiten …");
        bookGo.setToolTipText("Das Regiebuch von vorn: Datum, Uhrzeit, Wetter, Ansichten, Schiffe; am Ende ein Blatt mit den Bildern in docs/status");
        bookGo.addActionListener(e -> {
            com.dan.haithabu.data.Daten.Regiebuch rb = buch();
            if (rb == null) return;
            try { r.startRegie(com.dan.haithabu.scene.Regie.parse(rb.text())); view.setMode(Camera.Mode.FREI); }
            catch (RuntimeException ex) { Dialoge.fehler(this, "Regiebuch", "„" + rb.name() + "“ lässt sich nicht lesen:\n" + ex.getMessage()); }
            view.requestFocusInWindow();
        });
        bookStop.addActionListener(e -> { r.startRegie(null); view.requestFocusInWindow(); });
        edit.setToolTipText("Das Regiebuch als Text: prüfen, gleich abspielen, als eigenes speichern (ein mitgeliefertes bleibt)");
        edit.addActionListener(e -> {
            com.dan.haithabu.data.Daten.Regiebuch rb = buch();
            if (rb != null) Dialoge.regiebuch(this, rb, neu -> listeRegiebuecher(neu.name()), b -> { r.startRegie(b); view.setMode(Camera.Mode.FREI); });
        });
        JPanel bp = new JPanel(new java.awt.GridLayout(1, 3, 6, 0));
        bp.setOpaque(false);
        bp.add(bookGo);
        bp.add(bookStop);
        bp.add(edit);
        put(bp);
        FButton weg = new FButton("Eigenes Regiebuch löschen");
        weg.addActionListener(e -> {
            com.dan.haithabu.data.Daten.Regiebuch rb = buch();
            if (rb == null) return;
            if (!com.dan.haithabu.data.Daten.EIGEN.equals(rb.herkunft())) { Dialoge.fehler(this, "Regiebuch", "„" + rb.name() + "“ ist mitgeliefert und bleibt."); return; }
            if (com.dan.foptionpane.FOptionPane.showConfirmDialog(this, "„" + rb.name() + "“ löschen?", "Regiebuch", com.dan.foptionpane.FOptionPane.YES_NO_OPTION)
                    != com.dan.foptionpane.FOptionPane.YES_OPTION) return;
            hinten("Regiebuch löschen", () -> { sp().loeschenRegiebuch(rb.name()); return null; }, x -> listeRegiebuecher(null));
        });
        JPanel wp = grid(1);
        wp.add(weg);
        put(wp);
        put(bookLbl);
    }

    private com.dan.haithabu.data.Daten.Regiebuch buch() {
        int i = bookBox.getSelectedIndex();
        return i >= 0 && i < buecher.size() ? buecher.get(i) : null;
    }

    private void listeRegiebuecher(String wahl) {
        java.util.List<com.dan.haithabu.data.Daten.Regiebuch> l;
        try { l = sp().regiebuecher(); } catch (com.dan.store.Ablage.Fehler e) { l = java.util.List.of(); }
        if (l.isEmpty()) l = com.dan.haithabu.data.Startdaten.regiebuecher();
        buecher = l;
        fuellen(bookBox, l, wahl);
        StringBuilder t = new StringBuilder("<html>");
        for (var b : l) t.append("<b>").append(b.name()).append("</b>").append(com.dan.haithabu.data.Daten.EIGEN.equals(b.herkunft()) ? " (eigen)" : "")
                .append(b.beschreibung() == null || b.beschreibung().isBlank() ? "" : ": " + b.beschreibung()).append("<br>");
        bookBox.setToolTipText(t.append("</html>").toString());
    }

    // ------------------------------------------------------------ WETTER: Wetterlagen

    private void wetterlagen() {
        sub("Wetterlagen");
        lageBox = new FComboBox();
        put(lageBox);
        listeLagen(null);
        FButton laden = new FButton("Laden"), merk = new FButton("Speichern unter …");
        laden.setToolTipText("Freie Regie mit dieser Lage; ihre Werte als Handregler (lösen mit „Regie weiter“)");
        laden.addActionListener(e -> {
            int i = lageBox.getSelectedIndex();
            if (i < 0 || i >= lagen.size()) return;
            lageAnwenden(lagen.get(i));
            view.requestFocusInWindow();
        });
        merk.setToolTipText("Die Werte der Regie, wie sie jetzt sind, als eigene Wetterlage");
        merk.addActionListener(e -> {
            String n = Dialoge.frage(this, "Name der Wetterlage", "Wetterlage speichern");
            if (n == null) return;
            com.dan.haithabu.data.Daten.Wetterlage w = lageJetzt(n);
            hinten("Wetterlage speichern", () -> { sp().speichern(w); return null; }, x -> listeLagen(n));
        });
        JPanel g = grid(2);
        g.add(laden);
        g.add(merk);
        put(g);
        put(lageLbl);
    }

    private void listeLagen(String wahl) {
        java.util.List<com.dan.haithabu.data.Daten.Wetterlage> l;
        try { l = sp().wetterlagen(); } catch (com.dan.store.Ablage.Fehler e) { l = java.util.List.of(); }
        if (l.isEmpty()) l = com.dan.haithabu.data.Startdaten.wetterlagen();
        lagen = l;
        fuellen(lageBox, l, wahl != null ? wahl : "Klar");
        lageLbl.setText("<html><body style='width:215px'>" + l.size() + " Wetterlagen in " + sp().wo() + "</body></html>");
    }

    private void lageAnwenden(com.dan.haithabu.data.Daten.Wetterlage w) {
        com.dan.weather.Weather.Phase ph;
        try { ph = com.dan.weather.Weather.Phase.valueOf(w.phase()); } catch (RuntimeException ex) { ph = com.dan.weather.Weather.Phase.KLAR; }
        wiring.regie = true;
        wiring.startFree(ph);
        double[] v = w.werte();
        com.dan.weather.Weather.Var[] vs = com.dan.weather.Weather.Var.values();
        for (int i = 0; i < Math.min(v.length, vs.length); i++) if (!Double.isNaN(v[i]) && vs[i] != com.dan.weather.Weather.Var.CLOUD) wiring.hand(vs[i], v[i]);
        fromScene = true;
        regieBox.setSelectedIndex(1);
        fromScene = false;
        lageLbl.setText("<html><body style='width:215px'>Geladen: „" + w.name() + "“" + (w.beschreibung() == null ? "" : " · " + w.beschreibung()) + "</body></html>");
        com.dan.store.Protokoll.info("Wetter", "Wetterlage „" + w.name() + "“ geladen");
    }

    private com.dan.haithabu.data.Daten.Wetterlage lageJetzt(String name) {
        com.dan.weather.Weather.Snapshot s = wiring.weather.snapshot();
        double[] v = s == null ? new double[com.dan.weather.Weather.Var.values().length]
                : new double[]{s.wind(), s.fromDeg(), s.gustiness(), s.oktas(), s.high(), Double.NaN, s.rain(), s.visibilityKm(), s.fog(), s.pressure(), s.temperature(),
                s.humidity(), Double.NaN, s.thunder()};
        if (s == null) java.util.Arrays.fill(v, Double.NaN);
        int m = clock.date().getMonthValue();
        return new com.dan.haithabu.data.Daten.Wetterlage(name, s == null ? null : (double) s.beaufort(), s == null ? "KLAR" : s.phase().name(), v, Integer.toString(m),
                "Gespeichert am " + clock.dateLabel() + ", " + clock.timeLabel(), com.dan.haithabu.data.Daten.EIGEN);
    }

    // ------------------------------------------------------------ KAMERA: gemerkte Ansichten (V) und Fahrten (P)

    private void gemerkt() {
        sub("Gemerkte Ansichten (V)");
        gemerktPanel.setOpaque(false);
        put(gemerktPanel);
        FButton v = new FButton("Ansicht merken (V)");
        v.setToolTipText("Kamera, Uhr, Wetter, Regiebuch, Brand und Schiffe, dazu ein Vorschaubild 320 × 180");
        v.addActionListener(e -> { merken(); view.requestFocusInWindow(); });
        JPanel g = grid(1);
        g.add(v);
        put(g);
        listeGemerkt();
    }

    private void listeGemerkt() {
        hinten("Ansichten lesen", () -> {
            java.util.List<com.dan.haithabu.data.Daten.Ansicht> l = new java.util.ArrayList<>();
            for (var a : sp().ansichten()) if ("GEMERKT".equals(a.art())) l.add(a);
            return l;
        }, l -> {
            gemerktPanel.removeAll();
            if (l.isEmpty()) gemerktPanel.add(small("<html><body style='width:215px'>Noch keine. V merkt die jetzige Ansicht.</body></html>"));
            for (var a : l) {
                JPanel z = new JPanel(new BorderLayout(4, 0));
                z.setOpaque(false);
                FButton b = new FButton(a.name());
                if (a.vorschau() != null) try {
                    java.awt.image.BufferedImage im = javax.imageio.ImageIO.read(new java.io.ByteArrayInputStream(a.vorschau()));
                    if (im != null) b.setToolTipText("<html>" + a.name() + (a.szenenzeit() != null ? "<br>" + a.szenenzeit().datum() : "") + "</html>");
                    if (im != null) b.setIcon(new javax.swing.ImageIcon(im.getScaledInstance(64, 36, java.awt.Image.SCALE_SMOOTH)));
                } catch (java.io.IOException ex) { /* ohne Vorschau */ }
                b.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
                b.addActionListener(e -> { ansichtHerstellen(a); view.requestFocusInWindow(); });
                FButton x = new FButton("×");
                x.setToolTipText("Diese gemerkte Ansicht löschen");
                x.addActionListener(e -> hinten("Ansicht löschen", () -> { sp().loeschenAnsicht(a.id()); return null; }, n -> listeGemerkt()));
                z.add(b, BorderLayout.CENTER);
                z.add(x, BorderLayout.EAST);
                gemerktPanel.add(z);
            }
            gemerktPanel.revalidate();
            revalidate();
        });
    }

    /** V: die jetzige Ansicht mit Zustand und Vorschau merken. */
    private void merken() {
        String name = "Ansicht " + clock.dateLabel() + " " + clock.timeLabel();
        var z = com.dan.haithabu.data.Zustand.erfassen(r, r.soundOn(), com.dan.haithabu.data.Datenseite.siedlungName);
        double[] k = com.dan.haithabu.data.Zustand.kamera(r);
        var sz = com.dan.haithabu.data.Zustand.szenenzeit(z);
        String text = com.dan.store.Felder.alsText(z, "Haithabu · gemerkte Ansicht");
        r.grabRequest = img -> {
            byte[] png = null;
            try {
                java.awt.image.BufferedImage v = new java.awt.image.BufferedImage(320, 180, java.awt.image.BufferedImage.TYPE_INT_RGB);
                java.awt.Graphics2D g = v.createGraphics();
                g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION, java.awt.RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                double s = Math.max(320.0 / img.getWidth(), 180.0 / img.getHeight());
                int w = (int) Math.round(img.getWidth() * s), h = (int) Math.round(img.getHeight() * s);
                g.drawImage(img, (320 - w) / 2, (180 - h) / 2, w, h, null);
                g.dispose();
                java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
                javax.imageio.ImageIO.write(v, "png", o);
                png = o.toByteArray();
            } catch (java.io.IOException | RuntimeException ex) { /* ohne Vorschau */ }
            byte[] p = png;
            var a = new com.dan.haithabu.data.Daten.Ansicht(0, name, null, "GEMERKT", k, null, false, null, sz, text, p, com.dan.haithabu.data.Daten.EIGEN);
            hinten("Ansicht merken", () -> sp().speichern(a, com.dan.store.Dienst.sitzung() >= 0 ? com.dan.store.Dienst.sitzung() : null), id -> {
                r.hudMeldung("Ansicht gemerkt: " + name);
                listeGemerkt();
            });
        };
    }

    private void ansichtHerstellen(com.dan.haithabu.data.Daten.Ansicht a0) {
        hinten("Ansicht lesen", () -> a0.zustand() != null ? a0 : sp().ansicht(a0.id()), a -> {
            if (a == null) return;
            if (a.zustand() != null) {
                var z = com.dan.store.Felder.ausText(a.zustand());
                java.util.List<String> f = com.dan.haithabu.data.Zustand.anwenden(r, z);
                if (!f.isEmpty()) com.dan.store.Protokoll.warnung("Ansicht", "„" + a.name() + "“: nicht hergestellt " + String.join(", ", f));
            } else if (a.kamera() != null) {
                double[] k = a.kamera();
                r.camera.stopFahrt();
                r.camera.place(k[0], k[1], k[2], k[3], k[4]);
            }
            view.setMode(r.camera.mode);
            syncFromScene();
        });
    }

    private void fahrten() {
        sub("Eigene Fahrten (Aufnahme, P)");
        fahrtBox = new FComboBox();
        put(fahrtBox);
        listeFahrten(null);
        FButton ab = new FButton("Abspielen"), auf = new FButton("Aufnahme");
        ab.setToolTipText("Die Fahrt durch ihre Stützpunkte; noch einmal: anhalten");
        ab.addActionListener(e -> {
            int i = fahrtBox.getSelectedIndex();
            if (i < 0 || i >= fahrtListe.size()) return;
            if (r.camera.fahrt != null) { r.camera.stopFahrt(); return; }
            var f = fahrtListe.get(i);
            if (f.punkte().size() < 2) {
                if (f.name().equals("Über den Wall")) fahrtWall(); else if (f.name().equals("Durch die Gasse")) fahrtGasse();
                else Dialoge.fehler(this, "Fahrt", "„" + f.name() + "“ hat keine Stützpunkte.");
                return;
            }
            double[][] p = new double[f.punkte().size()][];
            for (int k = 0; k < p.length; k++) { var s = f.punkte().get(k); p[k] = new double[]{s.zeitS(), s.x(), s.y(), s.z(), s.gier(), s.nick()}; }
            r.camera.startFahrt(com.dan.haithabu.camera.Fahrt.aus(f.name(), p));
            view.setMode(Camera.Mode.FREI);
            view.requestFocusInWindow();
        });
        auf.setToolTipText("Aufnahme beginnen; dann setzt P an jeder Stelle einen Stützpunkt; noch einmal: beenden und speichern");
        auf.addActionListener(e -> { aufnahme(); view.requestFocusInWindow(); });
        JPanel g = grid(2);
        g.add(ab);
        g.add(auf);
        put(g);
        put(aufLbl);
    }

    private void listeFahrten(String wahl) {
        java.util.List<com.dan.haithabu.data.Daten.Fahrt> l;
        try { l = sp().fahrten(); } catch (com.dan.store.Ablage.Fehler e) { l = java.util.List.of(); }
        fahrtListe = l;
        fuellen(fahrtBox, l, wahl);
    }

    private void aufnahme() {
        if (aufnahmeBeginn < 0) {
            aufnahme.clear();
            aufnahmeBeginn = System.currentTimeMillis();
            view.setMode(Camera.Mode.FREI);
            stuetzpunkt();
            return;
        }
        aufnahmeBeginn = -1;
        if (aufnahme.size() < 2) { aufLbl.setText("Aufnahme verworfen: weniger als zwei Stützpunkte."); return; }
        String n = Dialoge.frage(this, "Name der Fahrt (" + aufnahme.size() + " Stützpunkte)", "Fahrt speichern");
        if (n == null) { aufLbl.setText("Aufnahme verworfen."); return; }
        var f = new com.dan.haithabu.data.Daten.Fahrt(n, null, "STUETZPUNKTE", false, aufnahme.size() + " Stützpunkte, aufgenommen am " + clock.dateLabel(),
                com.dan.haithabu.data.Daten.EIGEN, new java.util.ArrayList<>(aufnahme));
        hinten("Fahrt speichern", () -> { sp().speichern(f); return null; }, x -> { listeFahrten(n); aufLbl.setText("Gespeichert: „" + n + "“"); });
    }

    /** P: ein Stützpunkt an der jetzigen Kamera (nur während einer Aufnahme). */
    private void stuetzpunkt() {
        if (aufnahmeBeginn < 0) { r.hudMeldung("P setzt Stützpunkte, wenn eine Aufnahme läuft (KAMERA › Eigene Fahrten)"); return; }
        double[] k = com.dan.haithabu.data.Zustand.kamera(r);
        double t = (System.currentTimeMillis() - aufnahmeBeginn) / 1000.0;
        aufnahme.add(new com.dan.haithabu.data.Daten.Stuetzpunkt(aufnahme.size() + 1, Math.round(t * 10) / 10.0, k[0], k[1], k[2], k[3], k[4], k[5]));
        aufLbl.setText(String.format(Locale.GERMAN, "<html><body style='width:215px'>Aufnahme läuft: %d Stützpunkte, %.0f s. P setzt den nächsten, „Aufnahme“ beendet.</body></html>",
                aufnahme.size(), t));
        r.hudMeldung("Stützpunkt " + aufnahme.size());
    }

    // ------------------------------------------------------------ SIEDLUNG

    private void siedlung() {
        block("SIEDLUNG", false);
        housesBox.setSelected(r.showHouses);
        housesBox.addActionListener(e -> { r.showHouses = housesBox.isSelected(); view.requestFocusInWindow(); });
        put(housesBox);
        put(housesLbl);
        sub("Siedlungen");
        siedBox = new FComboBox();
        put(siedBox);
        listeSiedlungen();
        FButton akt = new FButton("Aktivieren"), unter = new FButton("Speichern unter …"), weg = new FButton("Löschen");
        akt.setToolTipText("Diese Siedlung in die Szene und beim nächsten Start");
        akt.addActionListener(e -> {
            String n = gewaehlt(siedBox);
            if (n == null) return;
            seedNote = "lade „" + n + "“ …";
            hinten("Siedlung aktivieren", () -> { sp().aktivieren(name(n)); r.setSiedlung(com.dan.haithabu.data.Datenseite.laden(r.terrain)); return null; },
                    x -> { seedNote = ""; listeSiedlungen(); });
        });
        unter.setToolTipText("Die Siedlung der Szene mit allen Häusern als eigene Siedlung; sie wird aktiv");
        unter.addActionListener(e -> {
            String n = Dialoge.frage(this, "Name der Siedlung", "Siedlung speichern");
            if (n == null) return;
            var s = r.siedlung;
            hinten("Siedlung speichern", () -> { com.dan.haithabu.data.Datenseite.speichernUnter(s, n, "Gespeichert am " + java.time.LocalDate.now()); return null; },
                    x -> { seedNote = "gespeichert als „" + n + "“"; listeSiedlungen(); });
        });
        weg.setToolTipText("Eine eigene Siedlung löschen (die mitgelieferte und die aktive bleiben)");
        weg.addActionListener(e -> {
            String n = gewaehlt(siedBox);
            if (n == null) return;
            var d = siedListe.stream().filter(x -> x.name().equals(name(n))).findFirst().orElse(null);
            if (d == null || !com.dan.haithabu.data.Daten.EIGEN.equals(d.herkunft()) || d.aktiv()) { Dialoge.fehler(this, "Siedlung", "Mitgelieferte und aktive Siedlungen bleiben."); return; }
            if (com.dan.foptionpane.FOptionPane.showConfirmDialog(this, "„" + d.name() + "“ mit " + d.haeuser() + " Häusern löschen?", "Siedlung",
                    com.dan.foptionpane.FOptionPane.YES_NO_OPTION) != com.dan.foptionpane.FOptionPane.YES_OPTION) return;
            hinten("Siedlung löschen", () -> { sp().loeschenSiedlung(d.name()); return null; }, x -> listeSiedlungen());
        });
        JPanel g = grid(3);
        g.add(akt);
        g.add(unter);
        g.add(weg);
        put(g);
        put(siedLbl);
        sub("Startwert");
        put(seedLbl);
        JPanel seeds = grid(3);
        FButton less = new FButton("− 1"), dice = new FButton("Neu würfeln"), more = new FButton("+ 1");
        less.addActionListener(e -> regenerate(r.siedlung.seed - 1));
        more.addActionListener(e -> regenerate(r.siedlung.seed + 1));
        dice.setToolTipText("Ein zufälliger neuer Startwert; die sieben Häuser am Bach bleiben. Speichern mit „Speichern unter …“");
        dice.addActionListener(e -> regenerate(new java.util.Random().nextInt(100_000)));
        seeds.add(less); seeds.add(dice); seeds.add(more);
        put(seeds);
        put(small("<html><body style='width:215px'><b>Hauskarte:</b> ein Klick auf ein Haus zeigt Typ, Maße, Zustand und Befund; Typ und Zustand lassen sich ändern, "
                + "das Haus lässt sich entfernen. Eine mitgelieferte Siedlung wird dabei als „… (bearbeitet)“ gespeichert.</body></html>"));
        StringBuilder hs = new StringBuilder("<html><body style='width:215px'>Die sieben Häuser am Ufer nach dem Museum [G]:");
        for (com.dan.haithabu.scene.Siedlung.Haus h : r.siedlung.haeuser) if (h.museum())
            hs.append("<br>· ").append(h.name()).append(" (").append(h.house().type().label).append(String.format(Locale.GERMAN, ", %.1f × %.1f m)", h.house().length(), h.house().width()));
        hs.append("<br>Bohlenwege an beiden Ufern, Brücke, Zäune zwischen den Grundstücken, Ziehbrunnen, Fischgestelle und Boote am Strand. Ruß um die Rauchlöcher, "
                + "Moos auf alten Dächern; nach Regen bleiben Holz und Reet nass (com.dan.weathering). Die übrige Siedlung im Wall kommt aus dem Startwert: Gassen aus "
                + "Bohlen, schmale Grundstücke mit dem Giebel zur Gasse, dahinter Grubenhäuser, Schuppen und Gärten; Schmiede, Glas und Bronze im Nordwesten abseits; "
                + "vor dem Wall Felder in Streifen [G].</body></html>");
        put(small(hs.toString()));
    }

    /** „Haithabu 950 · 540 Häuser · aktiv“ → „Haithabu 950“. */
    private static String name(String eintrag) { int i = eintrag.indexOf(" · "); return i < 0 ? eintrag : eintrag.substring(0, i); }

    private void listeSiedlungen() {
        hinten("Siedlungen lesen", () -> sp().siedlungen(), l -> {
            siedListe = l;
            java.util.List<String> n = new java.util.ArrayList<>();
            String akt = null;
            for (var s : l) {
                String e = s.name() + " · " + s.haeuser() + " Häuser" + (com.dan.haithabu.data.Daten.EIGEN.equals(s.herkunft()) ? "" : " · mitgeliefert") + (s.aktiv() ? " · aktiv" : "");
                n.add(e);
                if (s.aktiv()) akt = e;
            }
            fuellen(siedBox, n, akt);
            String sn = com.dan.haithabu.data.Datenseite.siedlungName;
            siedLbl.setText("<html><body style='width:215px'>In der Szene: " + (sn == null ? "neu gewürfelt, nicht gespeichert" : "„" + sn + "“") + " · " + l.size()
                    + " Siedlungen in " + sp().wo() + "</body></html>");
        });
    }

    // ------------------------------------------------------------ HAFEN

    private void hafen() {
        block("HAFEN", false);
        FCheckBox shipsBox = new FCheckBox("Schiffe im Hafen");
        shipsBox.setSelected(r.showShips);
        shipsBox.addActionListener(e -> { r.showShips = shipsBox.isSelected(); view.requestFocusInWindow(); });
        put(shipsBox);
        put(shipLbl);
        JPanel g = new JPanel(new java.awt.GridLayout(0, 2, 6, 4));
        g.setOpaque(false);
        FButton ride9 = new FButton("9 Mitfahren"), ein = new FButton("Knorr einlaufen"), aus = new FButton("Knorr auslaufen"), brander = new FButton("Brander");
        for (FButton b : new FButton[]{ride9, ein, aus, brander}) b.setEnabled(r.flotte != null);
        ride9.setToolTipText("<html>Am Steuer der Knorr: sie segelt aus dem Noor heran, birgt vor der Durchfahrt das Segel,<br>rudert durch die Palisade und legt am Querkopf an. Ziehen schaut umher; noch einmal 9: aussteigen</html>");
        ride9.addActionListener(e -> { mitfahrt(); view.requestFocusInWindow(); });
        ein.setToolTipText("Die Knorr von draußen hereinholen, ohne mitzufahren (Ansicht „Hafen“ zeigt den Liegeplatz)");
        ein.addActionListener(e -> { r.knorrEinlaufen(); if (r.flotte != null) r.flotte.knorrAway = false; view.requestFocusInWindow(); });
        aus.setToolTipText("Die Knorr legt ab, rudert durch die Palisade und segelt ins Noor hinaus");
        aus.addActionListener(e -> { r.knorrAuslaufen(); view.requestFocusInWindow(); });
        brander.setToolTipText("<html>Wie 1050: ein brennendes Schiff treibt mit dem Wind in den Hafen; wo es antreibt, fangen<br>die nächsten Häuser Feuer (Brand löschen im Block FEUER)</html>");
        brander.addActionListener(e -> { r.branderLos(); view.requestFocusInWindow(); });
        g.add(ride9); g.add(ein); g.add(aus); g.add(brander);
        put(g);
        FCheckBox tagBox = new FCheckBox("Tagesregie (die Knorr läuft um 15:30 aus, um 8 Uhr ein)");
        tagBox.setSelected(r.tagesregie);
        tagBox.addActionListener(e -> { r.tagesregie = tagBox.isSelected(); view.requestFocusInWindow(); });
        put(tagBox);
        sub("Liegeplätze");
        put(hafenLbl);
        put(small("<html><body style='width:215px'>Landebrücken und Plattformen auf Pfählen, das Becken von 10 ha hinter der Palisade im Wasser, "
                + "die Durchfahrt mit Pfahlreihen (com.dan.longship, com.dan.buoyancy). Die Schiffe schwimmen auf dem Noor; Riemen spritzen (com.dan.spray). "
                + "Lage und Schiffe im Schema als HB_SCHIFF, die Liegeplätze als Punkte.</body></html>"));
    }

    private String hafenZeilen() {
        var fl = r.flotte;
        if (fl == null) return "Kein Hafen.";
        StringBuilder b = new StringBuilder("<html><body style='width:215px'>");
        java.util.List<com.dan.longship.Longship> l = new java.util.ArrayList<>(fl.ships);
        if (fl.branderOn) l.add(fl.brander);
        for (var s : l) b.append("· ").append(s.name).append(String.format(Locale.GERMAN, ": %s, x %.0f, z %.0f, %03.0f°%s<br>", s.type.label, s.x, s.z, ((s.heading % 360) + 360) % 360,
                s.mode == com.dan.longship.Longship.Mode.FEST ? ", fest" : String.format(Locale.GERMAN, ", %.1f kn", s.speed * 1.944)));
        b.append(fl.fischer.size()).append(" Fischerboote an den Brücken");
        return b.append("</body></html>").toString();
    }

    // ------------------------------------------------------------ DATEN

    private void daten() {
        block("DATEN", false);
        put(datenLbl);
        JPanel g = new JPanel(new java.awt.GridLayout(0, 2, 6, 4));
        g.setOpaque(false);
        FButton verb = new FButton("Verbinden …"), einr = new FButton("Einrichten"), pruef = new FButton("Prüfen"), ohne = new FButton("Ohne Datenbank"),
                weiter = new FButton("Weiter wie zuletzt"), ueber = new FButton("In die Datenbank übernehmen");
        verb.setToolTipText("Mit dem Schema aus db/db.properties verbinden (fragt nach dem Passwort, wenn keins hinterlegt ist)");
        verb.addActionListener(e -> verbinden());
        einr.setToolTipText("Die Skripte aus db/sql ausführen und alles prüfen; löscht nie etwas");
        einr.addActionListener(e -> einrichter(false));
        pruef.setToolTipText("Nur prüfen: Tabellen, Sichten, Metadaten, räumliche Indizes, Zahl der Startdaten");
        pruef.addActionListener(e -> einrichter(true));
        ohne.setToolTipText("Mit Dateien in daten/ weiterarbeiten");
        ohne.addActionListener(e -> {
            com.dan.haithabu.data.Datenseite.setzen(new com.dan.haithabu.data.DateiSpeicher(com.dan.haithabu.data.DateiSpeicher.ordner()));
            neuLesen();
        });
        weiter.setToolTipText("Die letzte gesicherte Sitzung herstellen: Siedlung, Uhr, Wetter, Kamera, Regiebuch an seiner Stelle, Brand, Schiffe");
        weiter.addActionListener(e -> weiterWieZuletzt());
        ueber.setToolTipText("Eigene Siedlungen, Wetterlagen, Regiebücher, Fahrten, Ansichten und Presets aus daten/ in die Datenbank (die Dateien bleiben)");
        ueber.addActionListener(e -> uebernehmen());
        g.add(verb); g.add(ohne); g.add(einr); g.add(pruef); g.add(weiter); g.add(ueber);
        put(g);
        sub("Presets der Packages");
        java.util.List<String> pk = new java.util.ArrayList<>();
        for (String k : com.dan.haithabu.data.Startdaten.PAKETE) pk.add(k.substring(k.lastIndexOf('.') + 1) + " · " + k.substring(0, k.lastIndexOf('.')));
        paketBox = new FComboBox(pk.toArray());
        presetBox = new FComboBox();
        paketBox.addActionListener(e -> { if (!fromScene) listePresets(null); });
        put(paketBox);
        put(presetBox);
        FButton an = new FButton("Anwenden"), unter = new FButton("Speichern unter …");
        an.setToolTipText("Alle Felder des Presets in das laufende Objekt der Szene schreiben");
        an.addActionListener(e -> presetAnwenden());
        unter.setToolTipText("Die Felder, wie sie jetzt in der Szene stehen, als eigenes Preset");
        unter.addActionListener(e -> presetSpeichern());
        JPanel pg = grid(2);
        pg.add(an);
        pg.add(unter);
        put(pg);
        put(presetLbl);
        listePresets(null);
        sub("Protokoll");
        put(protLbl);
        put(small("<html><body style='width:215px'>Das Protokoll geht alle 5 s in HB_LOG (90 Tage) oder daten/protokoll.txt, der Zustand alle 2 min und beim Ende in "
                + "HB_SITZUNG oder daten/sitzungen. Lageplan in QGIS: Sicht HB_LAGEPLAN_V, SRID 8307.</body></html>"));
    }

    private String paket() { String s = gewaehlt(paketBox); return s == null ? null : s.substring(s.indexOf(" · ") + 3); }
    private String klasse() { String s = gewaehlt(paketBox); return s == null ? null : s.substring(0, s.indexOf(" · ")); }

    private void listePresets(String wahl) {
        String p = paket(), k = klasse();
        if (p == null) return;
        hinten("Presets lesen", () -> sp().presets(p, k), l -> {
            presetListe = l;
            fuellen(presetBox, l, wahl);
            Object o = com.dan.haithabu.data.Zustand.objekt(r, k);
            presetLbl.setText("<html><body style='width:215px'>" + l.size() + " Presets · " + (o == null ? "nicht in der Szene" : "in der Szene: " + o.getClass().getSimpleName()) + "</body></html>");
        });
    }

    private void presetAnwenden() {
        int i = presetBox.getSelectedIndex();
        if (i < 0 || i >= presetListe.size()) return;
        var pr = presetListe.get(i);
        Object o = com.dan.haithabu.data.Zustand.objekt(r, pr.klasse());
        if (o == null) { presetLbl.setText(pr.klasse() + " läuft nicht in der Szene."); return; }
        java.util.List<String> f = com.dan.store.Felder.schreiben(o, pr.felder());
        presetLbl.setText("<html><body style='width:215px'>„" + pr.name() + "“ angewandt: " + (pr.felder().size() - f.size()) + " Felder"
                + (f.isEmpty() ? "" : ", nicht: " + String.join(", ", f)) + "</body></html>");
        com.dan.store.Protokoll.info("Preset", pr.klasse() + " ← „" + pr.name() + "“");
        view.requestFocusInWindow();
    }

    private void presetSpeichern() {
        String p = paket(), k = klasse();
        Object o = com.dan.haithabu.data.Zustand.objekt(r, k);
        if (o == null) { presetLbl.setText(k + " läuft nicht in der Szene."); return; }
        String n = Dialoge.frage(this, "Name des Presets für " + k, "Preset speichern");
        if (n == null) return;
        var pr = new com.dan.haithabu.data.Daten.PaketPreset(p, k, n, "Aus der Szene am " + java.time.LocalDate.now(), com.dan.haithabu.data.Daten.EIGEN, com.dan.store.Felder.lesen(o));
        hinten("Preset speichern", () -> { sp().speichern(pr); return null; }, x -> listePresets(n));
    }

    /** Nach einem Wechsel des Speichers alle Listen neu lesen. */
    private void neuLesen() {
        listeRegiebuecher(null);
        listeLagen(null);
        listeFahrten(null);
        listeSiedlungen();
        listeGemerkt();
        listePresets(null);
        technik();
    }

    private void verbinden() {
        datenNote = "verbinde …";
        hinten("Verbinden", () -> {
            com.dan.store.Db.Konfig k = com.dan.haithabu.data.Verbindung.konfig();
            return k;
        }, k -> {
            com.dan.store.Db.Konfig kk = k;
            char[] neu = null;
            if (!k.hatPasswort()) {
                com.dan.ftextfield.FPasswordfield pw = new com.dan.ftextfield.FPasswordfield();
                JPanel p = new JPanel(new BorderLayout(0, 6));
                p.add(new JLabel("Passwort für " + k.kurz() + ":"), BorderLayout.NORTH);
                p.add(pw, BorderLayout.CENTER);
                if (com.dan.foptionpane.FOptionPane.showConfirmDialog(this, p, "Haithabu · Datenbank", com.dan.foptionpane.FOptionPane.OK_CANCEL_OPTION)
                        != com.dan.foptionpane.FOptionPane.OK_OPTION || pw.getPassword().length == 0) { datenNote = ""; return; }
                neu = pw.getPassword();
                kk = k.mitPasswort(neu);
            }
            char[] eingabe = neu;
            com.dan.store.Db.Konfig kf = kk;
            hinten("Verbinden", () -> {
                String[] grund = {""};
                com.dan.haithabu.data.DbSpeicher d = com.dan.haithabu.data.Datenseite.verbinden(kf, grund);
                if (d == null) throw new com.dan.store.Ablage.Fehler(grund[0]);
                if (eingabe != null) try { com.dan.store.Db.passwortSpeichern(kf, eingabe); } catch (Exception ex) { com.dan.store.Protokoll.warnung("Daten", "Passwort nicht eingetragen: " + ex.getMessage()); }
                int st = com.dan.haithabu.data.Verbindung.einrichter().stufe(d.verbindung());
                return new Object[]{d, st};
            }, o -> {
                var d = (com.dan.haithabu.data.DbSpeicher) o[0];
                int st = (Integer) o[1];
                if (st < com.dan.haithabu.data.Verbindung.VERSION) {
                    if (com.dan.foptionpane.FOptionPane.showConfirmDialog(this, d.wo() + " ist noch nicht eingerichtet (Stufe " + st + ").\nJetzt einrichten? (löscht nie etwas)",
                            "Haithabu · Datenbank", com.dan.foptionpane.FOptionPane.YES_NO_OPTION) != com.dan.foptionpane.FOptionPane.YES_OPTION) { d.schliessen(); datenNote = "nicht eingerichtet"; return; }
                    com.dan.haithabu.data.Datenseite.setzen(d);
                    einrichter(false);
                    return;
                }
                com.dan.haithabu.data.Datenseite.setzen(d);
                datenNote = "verbunden";
                neuLesen();
            });
        });
    }

    private void einrichter(boolean nurPruefen) {
        if (!(sp() instanceof com.dan.haithabu.data.DbSpeicher d)) { Dialoge.fehler(this, "Einrichter", "Erst mit der Datenbank verbinden („Verbinden …“)."); return; }
        datenNote = nurPruefen ? "prüfe …" : "richte ein …";
        hinten(nurPruefen ? "Prüfen" : "Einrichten", () -> {
            var e = com.dan.haithabu.data.Verbindung.einrichter();
            return nurPruefen ? e.pruefen(d.verbindung(), com.dan.haithabu.data.Verbindung.skripte())
                    : e.einrichten(d.verbindung(), com.dan.haithabu.data.Verbindung.skripte(), (t, a) -> datenNote = String.format(Locale.GERMAN, "%.0f %% · %s", a * 100, t));
        }, er -> {
            com.dan.haithabu.data.Datenseite.einrichterStand = er.kurz();
            datenNote = "";
            if (er.ok()) com.dan.store.Dienst.spaeter(com.dan.store.Dienst::neuBeginnen);
            com.dan.store.Protokoll.info("Einrichter", (nurPruefen ? "Prüfen: " : "Einrichten: ") + er.kurz());
            for (String z : er.zeilen()) if (!z.startsWith("ok")) com.dan.store.Protokoll.warnung("Einrichter", z);
            JLabel t = small("<html><body style='width:560px'>" + String.join("<br>", er.zeilen()) + "</body></html>");
            Dialoge.text(this, (nurPruefen ? "Prüfen: " : "Einrichten: ") + er.kurz(), t);
            neuLesen();
        });
    }

    private void uebernehmen() {
        if (!sp().datenbank()) { Dialoge.fehler(this, "Übernehmen", "Erst mit der Datenbank verbinden („Verbinden …“)."); return; }
        var von = new com.dan.haithabu.data.DateiSpeicher(com.dan.haithabu.data.DateiSpeicher.ordner());
        datenNote = "übernehme …";
        hinten("Übernehmen", () -> com.dan.haithabu.data.Uebernahme.uebernehmen(von, sp(), r.terrain), z -> {
            datenNote = "übernommen";
            com.dan.store.Protokoll.info("Übernahme", String.join(" · ", z));
            com.dan.foptionpane.FOptionPane.showMessageDialog(this, "Aus " + von.wo() + " nach " + sp().wo() + ":\n" + String.join("\n", z), "Haithabu · Übernahme",
                    com.dan.foptionpane.FOptionPane.INFORMATION_MESSAGE);
            neuLesen();
        });
    }

    private void weiterWieZuletzt() {
        hinten("Weiter wie zuletzt", () -> {
            var s = sp().letzteSitzung(com.dan.store.Dienst.sitzung());
            if (s == null || s.zustand() == null) throw new com.dan.store.Ablage.Fehler("Keine gesicherte Sitzung in " + sp().wo());
            var z = com.dan.store.Felder.ausText(s.zustand());
            String sn = z.get("siedlung.name");
            if (sn != null && !sn.equals(com.dan.haithabu.data.Datenseite.siedlungName)) {
                boolean da = false;
                for (var x : sp().siedlungen()) da |= x.name().equals(sn);
                if (da) { sp().aktivieren(sn); r.setSiedlung(com.dan.haithabu.data.Datenseite.laden(r.terrain)); }
            }
            return z;
        }, z -> Weiter.anwenden(this, r, z, () -> { view.setMode(r.camera.mode); syncFromScene(); }));
    }

    private final java.util.Map<FCollapsiblePanel, Integer> hoehe = new java.util.HashMap<>();

    /**
     * Phase 14 (Befund): FCollapsiblePanel merkt sich die Höhe des Inhalts beim Aufklappen. Wachsen danach Zeilen
     * (Vögel, Haustiere, Klang), schnitt der Block unten ab und die Schalter darunter waren nicht zu erreichen. Darum
     * hier alle halbe Sekunde nachmessen und offene Blöcke auf die neue Höhe setzen.
     */
    private void nachmessen() {
        boolean changed = false;
        for (Object[] b : bloecke) {
            FCollapsiblePanel p = (FCollapsiblePanel) b[0];
            if (!p.isExpanded()) { hoehe.remove(p); continue; }
            JComponent body = (JComponent) b[1];
            body.invalidate();
            int h = body.getPreferredSize().height;
            Integer old = hoehe.put(p, h);
            if (old == null || old != h) { p.setExpanded(true, false); changed = true; }
        }
        if (changed) { revalidate(); repaint(); }
    }

    /** „Weiter wie zuletzt“ beim Start: den gesicherten Zustand herstellen, sobald die Siedlung steht. */
    public void weiter(java.util.Map<String, String> z) {
        Weiter.anwenden(this, r, z, () -> { view.setMode(r.camera.mode); syncFromScene(); listeSiedlungen(); });
    }

    /** Für Werkzeuge (Statusbild): genau diese Blöcke öffnen, alle anderen schließen. */
    public void oeffnen(String... titel) {
        java.util.Set<String> t = java.util.Set.of(titel);
        for (Object[] b : bloecke) {
            FCollapsiblePanel p = (FCollapsiblePanel) b[0];
            p.setExpanded(t.contains(p.getTitle()), false);
        }
        revalidate();
    }

    /** Phase 3: Regie wählen. Ein Regiebuch stellt die Uhr auf seinen Beginn (am selben Tag) und den Zeitraffer. */
    private void regie(int i) {
        if (i <= 0) { wiring.regie = false; return; }
        wiring.regie = true;
        com.dan.weather.Scenario sc = switch (i) {
            case 2 -> com.dan.weather.Scenario.autumnFogMorning();
            case 3 -> com.dan.weather.Scenario.fogDay();
            case 4 -> com.dan.weather.Scenario.stormDay();
            default -> null;
        };
        if (sc == null) { wiring.startFree(com.dan.weather.Weather.Phase.KLAR); return; }
        clock.setHour(sc.startHour());
        wiring.start(sc);
        clock.lapse = sc.lapse();
        int best = 0;
        for (int k = 0; k < LAPSE.length; k++) if (Math.abs(LAPSE[k] - sc.lapse()) < Math.abs(LAPSE[best] - sc.lapse())) best = k;
        fromScene = true;
        lapseBox.setSelectedIndex(best);
        fromScene = false;
        clock.lapse = sc.lapse();
        r.readapt();
        syncFromScene();
    }

    /** Ein Handregler: mit Regie überschreibt er die Größe, ohne setzt er das Feld der Verdrahtung. */
    private void hand(com.dan.weather.Weather.Var v, double value) {
        if (wiring.regie) { wiring.hand(v, value); return; }
        switch (v) {
            case COVER -> wiring.oktas = value;
            case RAIN -> wiring.rainRate = value;
            case FOG -> wiring.fogAmount = value;
            case VISIBILITY -> wiring.visibilityKm = value;
            case THUNDER -> wiring.thunderstorm = com.dan.lightning.Lightning.Level.values()[(int) Math.max(0, Math.min(4, value))];
            default -> { }
        }
    }

    /** Reglerstellung 0..200 → mm/h (0 bis 40, unten fein). */
    static double rainMm(int v) { return v <= 0 ? 0 : 40 * Math.pow(v / 200.0, 2.2); }
    static int rainPos(double mm) { return mm <= 0 ? 0 : (int) Math.round(200 * Math.pow(Math.min(40, mm) / 40, 1 / 2.2)); }

    /** Phase 2: eine Ansicht anfahren (springt). */
    private void ansicht(com.dan.haithabu.camera.Ansichten.Ansicht a) {
        r.camera.stopFahrt();
        r.camera.stopMitfahrt();
        if (a.orbit()) { view.goHome(); return; }
        if (com.dan.haithabu.camera.Ansichten.apply(a, r.camera, r.terrain)) view.setMode(Camera.Mode.FREI);
    }

    /** Phase 9: Mitfahrt auf der Knorr an oder aus. */
    private void mitfahrt() {
        if (r.toggleMitfahrt()) view.setMode(Camera.Mode.FREI);
    }

    /** Phase 11: Fahrt „Durch die Gasse“ starten oder anhalten. */
    private void fahrtGasse() {
        if (r.fahrtGasse == null) return;
        if (r.camera.fahrt != null) { r.camera.stopFahrt(); return; }
        r.camera.startFahrt(r.fahrtGasse);
        view.setMode(Camera.Mode.FREI);
    }

    /** Phase 7: Fahrt „Über den Wall“ starten oder anhalten. */
    private void fahrtWall() {
        if (r.fahrtWall == null) return;
        if (r.camera.fahrt != null) { r.camera.stopFahrt(); return; }
        r.camera.startFahrt(r.fahrtWall);
        view.setMode(Camera.Mode.FREI);
    }

    /** F1: die Tasten. */
    private void tasten() {
        com.dan.foptionpane.FOptionPane.showMessageDialog(this, "<html><body style='width:420px'>"
                + "<b>Szene</b><br>Links ziehen: drehen · rechts ziehen: verschieben · Rad, Bild↑/↓, +/−: zoomen<br>"
                + "Pfeile: drehen · W A S D: gleiten · Q/E: ab und auf (frei) · Umschalt: schneller<br>"
                + "F: frei fliegen · R: von selbst kreisen · Pos1: Grundansicht „Vom Noor“ · H: HUD kurz, voll, aus<br>"
                + "Leertaste: Uhr anhalten und weiter · F12: Foto nach docs/status · F9: Bildfolge Klang · F5: Shader neu laden<br>"
                + "1–7: Ansichten Vom Noor, Hafen, Am Bach, Vom Wall, Hochburg, Gegenufer, Im Haus<br>"
                + "0: Fahrt „Durch die Gasse“ ins Versammlungshaus (noch einmal 0 hält sie an)<br>"
                + "8: Fahrt „Über den Wall“ (noch einmal 8 hält sie an); im Block KAMERA auch als Bildfolge<br>"
                + "9: Mitfahrt auf der Knorr, die in den Hafen einläuft (noch einmal 9: aussteigen)<br>"
                + "V: Ansicht merken (mit Uhr, Wetter, Brand und Vorschau; Block KAMERA) · P: Stützpunkt, während eine Fahrt aufgenommen wird<br>"
                + "Klick auf ein Haus: die Hauskarte (Typ, Zustand, Befund; ändern oder entfernen)<br><br>"
                + "<b>Fenster</b><br>F1: diese Übersicht · F11: nur die Szene (Bedienfeld und Statuszeile weg und wieder da)</body></html>",
                "Haithabu · Tasten", com.dan.foptionpane.FOptionPane.INFORMATION_MESSAGE);
    }

    /** Regler nach der Szene stellen (alle 0,5 s). */
    private void syncFromScene() {
        fromScene = true;
        int m = (int) Math.round(clock.hour() * 60) % (24 * 60);
        if (!time.getValueIsAdjusting()) time.setValue(m);
        if (!wind.getValueIsAdjusting()) wind.setValue(wiring.wind.beaufort());
        if (!windDir.getValueIsAdjusting()) windDir.setValue((int) Math.round(wiring.wind.fromDeg()) % 360);
        if (!scaleSl.getValueIsAdjusting() && r.autoScale) scaleSl.setValue((int) Math.round(r.renderScale * 100));
        if (!level.getValueIsAdjusting()) level.setValue((int) Math.round(wiring.waterLevel.level() * 100));
        if (!cover.getValueIsAdjusting()) cover.setValue((int) Math.round(wiring.oktas * 10));
        if (!rainSl.getValueIsAdjusting()) rainSl.setValue(rainPos(wiring.rainRate));
        if (!fogSl.getValueIsAdjusting()) fogSl.setValue((int) Math.round(wiring.fogAmount * 100));
        if (!visSl.getValueIsAdjusting()) visSl.setValue((int) Math.round(Math.max(2, Math.min(60, wiring.visibilityKm))));
        if (!thunderBox.isPopupVisible() && thunderBox.getSelectedIndex() != wiring.thunderstorm.ordinal()) thunderBox.setSelectedIndex(wiring.thunderstorm.ordinal());
        int li = 0;
        for (int k = 0; k < LAPSE.length; k++) if (Math.abs(LAPSE[k] - clock.lapse) < 1e-9) li = k;
        if (!lapseBox.isPopupVisible() && lapseBox.getSelectedIndex() != li && LAPSE[li] == clock.lapse) lapseBox.setSelectedIndex(li);
        fromScene = false;
        labels();
        nachmessen();
        if (ticks++ % 2 == 0) technik();
    }

    private void labels() {
        dateLbl.setText("Datum: " + clock.dateLabel() + " (gregorianisch)");
        var lb = r.leben;
        if (lb != null) {
            birdLbl.setText("<html><body style='width:215px'>" + lb.birdLine() + "</body></html>");
            herdLbl.setText("<html><body style='width:215px'>" + lb.animalLine() + "</body></html>");
        }
        bookLbl.setText("<html><body style='width:215px'>" + r.regieLine() + "</body></html>");
        var kl = r.klang;
        if (kl != null) soundLbl.setText("<html><body style='width:215px'>" + (r.soundOn() ? "" : "Ton aus · ") + kl.describe() + "</body></html>");
        var ys = r.yearNow();
        yearLbl.setText(String.format(java.util.Locale.GERMAN, "<html><body style='width:215px'>%s · Luft %.1f °C%s</body></html>", ys.describe(), wiring.airTempC,
                wiring.snowRate > 0.05 ? String.format(java.util.Locale.GERMAN, " · Schneefall %.1f mm/h", wiring.snowRate) : ""));
        timeLbl.setText("Uhrzeit: " + clock.timeLabel());
        double[] s = clock.sun();
        LocalDate d = clock.date();
        double day0 = d.atStartOfDay(SceneClock.ZONE).toInstant().toEpochMilli();
        double up = Sun.crossing(day0, clock.lat, clock.lon, true), down = Sun.crossing(day0, clock.lat, clock.lon, false);
        sunLbl.setText(String.format(Locale.GERMAN, "<html><body style='width:215px'>Sonne %.1f° hoch, Azimut %03.0f°. Aufgang %s, Untergang %s.</body></html>",
                s[0], s[1], hm(up), hm(down)));
        windLbl.setText(String.format(Locale.GERMAN, "Bft %d · %s · %.1f m/s%s", wiring.wind.beaufort(), Beaufort.NAME[wiring.wind.beaufort()], wiring.wind.speed(),
                wiring.regie ? String.format(Locale.GERMAN, " · Böe %.1f", wiring.gustNow) : ""));
        com.dan.weather.Weather.Snapshot ws = wiring.weather.snapshot();
        regieLbl.setText("<html><body style='width:215px'>" + (!wiring.regie ? "Alles von Hand; die Regie steht." : ws == null ? "Regie startet …"
                : (ws.scenario().isEmpty() ? "Freie Regie: " + ws.phase().label + String.format(Locale.GERMAN, ", als Nächstes %s in %.1f h", ws.next().label, ws.nextInH())
                : ws.scenario() + String.format(Locale.GERMAN, ", Schritt %d von %d: %s", ws.step() + 1, ws.steps(), ws.stepText()))
                + String.format(Locale.GERMAN, "<br>%.1f °C, %.0f %% Feuchte, %.0f hPa %s", ws.temperature(), ws.humidity(), ws.pressure(), ws.tendencyText())
                + (wiring.weather.overrides() > 0 ? "<br>" + wiring.weather.overrides() + " Größen von Hand" : "")) + "</body></html>");
        coverLbl.setText(String.format(Locale.GERMAN, "Bedeckung %.1f/8 · %s", wiring.oktas, wiring.cloudType.label));
        rainLbl.setText(wiring.rainRate <= 0.01 ? "Regen: trocken" : String.format(Locale.GERMAN, "Regen %.1f mm/h", wiring.rainRate));
        fogLbl.setText(String.format(Locale.GERMAN, "Nebel %.0f %%%s", wiring.fogAmount * 100,
                r.fog.snapshot().any() ? String.format(Locale.GERMAN, " · %.0f bis %.0f m", wiring.fogBase, wiring.fogTop) : ""));
        visLbl.setText(String.format(Locale.GERMAN, "Sicht %.0f km", wiring.visibilityKm));
        dirLbl.setText(String.format(Locale.GERMAN, "aus %03.0f° (%s)", wiring.wind.fromDeg(), compass(wiring.wind.fromDeg())));
        camLbl.setText(String.format(Locale.GERMAN, "<html><body style='width:215px'>%s · Auge %.0f m · Blick %03.0f° · %.0f m vom Bachmund</body></html>",
                r.camera.modeName(), r.camera.eye[1], r.camera.heading(), r.camera.originDistance()));
        scaleLbl.setText(String.format(Locale.GERMAN, "Auflösung %.0f %% (%s)", r.renderScale * 100, r.autoScale ? "geregelt, " + r.scaleSteps() + "× geändert" : "fest"));
        qualLbl.setText("<html><body style='width:215px'>" + r.quality().summary() + "</body></html>");
        levelLbl.setText(String.format(Locale.GERMAN, "Windstau %+.2f m", wiring.waterLevel.level()));
        densLbl.setText(String.format(Locale.GERMAN, "Dichte der Halme %.0f %%", r.reed.density * 100));
    }

    private void technik() {
        perfLbl.setText(String.format(Locale.GERMAN, "<html><body style='width:215px'>%.0f Bilder/s · Grafikkarte %.2f ms · Prozessor %.2f ms<br>%s</body></html>",
                r.fps(), r.gpuMs(), r.cpuMs(), r.passTimes()));
        ComputeProbe.Result c = r.compute();
        computeLbl.setText("<html><body style='width:215px'>" + (c == null ? "Compute-Test läuft …" : c.line()) + "</body></html>");
        glLbl.setText("<html><body style='width:215px'>" + r.glInfo() + (r.reversedDepth() ? " · umgekehrte Tiefe" : "") + "</body></html>");
        noorLbl.setText("<html><body style='width:215px'>" + r.oceanLine().replace("!", "") + "</body></html>");
        skyLbl.setText("<html><body style='width:215px'>" + (r.skyLine() + "<br>" + r.cloudLine()).replace("!", "") + "</body></html>");
        reedLbl.setText("<html><body style='width:215px'>" + r.reed.describe() + " · " + r.reedInfo() + "</body></html>");
        forestLbl.setText("<html><body style='width:215px'>" + r.forestInfo() + "</body></html>");
        housesLbl.setText("<html><body style='width:215px'>" + r.housesInfo() + "</body></html>");
        shipLbl.setText("<html><body style='width:215px'>" + r.shipLine().replace("!", "") + "</body></html>");
        fireLbl.setText("<html><body style='width:215px'>" + r.fireLine().replace("!", "") + "</body></html>");
        smokeLbl.setText("<html><body style='width:215px'>" + r.smokeLine().replace("!", "") + "</body></html>");
        hallLbl.setText("<html><body style='width:215px'>" + r.hallLine().replace("!", "") + "</body></html>");
        seedLbl.setText("<html><body style='width:215px'>Startwert " + r.siedlung.seed + (seedNote.isEmpty() ? "" : " · " + seedNote) + "</body></html>");
        groundLbl.setText("<html><body style='width:215px'>" + r.terrain.describe() + (r.brook != null ? "<br>" + r.brook.describe() : "") + "</body></html>");
        pkgLbl.setText("<html><body style='width:215px'>" + String.join(", ", PAKETE) + ". Die Isolationsprüfung "
                + "<i>check-packages</i> läuft nach jedem Übersetzen.</body></html>");
        StringBuilder sb = new StringBuilder("<html><body style='width:215px'>").append(wiring.summary());
        for (Wiring.Link l : Wiring.planned()) sb.append("<br>· ").append(l.toString().replace("→", "&rarr;"));
        linksLbl.setText(sb.append("</body></html>").toString());
        hafenLbl.setText(hafenZeilen());
        datenLbl.setText(datenZeile());
        StringBuilder pz = new StringBuilder("<html><body style='width:215px;font-size:9px'>");
        for (com.dan.store.Protokoll.Zeile z : com.dan.store.Protokoll.zuletzt(8))
            pz.append(z.stufe().equals(com.dan.store.Protokoll.INFO) ? "" : "<b>").append(esc(com.dan.store.Protokoll.zeile(z))).append(z.stufe().equals(com.dan.store.Protokoll.INFO) ? "" : "</b>").append("<br>");
        protLbl.setText(pz.append("</body></html>").toString());
        StringBuilder h = new StringBuilder("<html><body style='width:215px'>");
        for (String l : r.hudLines()) h.append(l.startsWith("!") ? l.substring(1) : l).append("<br>");
        hudLbl.setText(h.append("</body></html>").toString());
    }

    private static String esc(String t) { return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); }

    private String datenZeile() {
        var a = sp();
        long g = com.dan.store.Dienst.gesichert();
        String f = com.dan.store.Dienst.letzterFehler();
        return "<html><body style='width:215px'><b>" + a.wo() + "</b><br>Sitzung " + com.dan.store.Dienst.sitzung()
                + (g > 0 ? " · gesichert " + java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss").format(java.time.Instant.ofEpochMilli(g).atZone(java.time.ZoneId.systemDefault())) : " · noch nicht gesichert")
                + (com.dan.haithabu.data.Datenseite.einrichterStand.isEmpty() ? "" : "<br>Einrichter: " + esc(com.dan.haithabu.data.Datenseite.einrichterStand))
                + (datenNote.isEmpty() || datenNote.equals(com.dan.haithabu.data.Datenseite.einrichterStand) ? "" : "<br>" + esc(datenNote))
                + (f == null || f.isEmpty() ? "" : "<br><b>Zuletzt:</b> " + esc(f)) + "</body></html>";
    }

    static String hm(double epochMs) {
        if (Double.isNaN(epochMs)) return "—";
        return String.format("%tR", Instant.ofEpochMilli((long) epochMs).atZone(SceneClock.ZONE));
    }

    static String compass(double deg) {
        String[] n = {"Nord", "Nordnordost", "Nordost", "Ostnordost", "Ost", "Ostsüdost", "Südost", "Südsüdost",
                "Süd", "Südsüdwest", "Südwest", "Westsüdwest", "West", "Westnordwest", "Nordwest", "Nordnordwest"};
        return n[(int) Math.round(((deg % 360) + 360) % 360 / 22.5) % 16];
    }

    // ------------------------------------------------------------ Aufbau

    /** Ein Klappblock (FCollapsiblePanel); offen bleibt, was zuletzt offen war. */
    private void block(String title, boolean offen) {
        FCollapsiblePanel p = new FCollapsiblePanel() {
            @Override public Dimension getMaximumSize() { return new Dimension(Integer.MAX_VALUE, getPreferredSize().height); }
        };
        p.setTitle(title);
        p.setAlignmentX(Component.LEFT_ALIGNMENT);
        JPanel inhalt = new JPanel();
        inhalt.setOpaque(false);
        inhalt.setLayout(new BoxLayout(inhalt, BoxLayout.Y_AXIS));
        inhalt.setBorder(BorderFactory.createEmptyBorder(6, 10, 10, 8));
        bloecke.add(new Object[]{p, inhalt});
        String key = "offen." + title;
        boolean auf = PREFS == null ? offen : PREFS.getBoolean(key, offen);
        if (!auf) zu.add(p);
        p.addFCollapsiblePanelListener((panel, expanded) -> {
            if (PREFS != null) try { PREFS.putBoolean(key, expanded); } catch (RuntimeException ex) { /* nicht gemerkt */ }
        });
        if (getComponentCount() > 0) add(Box.createVerticalStrut(6));
        add(p);
        target = inhalt;
    }

    /** Eine Zwischenüberschrift im Block. */
    private void sub(String text) {
        JLabel h = new JLabel(text);
        h.setForeground(Theme.accent());
        h.setFont(new Font("SansSerif", Font.BOLD, 11));
        h.setBorder(BorderFactory.createEmptyBorder(10, 0, 3, 0));
        put(h);
    }

    private void put(Component c) { target.add(row(c)); }

    private static JPanel grid(int n) {
        JPanel p = new JPanel(new java.awt.GridLayout(1, n, 6, 0));
        p.setOpaque(false);
        return p;
    }

    /** Eine Zeile, die mit ihrem Inhalt wächst. */
    private static JComponent row(Component c) {
        JPanel p = new JPanel(new BorderLayout()) {
            @Override public Dimension getMaximumSize() { return new Dimension(Integer.MAX_VALUE, getPreferredSize().height); }
        };
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));
        p.add(c, BorderLayout.CENTER);
        p.setAlignmentX(Component.LEFT_ALIGNMENT);
        return p;
    }

    static JLabel label(String t) {
        JLabel l = new JLabel(t);
        l.setForeground(Theme.ink());
        l.setFont(new Font("SansSerif", Font.PLAIN, 13));
        return l;
    }

    static JLabel small(String t) {
        JLabel l = new JLabel(t);
        l.setForeground(Theme.muted());
        l.setFont(new Font("SansSerif", Font.PLAIN, 11));
        return l;
    }

    // ------------------------------------------------------------ Scrollable: nur senkrecht
    @Override public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
    @Override public int getScrollableUnitIncrement(java.awt.Rectangle rr, int o, int d) { return 16; }
    @Override public int getScrollableBlockIncrement(java.awt.Rectangle rr, int o, int d) { return 120; }
    @Override public boolean getScrollableTracksViewportWidth() { return true; }
    @Override public boolean getScrollableTracksViewportHeight() { return false; }
}
