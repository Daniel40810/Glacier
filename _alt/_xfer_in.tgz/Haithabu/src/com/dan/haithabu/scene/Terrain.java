package com.dan.haithabu.scene;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

/**
 * Das Gelände der Szene (Phase 2): ein Höhenraster von 4096 × 4096 Zellen zu 1 m um den Bachmund, Höhen in m über dem
 * Wasserspiegel des Noors um 950 (y = 0). Dazu je Zelle die Herkunft (gemessen, modelliert, Noorbett, Bach) und der
 * Lauf des Haithabu-Bachs. Erzeugt von {@code tools.GelaendeImport} aus den DGM1-Kacheln von Schleswig-Holstein, gelesen
 * aus {@code daten/gelaende/}. Ohne diese Dateien entsteht die flache Bühne von Phase 1 (alles 0,5 m, Noor als Ellipse).
 * <p>
 * Höhen liegen als 16-Bit-Werte vor ({@link #HMIN} bis {@link #HMAX}, 0,7 mm Stufe); dieselben Werte gehen als
 * R16-Textur auf die Grafikkarte, darum sehen Kamera und Bild dieselbe Fläche (bilinear).
 */
public final class Terrain implements com.dan.haithabu.wiring.Terrain {
    public static final int N = 4096;
    public static final double CELL = 1.0;
    /** Lage der linken oberen Ecke (Nordwest) des Rasters in der Szene; Zelle (i, j) hat ihre Mitte bei X0 + i + 0,5. */
    public static final double X0 = -1920, Z0 = -2048;
    public static final double HMIN = -8, HMAX = 40;
    /** Herkunft je Zelle. */
    public static final byte GEMESSEN = 0, MODELLIERT = 1, NOORBETT = 2, BACH = 3;

    /** Höhen als vorzeichenlose 16-Bit-Werte, Zeile für Zeile von Nord nach Süd. */
    public final short[] h;
    public final byte[] src;
    /** Lauf des Bachs: je Punkt x, z, Sohle, Wasserspiegel, halbe Breite; von der Quelle zur Mündung. */
    public final double[][] brook;
    /** Bachmund (Ende des Laufs am Ufer von 950) und Wasserspiegel des Noors heute über NHN. */
    public final double[] mouth;
    public final double noorToday;
    /** Woher die Höhen stammen, für Statuszeile und Werkbuch. */
    public final String source;
    public final Properties props;
    /** Phase 7: Wall, Tore und Hochburg; formt das Gelände beim Laden für 950 (null auf der flachen Bühne). */
    public Befestigung befestigung;
    private final float[][] minPyr = new float[LEVELS][], maxPyr = new float[LEVELS][];
    private final int[] side = new int[LEVELS];
    private static final int LEVELS = 13;

    public Terrain(short[] h, byte[] src, double[][] brook, Properties props) {
        this.h = h;
        this.src = src;
        this.brook = brook;
        this.props = props;
        this.noorToday = Double.parseDouble(props.getProperty("noor.heute", "0.06"));
        this.mouth = new double[]{Double.parseDouble(props.getProperty("bachmund.x", "0")), Double.parseDouble(props.getProperty("bachmund.z", "0"))};
        this.source = props.getProperty("quelle", "flache Bühne (keine Höhendaten)");
        pyramid();
    }

    // ------------------------------------------------------------------ Abfragen

    public static short encode(double y) {
        double v = (y - HMIN) / (HMAX - HMIN) * 65535.0;
        return (short) (int) Math.max(0, Math.min(65535, Math.round(v)));
    }

    public static double decode(short s) { return HMIN + (s & 0xFFFF) / 65535.0 * (HMAX - HMIN); }

    public double at(int i, int j) {
        i = Math.max(0, Math.min(N - 1, i));
        j = Math.max(0, Math.min(N - 1, j));
        return decode(h[j * N + i]);
    }

    public byte sourceAt(double x, double z) {
        int i = (int) Math.floor((x - X0) / CELL), j = (int) Math.floor((z - Z0) / CELL);
        if (i < 0 || j < 0 || i >= N || j >= N) return MODELLIERT;
        return src[j * N + i];
    }

    /** Höhe an (x, z), bilinear zwischen den Zellmitten wie die Textur; außerhalb des Rasters der Rand. */
    @Override
    public double height(double x, double z) {
        double u = (x - X0) / CELL - 0.5, v = (z - Z0) / CELL - 0.5;
        int i = (int) Math.floor(u), j = (int) Math.floor(v);
        double fx = u - i, fz = v - j;
        double a = at(i, j), b = at(i + 1, j), c = at(i, j + 1), d = at(i + 1, j + 1);
        return (a * (1 - fx) + b * fx) * (1 - fz) + (c * (1 - fx) + d * fx) * fz;
    }

    /** Wassertiefe am Ort: im Noor bis zum Spiegel 0, im Bach bis zu seinem Spiegel (m, 0 = trocken). */
    @Override
    public double waterDepth(double x, double z) {
        double g = height(x, z);
        double level = Math.max(0, brookLevel(x, z));
        return Math.max(0, level - g);
    }

    /** Wasserspiegel des Bachs am Ort, wenn (x, z) im Bachbett liegt, sonst −∞. */
    public double brookLevel(double x, double z) {
        double best = Double.NEGATIVE_INFINITY, bestD = Double.MAX_VALUE;
        for (int k = 0; k + 1 < brook.length; k++) {
            double[] p = brook[k], q = brook[k + 1];
            double dx = q[0] - p[0], dz = q[1] - p[1], l2 = dx * dx + dz * dz;
            double t = l2 <= 0 ? 0 : Math.max(0, Math.min(1, ((x - p[0]) * dx + (z - p[1]) * dz) / l2));
            double ex = p[0] + t * dx - x, ez = p[1] + t * dz - z, d = Math.hypot(ex, ez);
            double half = p[4] + t * (q[4] - p[4]);
            if (d <= half + 0.5 && d < bestD) { bestD = d; best = p[3] + t * (q[3] - p[3]); }
        }
        return best;
    }

    /** Kleinste und größte Höhe im Quadrat (x0, z0, Kante) aus der Min-Max-Pyramide (für das Ausblenden von Knoten). */
    public void range(double x0, double z0, double size, double[] out) {
        int i0 = (int) Math.floor((x0 - X0) / CELL) - 1, j0 = (int) Math.floor((z0 - Z0) / CELL) - 1;
        int i1 = (int) Math.ceil((x0 + size - X0) / CELL) + 1, j1 = (int) Math.ceil((z0 + size - Z0) / CELL) + 1;
        i0 = Math.max(0, Math.min(N - 1, i0)); j0 = Math.max(0, Math.min(N - 1, j0));
        i1 = Math.max(0, Math.min(N - 1, i1)); j1 = Math.max(0, Math.min(N - 1, j1));
        int span = Math.max(i1 - i0, j1 - j0) + 1, k = 0;
        while (k < LEVELS - 1 && (1 << (k + 1)) * 2 <= span) k++;
        int s = side[k];
        double lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE;
        for (int j = j0 >> k; j <= j1 >> k; j++)
            for (int i = i0 >> k; i <= i1 >> k; i++) {
                int ii = Math.min(s - 1, i), jj = Math.min(s - 1, j);
                lo = Math.min(lo, minPyr[k][jj * s + ii]);
                hi = Math.max(hi, maxPyr[k][jj * s + ii]);
            }
        out[0] = lo;
        out[1] = hi;
    }

    /** Nach Änderungen an {@link #h}: die Min-Max-Pyramide neu rechnen. */
    void refresh() { pyramid(); }

    private void pyramid() {
        float[] base = new float[N * N];
        for (int i = 0; i < base.length; i++) base[i] = (float) decode(h[i]);
        minPyr[0] = base;
        maxPyr[0] = base;
        side[0] = N;
        int n = N;
        for (int k = 1; k < LEVELS; k++) {
            int m = (n + 1) / 2;
            float[] mn = new float[m * m], mx = new float[m * m], pmn = minPyr[k - 1], pmx = maxPyr[k - 1];
            for (int j = 0; j < m; j++)
                for (int i = 0; i < m; i++) {
                    float lo = Float.MAX_VALUE, hi = -Float.MAX_VALUE;
                    for (int b = 0; b < 2; b++)
                        for (int a = 0; a < 2; a++) {
                            int ii = Math.min(n - 1, 2 * i + a), jj = Math.min(n - 1, 2 * j + b);
                            lo = Math.min(lo, pmn[jj * n + ii]);
                            hi = Math.max(hi, pmx[jj * n + ii]);
                        }
                    mn[j * m + i] = lo;
                    mx[j * m + i] = hi;
                }
            minPyr[k] = mn;
            maxPyr[k] = mx;
            side[k] = m;
            n = m;
        }
    }

    /** Anteil der Zellen je Herkunft (gemessen, modelliert, Noorbett, Bach). */
    public double[] sourceShares() {
        long[] c = new long[4];
        for (byte b : src) c[Math.max(0, Math.min(3, b))]++;
        double t = src.length;
        return new double[]{c[0] / t, c[1] / t, c[2] / t, c[3] / t};
    }

    /** „DGM1 SH 2024, 4 Kacheln, 31 % gemessen, Bachmund 54°29′27″ N …“ */
    public String describe() {
        double[] s = sourceShares();
        return String.format(Locale.GERMAN, "%s · %.0f %% gemessen, %.0f %% modelliert, Noorbett %.0f %% [G]", source, s[0] * 100, s[1] * 100, s[2] * 100);
    }

    // ------------------------------------------------------------------ Dateien

    public static final String HOEHE = "hoehe.r16", HERKUNFT = "herkunft.u8", BACH_CSV = "bach.csv", INFO = "gelaende.properties";

    /**
     * Liest {@code daten/gelaende} (oder die flache Bühne, wenn es fehlt) und formt es für 950 ({@link Befestigung}).
     * Wer die Höhen unverändert braucht (etwa um sie neu zu speichern), setzt {@code -Dhaithabu.befestigung=false}.
     */
    public static Terrain load(File dir) {
        File hf = new File(dir, HOEHE), sf = new File(dir, HERKUNFT), pf = new File(dir, INFO);
        if (!hf.isFile() || !sf.isFile() || !pf.isFile()) return flat();
        try {
            Properties p = new Properties();
            try (InputStream in = new FileInputStream(pf)) { p.load(new java.io.InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8)); }
            short[] h = new short[N * N];
            byte[] raw = Files.readAllBytes(hf.toPath());
            if (raw.length != N * N * 2) throw new IOException(hf + ": " + raw.length + " Bytes statt " + N * N * 2);
            ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(h);
            byte[] src = Files.readAllBytes(sf.toPath());
            if (src.length != N * N) throw new IOException(sf + ": falsche Größe");
            List<double[]> b = new ArrayList<>();
            File bf = new File(dir, BACH_CSV);
            if (bf.isFile()) for (String line : Files.readAllLines(bf.toPath())) {
                if (line.isBlank() || line.startsWith("#")) continue;
                String[] f = line.split(";");
                double[] v = new double[5];
                for (int k = 0; k < 5; k++) v[k] = Double.parseDouble(f[k].trim());
                b.add(v);
            }
            Terrain t = new Terrain(h, src, b.toArray(new double[0][]), p);
            // Phase 7: Graben, ergänzter Wall, Hochburg, Verbindungswall eingeebnet (-Dhaithabu.befestigung=false: wie im DGM)
            if (!"false".equals(System.getProperty("haithabu.befestigung"))) t.befestigung = Befestigung.formen(t);
            return t;
        } catch (IOException | RuntimeException e) {
            System.err.println("Gelände: " + e.getMessage() + " – es bleibt die flache Bühne");
            return flat();
        }
    }

    /** Ordner {@code daten/gelaende} neben dem Programm ({@code -Dhaithabu.daten=…} setzt ihn anders). */
    public static File defaultDir() {
        String d = System.getProperty("haithabu.daten");
        return new File(d != null ? d : "daten", "gelaende");
    }

    public void save(File dir) throws IOException {
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Ordner " + dir + " lässt sich nicht anlegen");
        ByteBuffer bb = ByteBuffer.allocate(N * N * 2).order(ByteOrder.LITTLE_ENDIAN);
        bb.asShortBuffer().put(h);
        Files.write(new File(dir, HOEHE).toPath(), bb.array());
        Files.write(new File(dir, HERKUNFT).toPath(), src);
        StringBuilder sb = new StringBuilder("# Haithabu-Bach: x; z; Sohle; Wasserspiegel; halbe Breite (m, Szene)\n");
        for (double[] p : brook) sb.append(String.format(Locale.ROOT, "%.2f;%.2f;%.3f;%.3f;%.2f%n", p[0], p[1], p[2], p[3], p[4]));
        Files.writeString(new File(dir, BACH_CSV).toPath(), sb.toString());
        try (OutputStream out = new java.io.FileOutputStream(new File(dir, INFO))) {
            props.store(new java.io.OutputStreamWriter(out, java.nio.charset.StandardCharsets.UTF_8), "Gelaende der Szene Haithabu (tools.GelaendeImport)");
        }
    }

    /** Die flache Bühne von Phase 1: Land 0,5 m, das Noor als Ellipse mit 3 m Tiefe [G]. */
    public static Terrain flat() {
        short[] h = new short[N * N];
        byte[] s = new byte[N * N];
        for (int j = 0; j < N; j++)
            for (int i = 0; i < N; i++) {
                double x = X0 + i + 0.5, z = Z0 + j + 0.5;
                double qx = (x - 430) / 450, qz = (z + 60) / 800, r = Math.sqrt(qx * qx + qz * qz);
                double y = r < 1 ? -3.0 * Math.min(1, (1 - r) * 4) : 0.5;
                h[j * N + i] = encode(y);
                s[j * N + i] = r < 1 ? NOORBETT : MODELLIERT;
            }
        return new Terrain(h, s, new double[0][], new Properties());
    }
}
