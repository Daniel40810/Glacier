package com.dan.haithabu.scene;

import com.dan.flock.Flock;
import com.dan.flock.Species;
import com.dan.hearth.Fire;
import com.dan.herd.Herd;
import com.dan.lightning.Bolt;
import com.dan.lightning.Lightning;
import com.dan.longship.Longship;
import com.dan.reed.Reed;
import com.dan.soundscape.Blaze;
import com.dan.soundscape.Crowd;
import com.dan.soundscape.Room;
import com.dan.soundscape.Soundscape;
import com.dan.soundscape.Workshop;
import com.dan.timber.House;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Phase 14: der Klang von Haithabu ({@code com.dan.soundscape}, F20 A). Hier wird die Szene an den Klang gehängt:
 * <ul>
 * <li>Vögel ({@code flock}) und Haustiere ({@code herd}) rufen; der Schwan singt mit den Schwingen, wenn er fliegt.</li>
 * <li>Schiffe ({@code longship}) melden jeden Ruderschlag.</li>
 * <li>Schmieden und Bronzegießer arbeiten am Tag in ihren Werkstätten, der Kammmacher sägt Geweih, am Strand hackt ein
 * Bootsbauer, zwei Handwerker sägen und hacken in der Siedlung.</li>
 * <li>Feuer knistern: Essen in offenen Schuppen, die Feuerstelle am Strand, Fackeln, der Herd im Versammlungshaus (nur
 * drinnen).</li>
 * <li>Am Umschlagplatz reden die Leute (Markt nach der Tageszeit), die Wellen glucksen an den Pfählen, Schilf und Reet
 * rauschen im Wind, der Donner kommt vom Kanal des Blitzes.</li>
 * <li>Im Versammlungshaus: Raum {@link Room#LONGHOUSE}, die Wand dämpft, der Herd knistert nah.</li>
 * </ul>
 * Gestaltet [G]: die Arbeitszeiten, wer wo arbeitet, wie viele Leute auf dem Markt sind.
 */
public final class Klang {
    /** Der Klang selbst (die App spielt ihn mit {@code AudioOut}, die Hörproben rechnen ihn ohne Lautsprecher). */
    public final Soundscape scape;
    public final Crowd markt;
    private final Siedlung s;
    private final Terrain t;
    private final Feuer feuer;
    private final Leben leben;
    private final Flotte flotte;
    private final Reed.Density reed;
    private final List<Workshop> outdoor = new ArrayList<>();
    private final List<Blaze> pool = new ArrayList<>();
    private final List<Fire> pooled = new ArrayList<>();
    private Blaze hallBlaze;
    private final Map<Integer, Double> swanNext = new HashMap<>();
    private double time, sortTimer, insideNow;
    private volatile double hourNow = 12;
    /** Zähler für die Prüfung: Rufe, Ruderschläge, Donner. */
    public long calls, strokes, thunders;

    private Klang(Soundscape sc, Terrain t, Siedlung s, Feuer f, Leben l, Flotte fl, Reed.Density reed) {
        this.scape = sc != null ? sc : new Soundscape();
        scape.workshops.clear();
        scape.crowds.clear();
        scape.pilings.clear();
        scape.blazes.clear();
        this.t = t;
        this.s = s;
        this.feuer = f;
        this.leben = l;
        this.flotte = fl;
        this.reed = reed;
        if (sc == null) scape.quality = Soundscape.Quality.MEDIUM;
        scape.seed = 950;
        scape.obstruction = 4;
        // Markt am Umschlagplatz (Mitte der Linie, ein Stück landeinwärts)
        double mx = -20, mz = -40;
        Hafen h = s.hafen;
        if (h != null && h.umschlag != null && h.umschlag.length > 0) {
            double[] a = h.umschlag[0], b = h.umschlag[h.umschlag.length - 1];
            mx = (a[0] + b[0]) / 2;
            mz = (a[1] + b[1]) / 2;
        }
        markt = new Crowd("Markt", mx, Math.max(0.5, t.height(mx, mz)) + 1.5, mz, 0);
        markt.radius = 25;
        scape.crowds.add(markt);
        // Werkstätten nach den Rollen der Häuser
        int handwerker = 0;
        for (Siedlung.Haus hs : s.haeuser) {
            String r = hs.rolle() == null ? "" : hs.rolle();
            House ho = hs.house();
            double[] p = ho.toWorld(0, 0.9, 0);
            Workshop.Craft c = switch (r) {
                case "Schmiede" -> Workshop.Craft.SCHMIED;
                case "Bronzegießer" -> Workshop.Craft.BRONZE;
                default -> null;
            };
            if (hs.name().equals("Werkstatt des Kammmachers")) c = Workshop.Craft.KAMMMACHER;
            else if (c == null && r.equals("Handwerker") && handwerker < 4) c = handwerker++ % 2 == 0 ? Workshop.Craft.SAEGE : Workshop.Craft.ZIMMERER;
            if (c == null) continue;
            Workshop w = new Workshop(hs.name() + " " + scape.workshops.size(), c, p[0], p[1], p[2]);
            scape.workshops.add(w);
            if (c == Workshop.Craft.SAEGE || c == Workshop.Craft.ZIMMERER) outdoor.add(w);
        }
        // der Bootsbauer am Strand, neben der Feuerstelle des Fischers
        if (f != null && f.beach != null) {
            Workshop w = new Workshop("Bootsbauer am Strand", Workshop.Craft.ZIMMERER, f.beach.x + 6, f.beach.y + 0.5, f.beach.z - 4);
            scape.workshops.add(w);
            outdoor.add(w);
        }
        // Pfähle im Wasser
        if (h != null) for (double[] p : h.pfaehle) scape.pilings.add(new double[]{p[0], p[1]});
        // Feuer, die man draußen hört (Essen in offenen Schuppen, Strand, Fackeln) und der Herd im Haus
        if (f != null) {
            for (Fire fi : f.open) { Blaze b = new Blaze(fi.kind.label, fi.x, fi.y, fi.z, 0, false); pool.add(b); pooled.add(fi); }
            if (f.hall != null) {
                Fire hf = f.hall.herd;
                hallBlaze = new Blaze("Herd im Versammlungshaus", hf.x, hf.y, hf.z, 0, true);
            }
        }
        attach();
    }

    /** Klang für die Szene; reed darf null sein (dann kein Schilf). */
    public static Klang of(Terrain t, Siedlung s, Feuer f, Leben l, Flotte fl, Reed.Density reed) { return new Klang(null, t, s, f, l, fl, reed); }

    /** Dasselbe in einen vorhandenen Klang (die App behält ihn über einen Wechsel der Siedlung, er spielt weiter). */
    public static Klang into(Soundscape sc, Terrain t, Siedlung s, Feuer f, Leben l, Flotte fl, Reed.Density reed) { return new Klang(sc, t, s, f, l, fl, reed); }

    /** Rufe, Bellen und Ruderschläge an den Klang hängen. */
    private void attach() {
        if (leben != null) {
            leben.flock.onCall = (x, y, z, st, g) -> {
                Soundscape.Kind k = switch (g.species) {
                    case MOEWE -> Soundscape.Kind.MOEWE;
                    case KRAEHE -> Soundscape.Kind.KRAEHE;
                    case SCHWALBE -> Soundscape.Kind.SCHWALBE;
                    case ENTE -> g.id % 2 == 0 ? Soundscape.Kind.ERPEL : Soundscape.Kind.ENTE;
                    case KORMORAN -> Soundscape.Kind.KORMORAN;
                    case SCHWAN -> null;                                  // der Höckerschwan ist fast stumm
                };
                if (k != null && near(x, z, 600)) { scape.event(k, x, y, z, st, 0.5); calls++; }
            };
            leben.herd.onCall = (x, y, z, st, a) -> {
                Soundscape.Kind k = switch (a.kind) {
                    case HUHN -> a.rooster() ? Soundscape.Kind.HAHN : Soundscape.Kind.HUHN;
                    case ZIEGE -> Soundscape.Kind.ZIEGE;
                    case SCHWEIN -> st >= 0.99 ? Soundscape.Kind.QUIEKEN : Soundscape.Kind.SCHWEIN;
                    case HUND -> Soundscape.Kind.HUND;
                };
                if (near(x, z, 600)) { scape.event(k, x, y, z, a.rooster() ? 0.8 : st, 0.5); calls++; }
            };
            leben.herd.onBark = (x, y, z, st, a) -> { if (near(x, z, 800)) { scape.event(Soundscape.Kind.HUND, x, y, z, st, 0.5); calls++; } };
        }
        if (flotte != null) flotte.onStroke = (ship, x, y, z, loud) -> {
            if (!near(x, z, 1500)) return;
            scape.event(Soundscape.Kind.RUDER, x, y, z, loud, Math.min(12, 2 * ship.type.oarPairs));
            strokes++;
        };
    }

    private boolean near(double x, double z, double r) { return Math.hypot(x - scape.earX, z - scape.earZ) < r; }

    /** Donner vom Kanal des Blitzes (der Aufrufer meldet ihn, wenn er das Ohr erreicht). */
    public void thunder(Lightning.Thunder th) {
        Bolt b = th.bolt();
        double[] dist = null, w = null, strokes = null;
        if (b != null && b.n > 0) {
            dist = new double[b.n];
            w = new double[b.n];
            for (int i = 0; i < b.n; i++) {
                double mx = (b.ax[i] + b.bx[i]) / 2, my = (b.ay[i] + b.by[i]) / 2, mz = (b.az[i] + b.bz[i]) / 2;
                dist[i] = Math.sqrt(sq(mx - scape.earX) + sq(my - scape.earY) + sq(mz - scape.earZ));
                w[i] = b.length(i) / 6 * (b.order[i] == 0 ? 1 : 0.45);
            }
            strokes = b.strokeTime;
        }
        scape.thunder(th.x(), th.y(), th.z(), th.levelDb(), dist, w, strokes, true);
        thunders++;
    }

    /** Leute auf dem Markt zur Stunde h (MEZ) an einem Handelstag [G]: ab 7 Uhr mehr, von 10 bis 15 Uhr gut 150, abends wenige. */
    public static double marketPeople(double h) {
        double up = smooth(6.5, 10, h), down = 1 - smooth(15, 20.5, h);
        return 150 * Math.min(up, down) + 12 * smooth(6, 8, h) * (1 - smooth(21, 23, h));
    }

    /** Gearbeitet wird von 7 bis 18 Uhr 30, mittags eine Pause [G]. */
    public static boolean workHours(double h) { return h > 7 && h < 18.5 && !(h > 12 && h < 12.75); }

    /**
     * Je Bild (in echter Zeit dt): Ohr, Wetter, Wasser, Uhrzeit; Werkstätten, Markt, Feuer, Schilf und Reet nach dem
     * Ort des Ohrs.
     */
    public void feed(double dt, double[] eye, double yawDeg, boolean inHall, double hour, double sunAlt, double windSpeed, double windFromDeg,
                     double gustiness, double rain, double airTempC, double hs, double tp, double level, boolean frozen) {
        time += dt;
        hourNow = hour;
        scape.earX = eye[0];
        scape.earY = eye[1];
        scape.earZ = eye[2];
        scape.earYawDeg = yawDeg;
        scape.windSpeed = windSpeed;
        // in der Siedlung bremsen Häuser und Zäune den Wind am Ohr, am Wasser und auf den Brücken kaum
        boolean town = s.insideWall(eye[0], eye[2], 0) && t.height(eye[0], eye[2]) > 0.6;
        scape.roughness = inHall ? 0.5 : town ? 0.3 : 0.02;
        scape.windFromDeg = windFromDeg;
        scape.gustiness = gustiness;
        scape.rainRate = rain;
        scape.temperatureC = airTempC;
        scape.waterLevel = level;
        scape.waveHeight = frozen ? 0 : hs;
        scape.wavePeriod = Math.max(2, tp);
        // drinnen: in einer halben Sekunde hinein und hinaus (die Tür)
        insideNow += ((inHall ? 1 : 0) - insideNow) * Math.min(1, dt / 0.5);
        scape.inside = insideNow < 0.01 ? 0 : insideNow;
        scape.room = Room.LONGHOUSE;
        // Arbeit und Markt
        boolean work = workHours(hour);
        for (Workshop w : scape.workshops) w.active = work && (rain < 2 || !outdoor.contains(w));
        markt.people = marketPeople(hour) * (rain > 1 ? 0.4 : 1);
        // Feuer nach ihrem Stand; der Herd im Haus
        for (int i = 0; i < pool.size(); i++) {
            Fire f = pooled.get(i);
            double base = switch (f.kind) { case FACKEL -> 0.1; case FEUERSTELLE -> 0.3; case SCHMIEDE -> 0.4; default -> 0.25; };
            pool.get(i).size = base * f.level * Math.max(0.5, Math.min(1.5, f.scale)) + (f.lit ? 0 : 0.04 * f.glow);
        }
        if (hallBlaze != null && feuer.hall != null) {
            Fire hf = feuer.hall.herd;
            hallBlaze.size = 0.35 * hf.level + 0.06 * hf.glow;          // der große Herd der Halle (12 kW)
        }
        brand(dt, eye);
        sortTimer -= dt;
        if (sortTimer <= 0) {
            sortTimer = 0.5;
            List<Blaze> l = new ArrayList<>(pool);
            l.addAll(brandBlazes.values());
            l.removeIf(b -> b.size < 0.01);
            l.removeIf(b -> b.size < 0.01 || Math.hypot(b.x - eye[0], b.z - eye[2]) > 160);
            l.sort((a, b) -> Double.compare(Math.hypot(a.x - eye[0], a.z - eye[2]), Math.hypot(b.x - eye[0], b.z - eye[2])));
            if (hallBlaze != null && insideNow > 0.01) l.add(0, hallBlaze);
            List<Blaze> keep = new ArrayList<>(scape.blazes);
            keep.removeIf(b -> pool.contains(b) || b == hallBlaze || brandBlazes.containsValue(b));   // fremde Feuer (Brand der Hörprobe) bleiben
            List<Blaze> next = new ArrayList<>(l);
            for (Blaze b : keep) if (!next.contains(b)) next.add(0, b);
            scape.blazes.clear();
            scape.blazes.addAll(next.subList(0, Math.min(8, next.size())));
            // Schilf und Reet um das Ohr
            scape.reedNear = reedAt(eye[0], eye[2]);
            scape.thatchNear = inHall ? 1 : thatchAt(eye[0], eye[2]);
        }
        // fliegende Schwäne singen mit den Schwingen
        if (leben != null) {
            for (Flock.Gull g : leben.flock.gulls()) {
                if (g.species != Species.SCHWAN) continue;
                boolean fly = g.state == Flock.State.FLY || g.state == Flock.State.TAKEOFF || g.state == Flock.State.LAND || g.state == Flock.State.LEAVE;
                if (!fly || !near(g.pos[0], g.pos[2], 400)) { swanNext.remove(g.id); continue; }
                Double n = swanNext.get(g.id);
                if (n == null || time >= n) {
                    scape.event(Soundscape.Kind.SCHWAN, g.pos[0], g.pos[1], g.pos[2], 1, 0.5);
                    swanNext.put(g.id, time + 2.9);
                }
            }
        }
    }

    // ------------------------------------------------------------------ Phase 15: der Brand
    private final Map<Integer, Blaze> brandBlazes = new HashMap<>();
    private Brand attached;
    private double alarmNext;
    private final java.util.Random alarmRnd = new java.util.Random(1050);

    /**
     * Phase 15: der Brand der Nacht von 1050 klingt: jedes brennende Haus und der Brander brausen und knistern, ein
     * stürzendes Dach kracht ({@code EINSTURZ}); solange es brennt, bellen Hunde, quieken Schweine, schreien Möwen.
     */
    private void brand(double dt, double[] eye) {
        Brand br = feuer != null ? feuer.brand : null;
        if (br != attached) {
            brandBlazes.clear();
            attached = br;
            if (br != null) br.onCollapse = (h, x, y, z) -> { scape.event(Soundscape.Kind.EINSTURZ, x, y, z, 0.9, 0.5); calls++; };
        }
        if (br == null) return;
        for (int i = 0; i < br.houses.size(); i++) {
            double q = br.hrr(i);
            Blaze b = brandBlazes.get(i);
            if (q < 50) { if (b != null) b.size = 0; continue; }
            if (b == null) {
                House h = br.houses.get(i);
                brandBlazes.put(i, b = new Blaze("Brand " + i, h.x(), h.y() + 3, h.z(), 0, false));
            }
            b.size = Math.min(1.2, 0.25 + q / 30_000);
        }
        Blaze ship = brandBlazes.get(-1);
        if (flotte != null && flotte.branderOn) {
            if (ship == null) brandBlazes.put(-1, ship = new Blaze("Brander", 0, 0, 0, 0.9, false));
            ship.x = flotte.brander.x;
            ship.y = flotte.brander.y + 2;
            ship.z = flotte.brander.z;
            ship.size = 0.9;
        } else if (ship != null) ship.size = 0;
        // Aufruhr in der Siedlung
        boolean fire = br.burning() > 0 || (flotte != null && flotte.branderOn);
        alarmNext -= dt;
        if (fire && alarmNext <= 0) {
            alarmNext = 1.5 + 3.5 * alarmRnd.nextDouble();
            double u = alarmRnd.nextDouble(), ax = eye[0] + 70 * (alarmRnd.nextDouble() - 0.5), az = eye[2] + 70 * (alarmRnd.nextDouble() - 0.5);
            Soundscape.Kind k = u < 0.5 ? Soundscape.Kind.HUND : u < 0.7 ? Soundscape.Kind.MOEWE : u < 0.85 ? Soundscape.Kind.QUIEKEN : Soundscape.Kind.HAHN;
            scape.event(k, ax, k == Soundscape.Kind.MOEWE ? 25 : 1, az, 1, 0.5);
            calls++;
        }
    }

    /** Schilf um das Ohr 0..1 (Mittel aus fünf Punkten in 6 m). */
    double reedAt(double x, double z) {
        if (reed == null) return 0;
        double sum = 0;
        double[][] o = {{0, 0}, {6, 0}, {-6, 0}, {0, 6}, {0, -6}};
        for (double[] q : o) sum += reed.at(x + q[0], z + q[1], Reed.Kind.SCHILF);
        return Math.min(1, sum / 5);
    }

    /** Reetdächer in 12 m um das Ohr 0..1. */
    double thatchAt(double x, double z) {
        double sum = 0;
        for (House h : s.houses) {
            double d = Math.hypot(h.x() - x, h.z() - z) - h.length() / 2;
            if (d < 12) sum += 1 - Math.max(0, d) / 12;
        }
        return Math.min(1, sum * 0.6);
    }

    /** „Klang 58 dB · Wind 44 dB · … · Werkstätten 6 von 14 · Markt 150 Leute“ für das HUD. */
    public String describe() {
        int active = 0;
        for (Workshop w : scape.workshops) if (w.active) active++;
        return String.format(Locale.GERMAN, "%s · Werkstätten %d von %d · Markt %.0f Leute%s", scape.describe(), active, scape.workshops.size(), markt.people,
                scape.inside > 0.5 ? " · im Langhaus" : "");
    }

    /** Werkstätten nach Gewerk: „Schmied 9, Bronzegießer 4, …“ */
    public String workshops() {
        Map<Workshop.Craft, Integer> m = new java.util.EnumMap<>(Workshop.Craft.class);
        for (Workshop w : scape.workshops) m.merge(w.craft, 1, Integer::sum);
        StringBuilder b = new StringBuilder();
        for (var e : m.entrySet()) b.append(b.length() > 0 ? ", " : "").append(label(e.getKey())).append(' ').append(e.getValue());
        return b.toString();
    }

    static String label(Workshop.Craft c) {
        return switch (c) { case SCHMIED -> "Schmied"; case BRONZE -> "Bronzegießer"; case ZIMMERER -> "Zimmermann"; case SAEGE -> "Säger"; case KAMMMACHER -> "Kammmacher"; };
    }

    public double hour() { return hourNow; }

    private static double sq(double v) { return v * v; }

    private static double smooth(double a, double b, double x) {
        double u = Math.max(0, Math.min(1, (x - a) / (b - a)));
        return u * u * (3 - 2 * u);
    }
}
