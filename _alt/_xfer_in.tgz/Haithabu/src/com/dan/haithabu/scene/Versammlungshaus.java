package com.dan.haithabu.scene;

import com.dan.hearth.Fire;
import com.dan.hearth.Flame;
import com.dan.smoke.RoomSmoke;
import com.dan.smoke.Source;
import com.dan.timber.Builder;
import com.dan.timber.House;
import com.dan.timber.HouseType;
import com.dan.timber.Interior;
import com.dan.timber.Mesh;
import com.dan.timber.Timber;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Phase 11: das Versammlungshaus innen (F14 A). Das Haus aus Phase 5 bekommt offene Türen und Rauchlöcher und eine
 * Einrichtung ({@code com.dan.timber.Interior}): Langfeuer in der Mitte, Wandbänke mit Fellen, Sparren unter dem
 * Reet, Kessel an der Kette, Webstuhl am Nordgiebel, Truhe, Fass, Töpfe, Schilde, zwei Talglampen. Der Rauch des
 * Herds sammelt sich unter dem Dach als Schicht ({@code com.dan.smoke.RoomSmoke}) und zieht durch die Rauchlöcher ab;
 * Licht fällt durch Tür und Rauchlöcher als Strahlen in den Rauch.
 * <p>
 * Der Tag im Haus [G]: das Feuer brennt am Morgen (6:30 bis 9:30), mittags (11:30 bis 13:30) und am Abend (16:30
 * bis 22:30); dazwischen und in der Nacht bleibt die Glut unter der Asche. Die Lampen brennen, wenn das Feuer brennt
 * und es draußen dämmert.
 */
public final class Versammlungshaus {
    public final Siedlung.Haus haus;
    public final House house;
    public final Interior.Room room;
    /** Netz für {@code TimberGl.setSpecial}: Hülle mit offenen Türen und Rauchlöchern und die Einrichtung. */
    public final Mesh mesh;
    public final RoomSmoke smoke;
    public final Fire herd;
    public final List<Fire> lamps = new ArrayList<>();
    /** Herd: −1 nach der Tageszeit, 0 nur Glut, 1 brennt. */
    public volatile int herdMode = -1;
    /** Rauch im Haus 0..1,5 (Bedienfeld), Außentemperatur (°C). */
    public volatile double outsideC = 10;
    private double hour = 8, sunAlt = 10, time;

    private Versammlungshaus(Siedlung.Haus haus) {
        this.haus = haus;
        this.house = haus.house();
        this.room = Interior.room(house);
        Mesh m = Builder.buildOpen(house.type());
        m.append(Interior.hall(house, house.seed()));
        this.mesh = m;
        List<RoomSmoke.Vent> vents = new ArrayList<>();
        for (Interior.Opening o : room.openings()) vents.add(new RoomSmoke.Vent(o.a1() - o.a0(), o.y0(), o.y1(), o.triangle()));
        this.smoke = new RoomSmoke(new RoomSmoke.Box(room.hx(), room.hz(), room.wallH(), room.ridgeY(), room.tanRoof()), vents);
        double[] hs = Interior.hearthSpot();
        smoke.fireX = hs[0];
        smoke.fireY = hs[1];
        smoke.fireZ = hs[2];
        double[] hw = room.toWorld(hs[0], hs[1], hs[2]);
        herd = new Fire(Fire.Kind.HERD, hw[0], hw[1], hw[2], 11_950);
        herd.scale = 1.2;
        int k = 0;
        for (double[] l : Interior.lampSpots(room)) {
            double[] p = room.toWorld(l[0], l[1] + 0.04, l[2]);
            Fire f = new Fire(Fire.Kind.LAMPE, p[0], p[1], p[2], 11_960 + k++);
            f.level = 0;
            lamps.add(f);
        }
    }

    /** Das Versammlungshaus der Siedlung, oder null (Hallenhaus mit Namen „Versammlungshaus“). */
    public static Versammlungshaus of(Siedlung s) {
        for (Siedlung.Haus h : s.haeuser)
            if (h.name().equals("Versammlungshaus") && h.house().type() == HouseType.HALLE) {
                Versammlungshaus v = new Versammlungshaus(h);
                v.settle(8, 10);
                return v;
            }
        return null;
    }

    /** Feuer nach der Tageszeit (Stunde MEZ) [G]. */
    public static boolean burning(double h) {
        return (h >= 6.5 && h < 9.5) || (h >= 11.5 && h < 13.5) || (h >= 16.5 && h < 22.5);
    }

    /** Sofort in den Zustand zur Stunde h (nach Sprüngen der Uhr): Feuer, Glut und Rauch wie nach Stunden. */
    public void settle(double h, double sunAltDeg) {
        hour = h;
        sunAlt = sunAltDeg;
        boolean on = herdMode == 1 || (herdMode < 0 && burning(h));
        herd.lit = on;
        herd.level = on ? 1 : 0;
        // Glut: wie lange das Feuer schon aus ist (bis zu acht Stunden zurück)
        double off = 0;
        if (!on) for (double t = 0; t < 8; t += 0.25) { if (burning(((h - t) % 24 + 24) % 24)) break; off = t + 0.25; }
        herd.glow = herdMode == 0 ? 0.6 : on ? 1 : Math.exp(-off * 3600 / 10_800);
        for (Fire l : lamps) { l.lit = on && sunAltDeg < 3; l.level = l.lit ? 1 : 0; }
        feedSmoke();
        smoke.settle();
    }

    /** Um dt Sekunden Szenenzeit weiter. */
    public void step(double sceneDt, double hourNow, double sunAltDeg) {
        // Sprung der Uhr (Regler, Datum, Bildfolge): mehr als 3 Minuten neben dem, was der Schritt erwarten lässt.
        // Dann sofort in den Zustand zur neuen Stunde (Befund Phase 11: nach dem Stellen auf 9:00 war die Schicht noch leer)
        double jump = ((hourNow - hour - sceneDt / 3600) % 24 + 36) % 24 - 12;
        if (Math.abs(jump) > 0.05 || sceneDt > 1800) { settle(hourNow, sunAltDeg); return; }
        hour = hourNow;
        sunAlt = sunAltDeg;
        time += sceneDt;
        boolean on = herdMode == 1 || (herdMode < 0 && burning(hour));
        herd.lit = on;
        // in großen Schritten (Zeitraffer) stückeln, damit Anzünden und Glut stimmen
        double rest = Math.max(0, sceneDt);
        while (rest > 0) {
            double d = Math.min(5, rest);
            herd.step(d);
            if (herdMode == 0) { herd.level = 0; herd.glow = Math.max(herd.glow, 0.6); }
            for (Fire l : lamps) { l.lit = on && sunAlt < 3; l.step(d); }
            rest -= d;
        }
        feedSmoke();
        smoke.step(sceneDt);
    }

    private void feedSmoke() {
        double qf = herd.heatKw(), qe = herd.emberKw();
        smoke.heatKw = qf + qe;
        smoke.yield = qf + qe > 1e-6 ? (qf * RoomSmoke.YIELD + qe * 0.012) / (qf + qe) : RoomSmoke.YIELD;
        smoke.outsideC = outsideC;
    }

    /** Liegt der Punkt (Szene) im Haus? */
    public boolean contains(double x, double y, double z) { return room.contains(x, y, z); }

    /** Abstand eines Punkts zur Mitte des Hauses (m, waagerecht). */
    public double distance(double x, double z) { return Math.hypot(x - house.x(), z - house.z()); }

    /** Sichtbare Flammen im Haus: das Herdfeuer (mit Zungen), die Glut, die Lampen. */
    public List<Flame> flames() {
        List<Flame> l = new ArrayList<>();
        if (herd.level >= 0.02) {
            double h = herd.flameHeight(), w = 0.45 * Math.sqrt(herd.scale);
            l.add(new Flame(herd.x, herd.y, herd.z, w, h, herd.level, herd.seed, Flame.CAMPFIRE));
        }
        Flame e = herd.ember();
        if (e != null) l.add(e);
        for (Fire f : lamps) { Flame fl = f.flame(); if (fl != null) l.add(fl); }
        return l;
    }

    /**
     * Die Lichter im Haus: {x, y, z, Größe, R, G, B (cd)} – Herd (Flamme und Glut) und Lampen, für Wände, Einrichtung
     * und Rauch im Haus.
     */
    public List<double[]> lights(double t) {
        List<double[]> l = new ArrayList<>();
        double[] rgb = herd.intensity(t);
        if (rgb[0] + rgb[1] > 1e-4) {
            double[] p = herd.level > 0.05 ? herd.lightPosition() : new double[]{herd.x, herd.y + 0.06, herd.z};
            l.add(new double[]{p[0], p[1], p[2], herd.level > 0.05 ? 0.35 : 0.6, rgb[0], rgb[1], rgb[2]});
        }
        for (Fire f : lamps) {
            if (f.level < 0.05) continue;
            double[] c = f.intensity(t), p = f.lightPosition();
            l.add(new double[]{p[0], p[1], p[2], 0.05, c[0], c[1], c[2]});
        }
        return l;
    }

    /**
     * Licht, das aus den Türen nach draußen fällt: je Tür ein schwaches Punktlicht 0,6 m vor der Schwelle, mit dem
     * Anteil, den die Tür vom Herd sieht [G]. {x, y, z, Größe, R, G, B (cd)}.
     */
    public List<double[]> doorLights(double t) {
        List<double[]> l = new ArrayList<>();
        double[] rgb = herd.intensity(t);
        for (Interior.Opening o : room.openings()) {
            if (o.triangle()) continue;
            double[][] f = room.openingFrame(o);
            double[] p = room.toWorld(f[0][0] + f[1][0] * 0.8, 1.0, f[0][2] + f[1][2] * 0.8);
            double k = 0.06;
            l.add(new double[]{p[0], p[1], p[2], 0.7, rgb[0] * k, rgb[1] * k, rgb[2] * k});
        }
        return l;
    }

    /** Rauch, der aus den Rauchlöchern ins Freie zieht (je Loch eine Fahne). */
    public List<Source> sources() {
        List<Source> l = new ArrayList<>();
        double amount = herd.smoke() * 0.5 + 0.08 * herd.glow * (1 - herd.level);
        if (amount < 0.02) return l;
        int k = 0;
        for (double[] p : Timber.smokeHoles(house))
            l.add(new Source(p[0], p[1] + 0.2, p[2], Math.max(2, (herd.heatKw() + herd.emberKw()) / 2), Math.min(1, amount), herd.blackness(), herd.seed + 17 * ++k));
        return l;
    }

    /**
     * Leuchtdichte im Haus für die Augenanpassung (in den Einheiten von {@code com.dan.sky}: cd/m² / CD_PER_UNIT):
     * Herd und Lampen auf die Flächen im mittleren Abstand, dazu das Tageslicht durch die Öffnungen (mittlerer
     * Tageslichtquotient) und die Sonne, wenn sie durch eine Öffnung fällt; Rückstrahlung 0,15.
     */
    public double interiorLuminance(double horizIrrUnits, double cdPerUnit, double t) {
        double e = 0;
        for (double[] l : lights(t)) e += (0.2126 * l[4] + 0.7152 * l[5] + 0.0722 * l[6]) / (3.2 * 3.2);
        double eUnits = e / cdPerUnit + horizIrrUnits * room.daylightFactor(0.15) * 1.6;
        return eUnits * 0.15 / Math.PI;
    }

    /**
     * Rückstrahlung im Raum als Bestrahlung (Einheiten von sunColor): das Licht, das durch die Öffnungen hereinkommt
     * (Himmel, und die Sonne, soweit sie auf den Boden fällt), gleichmäßig über die Flächen verteilt und einmal
     * zurückgeworfen (ρ = 0,15).
     */
    public double[] bounce(double[] sunIrr, double sunPatch, double[] skyIrr) {
        double rho = 0.15, share = room.openArea() * 0.5 / room.surface();
        double[] b = new double[3];
        for (int c = 0; c < 3; c++) b[c] = rho / (1 - rho) * (skyIrr[c] * share + sunIrr[c] * sunPatch / room.surface());
        return b;
    }

    /**
     * Wie viel Sonne durch die Öffnungen hereinkommt, als Fläche senkrecht zur Sonne (m²): je Öffnung Fläche mal
     * Kosinus zwischen ihrer Normale und der Richtung zur Sonne d (Szene).
     */
    public double sunPatch(double[] d) {
        if (d[1] <= 0.0) return 0;
        double[] dl = room.dirToLocal(d);
        double s = 0;
        for (Interior.Opening o : room.openings()) {
            double[][] f = room.openingFrame(o);
            double c = dl[0] * f[1][0] + dl[1] * f[1][1] + dl[2] * f[1][2];
            if (c > 0) s += o.area() * c;
        }
        return s;
    }

    public double hour() { return hour; }

    /** Die Tür an der Traufseite +z (nach Osten; am Morgen fällt die Sonne hinein), oder die erste Tür. */
    public Interior.Opening frontDoor() {
        Interior.Opening first = null;
        for (Interior.Opening o : room.openings()) {
            if (o.triangle()) continue;
            if (first == null) first = o;
            if (o.face() == Interior.SIDE_PZ) return o;
        }
        return first;
    }

    /**
     * Ansicht „Im Haus“ (Taste 7): am Südende der Halle (örtlich −x), 1,6 m über dem Lehmboden, Blick den First
     * entlang nach Norden, ein wenig zur Osttür, leicht nach oben in den Rauch: {x, Augenhöhe, z, Blick, Neigung}.
     */
    public double[] imHaus() {
        double[] p = room.toWorld(-room.hx() + 1.75, 1.6, 0.6);
        return new double[]{p[0], p[1], p[2], (house.headingDeg() + 8 + 360) % 360, -4};
    }

    /**
     * Weg der Fahrt „Durch die Gasse“: auf dem Bohlenweg am Nordufer des Bachs von Westen bis vor den Hof, durch den
     * Hof zur Osttür, hinein, am Herd vorbei bis ans Südende; je Punkt {x, Augenhöhe, z}.
     */
    public double[][] gasse(Siedlung s, Terrain t) {
        List<double[]> l = new ArrayList<>();
        Interior.Opening d = frontDoor();
        double c = (d.a0() + d.a1()) / 2, side = d.face() == Interior.SIDE_PZ ? 1 : -1;
        double[] out = room.toWorld(c, 0, side * (room.hz() + 3.2));
        double xYard = out[0] + 2.2 * Math.signum(out[0] - house.x());
        for (double x = -172; x <= xYard - 3; x += 6) {
            double z = s.brookZ(x) - 4.6;
            l.add(new double[]{x, Math.max(t.height(x, z), 0) + 1.75, z});
        }
        double z0 = s.brookZ(xYard) - 4.6;
        for (int i = 0; i <= 6; i++) {
            double f = i / 6.0, ff = f * f * (3 - 2 * f);
            double x = xYard + (out[0] - xYard) * ff, z = z0 + (out[2] - z0) * f;
            l.add(new double[]{x, Math.max(t.height(x, z), 0) + 1.7, z});
        }
        double eye = house.y() + 1.6;
        double[][] inside = {{c, side * (room.hz() + 1.6)}, {c, side * (room.hz() + 0.3)}, {c, side * (room.hz() - 0.9)},
                {c - 1.0, side * 1.35}, {-2.9, side * 1.2}, {-4.6, side * 0.95}, {-room.hx() + 1.75, 0.6}};
        for (double[] q : inside) {
            double[] w = room.toWorld(q[0], 0, q[1]);
            l.add(new double[]{w[0], eye, w[2]});
        }
        return l.toArray(new double[0][]);
    }

    /** „Herd brennt (12 kW) · Schicht ab 2,4 m, σ 0,31/m (Sicht 10 m) · 2 Lampen“ */
    public String describe() {
        String h = herd.level > 0.05 ? String.format(Locale.GERMAN, "Herd brennt (%.0f kW)", herd.heatKw())
                : herd.glow > 0.03 ? String.format(Locale.GERMAN, "nur Glut (%.0f %%)", herd.glow * 100) : "Herd kalt";
        int lit = 0;
        for (Fire f : lamps) if (f.level > 0.5) lit++;
        return h + " · " + smoke.describe() + (lit > 0 ? " · " + lit + " Lampen" : "");
    }
}
