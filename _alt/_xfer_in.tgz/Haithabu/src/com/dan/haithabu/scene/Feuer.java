package com.dan.haithabu.scene;

import com.dan.hearth.Fire;
import com.dan.hearth.Flame;
import com.dan.smoke.Source;
import com.dan.timber.House;
import com.dan.timber.HouseType;
import com.dan.timber.Timber;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.SplittableRandom;

/**
 * Phase 10: Feuer und Rauch in Haithabu. Jedes Haus mit Rauchloch hat einen Herd; ob er brennt, hängt von der
 * Tageszeit ab (Kochen am Morgen und am Abend, in der Nacht nur Glut) und von einem festen Zufall je Haus. Aus dem
 * Rauchloch steigt dann eine Fahne ({@code com.dan.smoke}). Schmieden, Glasmacher und Bronzegießer arbeiten am Tag
 * mit offener Esse, dunklerem Rauch und Funken. Am Strand des Fischers brennt abends eine Feuerstelle, an den drei
 * Toren und an den Querköpfen der Brücken stecken nachts Fackeln ({@code com.dan.hearth}). Die Feuer geben Licht an
 * Häuser, Gelände, Rauch und das Noor.
 * <p>
 * Belegt: Herdstellen in den Häusern, Rauchabzug durch Giebelöffnungen, Gewerbe im Nordwesten. Gestaltet [G]: der
 * Tagesgang, die Anteile, Fackeln an Toren und Brücken, die Feuerstelle am Strand.
 */
public final class Feuer {
    /** Ein Herd unter einem Rauchloch: Haus, Austritt des Rauchs, Feuer (im Haus, unsichtbar), Zufall für den Tagesgang. */
    record Herd(House house, double[] hole, Fire fire, double rank, boolean workshop, boolean weaver) { }

    final List<Herd> herds = new ArrayList<>();
    final List<Fire> open = new ArrayList<>();
    final List<Fire> torches = new ArrayList<>();
    Fire beach;
    /** Phase 11: das Versammlungshaus mit Herd, Glut, Lampen und Rauch im Haus (eigener Tagesgang), oder null. */
    public final Versammlungshaus hall;
    /** Phase 15: der Brand der Nacht von 1050 (Brander und Häuser) oder null; geht in Flammen, Licht und Rauch ein. */
    public volatile Brand brand;
    private double hour = 18, sunAlt = 0;
    /** Anteil der Herde, die gerade brennen (Bedienfeld: 0..2 · Tagesgang). */
    public volatile double herdShare = 1;
    /** Fackeln: -1 automatisch (nachts), 0 aus, 1 an. */
    public volatile int torchMode = -1;
    private double time;

    private Feuer(Versammlungshaus hall) { this.hall = hall; }

    /** Feuer der Siedlung (Herde, Gewerbe, Fackeln, Strand). */
    public static Feuer of(Terrain t, Siedlung s) {
        Feuer f = new Feuer(Versammlungshaus.of(s));
        SplittableRandom r = new SplittableRandom(950_10L);
        int seed = 1000;
        for (Siedlung.Haus h : s.haeuser) {
            House house = h.house();
            // Phase 11: das Versammlungshaus führt seinen Herd selbst
            if (f.hall != null && house.equals(f.hall.house)) { seed++; r.nextDouble(); continue; }
            String rolle = h.rolle() == null ? "" : h.rolle();
            boolean workshop = rolle.equals("Schmiede") || rolle.equals("Glasmacher") || rolle.equals("Bronzegießer");
            List<double[]> holes = Timber.smokeHoles(house);
            double[] hole;
            if (!holes.isEmpty()) hole = holes.get(0);
            else if (workshop) hole = house.toWorld(0, house.type().ridgeY() * 0.6, 0);
            else continue;
            Fire fire;
            if (workshop) {
                double[] p = house.toWorld(house.type() == HouseType.SCHUPPEN ? 0.3 : 0, 0.8, 0);
                fire = new Fire(Fire.Kind.SCHMIEDE, p[0], p[1], p[2], seed++);
                if (house.type() == HouseType.SCHUPPEN) f.open.add(fire);     // im offenen Schuppen sieht man die Esse
            } else fire = new Fire(Fire.Kind.HERD, hole[0], hole[1] - 3, hole[2], seed++);
            fire.level = 0;
            f.herds.add(new Herd(house, hole, fire, r.nextDouble(), workshop, house.type() == HouseType.GRUBENHAUS));
        }
        // Feuerstelle am Strand des Fischers (zwischen Bachmündung und Plattform, z 20 … 40)
        if (s.hafen != null) {
            double[] best = null;
            for (double[] u : s.hafen.ufer) if (u[1] > 20 && u[1] < 40 && (best == null || Math.abs(u[1] - 30) < Math.abs(best[1] - 30))) best = u;
            if (best != null) {
                double bx = best[0] - best[2] * 5, bz = best[1] - best[3] * 5;
                f.beach = new Fire(Fire.Kind.FEUERSTELLE, bx, Math.max(0.2, t.height(bx, bz)) + 0.05, bz, seed++);
                f.beach.scale = 1.3;
                f.beach.level = 0;
                f.open.add(f.beach);
            }
            // Fackeln an den Querköpfen
            for (Hafen.Bruecke b : s.hafen.bruecken) {
                if (!b.querkopf()) continue;
                double l = b.length(), ux = (b.x1() - b.x0()) / l, uz = (b.z1() - b.z0()) / l;
                for (int side = -1; side <= 1; side += 2) {
                    double px = b.x1() - ux * 1.5 - uz * side * (b.width() / 2 + 0.2), pz = b.z1() - uz * 1.5 + ux * side * (b.width() / 2 + 0.2);
                    f.torches.add(new Fire(Fire.Kind.FACKEL, px, Hafen.DECK + 1.6, pz, seed++));
                }
            }
        }
        // Fackeln an den Toren: innen beiderseits der Torgasse
        if (t.befestigung != null)
            for (Befestigung.Tor tor : t.befestigung.tore) {
                if (tor.bach()) continue;
                var g = tor.gate();
                for (int side = -1; side <= 1; side += 2) {
                    double[] p = g.at(-g.depth() / 2 - 0.4, side * (g.width() / 2 + 0.35), g.floorIn() + 2.3);
                    f.torches.add(new Fire(Fire.Kind.FACKEL, p[0], p[1], p[2], seed++));
                }
            }
        for (Fire tc : f.torches) tc.level = 0;
        f.open.addAll(f.torches);
        return f;
    }

    /** Tagesgang der Herde: Anteil, der brennt (0..1) zur Stunde h (MEZ) [G]. */
    public static double activity(double h) {
        double morning = Math.exp(-sq((h - 7.5) / 1.4)), noon = Math.exp(-sq((h - 12.5) / 1.5)), evening = Math.exp(-sq((h - 18.5) / 2.0));
        return 0.07 + 0.28 * morning + 0.12 * noon + 0.33 * evening;
    }

    /** Um dt weiter: wer brennt, Anzünden und Ausgehen. */
    public void step(double dt, double hourNow, double sunAltDeg) {
        hour = hourNow;
        sunAlt = sunAltDeg;
        time += dt;
        double act = activity(hour) * herdShare;
        boolean work = hour > 7 && hour < 18.5;
        for (Herd h : herds) {
            double share = h.workshop ? (work ? 0.9 : 0.0) : h.weaver ? act * 0.5 : act;
            h.fire.lit = h.rank < share;
            h.fire.step(dt);
        }
        boolean night = torchMode == 1 || (torchMode < 0 && sunAlt < 1.5);
        for (Fire tc : torches) { tc.lit = night; tc.step(dt); }
        if (beach != null) {
            beach.lit = (hour > 16.5 && hour < 23.5) || (sunAlt < -2 && hour < 2);
            beach.step(dt);
        }
        if (hall != null) hall.step(dt, hour, sunAlt);
    }

    /**
     * Nach einem Sprung der Uhr (Regiebuch, Monat, „Weiter wie zuletzt“): alle Feuer sofort auf den Stand der neuen
     * Stunde, ohne Anzünden und Ausgehen. Sonst rauchten nach einem Sprung vom Abend in die Nacht noch eine Minute
     * lang alle Herde des Abends weiter (Befund der Abnahme Phase 15: 140 Fahnen, wo 25 Herde brennen). Die Glut
     * eines Herds, der jetzt brennt, ist voll; die übrigen behalten ihre.
     */
    public void springen(double hourNow, double sunAltDeg) {
        step(1e-6, hourNow, sunAltDeg);
        for (Herd h : herds) setze(h.fire);
        for (Fire tc : torches) setze(tc);
        if (beach != null) setze(beach);
    }

    private static void setze(Fire f) {
        f.level = f.lit ? 1 : 0;
        if (f.lit) f.glow = 1;
    }

    /** Rauchquellen jetzt (aus allen Herden mit Glut, der Feuerstelle, den Fackeln in der Nähe nicht). */
    public List<Source> sources() {
        List<Source> l = new ArrayList<>();
        for (Herd h : herds) {
            Fire f = h.fire;
            // Glut eines ausgegangenen Herds raucht noch eine Weile schwach
            double amount = f.smoke();
            if (amount < 0.02) continue;
            l.add(new Source(h.hole[0], h.hole[1] + 0.2, h.hole[2], Math.max(2, f.heatKw()), amount, f.blackness(), f.seed));
        }
        if (beach != null && beach.smoke() > 0.02) l.add(new Source(beach.x, beach.y + 0.8, beach.z, beach.heatKw(), beach.smoke(), beach.blackness(), beach.seed));
        if (hall != null) l.addAll(hall.sources());
        Brand b = brand;
        if (b != null) l.addAll(b.sources());
        return l;
    }

    /** Sichtbare Flammen (Esse im Schuppen, Feuerstelle, Fackeln). */
    public List<Flame> flames() {
        List<Flame> l = new ArrayList<>();
        for (Fire f : open) { Flame fl = f.flame(); if (fl != null) l.add(fl); }
        if (hall != null) l.addAll(hall.flames());
        Brand b = brand;
        if (b != null) l.addAll(b.flames());
        return l;
    }

    /**
     * Die n hellsten Lichter für das Auge: {x, y, z, Größe der Quelle, R, G, B (cd)} je Licht, nach Beleuchtungsstärke
     * am Auge sortiert. Herde leuchten nur durch die Tür nach außen: ein schwaches Licht vor der ersten Tür (seit
     * Phase 11; vorher ein Zehntel aus der Mitte des Hauses, das durch die Wände schien) [G]. Das Versammlungshaus
     * gibt das Licht seiner beiden offenen Türen.
     */
    public List<double[]> lights(double ex, double ey, double ez, int n, double range) {
        List<double[]> all = new ArrayList<>();
        for (Herd h : herds) {
            Fire f = h.fire;
            if (f.level < 0.05) continue;
            boolean visible = h.workshop && open.contains(f);
            double k = visible ? 1 : 0.025;
            double[] p = visible ? f.lightPosition() : doorFront(h.house);
            add(all, p, f.intensity(time), k, visible ? 0.3 : 0.6, ex, ey, ez, range);
        }
        if (hall != null)
            for (double[] d : hall.doorLights(time)) add(all, new double[]{d[0], d[1], d[2]}, new double[]{d[4], d[5], d[6]}, 1, d[3], ex, ey, ez, range);
        for (Fire f : open) {
            if (herdsContain(f) || f.level < 0.05) continue;
            add(all, f.lightPosition(), f.intensity(time), 1, f.kind == Fire.Kind.FACKEL ? 0.1 : 0.4, ex, ey, ez, range);
        }
        Brand br = brand;
        if (br != null) for (double[] q : br.lights(time)) add(all, new double[]{q[0], q[1], q[2]}, new double[]{q[4], q[5], q[6]}, 1, q[3], ex, ey, ez, range * 4);
        all.sort((a, b) -> Double.compare(b[7], a[7]));
        return all.subList(0, Math.min(n, all.size()));
    }

    /** 0,6 m vor der ersten Tür eines Hauses, 1 m hoch (Szene); ohne Tür die Mitte. */
    static double[] doorFront(House h) {
        HouseType t = h.type();
        if (t.doors.isEmpty()) return new double[]{h.x(), h.y() + 1.2, h.z()};
        HouseType.Door d = t.doors.get(0);
        double lx, lz;
        switch (d.side()) {
            case SOUTH -> { lx = -t.length / 2 + d.at() * t.length; lz = t.width / 2 + 0.6; }
            case NORTH -> { lx = -t.length / 2 + d.at() * t.length; lz = -t.width / 2 - 0.6; }
            case EAST -> { lx = t.length / 2 + 0.6; lz = -t.width / 2 + d.at() * t.width; }
            default -> { lx = -t.length / 2 - 0.6; lz = -t.width / 2 + d.at() * t.width; }
        }
        // toWorld streckt; die 0,6 m sollen ungestreckt bleiben, darum knapp genug
        return h.toWorld(lx, 1.0 - t.sunk, lz);
    }

    private boolean herdsContain(Fire f) { for (Herd h : herds) if (h.fire == f) return true; return false; }

    private static void add(List<double[]> all, double[] p, double[] rgb, double k, double size, double ex, double ey, double ez, double range) {
        double d2 = sq(p[0] - ex) + sq(p[1] - ey) + sq(p[2] - ez);
        if (d2 > range * range) return;
        double e = (0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2]) * k / (d2 + 25);
        all.add(new double[]{p[0], p[1], p[2], size, rgb[0] * k, rgb[1] * k, rgb[2] * k, e});
    }

    public int herdCount() { return herds.size(); }
    public int burningHerds() { int n = 0; for (Herd h : herds) if (h.fire.lit && !h.workshop) n++; return n; }
    public int workshopsBurning() { int n = 0; for (Herd h : herds) if (h.fire.lit && h.workshop) n++; return n; }
    public int torchesLit() { int n = 0; for (Fire f : torches) if (f.level > 0.5) n++; return n; }
    public int torchCount() { return torches.size(); }
    public boolean beachLit() { return beach != null && beach.level > 0.5; }

    /** „Herde 118 von 344 an (Tagesgang 34 %) · 5 Essen · 10 von 10 Fackeln · Feuerstelle am Strand“ */
    public String describe() {
        return String.format(Locale.GERMAN, "Herde %d von %d an (Tagesgang %.0f %%) · %d Essen · %d von %d Fackeln%s",
                burningHerds(), herds.size() - workshopsTotal(), activity(hour) * herdShare * 100, workshopsBurning(), torchesLit(), torches.size(), beachLit() ? " · Feuerstelle am Strand" : "");
    }

    private int workshopsTotal() { int n = 0; for (Herd h : herds) if (h.workshop) n++; return n; }

    static double sq(double v) { return v * v; }
}
