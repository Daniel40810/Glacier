package com.dan.haithabu.scene;

import com.dan.ocean.ObstacleField;
import com.dan.timber.Mesh;
import com.dan.timber.Structures;
import com.dan.timber.Wharf;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.SplittableRandom;

/**
 * Phase 8: der Hafen. Das Ufer von 950 zwischen den Enden des Halbkreiswalls wird im Gelände gesucht (die Linie, an
 * der das Land unter den Spiegel des Noors taucht). Davor liegt eine Plattform aus Bohlen auf Pfahlreihen, nördlich und
 * südlich des Bachs, frei bleibt der Strand des Fischers; aus ihr laufen Landebrücken hinaus, bis das Wasser 1,9 m tief
 * ist (Tiefgang der Schiffe 1,3 bis 1,5 m), einige mit Querkopf, zwischen zwei Brücken ein großer Umschlagplatz. Eine
 * Pfahlreihe im Wasser fasst das Hafenbecken im Bogen von Wallende zu Wallende, mit einer Durchfahrt nach Nordosten.
 * Wo keine Plattform steht, hält eine Bohlenwand das Ufer. Auf den Brücken liegen Waren aus der Fundliste: Fässer,
 * Ballen, Mühlsteine aus Basalt, Specksteintöpfe.
 * <p>
 * Belegt: Plattformen am ganzen Ufer (um 900), Pfahlbrücken, die Palisade im Wasser, Tiefgang, Hafenbecken 8 bis 11 ha.
 * Gestaltet [G]: Pfahlraster, Zahl, Länge und Breite der Brücken, Lage der Durchfahrt, die Waren im Einzelnen.
 */
public final class Hafen {
    /** Deckhöhe über dem Mittelwasser (m) und Breite der Plattform am Ufer; Tiefe, bis zu der die Brücken reichen. */
    public static final double DECK = 0.9, PLATTFORM_BREITE = 13, TIEFE = 1.9;
    /** Oberkante der Hafenpalisade über dem Mittelwasser (m), Breite der Durchfahrt (m). */
    public static final double PALISADE_TOP = 1.3, DURCHFAHRT = 14;

    /** Eine Landebrücke: Wurzel und Kopf (x, z), Breite, mit Querkopf. */
    public record Bruecke(double x0, double z0, double x1, double z1, double width, boolean querkopf) {
        public double length() { return Math.hypot(x1 - x0, z1 - z0); }
    }

    /** Ufer von 950 zwischen den Wallenden, von Süden nach Norden, je 4 m: x, z, Normale nach außen (zum Wasser). */
    public final List<double[]> ufer = new ArrayList<>();
    public final List<double[][]> plattformen = new ArrayList<>();
    public final List<Bruecke> bruecken = new ArrayList<>();
    /** Umschlagplatz: Linie, Breite. */
    public double[][] umschlag;
    public double umschlagBreite;
    /** Hafenpalisade (zwei Stücke, Lücke der Durchfahrt dazwischen) und Mitte der Durchfahrt. */
    public final List<double[][]> palisade = new ArrayList<>();
    public double[] durchfahrt;
    /** Phase 16: das Becken zwischen Ufer und Bogen der Palisade als Fläche (für HB_BAUWERK). */
    public double[][] becken;
    public final List<double[][]> befestigung = new ArrayList<>();
    /** Pfähle im Wasser {x, z, Halbmesser} für den Brandungsring des Noors. */
    public final List<double[]> pfaehle = new ArrayList<>();
    public ObstacleField feld;
    /** Fläche des Hafenbeckens (ha), Zahl der Waren je Art (Fass, Ballen, Mühlstein, Topf). */
    public double flaecheHa;
    public final int[] waren = new int[4];
    public double ms;

    private final Terrain t;

    private Hafen(Terrain t) { this.t = t; }

    /** Baut den Hafen in die Bauwerke der Siedlung; null ohne Wall (flache Bühne). */
    static Hafen bauen(Terrain t, Siedlung s) {
        Befestigung w = t.befestigung;
        if (w == null) return null;
        long t0 = System.nanoTime();
        Hafen h = new Hafen(t);
        h.uferSuchen(w);
        if (h.ufer.size() < 20) return null;
        Structures.Ground g = (x, z) -> t.height(x, z);
        h.plattformen(s, g);
        h.palisade(g, s);
        h.befestigung(s, g);
        h.waren(s);
        h.feld();
        h.ms = (System.nanoTime() - t0) / 1e6;
        return h;
    }

    // ------------------------------------------------------------------ Ufer

    /** Das Ufer: je 4 m in z die erste Stelle von Westen, an der das Land unter 0 m fällt, geglättet, innerhalb des Walls. */
    private void uferSuchen(Befestigung w) {
        int n = w.x.length;
        double zs = w.z[0] - 6, zn = w.z[n - 1] + 6;      // Südende (z groß), Nordende (z klein)
        List<double[]> raw = new ArrayList<>();
        for (double z = zs; z >= zn; z -= 4) {
            double last = Double.NaN;
            for (double x = -260; x <= 160; x += 0.5) {
                double y = t.height(x, z);
                if (y <= 0 && t.height(x - 0.5, z) > 0) { last = x; break; }
            }
            if (!Double.isNaN(last) && w.inside(last - 3, z, 0)) raw.add(new double[]{last, z});
        }
        int m = raw.size();
        for (int i = 0; i < m; i++) {
            double sx = 0, sz = 0;
            int c = 0;
            for (int j = Math.max(0, i - 3); j <= Math.min(m - 1, i + 3); j++) { sx += raw.get(j)[0]; sz += raw.get(j)[1]; c++; }
            ufer.add(new double[]{sx / c, sz / c, 0, 0});
        }
        for (int i = 0; i < ufer.size(); i++) {
            double[] a = ufer.get(Math.max(0, i - 2)), b = ufer.get(Math.min(ufer.size() - 1, i + 2));
            double tx = b[0] - a[0], tz = b[1] - a[1], l = Math.hypot(tx, tz);
            double nx = -tz / l, nz = tx / l;
            // zum Wasser (nach Osten, tieferes Gelände)
            double[] p = ufer.get(i);
            if (t.height(p[0] + nx * 10, p[1] + nz * 10) > t.height(p[0] - nx * 10, p[1] - nz * 10)) { nx = -nx; nz = -nz; }
            p[2] = nx;
            p[3] = nz;
        }
    }

    /** Ufer an Index i, um off m nach außen versetzt. */
    private double[] off(int i, double off) {
        double[] p = ufer.get(i);
        return new double[]{p[0] + p[2] * off, p[1] + p[3] * off};
    }

    private int idx(double z) {
        int best = 0;
        double bd = 1e18;
        for (int i = 0; i < ufer.size(); i++) { double d = Math.abs(ufer.get(i)[1] - z); if (d < bd) { bd = d; best = i; } }
        return best;
    }

    // ------------------------------------------------------------------ Plattformen und Brücken

    private void plattformen(Siedlung s, Structures.Ground g) {
        SplittableRandom r = new SplittableRandom(950_8L);
        double mid = PLATTFORM_BREITE / 2 - 1.5;               // Mitte 5 m vor dem Ufer, Rand 1,5 m auf dem Land
        // nördlich des Bachs (z −210 … −7) und südlich des Fischerstrands (z 54 … 132) [G]
        double[][] spans = {{-7, -210}, {132, 54}};
        for (double[] sp : spans) {
            int a = idx(sp[0]), b = idx(sp[1]);
            List<double[]> line = new ArrayList<>();
            for (int i = Math.min(a, b); i <= Math.max(a, b); i++) line.add(off(i, mid));
            double[][] l = line.toArray(new double[0][]);
            plattformen.add(l);
            s.bauwerke.platform(l, PLATTFORM_BREITE, DECK, g, r.nextLong());
            s.blockLine(l, PLATTFORM_BREITE / 2);
            pilesPlatform(l, PLATTFORM_BREITE);
            // Landebrücken alle gut 30 m, von der Außenkante bis 1,9 m Wassertiefe
            int from = Math.min(a, b) + 2, to = Math.max(a, b) - 2;
            int k = 0;
            for (int i = from; i <= to; i += 7 + r.nextInt(3)) {
                double[] p = ufer.get(i);
                double[] root = off(i, PLATTFORM_BREITE - 1.5 - 0.5);
                double len = 4;
                while (len < 120 && t.height(root[0] + p[2] * len, root[1] + p[3] * len) > -TIEFE) len += 1;
                len += 3;
                double width = 3.2 + r.nextDouble() * 1.4;
                boolean head = r.nextDouble() < 0.4;
                double[][] pl = {root, {root[0] + p[2] * len, root[1] + p[3] * len}};
                bruecken.add(new Bruecke(pl[0][0], pl[0][1], pl[1][0], pl[1][1], width, head));
                s.bauwerke.pier(pl, width, DECK + 0.05, g, r.nextLong());
                s.blockLine(pl, width / 2);
                pilesPier(pl, width);
                if (head) {
                    double qx = -p[3], qz = p[2];
                    double[][] hl = {{pl[1][0] - qx * 7 - p[2] * 2, pl[1][1] - qz * 7 - p[3] * 2}, {pl[1][0] + qx * 7 - p[2] * 2, pl[1][1] + qz * 7 - p[3] * 2}};
                    s.bauwerke.platform(hl, 4.0, DECK + 0.05, g, r.nextLong());
                    pilesPlatform(hl, 4.0);
                }
                k++;
            }
        }
        // Umschlagplatz zwischen der zweiten und dritten Brücke des Nordteils [G]
        if (bruecken.size() >= 3) {
            Bruecke b1 = bruecken.get(1), b2 = bruecken.get(2);
            int i1 = idx(b1.z0()), i2 = idx(b2.z0());
            List<double[]> line = new ArrayList<>();
            for (int i = Math.min(i1, i2) + 1; i <= Math.max(i1, i2) - 1; i++) line.add(off(i, PLATTFORM_BREITE - 1.5 + 9.5));
            if (line.size() >= 2) {
                umschlag = line.toArray(new double[0][]);
                umschlagBreite = 18;
                s.bauwerke.platform(umschlag, umschlagBreite, DECK, g, 9508);
                s.blockLine(umschlag, umschlagBreite / 2);
                pilesPlatform(umschlag, umschlagBreite);
            }
        }
    }

    private void pilesPier(double[][] l, double width) {
        double dx = l[1][0] - l[0][0], dz = l[1][1] - l[0][1], len = Math.hypot(dx, dz);
        dx /= len; dz /= len;
        for (double d = 0; d <= len; d += 2.5)
            for (int s = -1; s <= 1; s += 2) pile(l[0][0] + dx * d - dz * s * (width / 2 - 0.15), l[0][1] + dz * d + dx * s * (width / 2 - 0.15), 0.14);
    }

    private void pilesPlatform(double[][] l, double width) {
        int cols = Math.max(2, (int) Math.ceil(width / 2.6) + 1);
        for (int i = 0; i + 1 < l.length; i++) {
            double dx = l[i + 1][0] - l[i][0], dz = l[i + 1][1] - l[i][1], len = Math.hypot(dx, dz);
            if (len < 1e-6) continue;
            dx /= len; dz /= len;
            for (double d = 0; d < len; d += 2.5)
                for (int c = 0; c < cols; c++) {
                    double q = -width / 2 + 0.18 + (width - 0.36) * c / (cols - 1);
                    pile(l[i][0] + dx * d - dz * q, l[i][1] + dz * d + dx * q, 0.14);
                }
        }
    }

    /** Pfähle der Palisade alle step m entlang der Linie. */
    private void walkLine(double[][] l, double step) {
        double carry = 0;
        for (int i = 0; i + 1 < l.length; i++) {
            double dx = l[i + 1][0] - l[i][0], dz = l[i + 1][1] - l[i][1], len = Math.hypot(dx, dz);
            if (len < 1e-9) continue;
            double d = carry;
            for (; d <= len; d += step) pile(l[i][0] + dx * d / len, l[i][1] + dz * d / len, 0.14);
            carry = d - len;
        }
    }

    private void pile(double x, double z, double r) { if (t.height(x, z) < -0.05) pfaehle.add(new double[]{x, z, r}); }

    // ------------------------------------------------------------------ Palisade

    /**
     * Die Pfahlreihe im Wasser: das Ufer, um d(u) nach außen versetzt, d = D · sin(πu)^0,6 von Wallende zu Wallende
     * (u = 0 … 1 entlang des Ufers). D so, dass das Becken 10 ha hat [G nach 8 bis 11 ha]. Die Durchfahrt liegt bei
     * u = 0,58, nach Nordosten zur Schlei.
     */
    private void palisade(Structures.Ground g, Siedlung s) {
        double lo = 60, hi = 260, d = 150;
        for (int it = 0; it < 30; it++) {
            d = (lo + hi) / 2;
            double a = area(arc(d));
            if (a < 100_000) lo = d; else hi = d;
        }
        double[][] full = arc(d);
        flaecheHa = area(full) / 10_000;
        List<double[]> bk = new ArrayList<>();
        for (double[] p : ufer) bk.add(new double[]{p[0], p[1]});
        for (int i = full.length - 1; i >= 0; i--) bk.add(full[i]);
        becken = bk.toArray(new double[0][]);
        // Durchfahrt: die Punkte innerhalb DURCHFAHRT/2 um u = 0,58 fallen weg
        int c = (int) Math.round(0.58 * (full.length - 1));
        double[] gc = full[c];
        durchfahrt = gc.clone();
        List<double[]> a = new ArrayList<>(), b = new ArrayList<>();
        for (int i = 0; i < full.length; i++) {
            double dd = Math.hypot(full[i][0] - gc[0], full[i][1] - gc[1]);
            if (dd < DURCHFAHRT / 2) continue;
            (i < c ? a : b).add(full[i]);
        }
        for (List<double[]> part : List.of(a, b)) {
            if (part.size() < 2) continue;
            double[][] l = part.toArray(new double[0][]);
            palisade.add(l);
            s.bauwerke.palisadeTo(l, PALISADE_TOP, g, 9500 + palisade.size());
            walkLine(l, 0.3);
        }
        // die beiden Pfähle der Durchfahrt kräftiger
        for (List<double[]> part : List.of(a, b)) {
            if (part.isEmpty()) continue;
            double[] e = part == a ? part.get(part.size() - 1) : part.get(0);
            Mesh m = new Mesh();
            m.beam(new double[]{e[0], t.height(e[0], e[1]) - 0.8, e[1]}, new double[]{e[0], PALISADE_TOP + 1.2, e[1]}, 0.25, 8, com.dan.timber.Material.POST, true, 0.3, 1);
            s.bauwerke.mesh(e[0], e[1], 1, m, m);
        }
    }

    /** Bogen der Palisade für den größten Abstand dmax: über das Ufer, von Ende zu Ende. */
    private double[][] arc(double dmax) {
        int n = ufer.size();
        double[][] p = new double[n][];
        for (int i = 0; i < n; i++) {
            double u = i / (double) (n - 1), dd = dmax * Math.pow(Math.sin(Math.PI * u), 0.6);
            p[i] = off(i, dd);
        }
        // glätten: der Versatz folgt sonst jeder Bucht des Ufers
        double[][] q = new double[n][];
        for (int i = 0; i < n; i++) {
            double sx = 0, sz = 0;
            int c = 0;
            for (int j = Math.max(0, i - 6); j <= Math.min(n - 1, i + 6); j++) { sx += p[j][0]; sz += p[j][1]; c++; }
            q[i] = i == 0 || i == n - 1 ? p[i] : new double[]{sx / c, sz / c};
        }
        return q;
    }

    /** Fläche zwischen Ufer und Bogen (m², Gauß). */
    private double area(double[][] arc) {
        List<double[]> poly = new ArrayList<>();
        for (double[] p : ufer) poly.add(new double[]{p[0], p[1]});
        for (int i = arc.length - 1; i >= 0; i--) poly.add(arc[i]);
        double s = 0;
        for (int i = 0; i < poly.size(); i++) {
            double[] a = poly.get(i), b = poly.get((i + 1) % poly.size());
            s += a[0] * b[1] - b[0] * a[1];
        }
        return Math.abs(s) / 2;
    }

    // ------------------------------------------------------------------ Uferbefestigung

    /** Bohlenwand an der Wasserlinie, wo keine Plattform steht und kein Strand ist (z 132 … Südende, −210 … Nordende). */
    private void befestigung(Siedlung s, Structures.Ground g) {
        double[][] spans = {{ufer.get(0)[1] - 8, 136}, {-214, ufer.get(ufer.size() - 1)[1] + 8}};
        for (double[] sp : spans) {
            int a = idx(sp[0]), b = idx(sp[1]);
            if (Math.abs(a - b) < 2) continue;
            List<double[]> line = new ArrayList<>();
            // Land zur Linken: von Süden nach Norden laufen (Wasser im Osten liegt rechts)
            for (int i = Math.min(a, b); i <= Math.max(a, b); i++) line.add(off(i, -0.4));
            double[][] l = line.toArray(new double[0][]);
            befestigung.add(l);
            s.bauwerke.revetment(l, 0.7, g, 9600 + befestigung.size());
        }
    }

    // ------------------------------------------------------------------ Waren

    /** Waren in Gruppen auf Plattform und Umschlagplatz: Fässer, Ballen, Mühlsteine (gestapelt und gelehnt), Töpfe [G]. */
    private void waren(Siedlung s) {
        SplittableRandom r = new SplittableRandom(950_88L);
        List<double[]> spots = new ArrayList<>();
        for (double[][] l : plattformen)
            for (int i = 2; i < l.length - 2; i += 5) {
                int ui = idxXZ(l[i][0], l[i][1]);
                double[] p = ufer.get(ui);
                if (r.nextDouble() < 0.85) spots.add(new double[]{l[i][0] + p[2] * (r.nextDouble() * 4 - 1), l[i][1] + p[3] * (r.nextDouble() * 4 - 1), Math.toDegrees(Math.atan2(p[2], -p[3]))});
            }
        if (umschlag != null)
            for (int i = 1; i < umschlag.length - 1; i += 2) {
                double[] p = ufer.get(idxXZ(umschlag[i][0], umschlag[i][1]));
                for (int k = 0; k < 2; k++) spots.add(new double[]{umschlag[i][0] + p[2] * (r.nextDouble() * 12 - 6), umschlag[i][1] + p[3] * (r.nextDouble() * 12 - 6), Math.toDegrees(Math.atan2(p[2], -p[3]))});
            }
        for (double[] sp : spots) {
            // nicht auf den Wurzeln der Brücken (dort wird gegangen)
            boolean onPath = false;
            for (Bruecke b : bruecken) if (Math.hypot(b.x0() - sp[0], b.z0() - sp[1]) < 4) onPath = true;
            if (onPath) continue;
            Mesh m = new Mesh();
            int kind = r.nextInt(4);
            double y = DECK + 0.035, hd = sp[2] + (r.nextDouble() - 0.5) * 40, a = Math.toRadians(hd);
            double ax = Math.sin(a), az = -Math.cos(a), bx = Math.cos(a), bz = Math.sin(a);
            switch (kind) {
                case 0 -> {
                    int n = 3 + r.nextInt(6);
                    for (int k = 0; k < n; k++) Wharf.barrel(m, sp[0] + ax * (k % 3) * 0.72 + bx * (k / 3) * 0.72, y, sp[1] + az * (k % 3) * 0.72 + bz * (k / 3) * 0.72, 0.31, 0.86);
                    waren[0] += n;
                }
                case 1 -> {
                    int n = 2 + r.nextInt(5);
                    for (int k = 0; k < n; k++) {
                        int lay = k / 3;
                        Wharf.bale(m, sp[0] + bx * (k % 3) * 0.85, y + lay * 0.58, sp[1] + bz * (k % 3) * 0.85, hd + (r.nextDouble() - 0.5) * 10, 1.2, 0.8, 0.56);
                    }
                    waren[1] += n;
                }
                case 2 -> {
                    int n = 2 + r.nextInt(4);
                    for (int k = 0; k < n; k++) Wharf.millstone(m, sp[0] + (r.nextDouble() - 0.5) * 0.06, y + k * 0.19, sp[1] + (r.nextDouble() - 0.5) * 0.06, 0.48 + r.nextDouble() * 0.06, 0.18, 0, hd);
                    // einer lehnt am Stapel
                    Wharf.millstone(m, sp[0] + bx * 0.62, y, sp[1] + bz * 0.62, 0.5, 0.18, 72, hd + 90);
                    waren[2] += n + 1;
                }
                default -> {
                    int n = 4 + r.nextInt(7);
                    for (int k = 0; k < n; k++) Wharf.pot(m, sp[0] + ax * (k % 4) * 0.48 + bx * (k / 4) * 0.48, y, sp[1] + az * (k % 4) * 0.48 + bz * (k / 4) * 0.48, 0.2 + r.nextDouble() * 0.05, 0.28 + r.nextDouble() * 0.06);
                    waren[3] += n;
                }
            }
            s.bauwerke.mesh(sp[0], sp[1], 3, m, m);
        }
    }

    private int idxXZ(double x, double z) {
        int best = 0;
        double bd = 1e18;
        for (int i = 0; i < ufer.size(); i++) { double d = Math.hypot(ufer.get(i)[0] - x, ufer.get(i)[1] - z); if (d < bd) { bd = d; best = i; } }
        return best;
    }

    // ------------------------------------------------------------------ Brandungsring

    /** Abstandsraster aller Pfähle im Wasser für {@code com.dan.ocean} (0,5 m, bis 6 m Abstand). */
    private void feld() {
        if (pfaehle.isEmpty()) return;
        double x0 = 1e9, z0 = 1e9, x1 = -1e9, z1 = -1e9;
        for (double[] p : pfaehle) { x0 = Math.min(x0, p[0]); z0 = Math.min(z0, p[1]); x1 = Math.max(x1, p[0]); z1 = Math.max(z1, p[1]); }
        x0 -= 8; z0 -= 8; x1 += 8; z1 += 8;
        feld = ObstacleField.of(pfaehle, x0, z0, x1 - x0, z1 - z0, 0.5, 6);
    }

    /** „Hafen 10,0 ha · Plattform 290 m · 9 Landebrücken (63–72 m) · Palisade 720 m, Durchfahrt 14 m · 1 830 Pfähle im Wasser · Waren …“ */
    public String describe() {
        double plat = 0, pal = 0, minL = 1e9, maxL = 0;
        for (double[][] l : plattformen) plat += Structures.length(l);
        for (double[][] l : palisade) pal += Structures.length(l);
        for (Bruecke b : bruecken) { minL = Math.min(minL, b.length()); maxL = Math.max(maxL, b.length()); }
        return String.format(Locale.GERMAN, "Hafen %.1f ha · Plattform %.0f m · %d Landebrücken (%.0f–%.0f m) · Palisade %.0f m, Durchfahrt %.0f m · %,d Pfähle im Wasser · Waren: %d Fässer, %d Ballen, %d Mühlsteine, %d Töpfe",
                flaecheHa, plat, bruecken.size(), minL, maxL, pal, DURCHFAHRT, pfaehle.size(), waren[0], waren[1], waren[2], waren[3]);
    }
}
