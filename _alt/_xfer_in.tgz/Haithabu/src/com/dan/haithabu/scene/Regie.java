package com.dan.haithabu.scene;

import com.dan.weather.Scenario;
import com.dan.weather.Weather;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/**
 * Phase 15: Regiebücher und Tagesregie (F13 A). Seit Phase 16 sind Regiebücher Text (F31 A): die drei mitgelieferten
 * stehen in {@code regie/*.txt} neben dieser Klasse und als Startdaten in HB_REGIEBUCH und HB_STICHWORT, eigene
 * speichert die App in der Datenbank oder in daten/regiebuecher ({@link #parse}). Ein Regiebuch ist eine Folge von
 * Stichworten in echten Sekunden seit dem Start: Datum und Uhrzeit, Zeitraffer, Wetter, Ansichten und Fahrten, Schiffe, der Brander, Fotos für eine
 * Bildfolge. Was ein Stichwort tut, führt die App über {@link Ctx} aus; so läuft dasselbe Regiebuch auch ohne Bild
 * (Prüfung).
 * <ul>
 * <li><b>Ein Handelstag</b> (16.10.950, 6 bis 20 Uhr, Zeitraffer 60): Herde am Morgen, die Knorr läuft ein, Markt,
 * Werkstätten, am Nachmittag läuft sie wieder aus, Fackeln am Abend, zuletzt im Versammlungshaus. 14 Minuten.</li>
 * <li><b>Ein Nebelmorgen</b> (16.10.950, 5 bis 10 Uhr, Zeitraffer 60): Nebel über dem Noor, die Hochburg ragt heraus,
 * der Nebel hebt sich, die Knorr kommt aus dem Dunst. Fünf Minuten.</li>
 * <li><b>Die Nacht von 1050</b> (16.10.1050, ab 1:30 Uhr, wie die Uhr läuft): Ostwind Bft 4, ein Langschiff als Brander
 * wird vor die Palisade gerudert, die Mannschaft verlässt es in der Durchfahrt, es treibt brennend in den Hafen, das
 * Feuer springt auf die Häuser am Ufer und mit dem Wind in die Siedlung. Sechs Minuten, fünf Bilder.</li>
 * </ul>
 * <b>Tagesregie</b> ({@link #tagesregie}): in der freien Regie läuft die Knorr um 15:30 aus und am nächsten Morgen um
 * 8 Uhr wieder ein. Herde, Rauch, Markt, Fackeln und das Licht in den Türen folgen schon der Uhr (Phasen 10 bis 14).
 * <p>
 * Belegt: der Überfall Harald Hardradas 1050, Brander im Hafen (Haithabu 1). Gestaltet [G]: Abläufe, Zeiten,
 * Blickpunkte.
 */
public final class Regie {

    /** Was ein Regiebuch braucht; die App führt es aus (ohne Bild: die Prüfung). */
    public interface Ctx {
        void time(LocalDate date, double hour);
        void lapse(double x);
        void weather(Scenario s);
        /** Freie Regie ab einer Lage, dazu Wind von Hand (Bft, woher), NaN = von der Regie. */
        void weatherFree(Weather.Phase p, double bft, double fromDeg);
        void view(String name);
        void fahrt(String name);
        void einlaufen();
        void auslaufen();
        void brander();
        /** Das Feuer springt vom Brander ans Ufer: die drei nächsten Häuser fangen Feuer. */
        void igniteNearBrander();
        void capture(String caption);
        void sheet(String name);
        void say(String text);
    }

    /** Ein Stichwort: Sekunde (echte Zeit seit dem Start), Text, Handlung. */
    public record Cue(double t, String text, Consumer<Ctx> action) { }

    /**
     * Ein Regiebuch: Name, Beschreibung, Länge (s), Stichworte (nach der Zeit geordnet); seit Phase 16 dazu der Text, aus
     * dem es gelesen ist, die Stichworte als Zeilen und der Wetterverlauf (oder null).
     */
    public record Book(String name, String about, double length, List<Cue> cues, String text, List<Zeile> zeilen, Scenario weather) {
        @Override public String toString() { return name; }
    }

    // ------------------------------------------------------------------ Ablauf

    private volatile Book book;
    private double t;
    private int next;
    private volatile String status = "";
    private int fired;

    /** Regiebuch beginnen (das erste Stichwort sofort). */
    public void start(Book b, Ctx c) {
        book = b;
        t = 0;
        next = 0;
        fired = 0;
        status = b.name() + " beginnt";
        step(0, c);
    }

    /**
     * Phase 16 (F33): ein Regiebuch an der Stelle t (s) fortsetzen, ohne die Stichworte davor noch einmal auszuführen;
     * Uhr, Wetter, Schiffe und Brand bringt „Weiter wie zuletzt“ selbst mit.
     */
    public void fortsetzen(Book b, double t0) {
        book = b;
        t = Math.max(0, t0);
        next = 0;
        fired = 0;
        while (next < b.cues().size() && b.cues().get(next).t() <= t) { next++; fired++; }
        status = b.name() + " geht weiter";
    }

    public void stop() {
        Book b = book;
        book = null;
        if (b != null) status = b.name() + " angehalten";
    }

    public boolean running() { return book != null; }

    public Book book() { return book; }

    public double time() { return t; }

    /** Wie viele Stichworte schon ausgeführt sind. */
    public int fired() { return fired; }

    /** Um dt echte Sekunden weiter, fällige Stichworte ausführen. */
    public void step(double dt, Ctx c) {
        Book b = book;
        if (b == null) return;
        t += Math.max(0, dt);
        while (next < b.cues().size() && b.cues().get(next).t() <= t) {
            Cue q = b.cues().get(next++);
            if (!q.text().isEmpty()) status = String.format(Locale.GERMAN, "%s · %s", b.name(), q.text());
            try { q.action().accept(c); } catch (RuntimeException e) { status = b.name() + " · Fehler bei „" + q.text() + "“: " + e.getMessage(); }
            fired++;
        }
        if (t >= b.length() && next >= b.cues().size()) {
            book = null;
            status = b.name() + " ist zu Ende (" + fired + " Stichworte)";
        }
    }

    /** „Ein Handelstag · Die Knorr läuft ein · 2:10 von 14:00“ */
    public String describe() {
        Book b = book;
        if (b == null) return status.isEmpty() ? "kein Regiebuch" : status;
        return String.format(Locale.GERMAN, "%s · %d:%02d von %d:%02d", status, (int) t / 60, (int) t % 60, (int) b.length() / 60, (int) b.length() % 60);
    }

    // ------------------------------------------------------------------ Tagesregie

    /** Tagesregie: Uhrzeit vorher und jetzt (Stunden); die Knorr läuft um 15:30 aus und um 8 Uhr ein. */
    public static void tagesregie(double before, double now, Flotte fl, Ctx c) {
        if (fl == null || now < before || now - before > 2) return;
        if (before < 15.5 && now >= 15.5 && !fl.knorrAway && !fl.arriving()) c.auslaufen();
        if (before < 8 && now >= 8 && fl.knorrAway && !fl.leaving()) c.einlaufen();
    }

    // ------------------------------------------------------------------ die Regiebücher (Phase 16: als Text, F31 A)

    /** Die drei mitgelieferten Regiebücher aus den Textdateien neben dieser Klasse (regie/*.txt). */
    public static final String[] DATEIEN = {"handelstag.txt", "nebelmorgen.txt", "nacht1050.txt"};

    public static List<Book> all() { return List.of(handelstag(), nebelmorgen(), nacht1050()); }

    public static Book byName(String n) {
        for (Book b : all()) if (b.name().equals(n)) return b;
        return null;
    }

    /** Ein Handelstag: 6 bis 20 Uhr im Zeitraffer 60 (eine Stunde je Minute). */
    public static Book handelstag() { return mitgeliefert(DATEIEN[0]); }

    /** Ein Nebelmorgen: 5 bis 10 Uhr im Zeitraffer 60. */
    public static Book nebelmorgen() { return mitgeliefert(DATEIEN[1]); }

    /** Die Nacht von 1050: wie die Uhr läuft, sechs Minuten. */
    public static Book nacht1050() { return mitgeliefert(DATEIEN[2]); }

    /** Der Text eines mitgelieferten Regiebuchs. */
    public static String text(String datei) {
        try (java.io.InputStream in = Regie.class.getResourceAsStream("regie/" + datei)) {
            if (in == null) throw new IllegalStateException("Regiebuch regie/" + datei + " fehlt im Build");
            return new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        } catch (java.io.IOException e) {
            throw new IllegalStateException("Regiebuch regie/" + datei + " nicht lesbar: " + e.getMessage(), e);
        }
    }

    private static Book mitgeliefert(String datei) { return parse(text(datei)); }

    /** Die Befehle der Stichworte (wie HB_STICHWORT.BEFEHL, klein geschrieben im Text). */
    public static final List<String> BEFEHLE = List.of("zeit", "raffer", "wetter", "wetter_frei", "ansicht", "fahrt", "einlaufen", "auslaufen", "brander",
            "zuenden", "foto", "blatt", "sage");

    /** Ein Stichwort, wie es im Text und in der Datenbank steht: Sekunde, Befehl, Argumente, Text fürs HUD. */
    public record Zeile(double sekunde, String befehl, String argumente, String text) { }

    /**
     * Liest ein Regiebuch aus Text (F31 A). Kopfzeilen: {@code Regiebuch:}, {@code Beschreibung:}, {@code Länge:}
     * (m:ss), {@code Wetter: hh:mm | Zeitraffer} mit folgenden {@code Schritt:}-Zeilen im Format von
     * {@link Scenario#parse}. Dann je Zeile ein Stichwort: {@code m:ss befehl argumente | Text}. Zeilen zur selben Zeit
     * ohne Text gehören zum Stichwort davor. Fehler nennen die Zeile.
     */
    public static Book parse(String text) {
        String name = null, about = "";
        double length = Double.NaN;
        String wetterKopf = null;
        StringBuilder steps = new StringBuilder();
        List<Zeile> zeilen = new ArrayList<>();
        int no = 0;
        for (String raw : text.split("\\R")) {
            no++;
            String line = raw.strip();
            if (line.isEmpty() || line.startsWith("#")) continue;
            String low = line.toLowerCase(Locale.ROOT);
            try {
                if (low.startsWith("regiebuch:")) name = line.substring(10).strip();
                else if (low.startsWith("beschreibung:")) about = line.substring(13).strip();
                else if (low.startsWith("länge:")) length = sekunden(line.substring(6).strip());
                else if (low.startsWith("wetter:")) wetterKopf = line.substring(7).strip();
                else if (low.startsWith("schritt:")) steps.append(line).append('\n');
                else zeilen.add(zeile(line));
            } catch (RuntimeException e) {
                throw new IllegalArgumentException("Zeile " + no + ": " + e.getMessage() + " („" + line + "“)");
            }
        }
        if (name == null || name.isEmpty()) throw new IllegalArgumentException("Es fehlt die Zeile „Regiebuch: Name“");
        if (zeilen.isEmpty()) throw new IllegalArgumentException("Das Regiebuch hat keine Stichworte");
        Scenario sc = null;
        if (wetterKopf != null) {
            String[] w = wetterKopf.split("\\|");
            String beginn = w[0].strip(), raffer = w.length > 1 ? w[1].strip() : "1";
            sc = Scenario.parse("Szenario: " + name + "\nBeginn: " + beginn + "\nZeitraffer: " + raffer + "\n" + steps);
        } else if (steps.length() > 0) throw new IllegalArgumentException("Schritte ohne Zeile „Wetter: hh:mm | Zeitraffer“");
        zeilen.sort(java.util.Comparator.comparingDouble(Zeile::sekunde));
        List<Cue> cues = new ArrayList<>();
        for (int i = 0; i < zeilen.size(); ) {
            Zeile z = zeilen.get(i);
            List<Zeile> grp = new ArrayList<>(List.of(z));
            int k = i + 1;
            while (k < zeilen.size() && zeilen.get(k).sekunde() == z.sekunde() && zeilen.get(k).text().isEmpty()) grp.add(zeilen.get(k++));
            final Scenario wsc = sc;
            List<Consumer<Ctx>> acts = new ArrayList<>();
            for (Zeile g : grp) acts.add(handlung(g, wsc, name));
            cues.add(new Cue(z.sekunde(), z.text(), x -> { for (Consumer<Ctx> a : acts) a.accept(x); }));
            i = k;
        }
        if (Double.isNaN(length)) length = cues.get(cues.size() - 1).t() + 1;
        return new Book(name, about, length, cues, text, zeilen, sc);
    }

    /** „1:48“, „0:04“, „96“ oder „1:36.5“ → Sekunden. */
    static double sekunden(String s) {
        int c = s.indexOf(':');
        if (c < 0) return Double.parseDouble(s);
        return Integer.parseInt(s.substring(0, c)) * 60 + Double.parseDouble(s.substring(c + 1));
    }

    /** Sekunden → „m:ss“ (mit Zehnteln, wenn nötig). */
    public static String zeit(double s) {
        int m = (int) (s / 60);
        double r = s - m * 60;
        return Math.abs(r - Math.rint(r)) < 1e-6 ? String.format(Locale.ROOT, "%d:%02d", m, (int) Math.rint(r)) : String.format(Locale.ROOT, "%d:%04.1f", m, r);
    }

    static Zeile zeile(String line) {
        String cmd = line, txt = "";
        int bar = line.indexOf(" | ");
        if (bar >= 0) { cmd = line.substring(0, bar).strip(); txt = line.substring(bar + 3).strip(); }
        String[] p = cmd.split("\\s+", 3);
        if (p.length < 2) throw new IllegalArgumentException("Zeit und Befehl erwartet");
        double t = sekunden(p[0]);
        String b = p[1].toLowerCase(Locale.ROOT);
        if (!BEFEHLE.contains(b)) throw new IllegalArgumentException("unbekannter Befehl „" + p[1] + "“, bekannt sind " + String.join(", ", BEFEHLE));
        return new Zeile(t, b, p.length > 2 ? p[2].strip() : "", txt);
    }

    /** Was ein Befehl tut; prüft die Argumente schon beim Lesen. */
    static Consumer<Ctx> handlung(Zeile z, Scenario sc, String buch) {
        String a = z.argumente();
        switch (z.befehl()) {
            case "zeit": {
                String[] p = a.split("\\s+");
                if (p.length != 2) throw new IllegalArgumentException("zeit TT.MM.JJJJ hh:mm erwartet");
                String[] d = p[0].split("\\.");
                LocalDate date = LocalDate.of(Integer.parseInt(d[2]), Integer.parseInt(d[1]), Integer.parseInt(d[0]));
                double h = sekunden(p[1]) / 60;
                return x -> x.time(date, h);
            }
            case "raffer": { double v = Double.parseDouble(a); return x -> x.lapse(v); }
            case "wetter": {
                if (sc == null) throw new IllegalArgumentException("wetter ohne Zeile „Wetter:“ im Kopf");
                return x -> x.weather(sc);
            }
            case "wetter_frei": {
                String[] p = a.split("\\s+");
                Weather.Phase ph = Weather.Phase.valueOf(p[0].toUpperCase(Locale.ROOT));
                double bft = p.length > 1 && !p[1].equals("-") ? Double.parseDouble(p[1]) : Double.NaN;
                double deg = p.length > 2 && !p[2].equals("-") ? Double.parseDouble(p[2]) : Double.NaN;
                return x -> x.weatherFree(ph, bft, deg);
            }
            case "ansicht": { need(a, "ansicht Name"); return x -> x.view(a); }
            case "fahrt": { need(a, "fahrt Name"); return x -> x.fahrt(a); }
            case "einlaufen": return Ctx::einlaufen;
            case "auslaufen": return Ctx::auslaufen;
            case "brander": return Ctx::brander;
            case "zuenden": return Ctx::igniteNearBrander;
            case "foto": { need(a, "foto Unterschrift"); return x -> x.capture(a); }
            case "blatt": { String n = a.isEmpty() ? buch : a; return x -> x.sheet(n); }
            case "sage": { need(a, "sage Text"); return x -> x.say(a); }
            default: throw new IllegalArgumentException(z.befehl());
        }
    }

    private static void need(String a, String form) { if (a.isEmpty()) throw new IllegalArgumentException(form + " erwartet"); }

    /** Ein Regiebuch als Text aus Kopf, Wetter und Stichworten (für die Datenbank: HB_REGIEBUCH und HB_STICHWORT). */
    public static String toText(String name, String about, double length, String wetter, List<Zeile> zeilen) {
        StringBuilder b = new StringBuilder();
        b.append("Regiebuch: ").append(name).append('\n');
        if (about != null && !about.isEmpty()) b.append("Beschreibung: ").append(about).append('\n');
        b.append("Länge: ").append(zeit(length)).append('\n');
        if (wetter != null && !wetter.isBlank()) b.append(wetter.strip()).append('\n');
        for (Zeile z : zeilen)
            b.append(zeit(z.sekunde())).append(' ').append(z.befehl()).append(z.argumente().isEmpty() ? "" : " " + z.argumente())
                    .append(z.text().isEmpty() ? "" : " | " + z.text()).append('\n');
        return b.toString();
    }

    /** Der Wetterblock eines Texts („Wetter:“ und „Schritt:“-Zeilen) oder null. */
    public static String wetterBlock(String text) {
        StringBuilder b = new StringBuilder();
        for (String raw : text.split("\\R")) {
            String l = raw.strip().toLowerCase(Locale.ROOT);
            if (l.startsWith("wetter:") || l.startsWith("schritt:")) b.append(raw.strip()).append('\n');
        }
        return b.length() == 0 ? null : b.toString();
    }
}
