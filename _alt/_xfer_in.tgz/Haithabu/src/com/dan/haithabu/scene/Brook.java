package com.dan.haithabu.scene;

import com.dan.river.FlowField;
import com.dan.river.RiverPath;

/**
 * Der Haithabu-Bach als Fluss aus {@code com.dan.river} (Phase 2): Lauf, Spiegel und Breite aus dem Gelände
 * ({@link Terrain#brook}), Strömung nach Manning aus Tiefe und Gefälle, in den Kurven außen schneller. Für die
 * Grafikkarte wird die Strömung einmal auf ein Raster zu 1 m um den Lauf gelegt (Geschwindigkeit, Tiefe, Schaum); das
 * Gelände zeichnet damit das Wasser im Bachbett mit Mustern, die mit dem Wasser treiben (zwei Phasen, Flow-Map).
 */
public final class Brook {
    public static final double CELL = 1.0;
    public final FlowField flow;
    /** Raster: Nordwestecke, Zellen in x und z, je Zelle vx, vz, Tiefe, Schaum. */
    public final double x0, z0;
    public final int nx, nz;
    public final float[] data;
    /** Länge (m), mittlere Geschwindigkeit in der Mitte (m/s). */
    public final double length, meanSpeed;

    private Brook(FlowField f, double x0, double z0, int nx, int nz, float[] data, double length, double meanSpeed) {
        this.flow = f;
        this.x0 = x0;
        this.z0 = z0;
        this.nx = nx;
        this.nz = nz;
        this.data = data;
        this.length = length;
        this.meanSpeed = meanSpeed;
    }

    /** Aus dem Lauf im Gelände; null, wenn es keinen gibt. */
    public static Brook of(Terrain t) {
        if (t.brook.length < 3) return null;
        double[][] nodes = new double[t.brook.length][];
        double minX = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, minZ = Double.MAX_VALUE, maxZ = -Double.MAX_VALUE;
        for (int i = 0; i < t.brook.length; i++) {
            double[] p = t.brook[i];
            nodes[i] = new double[]{p[0], p[1], p[3], p[4]};
            minX = Math.min(minX, p[0]); maxX = Math.max(maxX, p[0]); minZ = Math.min(minZ, p[1]); maxZ = Math.max(maxZ, p[1]);
        }
        RiverPath path = new RiverPath(nodes, 2.0, 6);
        FlowField f = new FlowField(path);
        f.depth = 0.8f;
        f.manning = 0.06f;   // Grasufer und Kraut im Bett bremsen
        f.discharge = 1;
        double m = 6;
        double x0 = Math.floor(minX - m), z0 = Math.floor(minZ - m);
        int nx = (int) Math.ceil((maxX + m - x0) / CELL), nz = (int) Math.ceil((maxZ + m - z0) / CELL);
        float[] d = new float[nx * nz * 4];
        FlowField.Flow fl = new FlowField.Flow();
        double sum = 0;
        int cnt = 0;
        for (int j = 0; j < nz; j++)
            for (int i = 0; i < nx; i++) {
                double x = x0 + (i + 0.5) * CELL, z = z0 + (j + 0.5) * CELL;
                if (!f.sample(x, z, fl) || !fl.wet) continue;
                int k = (j * nx + i) * 4;
                d[k] = fl.vx;
                d[k + 1] = fl.vz;
                d[k + 2] = Math.max(0.03f, fl.depth);
                d[k + 3] = Math.min(1, fl.foam + 0.3f * fl.turb);
                if (Math.abs(fl.u) < 0.3) { sum += fl.speed; cnt++; }
            }
        return new Brook(f, x0, z0, nx, nz, d, path.length, cnt == 0 ? 0 : sum / cnt);
    }

    /** „Bach 990 m, 0,4 m/s in der Mitte“ */
    public String describe() {
        return String.format(java.util.Locale.GERMAN, "Bach %.0f m, %.2f m/s in der Mitte (com.dan.river)", length, meanSpeed);
    }
}
