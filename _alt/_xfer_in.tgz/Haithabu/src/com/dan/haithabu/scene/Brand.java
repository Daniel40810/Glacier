package com.dan.haithabu.scene;

import com.dan.hearth.Blaze;
import com.dan.hearth.Fire;
import com.dan.hearth.Flame;
import com.dan.longship.Longship;
import com.dan.smoke.Source;
import com.dan.timber.House;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Phase 15: der Brand der Nacht von 1050 (F13 A). Harald Hardradas Leute schicken einen Brander in den Hafen; das
 * Feuer springt auf die Häuser am Ufer über und frisst sich mit dem Wind in die Siedlung.
 * <p>
 * Der Brand der Häuser ist {@link Blaze} aus {@code com.dan.hearth}: die 140 Häuser, die dem Hafen am nächsten
 * stehen, mit Dach, Wänden und Gerüst, Wärmestrahlung und Flugfeuer nach Lee. Er läuft {@link #speed} mal so schnell
 * wie die Szene, damit die Nacht in wenigen Minuten zu sehen ist (ein Haus brennt sonst eine Viertelstunde, bis das
 * Dach fällt; so gut drei Minuten). Der Brander selbst brennt mit acht Flammen längs des Rumpfs. Er zündet ein Haus, sobald er ihm auf
 * 16 m nahekommt; hängt er an einer Brücke fest, springen nach 20 s die Funken auf das nächste Haus in 50 m.
 * <p>
 * Was die Grafik und der Klang daraus nehmen: {@link #flames}, {@link #lights}, {@link #sources}, {@link #burnOf}
 * (für {@code Timber.burn}), {@link #onCollapse}. Belegt: der Brander (Haithabu 1), der Brand von 1050. Gestaltet
 * [G]: welches Haus zuerst brennt, wie schnell.
 */
public final class Brand {
    public final Blaze blaze;
    public final List<House> houses = new ArrayList<>();
    private final Map<House, Integer> index = new HashMap<>();
    private final Flotte flotte;
    /** So viel schneller als die Szene läuft der Brand der Häuser. */
    public volatile double speed = 5;
    /** Ein Dach stürzt ein: Haus, Ort (für den Klang). */
    @FunctionalInterface public interface Collapse { void at(House h, double x, double y, double z); }
    public volatile Collapse onCollapse;
    private double time, stuckFor;
    private int firstHouse = -1;
    /** Wann (Szenensekunden seit dem Start) das erste Haus Feuer fing; NaN = noch keins. */
    public volatile double firstIgnition = Double.NaN;

    private Brand(Siedlung s, Flotte fl, long seed) {
        this.flotte = fl;
        double cx = 0, cz = -60;
        if (fl != null) { cx = fl.lucke[0]; cz = fl.lucke[1]; }
        List<House> all = new ArrayList<>(s.houses);
        final double fx = cx, fz = cz;
        all.sort((a, b) -> Double.compare(Math.hypot(a.x() - fx, a.z() - fz), Math.hypot(b.x() - fx, b.z() - fz)));
        List<Blaze.Building> bs = new ArrayList<>();
        for (House h : all) {
            if (houses.size() >= 140) break;
            var t = h.type();
            index.put(h, houses.size());
            houses.add(h);
            bs.add(new Blaze.Building(h.x(), h.y(), h.z(), h.headingDeg(), t.length * h.lengthScale() / 2, t.width * h.widthScale() / 2,
                    Math.max(0.6, t.eaveY()), t.ridgeY(), true));
        }
        blaze = new Blaze(bs, seed);
        blaze.onCollapse = (i, tm) -> {
            Collapse c = onCollapse;
            if (c != null) {
                Blaze.Building b = blaze.building(i);
                c.at(houses.get(i), b.x(), b.y() + 2, b.z());
            }
        };
    }

    /** Ein Brand über den Häusern am Hafen (noch brennt nichts; der Brander zündet). */
    public static Brand of(Siedlung s, Flotte fl, long seed) { return new Brand(s, fl, seed); }

    /** Um dt Szenensekunden weiter: der Brander zündet, der Brand breitet sich mit dem Wind aus. */
    public void step(double dt, double windFromDeg, double windSpeed, double wetness) {
        if (dt <= 0) return;
        time += dt;
        blaze.windFromDeg = windFromDeg;
        blaze.windSpeed = windSpeed;
        blaze.wetness = wetness;
        Flotte fl = flotte;
        if (fl != null && fl.branderOn) {
            Longship b = fl.brander;
            double best = 1e9;
            int bi = -1;
            for (int i = 0; i < houses.size(); i++) {
                if (blaze.phase(i) != Blaze.Phase.INTAKT) continue;
                House h = houses.get(i);
                double d = Math.hypot(h.x() - b.x, h.z() - b.z) - b.hull.halfLength * 0.6;
                if (d < best) { best = d; bi = i; }
            }
            if (bi >= 0 && best < 16) ignite(bi);
            if (fl.branderAground) stuckFor += dt; else stuckFor = 0;
            if (stuckFor > 20 && Double.isNaN(firstIgnition) && bi >= 0 && best < 50) ignite(bi);
        }
        // die Häuser in Stücken (der Brand braucht kleine Schritte)
        double left = dt * speed;
        while (left > 1e-9) {
            double h = Math.min(0.5, left);
            blaze.step(h);
            left -= h;
        }
    }

    /**
     * Phase 16 (F33 A): der Zustand des Brands als Text für „Weiter wie zuletzt“: Zeit, Erstzündung und der Zustand
     * von {@link Blaze}. Die Häuser kommen aus derselben Siedlung in derselben Reihenfolge.
     */
    public String state() {
        return time + " " + stuckFor + " " + firstIgnition + " " + firstHouse + " # " + blaze.state();
    }

    /** Stellt einen Zustand aus {@link #state} her. */
    public void setState(String text) {
        int k = text.indexOf(" # ");
        String[] h = text.substring(0, k).trim().split(" ");
        time = Double.parseDouble(h[0]);
        stuckFor = Double.parseDouble(h[1]);
        firstIgnition = Double.parseDouble(h[2]);
        firstHouse = Integer.parseInt(h[3]);
        blaze.setState(text.substring(k + 3));
    }

    /** Haus i zünden (Regiebuch oder Brander). */
    public void ignite(int i) {
        if (i < 0 || i >= houses.size()) return;
        if (blaze.phase(i) != Blaze.Phase.INTAKT) return;
        blaze.ignite(i);
        if (Double.isNaN(firstIgnition)) { firstIgnition = time; firstHouse = i; }
    }

    /** Das Feuer springt über: die n Häuser, die dem Ort am nächsten stehen, fangen Feuer. */
    public void igniteNear(double x, double z, int n) {
        List<Integer> idx = new ArrayList<>();
        for (int i = 0; i < houses.size(); i++) idx.add(i);
        idx.sort((a, b) -> Double.compare(Math.hypot(houses.get(a).x() - x, houses.get(a).z() - z), Math.hypot(houses.get(b).x() - x, houses.get(b).z() - z)));
        for (int k = 0; k < Math.min(n, idx.size()); k++) ignite(idx.get(k));
    }

    /** Das Haus am Ufer, das dem Ort am nächsten steht (Index), oder −1. */
    public int nearest(double x, double z) {
        int bi = -1;
        double best = 1e18;
        for (int i = 0; i < houses.size(); i++) {
            double d = Math.hypot(houses.get(i).x() - x, houses.get(i).z() - z);
            if (d < best) { best = d; bi = i; }
        }
        return bi;
    }

    /** Für {@code Timber.burn}: 0 heil, bis 1 verkohlt, über 1 eingestürzt. */
    public double burnOf(House h) {
        Integer i = index.get(h);
        if (i == null) return 0;
        Blaze.Phase p = blaze.phase(i);
        if (p == Blaze.Phase.INTAKT) return 0;
        if (blaze.collapsed(i)) return 1 + Math.min(1, blaze.char_(i));
        return Math.min(1, Math.max(blaze.char_(i), 0.8 * (1 - blaze.roofLeft(i))));
    }

    /** Wie viele Häuser brennen, wie viele sind eingestürzt. */
    public int burning() { int n = 0; for (int i = 0; i < houses.size(); i++) if (blaze.hrr(i) > 50) n++; return n; }
    public int collapsed() { int n = 0; for (int i = 0; i < houses.size(); i++) if (blaze.collapsed(i)) n++; return n; }
    public int touched() { int n = 0; for (int i = 0; i < houses.size(); i++) if (blaze.phase(i) != Blaze.Phase.INTAKT) n++; return n; }

    /** Wärmefreisetzung von Haus i (kW). */
    public double hrr(int i) { return blaze.hrr(i); }

    /** Das Auge (je Bild von der App), für die Auswahl der Flammen. */
    public volatile double[] eye = {0, 0, 0};
    /** Höchstens so viele brennende Häuser bekommen Flammen (die nächsten am Auge); die übrigen leuchten und rauchen nur. */
    public static final int FLAME_HOUSES = 24;

    /** Flammen der brennenden Häuser (die nächsten {@link #FLAME_HOUSES} am Auge) und des Branders. */
    public List<Flame> flames() {
        List<Flame> l = new ArrayList<>();
        double[] e = eye;
        List<Integer> on = new ArrayList<>();
        for (int i = 0; i < houses.size(); i++) if (blaze.hrr(i) > 1) on.add(i);
        if (on.size() > FLAME_HOUSES)
            on.sort((a, b) -> Double.compare(Math.hypot(houses.get(a).x() - e[0], houses.get(a).z() - e[2]), Math.hypot(houses.get(b).x() - e[0], houses.get(b).z() - e[2])));
        for (int k = 0; k < Math.min(FLAME_HOUSES, on.size()); k++) l.addAll(blaze.flames(on.get(k)));
        Flotte fl = flotte;
        if (fl != null && fl.branderOn) {
            Longship b = fl.brander;
            for (int k = 0; k < 8; k++) {
                double s = (-0.8 + 1.6 * k / 7) * b.hull.halfLength;
                double[] p = b.toWorld(s, 0, b.type.freeboard * 0.6);
                double hgt = 3.5 + 2.5 * Math.sin(Math.PI * (k + 0.5) / 8);
                l.add(new Flame(p[0], p[1], p[2], 2.2, hgt, 1, 7001 + k * 17, Flame.BLAZE));
            }
        }
        return l;
    }

    /** Lichter {x, y, z, Größe, R, G, B (cd)}: brennende Häuser und der Brander. */
    public List<double[]> lights(double t) {
        List<double[]> l = new ArrayList<>();
        for (int i = 0; i < houses.size(); i++) {
            double[][] q = blaze.light(i, t);
            if (q == null) continue;
            l.add(new double[]{q[0][0], q[0][1], q[0][2], 3, q[1][0], q[1][1], q[1][2]});
        }
        Flotte fl = flotte;
        if (fl != null && fl.branderOn) {
            Longship b = fl.brander;
            double cd = Fire.lumenOf(8000) / (4 * Math.PI) * (1 + 0.1 * Math.sin(t * 6.1));
            l.add(new double[]{b.x, b.y + 4, b.z, 4, Fire.FLAME_RGB[0] * cd, Fire.FLAME_RGB[1] * cd, Fire.FLAME_RGB[2] * cd});
        }
        return l;
    }

    /** Rauchquellen: jedes brennende Haus, der Brander. */
    public List<Source> sources() {
        List<Source> l = new ArrayList<>();
        for (int i = 0; i < houses.size(); i++) {
            double q = blaze.hrr(i);
            if (q < 50) continue;
            Blaze.Building b = blaze.building(i);
            l.add(new Source(b.x(), b.y() + b.ridge(), b.z(), q, Math.min(1, 0.4 + blaze.smoke(i)), blaze.blackness(i), 5000 + i));
        }
        Flotte fl = flotte;
        if (fl != null && fl.branderOn) {
            Longship b = fl.brander;
            l.add(new Source(b.x, b.y + 2.5, b.z, 8000, 1, 0.75, 4999));
        }
        return l;
    }

    /** „Brander treibt · 7 Häuser brennen, 2 eingestürzt · 41 MW · Wind 6 m/s aus 80°“ */
    public String describe() {
        Flotte fl = flotte;
        String b = fl == null || !fl.branderOn ? "kein Brander" : fl.branderAground ? "Brander liegt fest" : fl.branderAdrift ? "Brander treibt" : "Brander wird gerudert";
        return String.format(Locale.GERMAN, "%s · %d Häuser brennen, %d eingestürzt (%d erfasst) · %.0f MW%s", b, burning(), collapsed(), touched(),
                blaze.totalHrr() / 1000, Double.isNaN(firstIgnition) ? "" : String.format(Locale.GERMAN, " · erstes Haus nach %.0f s", firstIgnition));
    }

    public double time() { return time; }
}
