package com.dan.haithabu.scene;

/**
 * Wo was wächst (Phase 2), aus dem Gelände abgeleitet [G]: der Schilfgürtel am Ufer von 950 (von 0,55 m unter bis
 * 0,35 m über dem Spiegel, in Flecken, nicht im Bach), Binsen auf dem nassen Saum darüber, Wiese auf dem trockenen,
 * nicht zu steilen Land. Schilf und Binsen liegen als Karte zu 2 m vor; dieselbe Karte geht als Textur an das Gelände,
 * das den Schilf in der Ferne als Farbe zeigt, so dass Halme und Fläche zusammenpassen.
 * <p>
 * Die Siedlung (Phase 6) und die Landebrücken (Phase 8) nehmen später Flächen heraus; bis dahin wächst der Schilf das
 * ganze Ufer entlang.
 * <p>
 * Phase 2b, Wald und Gehölz [G]: Innerhalb des Halbkreiswalls ist gerodet, davor liegen Felder und Weiden bis gut einen
 * Kilometer hinaus, dann Wald. Das Gegenufer im Osten trägt Eichen-Buchen-Wald mit Lichtungen und einem Gehöft, an
 * den Kuppen und Rändern Birken. Auf dem nassen Saum hinter dem Schilf, in Senken und Bachtälern stehen Schwarzerlen
 * (Erlenbruch); die Hochburg im Norden ist offen. Wald und Erlen liegen wie Schilf als Karte zu 2 m vor; die Karte geht
 * an das Gelände (Waldboden in der Nähe, Kronendach in der Ferne) und an {@code com.dan.forest} (wo welche Bäume stehen).
 */
public final class Vegetation implements com.dan.reed.Reed.Density, com.dan.reed.Reed.Ground, com.dan.forest.ForestField.Density {
    /** Arten des Waldes in der Reihenfolge von {@link #species()}. */
    public static final int EICHE = 0, BUCHE = 1, BIRKE = 2, ERLE = 3;
    /** Mitte und Halbmesser der gerodeten Fläche um den Halbkreiswall (der Wall selbst hat gut 400 m) [G]. */
    public static final double WALL_X = 10, WALL_Z = -85, WALL_R = 620;
    /** Standpunkte der Ansichten, an denen kein Baum stehen darf (wie {@code camera.Ansichten}). */
    static final double[][] VIEWS = {{6, -80.5}, {-166, -16}, {-560.5, -102.8}, {-200, -700}, {700, 60}};
    /** Lichtung des Gehöfts am Gegenufer [G]. */
    public static final double HOF_X = 1150, HOF_Z = 230;
    public static final int M = Terrain.N / 2;
    public static final double CELL = Terrain.CELL * 2;
    private final Terrain t;
    /** Schilf und Binsen je 2-m-Zelle (0..255). */
    public final byte[] reed, rush;
    /** Phase 2b: Wald (trocken: Eiche, Buche, Birke) und Erlenbruch je 2-m-Zelle (0..255). */
    public final byte[] wood, alder;
    /** Phase 5: die Höfe am Bach; wo sie Fußboden, Weg, Brunnen oder Boot haben, wachsen keine Halme. */
    public volatile Siedlung siedlung;

    public Vegetation(Terrain t) {
        this.t = t;
        reed = new byte[M * M];
        rush = new byte[M * M];
        wood = new byte[M * M];
        alder = new byte[M * M];
        for (int j = 0; j < M; j++)
            for (int i = 0; i < M; i++) {
                double x = Terrain.X0 + (i + 0.5) * CELL, z = Terrain.Z0 + (j + 0.5) * CELL;
                double y = t.height(x, z);
                woods(i, j, x, z, y);
                if (y < -1.0 || y > 1.2) continue;
                byte src = t.sourceAt(x, z);
                if (src == Terrain.BACH) continue;
                double patches = smooth(0.38, 0.62, fbm(x / 37.0 + 3.1, z / 37.0 - 1.7));
                double band = smooth(-0.70, -0.40, y) * (1 - smooth(0.20, 0.45, y));
                double r = band * patches * (0.75 + 0.25 * fbm(x / 9.0, z / 9.0));
                reed[j * M + i] = (byte) Math.round(255 * Math.max(0, Math.min(1, r)));
                double rb = smooth(0.15, 0.30, y) * (1 - smooth(0.55, 0.80, y)) * smooth(0.3, 0.55, fbm(x / 21.0 - 5.0, z / 21.0 + 2.0));
                rush[j * M + i] = (byte) Math.round(255 * Math.max(0, Math.min(1, rb)));
            }
    }

    /** Wald und Erlen einer Zelle [G]. */
    private void woods(int i, int j, double x, double z, double y) {
        if (y < 0.3 || t.sourceAt(x, z) == Terrain.BACH) return;
        double dWall = Math.hypot(x - WALL_X, z - WALL_Z);
        if (dWall < WALL_R && x < 150) return;                                   // im Wall gerodet
        double gx = t.height(x + 2, z) - t.height(x - 2, z), gz = t.height(x, z + 2) - t.height(x, z - 2);
        double slope = Math.hypot(gx, gz) / 4;
        double clearing = smooth(0.58, 0.68, fbm(x / 430.0 + 7.7, z / 430.0 - 3.1));
        double w;
        if (x > 420) {
            // Gegenufer: Wald mit Lichtungen, das Gehöft mit Feldern
            double hof = smooth(260, 420, Math.hypot(x - HOF_X, z - HOF_Z));
            w = 0.9 * (1 - clearing) * hof;
        } else {
            // Westufer: Felder und Weiden vor dem Wall, Wald erst weiter draußen; die Hochburg offen
            double open = 1 - smooth(1050, 1700, dWall);
            w = 0.85 * (1 - clearing * 0.8) * (1 - open * 0.96);
            w *= 0.15 + 0.85 * smooth(330, 480, Math.hypot(x + 200, z + 700));
        }
        w *= 1 - smooth(0.35, 0.7, slope) * 0.5;
        // Phase 6: die Felder vor dem Wall bleiben frei (gleiche Zone wie im Gelände-Shader, Kreis um die Wallmitte)
        double fd = Math.hypot(x + 223, z + 139), fa = (Math.toDegrees(Math.atan2(z + 139, x + 223)) + 360) % 360;
        if (fa > 60 && fa < 268) w *= smooth(930, 1010, fd);
        // Standpunkte frei: am Gegenufer eine Uferwiese mit Blick über das Noor, sonst je 35 m um die Ansichten
        w *= smooth(150, 230, Math.hypot(x - 700, z - 60));
        for (double[] v : VIEWS) w *= smooth(25, 45, Math.hypot(x - v[0], z - v[1]));
        w *= smooth(0.6, 1.4, y);                                                // nicht auf dem nassen Saum
        // Erlenbruch: nasser Saum hinter dem Schilf, Senken, Bachtäler (niedrig und im Gelände eingesenkt)
        double c0 = t.height(x, z), cs = (t.height(x + 12, z) + t.height(x - 12, z) + t.height(x, z + 12) + t.height(x, z - 12)) * 0.25;
        double hollow = Math.max(0, Math.min(1, (cs - c0) * 0.8));
        double wet = smooth(2.6, 0.9, y) * smooth(0.3, 0.55, y) + hollow * smooth(9, 3, y) * 0.8;
        double a = Math.min(1, wet) * (0.55 + 0.45 * fbm(x / 31.0 - 4.0, z / 31.0 + 6.0));
        if (x <= 420) a *= smooth(WALL_R, WALL_R + 120, dWall) * smooth(380, 520, Math.hypot(x + 200, z + 700));
        a *= smooth(110, 170, Math.hypot(x - 700, z - 60));
        for (double[] v : VIEWS) a *= smooth(25, 45, Math.hypot(x - v[0], z - v[1]));
        wood[j * M + i] = (byte) Math.round(255 * Math.max(0, Math.min(1, w * (1 - a * 0.7))));
        alder[j * M + i] = (byte) Math.round(255 * Math.max(0, Math.min(1, a)));
    }

    /**
     * Die Arten des Waldes (Eiche, Buche, Birke, Schwarzerle), frisch erzeugt. An der Küste färbt sich das Laub später
     * als im Binnenland [G]: Mitte Oktober ist die Buche erst halb gelb, die Eiche fast noch grün.
     */
    public static java.util.List<com.dan.forest.Species> species() {
        com.dan.forest.Species oak = com.dan.forest.Species.oak(), beech = com.dan.forest.Species.beech(), birch = com.dan.forest.Species.birch();
        oak.colorStart = 288; oak.colorFull = 312; oak.bare = 338;
        beech.colorStart = 284; beech.colorFull = 306; beech.bare = 326;
        birch.colorStart = 272; birch.colorFull = 296; birch.bare = 316;
        return java.util.List.of(oak, beech, birch, com.dan.forest.Species.alder());
    }

    /** Wald (trocken) 0..1 an (x, z). */
    public double wood(double x, double z) { return map(wood, x, z); }
    /** Erlenbruch 0..1 an (x, z). */
    public double alder(double x, double z) { return map(alder, x, z); }

    /** Dichte je Art für {@code com.dan.forest}: Eiche und Buche im Wald (Buche nicht im Nassen), Birke am Rand, Erle im Bruch. */
    @Override
    public double at(double x, double z, int species) {
        double w = map(wood, x, z);
        return switch (species) {
            case EICHE -> w * 0.42;
            case BUCHE -> w * 0.42 * smooth(2.0, 5.0, t.height(x, z));
            case BIRKE -> w * 0.06 + 0.35 * w * (1 - w) * 2;
            default -> map(alder, x, z) * 0.75;
        };
    }

    /** Boden für {@code com.dan.forest}. */
    public com.dan.forest.Ground forestGround() { return (x, z) -> (float) t.height(x, z); }

    /** Anteil der Fläche mit Wald bzw. Erlen über der Hälfte (Prüfung, HUD). */
    public double[] woodShare() {
        long n = 0, a = 0;
        for (int k = 0; k < wood.length; k++) { if ((wood[k] & 255) > 128) n++; if ((alder[k] & 255) > 128) a++; }
        return new double[]{n / (double) wood.length, a / (double) wood.length};
    }

    static double map(byte[] a, double x, double z) {
        double u = (x - Terrain.X0) / CELL - 0.5, v = (z - Terrain.Z0) / CELL - 0.5;
        int i = (int) Math.floor(u), j = (int) Math.floor(v);
        if (i < 0 || j < 0 || i >= M - 1 || j >= M - 1) return 0;
        double fx = u - i, fz = v - j;
        double p = (a[j * M + i] & 255) * (1 - fx) + (a[j * M + i + 1] & 255) * fx, q = (a[(j + 1) * M + i] & 255) * (1 - fx) + (a[(j + 1) * M + i + 1] & 255) * fx;
        return (p * (1 - fz) + q * fz) / 255.0;
    }

    @Override
    public double at(double x, double z, com.dan.reed.Reed.Kind k) {
        Siedlung s = siedlung;
        if (s != null && s.blocked(x, z)) return 0;
        double trodden = s != null ? 1 - 0.85 * s.yard(x, z) : 1;
        return trodden * switch (k) {
            case SCHILF -> map(reed, x, z);
            case BINSE -> map(rush, x, z);
            case GRAS -> {
                double y = t.height(x, z);
                if (y < 0.6 || t.sourceAt(x, z) == Terrain.BACH) yield 0;
                double gx = t.height(x + 1, z) - t.height(x - 1, z), gz = t.height(x, z + 1) - t.height(x, z - 1);
                double slope = Math.hypot(gx, gz) / 2;
                double canopy = Math.min(1, map(wood, x, z) + map(alder, x, z));
                yield (1 - smooth(0.35, 0.7, slope)) * (0.55 + 0.45 * fbm(x / 13.0 + 9.0, z / 13.0)) * smooth(0.6, 1.0, y) * (1 - 0.85 * canopy);
            }
        };
    }

    @Override
    public double height(double x, double z) { return t.height(x, z); }

    /** Anteil der Fläche im Raster mit Schilf (für Prüfung und HUD). */
    public double reedShare() {
        long n = 0;
        for (byte b : reed) if ((b & 255) > 64) n++;
        return n / (double) reed.length;
    }

    static double smooth(double a, double b, double x) {
        double q = Math.max(0, Math.min(1, (x - a) / (b - a)));
        return q * q * (3 - 2 * q);
    }

    static double hash(int x, int y) {
        long h = x * 374761393L + y * 668265263L;
        h = (h ^ (h >>> 13)) * 1274126177L;
        return ((h ^ (h >>> 16)) & 0xffffff) / (double) 0x1000000;
    }

    static double vnoise(double x, double y) {
        int i = (int) Math.floor(x), j = (int) Math.floor(y);
        double fx = x - i, fy = y - j;
        fx = fx * fx * (3 - 2 * fx);
        fy = fy * fy * (3 - 2 * fy);
        double a = hash(i, j), b = hash(i + 1, j), c = hash(i, j + 1), d = hash(i + 1, j + 1);
        return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy;
    }

    static double fbm(double x, double y) { return 0.5 * vnoise(x, y) + 0.3 * vnoise(x * 2.07 + 5.3, y * 2.07 + 5.3) + 0.2 * vnoise(x * 4.13 - 2.1, y * 4.13 - 2.1); }
}
