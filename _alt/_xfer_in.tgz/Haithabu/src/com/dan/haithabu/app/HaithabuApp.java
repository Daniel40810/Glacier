package com.dan.haithabu.app;

import com.dan.fframe.FFrame;
import com.dan.foptionpane.FOptionPane;
import com.dan.haithabu.data.Datenseite;
import com.dan.haithabu.gl.Renderer;
import com.dan.haithabu.gl.SceneView;
import com.dan.haithabu.scene.SceneClock;
import com.dan.haithabu.ui.AppIcon;
import com.dan.haithabu.ui.ControlPanel;
import com.dan.haithabu.ui.Startbild;
import com.dan.haithabu.ui.Theme;
import com.dan.haithabu.wiring.Wiring;
import com.jogamp.opengl.GLProfile;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingUtilities;
import javax.swing.ToolTipManager;
import java.awt.BorderLayout;
import java.io.File;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GraphicsEnvironment;
import java.awt.IllegalComponentStateException;
import java.awt.Rectangle;

/**
 * Haithabu — Rauch über dem Noor: die Wikingersiedlung um 950 als 3D-Szene auf der Grafikkarte (JOGL, OpenGL 4.3).
 * <p>
 * Einstieg: Startbild, dann FFrame beim Start maximiert (Taskleiste bleibt frei), Größe frei veränderbar; Szene in
 * der Mitte, Bedienfeld rechts, Statuszeile unten. Wasser, Himmel, Wetter und Leben kommen als eigenständige
 * Packages unter {@code com.dan} dazu (aus Lighthouse und Geyser, dazu sechs neue); diese App verdrahtet sie nur
 * ({@link Wiring}). Das Gerüst ist aus Lighthouse übernommen (F5 A).
 * <p>
 * Schalter: {@code -Dhaithabu.splash=false} ohne Startbild, {@code -Dhaithabu.gljpanel=true} leichter
 * GL-Rückfall, {@code -Dhaithabu.shaders=<ordner>} Shader von der Platte (F5 lädt neu).
 */
public final class HaithabuApp {
    /** Für Werkzeuge: Fenster und Szene, sobald sie stehen. */
    public static volatile FFrame frame;
    public static volatile SceneView scene;
    public static volatile ControlPanel controls;

    public static void main(String[] args) {
        System.setProperty("sun.java2d.uiScale.enabled", "true");
        // Der GL-Canvas ist ein schweres AWT-Element: Menüs und Tooltips müssen darüber liegen können
        JPopupMenu.setDefaultLightWeightPopupEnabled(false);
        ToolTipManager.sharedInstance().setLightWeightPopupEnabled(false);
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            System.err.println("Faden " + t.getName() + ": " + e);
            e.printStackTrace();
            fehlerDatei("Faden " + t.getName(), e);
        });
        GLProfile.initSingleton();
        SwingUtilities.invokeLater(() -> {
            try {
                open();
            } catch (Throwable e) {
                // Phase 17 (Befund): ohne Konsole (javaw, Verknüpfung) blieb ein Fehler beim Start unsichtbar; der Klang lief weiter
                e.printStackTrace();
                File f = fehlerDatei("Start", e);
                FOptionPane.showMessageDialog(null, "Haithabu ließ sich nicht starten:\n" + e + (e.getStackTrace().length > 0 ? "\n  bei " + e.getStackTrace()[0] : "")
                        + "\n\nDie ganze Meldung steht in\n" + (f != null ? f.getAbsolutePath() : "der Konsole") + ".", "Haithabu", FOptionPane.ERROR_MESSAGE);
                System.exit(1);
            }
        });
    }

    /** Schreibt einen Fehler mit Stapel nach daten/fehler.txt (angehängt) und gibt die Datei zurück, oder null. */
    static File fehlerDatei(String wo, Throwable e) {
        try {
            File f = new File(com.dan.haithabu.data.DateiSpeicher.ordner(), "fehler.txt");
            f.getParentFile().mkdirs();
            java.io.StringWriter sw = new java.io.StringWriter();
            e.printStackTrace(new java.io.PrintWriter(sw));
            String t = java.time.LocalDateTime.now().withNano(0) + " · " + Renderer.VERSION + " · Java " + System.getProperty("java.version") + " · " + wo + "\n" + sw + "\n";
            java.nio.file.Files.writeString(f.toPath(), t, java.nio.charset.StandardCharsets.UTF_8, java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
            return f;
        } catch (Exception x) {
            return null;
        }
    }

    private static void open() {
        // Phase 16: das Startbild verbindet mit der Datenbank (oder daten/); die Siedlung kommt aus dem Speicher
        Startbild.Wahl wahl = "false".equals(System.getProperty("haithabu.splash")) ? Startbild.stumm() : Startbild.zeigen();
        java.util.Map<String, String> weiter = null;
        if (wahl.weiter() != null && wahl.weiter().zustand() != null) {
            weiter = com.dan.store.Felder.ausText(wahl.weiter().zustand());
            String sn = weiter.get("siedlung.name");
            try {
                if (sn != null) for (com.dan.haithabu.data.Daten.Siedlung x : wahl.speicher().siedlungen())
                    if (x.name().equals(sn) && !x.aktiv()) { wahl.speicher().aktivieren(sn); break; }
            } catch (com.dan.store.Ablage.Fehler e) {
                com.dan.store.Protokoll.warnung("Sitzung", "Siedlung „" + sn + "“ nicht aktiviert: " + e.getMessage());
            }
        }
        Renderer.siedlungsLader = Datenseite::laden;
        SceneClock clock = new SceneClock();
        Wiring wiring = new Wiring(clock);
        // Phase 3: die Wetterregie läuft frei, beginnend mit klarem Wetter (Regiebücher im Block WETTER)
        wiring.regie = true;
        wiring.yearOn = true;      // Phase 12: das Jahr (Schnee, Eis, Reif, Pflanzen)
        wiring.startFree(com.dan.weather.Weather.Phase.KLAR);
        Renderer rd = new Renderer(clock, wiring);
        Datenseite.szene(() -> com.dan.haithabu.data.Startdaten.szene(rd.terrain, rd.siedlung, rd.flotte,
                rd.fahrtGasse != null ? com.dan.haithabu.data.Startdaten.punkte(rd.fahrtGasse) : java.util.List.of(), com.dan.haithabu.scene.Terrain.defaultDir()));
        FFrame f = new FFrame("Haithabu · Rauch über dem Noor · " + Renderer.VERSION);
        AppIcon.install(f);
        if (!Boolean.getBoolean("haithabu.gljpanel")) makeOpaque(f);
        SceneView view;
        try {
            view = new SceneView(rd);
        } catch (RuntimeException e) {
            FOptionPane.showMessageDialog(null, "OpenGL lässt sich nicht starten:\n" + e.getMessage()
                    + "\n\nBitte den Grafiktreiber aktualisieren. Als Rückfall: Start mit -Dhaithabu.gljpanel=true.", "Haithabu", FOptionPane.ERROR_MESSAGE);
            System.exit(1);
            return;
        }
        ControlPanel controls = new ControlPanel(view, wiring);
        JLabel status = new JLabel("Das Gelände wird geladen …");
        status.setForeground(new Color(176, 186, 178));
        status.setFont(new Font("SansSerif", Font.PLAIN, 12));
        status.setBorder(BorderFactory.createEmptyBorder(5, 12, 5, 12));
        JLabel dbStatus = new JLabel(Startbild.statuszeile());
        new javax.swing.Timer(2000, e -> dbStatus.setText(Startbild.statuszeile())).start();
        dbStatus.setFont(new Font("SansSerif", Font.PLAIN, 12));
        dbStatus.setBorder(BorderFactory.createEmptyBorder(5, 12, 5, 12));
        dbStatus.setForeground(new Color(230, 190, 120));
        rd.setStatusListener(s -> SwingUtilities.invokeLater(() -> status.setText(s)));
        rd.setErrorListener(msg -> SwingUtilities.invokeLater(() -> FOptionPane.showMessageDialog(f, msg, "Haithabu · Grafik", FOptionPane.ERROR_MESSAGE)));

        JPanel root = f.getComponentPane();
        root.setLayout(new BorderLayout());
        root.setBackground(Theme.bg());
        root.add(view, BorderLayout.CENTER);
        JScrollPane side = new JScrollPane(controls, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        side.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 0, Theme.line()));
        side.getViewport().setBackground(Theme.bg());
        side.setBackground(Theme.bg());
        try {
            com.dan.fscrollbar.FScrollBar bar = new com.dan.fscrollbar.FScrollBar(javax.swing.JScrollBar.VERTICAL);
            bar.setUnitIncrement(16);
            bar.setBlockIncrement(120);
            side.setVerticalScrollBar(bar);
        } catch (RuntimeException | LinkageError e) {
            side.getVerticalScrollBar().setUnitIncrement(16);
        }
        side.setPreferredSize(new Dimension(320, 600));
        root.add(side, BorderLayout.EAST);
        JPanel south = new JPanel(new BorderLayout());
        south.setBackground(Theme.status());
        south.add(status, BorderLayout.CENTER);
        south.add(dbStatus, BorderLayout.EAST);
        root.add(south, BorderLayout.SOUTH);

        f.setPreferredFrameSize(new Dimension(1480, 900));
        f.setSize(1480, 900);
        f.setMinimumSize(new Dimension(800, 520));
        f.setLocationRelativeTo(null);
        f.setResizable(true);
        f.setVisible(true);
        startMaximized(f);
        view.start();
        // Phase 16 (F33, F36): Sitzung, Protokoll alle 5 s, Zustand alle 2 min und beim Ende
        com.dan.store.Protokoll.kontext(() -> com.dan.haithabu.data.Zustand.text(com.dan.haithabu.data.Daten.Szenenzeit.of(clock.date(), clock.hour())),
                () -> String.format(java.util.Locale.ROOT, "%.0f %.0f %.0f", rd.camera.eye[0], rd.camera.eye[1], rd.camera.eye[2]));
        com.dan.store.Dienst.starten(Renderer.VERSION, "", rd.quality().name(), () -> sicherung(rd));
        com.dan.store.Protokoll.info("App", "Haithabu " + Renderer.VERSION + " gestartet · " + Datenseite.speicher().wo());
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try { com.dan.store.Dienst.beenden(); } catch (RuntimeException e) { System.err.println("Haithabu: Sitzung nicht beendet: " + e); }
            view.stop();
        }, "Haithabu-Ende"));
        if (weiter != null) {
            java.util.Map<String, String> z = weiter;
            // nach dem ersten Bild, wenn alles steht
            javax.swing.Timer t = new javax.swing.Timer(1500, e -> controls.weiter(z));
            t.setRepeats(false);
            t.start();
        }
        // F11: nur die Szene (Bedienfeld und Statuszeile weg und wieder da)
        view.setKeyAction(java.awt.event.KeyEvent.VK_F11, () -> SwingUtilities.invokeLater(() -> {
            boolean an = !side.isVisible();
            side.setVisible(an);
            south.setVisible(an);
            root.revalidate();
        }));
        view.requestFocusInWindow();
        frame = f;
        scene = view;
        HaithabuApp.controls = controls;
    }

    /** Was beim Sichern geschrieben wird: der ganze Zustand und die Spalten von HB_SITZUNG. */
    private static com.dan.store.Ablage.Sicherung sicherung(Renderer r) {
        java.util.LinkedHashMap<String, String> z = com.dan.haithabu.data.Zustand.erfassen(r, r.soundOn(), Datenseite.siedlungName);
        java.util.Map<String, String> sp = new java.util.HashMap<>();
        sp.put(com.dan.haithabu.data.Speicher.SZ, z.get("uhr.datum") + " " + z.get("uhr.stunde"));
        if (Datenseite.siedlungName != null) sp.put(com.dan.haithabu.data.Speicher.SIEDLUNG, Datenseite.siedlungName);
        if (z.containsKey("regiebuch.name")) {
            sp.put(com.dan.haithabu.data.Speicher.REGIEBUCH, z.get("regiebuch.name"));
            sp.put(com.dan.haithabu.data.Speicher.REGIE_SEKUNDE, z.get("regiebuch.sekunde"));
        }
        return new com.dan.store.Ablage.Sicherung(com.dan.store.Felder.alsText(z, "Haithabu · Sitzung · " + Renderer.VERSION), sp);
    }

    /**
     * Startet maximiert (MAXIMIZED_BOTH), ohne die Taskleiste zu verdecken. Die normale Größe von 1480 × 900 bleibt
     * als Rückfall; „Wiederherstellen“ des FFrame stellt sie wieder her (wie in Kīlauea, Kneiphof, Geyser und Lighthouse).
     */
    private static void startMaximized(FFrame f) {
        Rectangle normal = f.getBounds();
        f.setMaximizedBounds(GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds());
        f.setExtendedState(f.getExtendedState() | Frame.MAXIMIZED_BOTH);
        try {
            // Die Titelleiste des FFrame führt einen eigenen Maximiert-Zustand; ihn angleichen
            for (java.lang.reflect.Field fd : FFrame.class.getDeclaredFields()) {
                if (!fd.getType().getSimpleName().equals("FTaskbar")) continue;
                fd.setAccessible(true);
                Object bar = fd.get(f);
                Class<?> bc = bar.getClass();
                java.lang.reflect.Field mx = bc.getDeclaredField("maximized"), rb = bc.getDeclaredField("restoreBounds"),
                        btn = bc.getDeclaredField("btnMaximize");
                mx.setAccessible(true);
                rb.setAccessible(true);
                btn.setAccessible(true);
                mx.setBoolean(bar, true);
                rb.set(bar, normal);
                Object icon = btn.get(bar);
                icon.getClass().getMethod("setType", com.dan.ficons.FIconType.class).invoke(icon, com.dan.ficons.FIconType.RESTORE);
                ((javax.swing.JComponent) icon).setToolTipText("Wiederherstellen");
                ((java.awt.Component) icon).addMouseListener(new java.awt.event.MouseAdapter() {
                    @Override public void mouseReleased(java.awt.event.MouseEvent e) {
                        SwingUtilities.invokeLater(() -> {
                            if ((f.getExtendedState() & Frame.MAXIMIZED_BOTH) != 0) {
                                f.setExtendedState(f.getExtendedState() & ~Frame.MAXIMIZED_BOTH);
                                f.setBounds(normal);
                            }
                        });
                    }
                });
            }
        } catch (Exception e) {
            System.err.println("FFrame-Titelleiste nicht angeglichen: " + e);
        }
    }

    /**
     * Das FFrame ist ein durchscheinendes Fenster (runde Ecken). Darin zeigt Windows schwere Elemente wie den
     * GL-Canvas nicht; darum wird es deckend gemacht und die Rundung als Fensterform gesetzt.
     */
    private static void makeOpaque(FFrame f) {
        f.setBackground(Theme.bg());
        java.awt.event.ComponentAdapter shape = new java.awt.event.ComponentAdapter() {
            @Override public void componentResized(java.awt.event.ComponentEvent e) { reshape(f); }
            @Override public void componentShown(java.awt.event.ComponentEvent e) { reshape(f); }
        };
        f.addComponentListener(shape);
        f.addWindowStateListener(e -> reshape(f));
    }

    private static void reshape(FFrame f) {
        try {
            boolean max = (f.getExtendedState() & Frame.MAXIMIZED_BOTH) != 0;
            f.setShape(max ? null : new java.awt.geom.RoundRectangle2D.Double(0, 0, f.getWidth(), f.getHeight(), 20, 20));
        } catch (UnsupportedOperationException | IllegalComponentStateException e) {
            // Form nicht möglich: dann eben eckig
        }
    }

    private HaithabuApp() { }
}
