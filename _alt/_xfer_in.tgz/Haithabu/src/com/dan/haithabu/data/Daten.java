package com.dan.haithabu.data;

import com.dan.haithabu.scene.Site;
import com.dan.store.Zahl;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Die Datensätze, die {@link Speicher} liest und schreibt (Phase 16, Werkbuch Abschnitt 8). Je Tabelle ein Record mit
 * den Spalten, die die App braucht; ID, ANGELEGT und GEAENDERT führt die Datenbank selbst. Lagen stehen in
 * Szenenmetern (x nach Osten, z nach Süden); Länge und Breite rechnet {@link #lonLat}.
 */
public final class Daten {
    private Daten() { }

    /** HERKUNFT: mitgeliefert (stellt der Einrichter wieder her) oder eigen (fasst er nie an). */
    public static final String MITGELIEFERT = "MITGELIEFERT", EIGEN = "EIGEN";
    /** BEFUND: belegt, gemessen oder gestaltet [G]. */
    public static final String BELEGT = "BELEGT", GEMESSEN = "GEMESSEN", GESTALTET = "GESTALTET";

    /** {lon, lat} eines Szenenpunkts (x, z). */
    public static double[] lonLat(double x, double z) {
        double[] ll = Site.latLon(x, z);
        return new double[]{ll[1], ll[0]};
    }

    /** Szenenpunkt {x, z} aus Länge und Breite. */
    public static double[] xz(double lon, double lat) { return Site.xz(new double[]{lat, lon}); }

    /**
     * Szenenzeit als Zahlen (F32 A): Jahr, Monat, Tag gregorianisch zurückgerechnet wie {@code java.time} (F21), dazu
     * die Stunde mit Bruchteil. Nie als Oracle-DATE, weil Oracle vor dem 15.10.1582 julianisch rechnet.
     */
    public record Szenenzeit(int jahr, int monat, int tag, double stunde) {
        public static Szenenzeit of(LocalDate d, double stunde) { return new Szenenzeit(d.getYear(), d.getMonthValue(), d.getDayOfMonth(), stunde); }
        public LocalDate datum() { return LocalDate.of(jahr, monat, tag); }
        /** „16.10.950 17:30“ */
        @Override public String toString() {
            int m = (int) Math.round(stunde * 60);
            return String.format(Locale.GERMAN, "%d.%d.%d %02d:%02d", tag, monat, jahr, (m / 60) % 24, m % 60);
        }
    }

    /** Eine Geometrie in Szenenmetern: Art PUNKT, LINIE oder FLAECHE und die Punkte {x, z}. */
    public record Geom(String art, double[][] xz) {
        public static Geom punkt(double x, double z) { return new Geom("PUNKT", new double[][]{{x, z}}); }
        public static Geom linie(double[][] p) { return new Geom("LINIE", p); }
        public static Geom flaeche(double[][] p) { return new Geom("FLAECHE", p); }
        /** Als WKT in Länge und Breite (com.dan.store.Wkt). */
        public String wkt() {
            double[][] ll = new double[xz.length][];
            for (int i = 0; i < xz.length; i++) ll[i] = lonLat(xz[i][0], xz[i][1]);
            return switch (art) {
                case "PUNKT" -> com.dan.store.Wkt.punkt(ll[0][0], ll[0][1]);
                case "LINIE" -> com.dan.store.Wkt.linie(ll);
                default -> com.dan.store.Wkt.flaeche(ll);
            };
        }
        /** Die Punkte als Text „x z; x z; …“ (Szenenmeter, cm) für die Dateien. */
        public String text() {
            StringBuilder b = new StringBuilder(art).append(':');
            for (int i = 0; i < xz.length; i++) b.append(i > 0 ? ";" : "").append(Zahl.text(Math.round(xz[i][0] * 100) / 100.0)).append(' ').append(Zahl.text(Math.round(xz[i][1] * 100) / 100.0));
            return b.toString();
        }
        public static Geom ausText(String t) {
            int c = t.indexOf(':');
            String[] ps = t.substring(c + 1).split(";");
            double[][] p = new double[ps.length][];
            for (int i = 0; i < ps.length; i++) {
                String[] q = ps[i].strip().split(" ");
                p[i] = new double[]{Zahl.lies(q[0]), Zahl.lies(q[1])};
            }
            return new Geom(t.substring(0, c), p);
        }
        /** Länge einer Linie oder Umfang (m). */
        public double laenge() {
            double s = 0;
            for (int i = 0; i + 1 < xz.length; i++) s += Math.hypot(xz[i + 1][0] - xz[i][0], xz[i + 1][1] - xz[i][1]);
            return s;
        }
        /** Fläche (m², nach Gauß). */
        public double flaecheM2() {
            double a = 0;
            for (int i = 0; i < xz.length; i++) { double[] p = xz[i], q = xz[(i + 1) % xz.length]; a += p[0] * q[1] - q[0] * p[1]; }
            return Math.abs(a) / 2;
        }
    }

    /** Ein Haustyp (HB_HAUSTYP), Werte aus {@code timber.HouseType}. */
    public record Haustyp(String name, String bezeichnung, double laengeM, double breiteM, double wandhoeheM, double dachneigungGrad, String wand,
                          double eingetieftM, String befund, String befundGegenstand, String beschreibung) { }

    /** Kopf einer gespeicherten Siedlung (HB_SIEDLUNG). */
    public record Siedlung(String name, long startwert, boolean aktiv, int haeuser, String beschreibung, String herkunft) {
        @Override public String toString() { return name; }
    }

    /** Ein Haus (HB_HAUS) in Szenenmetern; y ist die Bodenhöhe. */
    public record Haus(int nr, String name, String haustyp, String rolle, double x, double y, double z, double richtungGrad, double laengeFaktor,
                       double breiteFaktor, double zustand, long zufall, boolean museum, boolean vonHand, String bemerkung) {
        /** Der Grundriss als Rechteck aus Typ, Faktoren und Richtung (Szenenmeter). */
        public Geom grundriss(Haustyp t) {
            double hl = t.laengeM() * laengeFaktor / 2, hw = t.breiteM() * breiteFaktor / 2, h = Math.toRadians(richtungGrad);
            double ax = Math.sin(h), az = -Math.cos(h), bx = Math.cos(h), bz = Math.sin(h);
            return Geom.flaeche(new double[][]{{x - ax * hl - bx * hw, z - az * hl - bz * hw}, {x + ax * hl - bx * hw, z + az * hl - bz * hw},
                    {x + ax * hl + bx * hw, z + az * hl + bz * hw}, {x - ax * hl + bx * hw, z - az * hl + bz * hw}});
        }
    }

    /** Ein Weg, Zaun oder Garten (HB_WEG). */
    public record Weg(String art, String name, Geom geom, double breiteM) { }

    /** Ein Bauwerk des Lageplans (HB_BAUWERK). */
    public record Bauwerk(String art, String name, Geom geom, Double hoeheM, Double breiteM, String befund, String befundGegenstand, String beschreibung) { }

    /** Eckdaten des Geländes (HB_GELAENDE). */
    public record Gelaende(String name, String quelle, Geom ausschnitt, double ursprungLon, double ursprungLat, double rasterM, int spalten, int zeilen,
                           double anteilGemessenProz, String datei, String pruefsumme, String eingriffe) { }

    /** Ein Schiffstyp (HB_SCHIFFSTYP), Werte aus {@code longship.ShipType}. */
    public record Schiffstyp(String name, String bezeichnung, String vorbild, double laengeM, double breiteM, double tiefgangM, int riemenpaare,
                             boolean segel, double masseKg, String befund, String befundGegenstand) { }

    /** Ein Schiff der Flotte (HB_SCHIFF) mit Liegeplatz in Szenenmetern. */
    public record Schiff(String name, String typ, String rolle, Double x, Double z, Double richtungGrad, Integer bruecke, String ladung) { }

    /**
     * Eine Wetterlage (HB_WETTERLAGE): je {@code Weather.Var} ein Wert oder NaN (die Dünung bleibt NaN, das Noor hat
     * keine). Die Wolkenart steht als Zahl wie in der Regie, in der Tabelle als Name.
     */
    public record Wetterlage(String name, Double beaufort, String phase, double[] werte, String monate, String beschreibung, String herkunft) {
        public Wetterlage { werte = werte.clone(); }
        @Override public String toString() { return name; }
    }

    /** Ein Regiebuch als ganzer Text (F31 A, Format von {@code scene.Regie.parse}). */
    public record Regiebuch(String name, String text, String beschreibung, String herkunft) {
        @Override public String toString() { return name; }
    }

    /** Ein Stützpunkt einer Kamerafahrt (HB_STUETZPUNKT); Szenenmeter und Grad. */
    public record Stuetzpunkt(int nr, double zeitS, double x, double y, double z, double gier, double nick, double fov) { }

    /** Eine Kamerafahrt (HB_FAHRT). */
    public record Fahrt(String name, Integer taste, String art, boolean schleife, String beschreibung, String herkunft, List<Stuetzpunkt> punkte) {
        public Fahrt { punkte = List.copyOf(punkte); }
        @Override public String toString() { return name; }
    }

    /**
     * Eine Ansicht (HB_ANSICHT): fest (Tasten 1–7) oder gemerkt (Taste V) mit Zustand und Vorschau (PNG oder null).
     * kamera = {x, y, z, Gier, Nick, Bildwinkel}.
     */
    public record Ansicht(long id, String name, Integer taste, String art, double[] kamera, Double augeUeberGrund, boolean orbit, Double abstandM,
                          Szenenzeit szenenzeit, String zustand, byte[] vorschau, String herkunft) {
        @Override public String toString() { return name; }
    }

    /** Ein benanntes Preset eines Package (HB_PAKET_PRESET mit HB_PAKET_WERT). */
    public record PaketPreset(String paket, String klasse, String name, String beschreibung, String herkunft, Map<String, String> felder) {
        public PaketPreset { felder = new LinkedHashMap<>(felder); }
        @Override public String toString() { return name; }
    }

    /** Eine Quelle (HB_QUELLE). */
    public record Quelle(String kurz, String titel, String url, String art, LocalDate abgerufen, String bemerkung) { }

    /** Ein Befund (HB_BEFUND) mit den Kurzzeichen seiner Quellen. */
    public record Befund(String thema, String gegenstand, String befund, String text, List<String> quellen) {
        public Befund { quellen = List.copyOf(quellen); }
    }

    /** Die letzte Sitzung für „Weiter wie zuletzt“. */
    public record Sitzung(long id, long beginnMs, Long endeMs, boolean sauber, String zustand, Long zustandMs, String siedlung, String regiebuch,
                          Double regieSekunde, Szenenzeit szenenzeit) { }

    /** Was das Startbild über den Stand der Daten zeigt. */
    public record Stand(int siedlungen, int haeuser, int bauwerke, int regiebuecher, int wetterlagen, int fahrten, int ansichten, int presets,
                        int befunde, String aktiveSiedlung, Sitzung letzte) { }
}
