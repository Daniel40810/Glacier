package com.dan.haithabu.data;

import com.dan.store.DateiAblage;
import com.dan.store.Felder;
import com.dan.store.Zahl;
import com.dan.weather.Weather;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Speichern ohne Datenbank (F36 A): Textdateien im Ordner {@code daten/} des Projekts, im Textformat von
 * {@link Felder#alsText}. Die mitgelieferten Einträge kommen aus {@link Startdaten} und stehen nicht in Dateien; eigene
 * liegen je in einer Datei. Der Ordner steht in {@code .gitignore}.
 * <pre>
 * daten/siedlungen/*.csv (+ aktiv.txt)   daten/wetterlagen/*.txt   daten/regiebuecher/*.txt   daten/fahrten/*.txt
 * daten/ansichten/N.txt + N.png   daten/presets/paket/Klasse/*.txt   daten/sitzungen/N.txt   daten/protokoll.txt
 * </pre>
 * Eine Siedlung ist eine CSV wie {@code daten/siedlung.csv} aus Phase 6 (eine Zeile je Haus); liegt diese alte Datei
 * noch da, wird sie beim ersten Lesen als eigene Siedlung „Gespeichert in siedlung.csv“ übernommen.
 */
public final class DateiSpeicher extends DateiAblage implements Speicher {

    /** Woher der Lageplan kommt (aus der Szene, sobald sie steht); ohne Szene leer. */
    public volatile Supplier<Startdaten.Szene> szene = () -> null;

    public DateiSpeicher(File dir) { super(dir); }

    /** Der Ordner daten neben db (oder -Dhaithabu.daten). */
    public static File ordner() {
        String p = System.getProperty("haithabu.daten");
        if (p != null && !p.isEmpty()) return new File(p);
        File db = Verbindung.ordner().getAbsoluteFile();
        File base = db.getParentFile();
        return new File(base != null ? base : new File("."), "daten");
    }

    private static void eigen(boolean mitgeliefert, String was) throws Fehler {
        if (mitgeliefert) throw new Fehler("„" + was + "“ ist mitgeliefert und wird nicht überschrieben; bitte unter einem eigenen Namen speichern");
    }

    @Override public Daten.Stand stand() throws Fehler {
        Daten.Siedlung a = aktiveSiedlung();
        int haeuser = 0;
        for (Daten.Siedlung s : siedlungen()) haeuser += s.haeuser();
        Startdaten.Szene sz = szene.get();
        return new Daten.Stand(siedlungen().size(), haeuser, sz == null ? 0 : sz.bauwerke().size(), regiebuecher().size(), wetterlagen().size(),
                fahrten().size(), ansichten().size(), presets(null, null).size(), befunde().size(), a == null ? null : a.name(), letzteSitzung(-1));
    }

    // ------------------------------------------------------------------ Siedlungen

    private File siedlungDatei(String name) { return sub("siedlungen", dateiname(name).replace(".txt", ".csv")); }

    private void altUebernehmen() throws Fehler {
        File alt = new File(dir, "siedlung.csv"), d = sub("siedlungen");
        if (!alt.isFile()) return;
        File neu = new File(d, "Gespeichert in siedlung.csv".replace(".csv", "") + ".csv");
        if (neu.isFile()) return;
        try {
            List<String> z = new ArrayList<>(Files.readAllLines(alt.toPath(), StandardCharsets.UTF_8));
            z.add(1, "# Name: Gespeichert in siedlung.csv");
            Files.createDirectories(d.toPath());
            Files.write(neu.toPath(), z, StandardCharsets.UTF_8);
            if (!sub("siedlungen", "aktiv.txt").isFile()) schreibe(sub("siedlungen", "aktiv.txt"), "Gespeichert in siedlung.csv\n");
        } catch (IOException e) {
            throw new Fehler("daten/siedlung.csv nicht übernommen: " + e.getMessage(), e);
        }
    }

    private String aktivName() throws Fehler {
        altUebernehmen();
        File f = sub("siedlungen", "aktiv.txt");
        try { return f.isFile() ? Files.readString(f.toPath(), StandardCharsets.UTF_8).strip() : Startdaten.SIEDLUNG; } catch (IOException e) { throw new Fehler(e.getMessage(), e); }
    }

    /** Kopf einer CSV: Startwert, Name, Beschreibung; Häuser zählen. */
    private Daten.Siedlung kopf(File f, String aktiv) throws Fehler {
        try {
            List<String> z = Files.readAllLines(f.toPath(), StandardCharsets.UTF_8);
            long sw = Startdaten.STARTWERT;
            String name = f.getName().replace(".csv", ""), about = null;
            int n = 0;
            for (String l : z) {
                if (l.startsWith("#")) {
                    java.util.regex.Matcher m = java.util.regex.Pattern.compile("Startwert (-?\\d+)").matcher(l);
                    if (m.find()) sw = Long.parseLong(m.group(1));
                    if (l.startsWith("# Name: ")) name = l.substring(8).strip();
                    if (l.startsWith("# Beschreibung: ")) about = l.substring(16).strip();
                } else if (!l.isBlank()) n++;
            }
            return new Daten.Siedlung(name, sw, name.equals(aktiv), n, about, Daten.EIGEN);
        } catch (IOException e) {
            throw new Fehler("Siedlung " + f + " nicht lesbar: " + e.getMessage(), e);
        }
    }

    @Override public List<Daten.Siedlung> siedlungen() throws Fehler {
        String aktiv = aktivName();
        List<Daten.Siedlung> l = new ArrayList<>();
        Startdaten.Szene sz = szene.get();
        l.add(new Daten.Siedlung(Startdaten.SIEDLUNG, Startdaten.STARTWERT, Startdaten.SIEDLUNG.equals(aktiv), sz == null ? 0 : sz.haeuser().size(),
                "Die Siedlung aus dem Startwert 950 mit den sieben Häusern am Bach", Daten.MITGELIEFERT));
        File[] fs = sub("siedlungen").listFiles((d, n) -> n.endsWith(".csv"));
        if (fs != null) {
            java.util.Arrays.sort(fs, Comparator.comparing(File::getName));
            for (File f : fs) l.add(kopf(f, aktiv));
        }
        return l;
    }

    @Override public Daten.Siedlung aktiveSiedlung() throws Fehler {
        for (Daten.Siedlung s : siedlungen()) if (s.aktiv()) return s;
        return siedlungen().get(0);
    }

    private Daten.Siedlung finde(String name) throws Fehler {
        for (Daten.Siedlung s : siedlungen()) if (s.name().equals(name)) return s;
        throw new Fehler("Siedlung „" + name + "“ gibt es nicht");
    }

    @Override public List<Daten.Haus> haeuser(String siedlung) throws Fehler {
        Daten.Siedlung s = finde(siedlung);
        if (Daten.MITGELIEFERT.equals(s.herkunft())) return List.of();
        File f = siedlungDatei(s.name());
        if (!f.isFile()) {
            // Name aus „# Name:“ weicht vom Dateinamen ab: suchen
            File[] fs = sub("siedlungen").listFiles((d, n) -> n.endsWith(".csv"));
            if (fs != null) for (File x : fs) if (kopf(x, "").name().equals(siedlung)) f = x;
        }
        try {
            List<Daten.Haus> l = new ArrayList<>();
            int nr = 0;
            for (String z : Files.readAllLines(f.toPath(), StandardCharsets.UTF_8)) {
                if (z.startsWith("#") || z.isBlank()) continue;
                String[] c = z.split(";", -1);
                l.add(new Daten.Haus(++nr, c[0], c[2], c[1], Zahl.lies(c[3]), Zahl.lies(c[4]), Zahl.lies(c[5]), Zahl.lies(c[6]), Zahl.lies(c[7]), Zahl.lies(c[8]),
                        Zahl.lies(c[9]), Long.parseLong(c[10].strip()), Boolean.parseBoolean(c[11].strip()), c.length > 12 && Boolean.parseBoolean(c[12].strip()),
                        c.length > 13 && !c[13].isBlank() ? c[13] : null));
            }
            return l;
        } catch (IOException | RuntimeException e) {
            throw new Fehler("Siedlung „" + siedlung + "“ nicht lesbar: " + e.getMessage(), e);
        }
    }

    /** Eine Zeile der CSV (Name; Rolle; Typ; x; y; z; Richtung; Länge; Breite; Zustand; Zufall; Museum; von Hand; Bemerkung). */
    static String csv(Daten.Haus h) {
        return String.join(";", h.name().replace(';', ','), h.rolle().replace(';', ','), h.haustyp(), f3(h.x()), f3(h.y()), f3(h.z()), f3(h.richtungGrad()),
                f3(h.laengeFaktor()), f3(h.breiteFaktor()), f3(h.zustand()), Long.toString(h.zufall()), Boolean.toString(h.museum()), Boolean.toString(h.vonHand()),
                h.bemerkung() == null ? "" : h.bemerkung().replace(';', ',').replace('\n', ' '));
    }

    private static String f3(double v) { return String.format(Locale.ROOT, "%.3f", v); }

    @Override public void speichern(Daten.Siedlung s, List<Daten.Haus> haeuser, List<Daten.Weg> wege) throws Fehler {
        eigen(Startdaten.SIEDLUNG.equals(s.name()), s.name());
        StringBuilder b = new StringBuilder();
        b.append("# Siedlung Haithabu, Startwert ").append(s.startwert()).append(" (Phase 16): Name; Rolle; Typ; x; y; z; Richtung; Länge; Breite; Zustand; Zufall; Museum; von Hand; Bemerkung\n");
        b.append("# Name: ").append(s.name()).append('\n');
        if (s.beschreibung() != null) b.append("# Beschreibung: ").append(s.beschreibung().replace('\n', ' ')).append('\n');
        for (Daten.Haus h : haeuser) b.append(csv(h)).append('\n');
        schreibe(siedlungDatei(s.name()), b.toString());
    }

    @Override public void aktivieren(String siedlung) throws Fehler {
        finde(siedlung);
        schreibe(sub("siedlungen", "aktiv.txt"), siedlung + "\n");
    }

    private void umschreiben(String siedlung, java.util.function.UnaryOperator<List<Daten.Haus>> f) throws Fehler {
        Daten.Siedlung s = finde(siedlung);
        eigen(Daten.MITGELIEFERT.equals(s.herkunft()), siedlung);
        speichern(s, f.apply(new ArrayList<>(haeuser(siedlung))), List.of());
    }

    @Override public void aendern(String siedlung, Daten.Haus h) throws Fehler {
        umschreiben(siedlung, l -> {
            for (int i = 0; i < l.size(); i++) if (l.get(i).nr() == h.nr())
                l.set(i, new Daten.Haus(h.nr(), h.name(), h.haustyp(), h.rolle(), h.x(), h.y(), h.z(), h.richtungGrad(), h.laengeFaktor(), h.breiteFaktor(),
                        h.zustand(), h.zufall(), h.museum(), true, h.bemerkung()));
            return l;
        });
    }

    @Override public void entfernen(String siedlung, int nr) throws Fehler { umschreiben(siedlung, l -> { l.removeIf(x -> x.nr() == nr); return l; }); }

    @Override public void loeschenSiedlung(String name) throws Fehler {
        Daten.Siedlung s = finde(name);
        eigen(Daten.MITGELIEFERT.equals(s.herkunft()), name);
        loesche(siedlungDatei(name), name);
        if (s.aktiv()) aktivieren(Startdaten.SIEDLUNG);
    }

    // ------------------------------------------------------------------ Lageplan und Quellen

    @Override public List<Daten.Bauwerk> bauwerke() {
        Startdaten.Szene sz = szene.get();
        return sz == null ? List.of() : sz.bauwerke();
    }

    @Override public Daten.Gelaende gelaende() {
        Startdaten.Szene sz = szene.get();
        return sz == null ? null : sz.gelaende();
    }

    @Override public List<Daten.Quelle> quellen() { return Startdaten.quellen(); }

    @Override public List<Daten.Befund> befunde() { return Startdaten.befunde(); }

    // ------------------------------------------------------------------ Wetterlagen

    static LinkedHashMap<String, String> alsMap(Daten.Wetterlage w) {
        LinkedHashMap<String, String> m = new LinkedHashMap<>();
        m.put("name", w.name());
        m.put("beaufort", w.beaufort() == null ? "" : Zahl.text(w.beaufort()));
        m.put("phase", w.phase() == null ? "" : w.phase());
        for (Weather.Var v : Weather.Var.values()) m.put(v.name(), Zahl.text(w.werte()[v.ordinal()]));
        m.put("monate", w.monate() == null ? "" : w.monate());
        m.put("beschreibung", w.beschreibung() == null ? "" : w.beschreibung());
        return m;
    }

    static Daten.Wetterlage wetterlage(Map<String, String> m, String herkunft) {
        double[] v = new double[Weather.Var.values().length];
        for (Weather.Var x : Weather.Var.values()) v[x.ordinal()] = Zahl.lies(m.get(x.name()));
        double bft = Zahl.lies(m.get("beaufort"));
        return new Daten.Wetterlage(m.get("name"), Double.isNaN(bft) ? null : bft, m.getOrDefault("phase", ""), v, m.get("monate"), m.get("beschreibung"), herkunft);
    }

    @Override public List<Daten.Wetterlage> wetterlagen() throws Fehler {
        List<Daten.Wetterlage> l = new ArrayList<>(Startdaten.wetterlagen());
        for (LinkedHashMap<String, String> m : eintraege("wetterlagen")) l.add(wetterlage(m, Daten.EIGEN));
        return l;
    }

    private static boolean mitgeliefert(List<?> l, String name) {
        for (Object o : l) if (o.toString().equals(name)) return true;
        return false;
    }

    @Override public void speichern(Daten.Wetterlage w) throws Fehler {
        eigen(mitgeliefert(Startdaten.wetterlagen(), w.name()), w.name());
        eintrag("wetterlagen", w.name(), alsMap(w), "Wetterlage " + w.name());
    }

    @Override public void loeschenWetterlage(String name) throws Fehler { eigen(mitgeliefert(Startdaten.wetterlagen(), name), name); loeschen("wetterlagen", name); }

    // ------------------------------------------------------------------ Regiebücher

    @Override public List<Daten.Regiebuch> regiebuecher() throws Fehler {
        List<Daten.Regiebuch> l = new ArrayList<>(Startdaten.regiebuecher());
        for (File f : dateien(sub("regiebuecher"))) {
            try {
                String t = Files.readString(f.toPath(), StandardCharsets.UTF_8);
                var b = com.dan.haithabu.scene.Regie.parse(t);
                l.add(new Daten.Regiebuch(b.name(), t, b.about(), Daten.EIGEN));
            } catch (IOException | RuntimeException e) {
                com.dan.store.Protokoll.warnung("Dateien", "Regiebuch " + f.getName() + " nicht lesbar: " + e.getMessage());
            }
        }
        return l;
    }

    @Override public void speichern(Daten.Regiebuch r) throws Fehler {
        eigen(mitgeliefert(Startdaten.regiebuecher(), r.name()), r.name());
        try { com.dan.haithabu.scene.Regie.parse(r.text()); } catch (RuntimeException e) { throw new Fehler("Regiebuch nicht lesbar: " + e.getMessage(), e); }
        schreibe(sub("regiebuecher", dateiname(r.name())), r.text());
    }

    @Override public void loeschenRegiebuch(String name) throws Fehler { eigen(mitgeliefert(Startdaten.regiebuecher(), name), name); loeschen("regiebuecher", name); }

    // ------------------------------------------------------------------ Fahrten

    static String punkteText(List<Daten.Stuetzpunkt> ps) {
        StringBuilder b = new StringBuilder();
        for (Daten.Stuetzpunkt p : ps)
            b.append(b.length() > 0 ? ";" : "").append(Zahl.text(p.zeitS())).append(' ').append(Zahl.text(p.x())).append(' ').append(Zahl.text(p.y())).append(' ')
                    .append(Zahl.text(p.z())).append(' ').append(Zahl.text(p.gier())).append(' ').append(Zahl.text(p.nick())).append(' ').append(Double.isNaN(p.fov()) ? "NaN" : Zahl.text(p.fov()));
        return b.toString();
    }

    static List<Daten.Stuetzpunkt> punkteAus(String t) {
        List<Daten.Stuetzpunkt> l = new ArrayList<>();
        if (t == null || t.isBlank()) return l;
        int nr = 0;
        for (String p : t.split(";")) {
            String[] v = p.strip().split(" ");
            l.add(new Daten.Stuetzpunkt(++nr, Zahl.lies(v[0]), Zahl.lies(v[1]), Zahl.lies(v[2]), Zahl.lies(v[3]), Zahl.lies(v[4]), Zahl.lies(v[5]), Zahl.lies(v[6])));
        }
        return l;
    }

    @Override public List<Daten.Fahrt> fahrten() throws Fehler {
        Startdaten.Szene sz = szene.get();
        List<Daten.Fahrt> l = new ArrayList<>(Startdaten.fahrten(sz == null ? null : sz.gasse()));
        for (LinkedHashMap<String, String> m : eintraege("fahrten")) {
            double t = Zahl.lies(m.get("taste"));
            l.add(new Daten.Fahrt(m.get("name"), Double.isNaN(t) ? null : (int) t, m.getOrDefault("art", "STUETZPUNKTE"), "true".equals(m.get("schleife")),
                    m.get("beschreibung"), Daten.EIGEN, punkteAus(m.get("punkte"))));
        }
        return l;
    }

    @Override public void speichern(Daten.Fahrt f) throws Fehler {
        eigen(mitgeliefert(Startdaten.fahrten(null), f.name()), f.name());
        LinkedHashMap<String, String> m = new LinkedHashMap<>();
        m.put("name", f.name());
        m.put("taste", f.taste() == null ? "" : f.taste().toString());
        m.put("art", f.art());
        m.put("schleife", Boolean.toString(f.schleife()));
        m.put("beschreibung", f.beschreibung() == null ? "" : f.beschreibung());
        m.put("punkte", punkteText(f.punkte()));
        eintrag("fahrten", f.name(), m, "Kamerafahrt " + f.name());
    }

    @Override public void loeschenFahrt(String name) throws Fehler { eigen(mitgeliefert(Startdaten.fahrten(null), name), name); loeschen("fahrten", name); }

    // ------------------------------------------------------------------ Ansichten

    private static Daten.Ansicht ansichtAus(Map<String, String> m, String zustand, byte[] png) {
        double[] k = new double[6];
        String[] n = {"x", "y", "z", "gier", "nick", "fov"};
        for (int i = 0; i < 6; i++) k[i] = Zahl.lies(m.get("kamera." + n[i]));
        Daten.Szenenzeit sz = null;
        if (m.get("sz.jahr") != null)
            sz = new Daten.Szenenzeit((int) Zahl.lies(m.get("sz.jahr")), (int) Zahl.lies(m.get("sz.monat")), (int) Zahl.lies(m.get("sz.tag")), Zahl.lies(m.get("sz.stunde")));
        return new Daten.Ansicht(Long.parseLong(m.get("id")), m.get("name"), null, "GEMERKT", k, null, false, null, sz, zustand, png, Daten.EIGEN);
    }

    @Override public List<Daten.Ansicht> ansichten() throws Fehler {
        List<Daten.Ansicht> l = new ArrayList<>(Startdaten.ansichten());
        List<Daten.Ansicht> g = new ArrayList<>();
        for (File f : dateien(sub("ansichten"))) {
            LinkedHashMap<String, String> m = lies(f);
            if (m.get("id") != null) g.add(ansichtAus(m, null, null));
        }
        g.sort((a, b) -> Long.compare(b.id(), a.id()));
        l.addAll(g);
        return l;
    }

    @Override public Daten.Ansicht ansicht(long id) throws Fehler {
        File f = sub("ansichten", id + ".txt");
        if (!f.isFile()) throw new Fehler("Ansicht " + id + " gibt es nicht");
        LinkedHashMap<String, String> m = lies(f);
        File z = sub("ansichten", id + ".zustand"), p = sub("ansichten", id + ".png");
        try {
            return ansichtAus(m, z.isFile() ? Files.readString(z.toPath(), StandardCharsets.UTF_8) : null, p.isFile() ? Files.readAllBytes(p.toPath()) : null);
        } catch (IOException e) {
            throw new Fehler("Ansicht " + id + " nicht lesbar: " + e.getMessage(), e);
        }
    }

    @Override public long speichern(Daten.Ansicht a, Long sitzung) throws Fehler {
        long id = naechsteNummer(sub("ansichten"));
        LinkedHashMap<String, String> m = new LinkedHashMap<>();
        m.put("id", Long.toString(id));
        m.put("name", a.name());
        String[] n = {"x", "y", "z", "gier", "nick", "fov"};
        for (int i = 0; i < 6; i++) m.put("kamera." + n[i], Zahl.text(a.kamera()[i]));
        if (a.szenenzeit() != null) {
            m.put("sz.jahr", Integer.toString(a.szenenzeit().jahr()));
            m.put("sz.monat", Integer.toString(a.szenenzeit().monat()));
            m.put("sz.tag", Integer.toString(a.szenenzeit().tag()));
            m.put("sz.stunde", Zahl.text(a.szenenzeit().stunde()));
        }
        if (sitzung != null) m.put("sitzung", sitzung.toString());
        schreibe(sub("ansichten", id + ".txt"), Felder.alsText(m, "Ansicht " + a.name()));
        if (a.zustand() != null) schreibe(sub("ansichten", id + ".zustand"), a.zustand());
        if (a.vorschau() != null) schreibe(sub("ansichten", id + ".png"), a.vorschau());
        return id;
    }

    @Override public void loeschenAnsicht(long id) throws Fehler {
        loesche(sub("ansichten", id + ".txt"), "Ansicht " + id);
        loesche(sub("ansichten", id + ".zustand"), "Ansicht " + id);
        loesche(sub("ansichten", id + ".png"), "Ansicht " + id);
    }

    // ------------------------------------------------------------------ Presets

    @Override public List<Daten.PaketPreset> presets(String paket, String klasse) throws Fehler {
        List<Daten.PaketPreset> l = new ArrayList<>();
        for (Daten.PaketPreset p : Startdaten.presets())
            if ((paket == null || p.paket().equals(paket)) && (klasse == null || p.klasse().equals(klasse))) l.add(p);
        File base = sub("presets");
        File[] ps = base.listFiles(File::isDirectory);
        if (ps == null) return l;
        for (File pd : ps) {
            if (paket != null && !pd.getName().equals(paket)) continue;
            File[] ks = pd.listFiles(File::isDirectory);
            if (ks == null) continue;
            for (File kd : ks) {
                if (klasse != null && !kd.getName().equals(klasse)) continue;
                for (File f : dateien(kd)) {
                    LinkedHashMap<String, String> m = lies(f);
                    String name = m.remove("#name"), about = m.remove("#beschreibung");
                    l.add(new Daten.PaketPreset(pd.getName(), kd.getName(), name == null ? f.getName().replace(".txt", "") : name, about, Daten.EIGEN, m));
                }
            }
        }
        return l;
    }

    private static boolean presetMitgeliefert(String paket, String klasse, String name) {
        for (Daten.PaketPreset p : Startdaten.presets()) if (p.paket().equals(paket) && p.klasse().equals(klasse) && p.name().equals(name)) return true;
        return false;
    }

    @Override public void speichern(Daten.PaketPreset p) throws Fehler {
        eigen(presetMitgeliefert(p.paket(), p.klasse(), p.name()), p.name());
        LinkedHashMap<String, String> m = new LinkedHashMap<>();
        m.put("#name", p.name());
        m.put("#beschreibung", p.beschreibung() == null ? "" : p.beschreibung());
        m.putAll(p.felder());
        schreibe(sub("presets", p.paket(), p.klasse(), dateiname(p.name())), Felder.alsText(m, "Preset " + p.paket() + "." + p.klasse() + " · " + p.name()));
    }

    @Override public void loeschenPreset(String paket, String klasse, String name) throws Fehler {
        eigen(presetMitgeliefert(paket, klasse, name), name);
        loesche(sub("presets", paket, klasse, dateiname(name)), name);
    }

    // ------------------------------------------------------------------ Sitzung

    @Override public Daten.Sitzung letzteSitzung(long ausser) throws Fehler {
        LinkedHashMap<String, String> m = super.letzteSitzungText(ausser);
        if (m == null) return null;
        String ende = m.get("ende"), zz = m.get("zustandZeit");
        Daten.Szenenzeit sz = null;
        String s = m.get(SZ);
        if (s != null && !s.isEmpty()) sz = Zustand.szenenzeit(s);
        double rs = Zahl.lies(m.get(REGIE_SEKUNDE));
        return new Daten.Sitzung(Long.parseLong(m.get("id")), Long.parseLong(m.get("beginn")), ende == null || ende.isEmpty() ? null : Long.parseLong(ende),
                "true".equals(m.get("sauber")), m.get("zustand"), zz == null ? null : Long.parseLong(zz), m.get(SIEDLUNG), emptyNull(m.get(REGIEBUCH)),
                Double.isNaN(rs) ? null : rs, sz);
    }

    private static String emptyNull(String s) { return s == null || s.isEmpty() ? null : s; }
}
