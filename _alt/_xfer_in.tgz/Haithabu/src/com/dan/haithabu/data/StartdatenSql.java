package com.dan.haithabu.data;

import com.dan.haithabu.scene.Regie;
import com.dan.store.Felder;
import com.dan.store.Zahl;
import com.dan.weather.Weather;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Schreibt die mitgelieferten Daten als SQL: {@code db/sql/04_startdaten.sql} (erzeugt von {@code tools.StartdatenSql},
 * nicht von Hand ändern). MERGE je Eintrag mit Namen; Kinder und die Zeilen der mitgelieferten Siedlung werden gelöscht
 * und neu angelegt. Eigene Zeilen (HERKUNFT = 'EIGEN') bleiben unberührt. Beliebig oft wiederholbar.
 * <p>
 * Geometrien: Punkte als {@code SDO_POINT_TYPE}, Linien und Flächen als WKT über {@code SDO_GEOMETRY(wkt, 8307)};
 * lange WKT in Stücken zu höchstens 1 000 Zeichen als {@code TO_CLOB(…) || TO_CLOB(…)}, je Stück eine Zeile, damit
 * SQL Developer, SQLcl und der Einrichter jede Zeile ohne Grenze lesen.
 */
public final class StartdatenSql {
    private StartdatenSql() { }

    static final String M = "'MITGELIEFERT'";

    static String s(String v) {
        if (v == null) return "NULL";
        return "'" + v.replace("'", "''").replace("\r", "").replace("\n", "' || CHR(10) || '") + "'";
    }

    static String n(Double v) { return v == null || Double.isNaN(v) ? "NULL" : Zahl.text(Math.round(v * 1e6) / 1e6); }

    static String n(double v) { return n((Double) v); }

    static String n3(double v) { return Double.isNaN(v) ? "NULL" : Zahl.text(Math.round(v * 1000) / 1000.0); }

    static String b(boolean v) { return v ? "1" : "0"; }

    /** Ein Punkt in Länge und Breite. */
    static String punkt(double x, double z) {
        double[] ll = Daten.lonLat(x, z);
        return "MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(" + Zahl.text(Math.round(ll[0] * 1e8) / 1e8) + ", " + Zahl.text(Math.round(ll[1] * 1e8) / 1e8) + ", NULL), NULL, NULL)";
    }

    static String geom(Daten.Geom g) {
        if (g.art().equals("PUNKT")) return punkt(g.xz()[0][0], g.xz()[0][1]);
        String w = g.wkt();
        if (w.length() <= 1000) return "MDSYS.SDO_GEOMETRY(" + s(w) + ", 8307)";
        StringBuilder b = new StringBuilder("MDSYS.SDO_GEOMETRY(");
        for (int i = 0; i < w.length(); i += 1000) b.append(i > 0 ? "\n    || " : "").append("TO_CLOB(").append(s(w.substring(i, Math.min(w.length(), i + 1000)))).append(")");
        return b.append(", 8307)").toString();
    }

    private static void kopf(StringBuilder b, String t) {
        b.append("\n-- ").append("-".repeat(Math.max(4, 100 - t.length()))).append(' ').append(t).append('\n');
    }

    /** Das ganze Skript. */
    public static String sql(Startdaten.Szene sz) {
        StringBuilder b = new StringBuilder();
        Map<String, Integer> z = zahlen(sz);
        b.append("""
                -- =====================================================================================================
                -- Haithabu · Datenbank · 04_startdaten.sql
                -- ERZEUGT aus com.dan.haithabu.data.Startdaten (tools.StartdatenSql) – nicht von Hand ändern.
                -- Mitgelieferte Zeilen (HERKUNFT = 'MITGELIEFERT') werden angelegt oder wiederhergestellt; eigene Zeilen
                -- bleiben unberührt. Beliebig oft wiederholbar. Die Siedlung „Haithabu 950“ und der Lageplan sind aus der
                -- Szene gerechnet (Startwert 950, Gelände aus daten/gelaende, Prüfsumme in HB_GELAENDE).
                -- =====================================================================================================
                """);
        StringBuilder zl = new StringBuilder("-- ZAHLEN:");
        for (Map.Entry<String, Integer> e : z.entrySet()) zl.append(' ').append(e.getKey()).append('=').append(e.getValue()).append(';');
        b.append(zl).append("\n\n-- Die Quellen enthalten „&“: in SQL Developer keine Ersetzungsvariablen\nSET DEFINE OFF\n");

        kopf(b, "Ausbaustufe");
        b.append("MERGE INTO HB_SCHEMA t USING (SELECT 1 AS VERSION FROM DUAL) q ON (t.VERSION = q.VERSION)\n")
                .append("WHEN NOT MATCHED THEN INSERT (VERSION, APP_VERSION, TEXT) VALUES (1, 'Phase 16', ")
                .append(s("Oberfläche und Datenbank: 22 Tabellen, Lageplan, Regiebücher als Text, Befunde")).append(");\n");

        kopf(b, "Quellen");
        for (Daten.Quelle q : Startdaten.quellen()) {
            String ab = q.abgerufen() == null ? "NULL" : "DATE '" + q.abgerufen() + "'";
            b.append("MERGE INTO HB_QUELLE t USING (SELECT ").append(s(q.kurz())).append(" AS KURZ FROM DUAL) q ON (t.KURZ = q.KURZ)\n")
                    .append("WHEN MATCHED THEN UPDATE SET t.TITEL = ").append(s(q.titel())).append(", t.URL = ").append(s(q.url())).append(", t.ART = ").append(s(q.art()))
                    .append(", t.ABGERUFEN = ").append(ab).append(", t.BEMERKUNG = ").append(s(q.bemerkung())).append(" WHERE t.HERKUNFT = ").append(M).append('\n')
                    .append("WHEN NOT MATCHED THEN INSERT (KURZ, TITEL, URL, ART, ABGERUFEN, BEMERKUNG, HERKUNFT) VALUES (").append(s(q.kurz())).append(", ")
                    .append(s(q.titel())).append(", ").append(s(q.url())).append(", ").append(s(q.art())).append(", ").append(ab).append(", ").append(s(q.bemerkung()))
                    .append(", ").append(M).append(");\n");
        }

        kopf(b, "Befunde");
        for (Daten.Befund f : Startdaten.befunde()) {
            b.append("MERGE INTO HB_BEFUND t USING (SELECT ").append(s(f.thema())).append(" AS THEMA, ").append(s(f.gegenstand()))
                    .append(" AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)\n")
                    .append("WHEN MATCHED THEN UPDATE SET t.BEFUND = ").append(s(f.befund())).append(", t.TEXT = ").append(s(f.text())).append(" WHERE t.HERKUNFT = ").append(M).append('\n')
                    .append("WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES (").append(s(f.thema())).append(", ").append(s(f.gegenstand()))
                    .append(", ").append(s(f.befund())).append(", ").append(s(f.text())).append(", ").append(M).append(");\n");
        }
        b.append("DELETE FROM HB_BEFUND_QUELLE WHERE BEFUND_ID IN (SELECT ID FROM HB_BEFUND WHERE HERKUNFT = ").append(M).append(");\n");
        for (Daten.Befund f : Startdaten.befunde())
            for (String q : f.quellen())
                b.append("INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = ")
                        .append(s(f.gegenstand())).append(" AND b.HERKUNFT = ").append(M).append(" AND q.KURZ = ").append(s(q)).append(";\n");

        kopf(b, "Haustypen");
        for (Daten.Haustyp t : Startdaten.haustypen()) {
            String bid = "(SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = " + s(t.befundGegenstand()) + ")";
            b.append("MERGE INTO HB_HAUSTYP t USING (SELECT ").append(s(t.name())).append(" AS NAME, ").append(bid).append(" AS BID FROM DUAL) q ON (t.NAME = q.NAME)\n")
                    .append("WHEN MATCHED THEN UPDATE SET t.BEZEICHNUNG = ").append(s(t.bezeichnung())).append(", t.LAENGE_M = ").append(n(t.laengeM())).append(", t.BREITE_M = ")
                    .append(n(t.breiteM())).append(", t.WANDHOEHE_M = ").append(n(t.wandhoeheM())).append(", t.DACHNEIGUNG_GRAD = ").append(n(t.dachneigungGrad()))
                    .append(", t.WAND = ").append(s(t.wand())).append(", t.EINGETIEFT_M = ").append(n(t.eingetieftM())).append(", t.BEFUND = ").append(s(t.befund()))
                    .append(", t.BEFUND_ID = q.BID, t.BESCHREIBUNG = ").append(s(t.beschreibung())).append(" WHERE t.HERKUNFT = ").append(M).append('\n')
                    .append("WHEN NOT MATCHED THEN INSERT (NAME, BEZEICHNUNG, LAENGE_M, BREITE_M, WANDHOEHE_M, DACHNEIGUNG_GRAD, WAND, EINGETIEFT_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)\n  VALUES (")
                    .append(s(t.name())).append(", ").append(s(t.bezeichnung())).append(", ").append(n(t.laengeM())).append(", ").append(n(t.breiteM())).append(", ")
                    .append(n(t.wandhoeheM())).append(", ").append(n(t.dachneigungGrad())).append(", ").append(s(t.wand())).append(", ").append(n(t.eingetieftM())).append(", ")
                    .append(s(t.befund())).append(", q.BID, ").append(s(t.beschreibung())).append(", ").append(M).append(");\n");
        }

        kopf(b, "Siedlung „Haithabu 950“");
        Daten.Siedlung si = sz.siedlung();
        b.append("MERGE INTO HB_SIEDLUNG t USING (SELECT ").append(s(si.name())).append(" AS NAME FROM DUAL) q ON (t.NAME = q.NAME)\n")
                .append("WHEN MATCHED THEN UPDATE SET t.STARTWERT = ").append(si.startwert()).append(", t.HAEUSER = ").append(sz.haeuser().size()).append(", t.BESCHREIBUNG = ")
                .append(s(si.beschreibung())).append(" WHERE t.HERKUNFT = ").append(M).append('\n')
                .append("WHEN NOT MATCHED THEN INSERT (NAME, STARTWERT, AKTIV, HAEUSER, BESCHREIBUNG, HERKUNFT) VALUES (").append(s(si.name())).append(", ")
                .append(si.startwert()).append(", 0, ").append(sz.haeuser().size()).append(", ").append(s(si.beschreibung())).append(", ").append(M).append(");\n");
        b.append("UPDATE HB_SIEDLUNG SET AKTIV = 1 WHERE NAME = ").append(s(si.name())).append(" AND NOT EXISTS (SELECT 1 FROM HB_SIEDLUNG WHERE AKTIV = 1);\n");
        String sid = "FROM HB_SIEDLUNG s WHERE s.NAME = " + s(si.name()) + " AND s.HERKUNFT = " + M;
        String sw = "(SELECT ID FROM HB_SIEDLUNG WHERE NAME = " + s(si.name()) + " AND HERKUNFT = " + M + ")";
        b.append("DELETE FROM HB_HAUS WHERE SIEDLUNG_ID IN ").append(sw).append(";\n");
        b.append("DELETE FROM HB_WEG WHERE SIEDLUNG_ID IN ").append(sw).append(";\n");
        Map<String, Daten.Haustyp> typen = new LinkedHashMap<>();
        for (Daten.Haustyp t : Startdaten.haustypen()) typen.put(t.name(), t);
        for (Daten.Haus h : sz.haeuser()) {
            b.append("INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)\n")
                    .append("  SELECT s.ID, ").append(h.nr()).append(", ").append(s(h.name())).append(", (SELECT ID FROM HB_HAUSTYP WHERE NAME = ").append(s(h.haustyp())).append("), ")
                    .append(s(h.rolle())).append(",\n    ").append(punkt(h.x(), h.z())).append(",\n    ").append(geom(h.grundriss(typen.get(h.haustyp())))).append(",\n    ")
                    .append(n3(h.x())).append(", ").append(n3(h.z())).append(", ").append(Zahl.text(Math.round(h.y() * 100) / 100.0)).append(", ")
                    .append(Zahl.text(Math.round(h.richtungGrad() * 100) / 100.0)).append(", ").append(n3(h.laengeFaktor())).append(", ").append(n3(h.breiteFaktor()))
                    .append(", ").append(n3(h.zustand())).append(", ").append(h.zufall()).append(", ").append(b(h.museum())).append(' ').append(sid).append(";\n");
        }
        for (Daten.Weg w : sz.wege())
            b.append("INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, ").append(s(w.art())).append(", ").append(s(w.name())).append(",\n    ")
                    .append(geom(w.geom())).append(",\n    ").append(n(w.breiteM())).append(' ').append(sid).append(";\n");

        kopf(b, "Lageplan");
        b.append("DELETE FROM HB_BAUWERK WHERE HERKUNFT = ").append(M).append(";\n");
        for (Daten.Bauwerk w : sz.bauwerke())
            b.append("INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)\n  SELECT ").append(s(w.art())).append(", ")
                    .append(s(w.name())).append(",\n    ").append(geom(w.geom())).append(",\n    ").append(n(w.hoeheM())).append(", ").append(n(w.breiteM())).append(", ")
                    .append(s(w.befund())).append(", (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = ").append(s(w.befundGegenstand())).append("), ")
                    .append(s(w.beschreibung())).append(", ").append(M).append(" FROM DUAL;\n");

        kopf(b, "Gelände");
        Daten.Gelaende g = sz.gelaende();
        String ursprung = "MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(" + Zahl.text(g.ursprungLon()) + ", " + Zahl.text(g.ursprungLat()) + ", NULL), NULL, NULL)";
        String set = "t.QUELLE = " + s(g.quelle()) + ", t.AUSSCHNITT = " + geom(g.ausschnitt()) + ", t.URSPRUNG = " + ursprung + ",\n    t.RASTER_M = " + n(g.rasterM())
                + ", t.SPALTEN = " + g.spalten() + ", t.ZEILEN = " + g.zeilen() + ", t.ANTEIL_GEMESSEN_PROZ = " + n(g.anteilGemessenProz()) + ", t.DATEI = " + s(g.datei())
                + ", t.PRUEFSUMME = " + s(g.pruefsumme()) + ",\n    t.EINGRIFFE = " + s(g.eingriffe());
        b.append("MERGE INTO HB_GELAENDE t USING (SELECT ").append(s(g.name())).append(" AS NAME FROM DUAL) q ON (t.NAME = q.NAME)\n")
                .append("WHEN MATCHED THEN UPDATE SET ").append(set).append(" WHERE t.HERKUNFT = ").append(M).append('\n')
                .append("WHEN NOT MATCHED THEN INSERT (NAME, QUELLE, AUSSCHNITT, URSPRUNG, RASTER_M, SPALTEN, ZEILEN, ANTEIL_GEMESSEN_PROZ, DATEI, PRUEFSUMME, EINGRIFFE, HERKUNFT)\n  VALUES (")
                .append(s(g.name())).append(", ").append(s(g.quelle())).append(", ").append(geom(g.ausschnitt())).append(", ").append(ursprung).append(", ").append(n(g.rasterM()))
                .append(", ").append(g.spalten()).append(", ").append(g.zeilen()).append(", ").append(n(g.anteilGemessenProz())).append(", ").append(s(g.datei())).append(", ")
                .append(s(g.pruefsumme())).append(", ").append(s(g.eingriffe())).append(", ").append(M).append(");\n");

        kopf(b, "Schiffe");
        for (Daten.Schiffstyp t : Startdaten.schiffstypen()) {
            String bid = "(SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = " + s(t.befundGegenstand()) + ")";
            b.append("MERGE INTO HB_SCHIFFSTYP t USING (SELECT ").append(s(t.name())).append(" AS NAME, ").append(bid).append(" AS BID FROM DUAL) q ON (t.NAME = q.NAME)\n")
                    .append("WHEN MATCHED THEN UPDATE SET t.BEZEICHNUNG = ").append(s(t.bezeichnung())).append(", t.VORBILD = ").append(s(t.vorbild())).append(", t.LAENGE_M = ")
                    .append(n(t.laengeM())).append(", t.BREITE_M = ").append(n(t.breiteM())).append(", t.TIEFGANG_M = ").append(n(t.tiefgangM())).append(", t.RIEMENPAARE = ")
                    .append(t.riemenpaare()).append(", t.SEGEL = ").append(b(t.segel())).append(", t.MASSE_KG = ").append(n(t.masseKg())).append(", t.BEFUND = ").append(s(t.befund()))
                    .append(", t.BEFUND_ID = q.BID WHERE t.HERKUNFT = ").append(M).append('\n')
                    .append("WHEN NOT MATCHED THEN INSERT (NAME, BEZEICHNUNG, VORBILD, LAENGE_M, BREITE_M, TIEFGANG_M, RIEMENPAARE, SEGEL, MASSE_KG, BEFUND, BEFUND_ID, HERKUNFT)\n  VALUES (")
                    .append(s(t.name())).append(", ").append(s(t.bezeichnung())).append(", ").append(s(t.vorbild())).append(", ").append(n(t.laengeM())).append(", ")
                    .append(n(t.breiteM())).append(", ").append(n(t.tiefgangM())).append(", ").append(t.riemenpaare()).append(", ").append(b(t.segel())).append(", ")
                    .append(n(t.masseKg())).append(", ").append(s(t.befund())).append(", q.BID, ").append(M).append(");\n");
        }
        for (Daten.Schiff f : sz.schiffe()) {
            String lp = f.x() == null ? "NULL" : punkt(f.x(), f.z());
            String tid = "(SELECT ID FROM HB_SCHIFFSTYP WHERE NAME = " + s(f.typ()) + ")";
            b.append("MERGE INTO HB_SCHIFF t USING (SELECT ").append(s(f.name())).append(" AS NAME, ").append(tid).append(" AS TID FROM DUAL) q ON (t.NAME = q.NAME)\n")
                    .append("WHEN MATCHED THEN UPDATE SET t.SCHIFFSTYP_ID = q.TID, t.ROLLE = ").append(s(f.rolle())).append(", t.LIEGEPLATZ = ").append(lp)
                    .append(", t.RICHTUNG_GRAD = ").append(n(f.richtungGrad() == null ? null : Math.round(f.richtungGrad() * 100) / 100.0)).append(", t.LADUNG = ").append(s(f.ladung()))
                    .append(" WHERE t.HERKUNFT = ").append(M).append('\n')
                    .append("WHEN NOT MATCHED THEN INSERT (NAME, SCHIFFSTYP_ID, ROLLE, LIEGEPLATZ, RICHTUNG_GRAD, LADUNG, HERKUNFT) VALUES (").append(s(f.name())).append(", q.TID, ")
                    .append(s(f.rolle())).append(", ").append(lp).append(", ").append(n(f.richtungGrad() == null ? null : Math.round(f.richtungGrad() * 100) / 100.0)).append(", ")
                    .append(s(f.ladung())).append(", ").append(M).append(");\n");
        }

        kopf(b, "Wetterlagen");
        for (Daten.Wetterlage w : Startdaten.wetterlagen()) {
            StringBuilder cols = new StringBuilder("NAME, BEAUFORT, PHASE"), vals = new StringBuilder(s(w.name()) + ", " + n(w.beaufort()) + ", " + s(w.phase()));
            StringBuilder upd = new StringBuilder("t.BEAUFORT = " + n(w.beaufort()) + ", t.PHASE = " + s(w.phase()));
            for (Map.Entry<Weather.Var, String> e : Verbindung.WETTER.entrySet()) {
                String v = wert(e.getKey(), w.werte()[e.getKey().ordinal()]);
                cols.append(", ").append(e.getValue());
                vals.append(", ").append(v);
                upd.append(", t.").append(e.getValue()).append(" = ").append(v);
            }
            b.append("MERGE INTO HB_WETTERLAGE t USING (SELECT ").append(s(w.name())).append(" AS NAME FROM DUAL) q ON (t.NAME = q.NAME)\n")
                    .append("WHEN MATCHED THEN UPDATE SET ").append(upd).append(", t.MONATE = ").append(s(w.monate())).append(", t.BESCHREIBUNG = ").append(s(w.beschreibung()))
                    .append(" WHERE t.HERKUNFT = ").append(M).append('\n')
                    .append("WHEN NOT MATCHED THEN INSERT (").append(cols).append(", MONATE, BESCHREIBUNG, HERKUNFT)\n  VALUES (").append(vals).append(", ").append(s(w.monate()))
                    .append(", ").append(s(w.beschreibung())).append(", ").append(M).append(");\n");
        }

        kopf(b, "Regiebücher");
        for (Daten.Regiebuch r : Startdaten.regiebuecher()) {
            Regie.Book bk = Regie.parse(r.text());
            Kopf k = Kopf.aus(bk);
            String wetter = Regie.wetterBlock(r.text());
            b.append("MERGE INTO HB_REGIEBUCH t USING (SELECT ").append(s(r.name())).append(" AS NAME FROM DUAL) q ON (t.NAME = q.NAME)\n")
                    .append("WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = ").append(s(r.beschreibung())).append(", t.SZ_JAHR = ").append(k.jahr).append(", t.SZ_MONAT = ")
                    .append(k.monat).append(", t.SZ_TAG = ").append(k.tag).append(", t.SZ_STUNDE = ").append(n(k.stunde)).append(", t.ZEITRAFFER = ").append(n(k.raffer))
                    .append(", t.LAENGE_S = ").append(n(bk.length())).append(", t.BLATT = 1, t.WETTER = ").append(s(wetter)).append(" WHERE t.HERKUNFT = ").append(M).append('\n')
                    .append("WHEN NOT MATCHED THEN INSERT (NAME, BESCHREIBUNG, SZ_JAHR, SZ_MONAT, SZ_TAG, SZ_STUNDE, ZEITRAFFER, LAENGE_S, BLATT, WETTER, HERKUNFT)\n  VALUES (")
                    .append(s(r.name())).append(", ").append(s(r.beschreibung())).append(", ").append(k.jahr).append(", ").append(k.monat).append(", ").append(k.tag).append(", ")
                    .append(n(k.stunde)).append(", ").append(n(k.raffer)).append(", ").append(n(bk.length())).append(", 1, ").append(s(wetter)).append(", ").append(M).append(");\n");
            String eltern = "FROM HB_REGIEBUCH WHERE NAME = " + s(r.name()) + " AND HERKUNFT = " + M;
            b.append("DELETE FROM HB_STICHWORT WHERE REGIEBUCH_ID IN (SELECT ID ").append(eltern).append(");\n");
            int nr = 0;
            for (Regie.Zeile zz : bk.zeilen())
                b.append("INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, ").append(++nr).append(", ").append(n(zz.sekunde())).append(", ")
                        .append(s(zz.befehl().toUpperCase(java.util.Locale.ROOT))).append(", ").append(s(zz.argumente().isEmpty() ? null : zz.argumente())).append(", ")
                        .append(s(zz.text().isEmpty() ? null : zz.text())).append(' ').append(eltern).append(";\n");
        }

        kopf(b, "Ansichten (Tasten 1–7)");
        for (Daten.Ansicht a : Startdaten.ansichten()) {
            double[] c = a.kamera();
            String upd = "t.TASTE = " + a.taste() + ", t.KAM_X = " + n(c[0]) + ", t.KAM_Z = " + n(c[2]) + ", t.KAM_GIER_GRAD = " + n(c[3]) + ", t.KAM_NICK_GRAD = " + n(c[4])
                    + ", t.AUGE_UEBER_GRUND_M = " + n(a.augeUeberGrund()) + ", t.ORBIT = " + b(a.orbit()) + ", t.ABSTAND_M = " + n(a.abstandM());
            b.append("MERGE INTO HB_ANSICHT t USING (SELECT ").append(s(a.name())).append(" AS NAME FROM DUAL) q ON (t.NAME = q.NAME AND t.ART = 'FEST')\n")
                    .append("WHEN MATCHED THEN UPDATE SET ").append(upd).append(" WHERE t.HERKUNFT = ").append(M).append('\n')
                    .append("WHEN NOT MATCHED THEN INSERT (NAME, TASTE, ART, KAM_X, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, AUGE_UEBER_GRUND_M, ORBIT, ABSTAND_M, HERKUNFT)\n  VALUES (")
                    .append(s(a.name())).append(", ").append(a.taste()).append(", 'FEST', ").append(n(c[0])).append(", ").append(n(c[2])).append(", ").append(n(c[3])).append(", ")
                    .append(n(c[4])).append(", ").append(n(a.augeUeberGrund())).append(", ").append(b(a.orbit())).append(", ").append(n(a.abstandM())).append(", ").append(M).append(");\n");
        }

        kopf(b, "Kamerafahrten");
        for (Daten.Fahrt f : Startdaten.fahrten(sz.gasse())) {
            b.append("MERGE INTO HB_FAHRT t USING (SELECT ").append(s(f.name())).append(" AS NAME FROM DUAL) q ON (t.NAME = q.NAME)\n")
                    .append("WHEN MATCHED THEN UPDATE SET t.TASTE = ").append(f.taste()).append(", t.ART = ").append(s(f.art())).append(", t.SCHLEIFE = ").append(b(f.schleife()))
                    .append(", t.BESCHREIBUNG = ").append(s(f.beschreibung())).append(" WHERE t.HERKUNFT = ").append(M).append('\n')
                    .append("WHEN NOT MATCHED THEN INSERT (NAME, TASTE, ART, SCHLEIFE, BESCHREIBUNG, HERKUNFT) VALUES (").append(s(f.name())).append(", ").append(f.taste()).append(", ")
                    .append(s(f.art())).append(", ").append(b(f.schleife())).append(", ").append(s(f.beschreibung())).append(", ").append(M).append(");\n");
            String eltern = "FROM HB_FAHRT WHERE NAME = " + s(f.name()) + " AND HERKUNFT = " + M;
            b.append("DELETE FROM HB_STUETZPUNKT WHERE FAHRT_ID IN (SELECT ID ").append(eltern).append(");\n");
            for (Daten.Stuetzpunkt p : f.punkte())
                b.append("INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, ").append(p.nr()).append(", ")
                        .append(Zahl.text(Math.round(p.zeitS() * 100) / 100.0)).append(", ").append(Zahl.text(Math.round(p.x() * 100) / 100.0)).append(", ")
                        .append(Zahl.text(Math.round(p.y() * 100) / 100.0)).append(", ").append(Zahl.text(Math.round(p.z() * 100) / 100.0)).append(", ")
                        .append(Zahl.text(Math.round(p.gier() * 100) / 100.0)).append(", ").append(Zahl.text(Math.round(p.nick() * 100) / 100.0)).append(", ")
                        .append(n(p.fov())).append(' ').append(eltern).append(";\n");
        }

        kopf(b, "Presets der Packages");
        for (Daten.PaketPreset p : Startdaten.presets()) {
            String key = "PAKET = " + s(p.paket()) + " AND KLASSE = " + s(p.klasse()) + " AND NAME = " + s(p.name());
            b.append("MERGE INTO HB_PAKET_PRESET t USING (SELECT ").append(s(p.paket())).append(" AS PAKET, ").append(s(p.klasse())).append(" AS KLASSE, ").append(s(p.name()))
                    .append(" AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)\n")
                    .append("WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = ").append(s(p.beschreibung())).append(" WHERE t.HERKUNFT = ").append(M).append('\n')
                    .append("WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES (").append(s(p.paket())).append(", ").append(s(p.klasse()))
                    .append(", ").append(s(p.name())).append(", ").append(s(p.beschreibung())).append(", ").append(M).append(");\n");
            String eltern = "FROM HB_PAKET_PRESET WHERE " + key + " AND HERKUNFT = " + M;
            b.append("DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID ").append(eltern).append(");\n");
            Map<String, String> typ = typen(p);
            for (Map.Entry<String, String> e : p.felder().entrySet())
                b.append("INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, ").append(s(e.getKey())).append(", ").append(s(typ.getOrDefault(e.getKey(), "STRING")))
                        .append(", ").append(s(e.getValue().isEmpty() ? null : e.getValue())).append(' ').append(eltern).append(";\n");
        }
        b.append("\nCOMMIT;\n\n-- Ende 04_startdaten.sql\n");
        return b.toString();
    }

    /** Die Zahl einer Wetterspalte als SQL (Wolkenart als Name). */
    static String wert(Weather.Var v, double x) {
        if (Double.isNaN(x)) return "NULL";
        if (v == Weather.Var.CLOUD) return s(Weather.CloudKind.values()[(int) Math.max(0, Math.min(Weather.CloudKind.values().length - 1, Math.round(x)))].name());
        return n(x);
    }

    static Map<String, String> typen(Daten.PaketPreset p) {
        try { return Felder.typen(Class.forName(p.paket() + "." + p.klasse())); } catch (ClassNotFoundException e) { return Map.of(); }
    }

    /** Beginn und Zeitraffer eines Regiebuchs: aus dem ersten „zeit“ und dem ersten „raffer“. */
    record Kopf(String jahr, String monat, String tag, Double stunde, Double raffer) {
        static Kopf aus(Regie.Book bk) {
            String j = "NULL", m = "NULL", d = "NULL";
            Double h = null, r = null;
            for (Regie.Zeile z : bk.zeilen()) {
                if (z.befehl().equals("zeit") && h == null) {
                    String[] p = z.argumente().split("\\s+"), dd = p[0].split("\\.");
                    d = dd[0]; m = dd[1]; j = dd[2];
                    String[] hm = p[1].split(":");
                    h = Integer.parseInt(hm[0]) + Integer.parseInt(hm[1]) / 60.0;
                }
                if (z.befehl().equals("raffer") && r == null) r = Double.parseDouble(z.argumente());
            }
            return new Kopf(j, m, d, h, r);
        }
    }

    /** Wie viele Zeilen je Art mitkommen (für die Zeile „-- ZAHLEN:“ und den Einrichter). */
    public static Map<String, Integer> zahlen(Startdaten.Szene sz) {
        Map<String, Integer> m = new LinkedHashMap<>();
        List<Daten.Befund> bf = Startdaten.befunde();
        int belege = 0;
        for (Daten.Befund f : bf) belege += f.quellen().size();
        int stich = 0;
        for (Daten.Regiebuch r : Startdaten.regiebuecher()) stich += Regie.parse(r.text()).zeilen().size();
        int werte = 0;
        for (Daten.PaketPreset p : Startdaten.presets()) werte += p.felder().size();
        m.put("Quellen", Startdaten.quellen().size());
        m.put("Befunde", bf.size());
        m.put("Belege", belege);
        m.put("Haustypen", Startdaten.haustypen().size());
        m.put("Siedlungen", 1);
        m.put("Häuser", sz.haeuser().size());
        m.put("Wege", sz.wege().size());
        m.put("Bauwerke", sz.bauwerke().size());
        m.put("Gelände", 1);
        m.put("Schiffstypen", Startdaten.schiffstypen().size());
        m.put("Schiffe", sz.schiffe().size());
        m.put("Wetterlagen", Startdaten.wetterlagen().size());
        m.put("Regiebücher", Startdaten.regiebuecher().size());
        m.put("Stichworte", stich);
        m.put("Ansichten", Startdaten.ansichten().size());
        m.put("Fahrten", 3);
        m.put("Stützpunkte", sz.gasse() == null ? 0 : sz.gasse().size());
        m.put("Presets", Startdaten.presets().size());
        m.put("Presetwerte", werte);
        return m;
    }
}
