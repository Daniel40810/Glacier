package com.dan.haithabu.data;

import com.dan.haithabu.scene.Regie;
import com.dan.store.Db;
import com.dan.store.Protokoll;
import com.dan.store.Wkt;
import com.dan.weather.Weather;

import java.io.StringReader;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Speichern im Schema HAITHABU (F26 A). Eine Verbindung, alle Zugriffe synchronisiert (der Faden der Daten und die
 * Oberfläche teilen sie). Geometrien schreibt sie als WKT über {@code SDO_GEOMETRY(?, 8307)} und liest sie mit
 * {@code SDO_UTIL.TO_WKTGEOMETRY}, ohne {@code sdoapi}. Mitgelieferte Zeilen werden nie überschrieben.
 */
public final class DbSpeicher implements Speicher {
    private final Db.Konfig konfig;
    private Connection c;
    private final String wo;

    public DbSpeicher(Db.Konfig k) throws Fehler {
        this.konfig = k;
        try {
            c = Db.oeffnen(k);
            String w = Db.einWert(c, "select user || ' auf ' || sys_context('USERENV','CON_NAME') from dual");
            wo = "Datenbank " + w;
        } catch (SQLException e) {
            throw new Fehler("Keine Verbindung zu " + k.kurz() + ": " + Db.erste(e), e);
        }
    }

    /** Für Prüfungen und den Einrichter: die offene Verbindung. */
    public synchronized Connection verbindung() throws Fehler {
        try {
            if (c == null || c.isClosed() || !c.isValid(3)) c = Db.oeffnen(konfig);
            return c;
        } catch (SQLException e) {
            throw new Fehler("Verbindung verloren: " + Db.erste(e), e);
        }
    }

    @Override public String wo() { return wo; }
    @Override public boolean datenbank() { return true; }

    private interface Arbeit<T> { T tun(Connection c) throws SQLException; }

    private synchronized <T> T mit(String was, Arbeit<T> a) throws Fehler {
        Connection cc = verbindung();
        try {
            return a.tun(cc);
        } catch (SQLException e) {
            throw new Fehler(was + ": " + Db.erste(e), e);
        }
    }

    /** In einer Transaktion: alles oder nichts. */
    private synchronized void zusammen(String was, Arbeit<Void> a) throws Fehler {
        Connection cc = verbindung();
        try {
            cc.setAutoCommit(false);
            a.tun(cc);
            cc.commit();
        } catch (SQLException e) {
            try { cc.rollback(); } catch (SQLException e2) { /* weiter */ }
            throw new Fehler(was + ": " + Db.erste(e), e);
        } finally {
            try { cc.setAutoCommit(true); } catch (SQLException e) { /* weiter */ }
        }
    }

    private static int zahl(Connection c, String sql, Object... a) throws SQLException {
        String v = Db.einWert(c, sql, a);
        return v == null ? 0 : Integer.parseInt(v);
    }

    private static void setD(PreparedStatement st, int i, Double v) throws SQLException {
        if (v == null || Double.isNaN(v)) st.setNull(i, Types.NUMERIC); else st.setDouble(i, v);
    }

    private static void setS(PreparedStatement st, int i, String v) throws SQLException {
        if (v == null || v.isEmpty()) st.setNull(i, Types.VARCHAR);
        else if (v.length() > 3900) st.setCharacterStream(i, new StringReader(v), v.length());
        else st.setString(i, v);
    }

    private static void setI(PreparedStatement st, int i, Integer v) throws SQLException {
        if (v == null) st.setNull(i, Types.NUMERIC); else st.setInt(i, v);
    }

    private static Double dbl(ResultSet r, String col) throws SQLException {
        double v = r.getDouble(col);
        return r.wasNull() ? null : v;
    }

    private static double d(ResultSet r, String col) throws SQLException {
        double v = r.getDouble(col);
        return r.wasNull() ? Double.NaN : v;
    }

    private static Integer integer(ResultSet r, String col) throws SQLException {
        int v = r.getInt(col);
        return r.wasNull() ? null : v;
    }

    private static String clob(ResultSet r, String col) throws SQLException {
        Clob cl = r.getClob(col);
        return cl == null ? null : cl.getSubString(1, (int) cl.length());
    }

    private static void eigen(boolean mitgeliefert, String was) throws Fehler {
        if (mitgeliefert) throw new Fehler("„" + was + "“ ist mitgeliefert und wird nicht überschrieben; bitte unter einem eigenen Namen speichern");
    }

    private static boolean mitgeliefert(Connection c, String tabelle, String name) throws SQLException {
        return zahl(c, "SELECT COUNT(*) FROM " + tabelle + " WHERE NAME = ? AND HERKUNFT = 'MITGELIEFERT'", name) > 0;
    }

    private static Daten.Szenenzeit sz(ResultSet r) throws SQLException {
        Integer j = integer(r, "SZ_JAHR");
        if (j == null) return null;
        return new Daten.Szenenzeit(j, r.getInt("SZ_MONAT"), r.getInt("SZ_TAG"), r.getDouble("SZ_STUNDE"));
    }

    private static void setSz(PreparedStatement st, int i, Daten.Szenenzeit z) throws SQLException {
        setI(st, i, z == null ? null : z.jahr());
        setI(st, i + 1, z == null ? null : z.monat());
        setI(st, i + 2, z == null ? null : z.tag());
        setD(st, i + 3, z == null ? null : z.stunde());
    }

    // ------------------------------------------------------------------ Stand

    @Override public Daten.Stand stand() throws Fehler {
        return mit("Stand", c -> {
            Daten.Siedlung a = aktiv(c);
            return new Daten.Stand(zahl(c, "SELECT COUNT(*) FROM HB_SIEDLUNG"), zahl(c, "SELECT COUNT(*) FROM HB_HAUS"), zahl(c, "SELECT COUNT(*) FROM HB_BAUWERK"),
                    zahl(c, "SELECT COUNT(*) FROM HB_REGIEBUCH"), zahl(c, "SELECT COUNT(*) FROM HB_WETTERLAGE"), zahl(c, "SELECT COUNT(*) FROM HB_FAHRT"),
                    zahl(c, "SELECT COUNT(*) FROM HB_ANSICHT"), zahl(c, "SELECT COUNT(*) FROM HB_PAKET_PRESET"), zahl(c, "SELECT COUNT(*) FROM HB_BEFUND"),
                    a == null ? null : a.name(), letzte(c, -1));
        });
    }

    // ------------------------------------------------------------------ Siedlung

    private static final String SIEDLUNG_SQL = "SELECT NAME, STARTWERT, AKTIV, HAEUSER, BESCHREIBUNG, HERKUNFT FROM HB_SIEDLUNG";

    private static Daten.Siedlung siedlung(ResultSet r) throws SQLException {
        return new Daten.Siedlung(r.getString(1), r.getLong(2), r.getInt(3) == 1, r.getInt(4), r.getString(5), r.getString(6));
    }

    @Override public List<Daten.Siedlung> siedlungen() throws Fehler {
        return mit("Siedlungen", c -> {
            List<Daten.Siedlung> l = new ArrayList<>();
            try (Statement st = c.createStatement();
                 ResultSet r = st.executeQuery(SIEDLUNG_SQL + " ORDER BY CASE HERKUNFT WHEN 'MITGELIEFERT' THEN 0 ELSE 1 END, NAME")) {
                while (r.next()) l.add(siedlung(r));
            }
            return l;
        });
    }

    private static Daten.Siedlung aktiv(Connection c) throws SQLException {
        try (Statement st = c.createStatement(); ResultSet r = st.executeQuery(SIEDLUNG_SQL + " WHERE AKTIV = 1 ORDER BY ID")) {
            return r.next() ? siedlung(r) : null;
        }
    }

    @Override public Daten.Siedlung aktiveSiedlung() throws Fehler { return mit("Aktive Siedlung", DbSpeicher::aktiv); }

    @Override public List<Daten.Haus> haeuser(String siedlung) throws Fehler {
        return mit("Häuser", c -> {
            List<Daten.Haus> l = new ArrayList<>();
            try (PreparedStatement st = c.prepareStatement("SELECT h.NR, h.NAME, t.NAME AS TYP, h.ROLLE, h.X_M, h.BODEN_M, h.Z_M, h.RICHTUNG_GRAD, h.LAENGE_FAKTOR, "
                    + "h.BREITE_FAKTOR, h.ZUSTAND, h.ZUFALL, h.MUSEUM, h.VON_HAND, h.BEMERKUNG FROM HB_HAUS h JOIN HB_SIEDLUNG s ON s.ID = h.SIEDLUNG_ID "
                    + "JOIN HB_HAUSTYP t ON t.ID = h.HAUSTYP_ID WHERE s.NAME = ? ORDER BY h.NR")) {
                st.setString(1, siedlung);
                try (ResultSet r = st.executeQuery()) {
                    while (r.next())
                        l.add(new Daten.Haus(r.getInt(1), r.getString(2), r.getString(3), r.getString(4), r.getDouble(5), d(r, "BODEN_M"), r.getDouble(7), r.getDouble(8),
                                r.getDouble(9), r.getDouble(10), r.getDouble(11), r.getLong(12), r.getInt(13) == 1, r.getInt(14) == 1, r.getString(15)));
                }
            }
            return l;
        });
    }

    private static final String HAUS_INSERT = "INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, "
            + "LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM, VON_HAND, BEMERKUNG) VALUES (?, ?, ?, (SELECT ID FROM HB_HAUSTYP WHERE NAME = ?), ?, "
            + "MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(?, ?, NULL), NULL, NULL), MDSYS.SDO_GEOMETRY(?, 8307), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static Map<String, Daten.Haustyp> typen() {
        Map<String, Daten.Haustyp> m = new LinkedHashMap<>();
        for (Daten.Haustyp t : Startdaten.haustypen()) m.put(t.name(), t);
        return m;
    }

    private static void haus(PreparedStatement st, long sid, Daten.Haus h, Map<String, Daten.Haustyp> typen) throws SQLException {
        double[] ll = Daten.lonLat(h.x(), h.z());
        int i = 1;
        st.setLong(i++, sid);
        st.setInt(i++, h.nr());
        st.setString(i++, h.name());
        st.setString(i++, h.haustyp());
        st.setString(i++, h.rolle());
        st.setDouble(i++, ll[0]);
        st.setDouble(i++, ll[1]);
        setS(st, i++, h.grundriss(typen.get(h.haustyp())).wkt());
        st.setDouble(i++, Math.round(h.x() * 1000) / 1000.0);
        st.setDouble(i++, Math.round(h.z() * 1000) / 1000.0);
        setD(st, i++, Math.round(h.y() * 100) / 100.0);
        st.setDouble(i++, Math.round(h.richtungGrad() * 100) / 100.0);
        st.setDouble(i++, Math.round(h.laengeFaktor() * 1000) / 1000.0);
        st.setDouble(i++, Math.round(h.breiteFaktor() * 1000) / 1000.0);
        st.setDouble(i++, Math.round(h.zustand() * 1000) / 1000.0);
        st.setLong(i++, h.zufall());
        st.setInt(i++, h.museum() ? 1 : 0);
        st.setInt(i++, h.vonHand() ? 1 : 0);
        setS(st, i, h.bemerkung());
    }

    @Override public void speichern(Daten.Siedlung s, List<Daten.Haus> haeuser, List<Daten.Weg> wege) throws Fehler {
        zusammen("Siedlung „" + s.name() + "“ speichern", c -> {
            if (mitgeliefert(c, "HB_SIEDLUNG", s.name())) throw new SQLException("„" + s.name() + "“ ist mitgeliefert; bitte unter einem eigenen Namen speichern");
            boolean warAktiv = zahl(c, "SELECT COUNT(*) FROM HB_SIEDLUNG WHERE NAME = ? AND AKTIV = 1", s.name()) > 0;
            try (PreparedStatement st = c.prepareStatement("DELETE FROM HB_SIEDLUNG WHERE NAME = ? AND HERKUNFT = 'EIGEN'")) { st.setString(1, s.name()); st.executeUpdate(); }
            try (PreparedStatement st = c.prepareStatement("INSERT INTO HB_SIEDLUNG (NAME, STARTWERT, AKTIV, HAEUSER, BESCHREIBUNG, HERKUNFT) VALUES (?, ?, ?, ?, ?, 'EIGEN')")) {
                st.setString(1, s.name());
                st.setLong(2, s.startwert());
                st.setInt(3, warAktiv ? 1 : 0);
                st.setInt(4, haeuser.size());
                setS(st, 5, s.beschreibung());
                st.executeUpdate();
            }
            long sid = Long.parseLong(Db.einWert(c, "SELECT TO_CHAR(ID) FROM HB_SIEDLUNG WHERE NAME = ?", s.name()));
            Map<String, Daten.Haustyp> typen = typen();
            try (PreparedStatement st = c.prepareStatement(HAUS_INSERT)) {
                for (Daten.Haus h : haeuser) { haus(st, sid, h, typen); st.addBatch(); }
                st.executeBatch();
            }
            try (PreparedStatement st = c.prepareStatement("INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) VALUES (?, ?, ?, MDSYS.SDO_GEOMETRY(?, 8307), ?)")) {
                for (Daten.Weg w : wege) {
                    st.setLong(1, sid);
                    st.setString(2, w.art());
                    setS(st, 3, w.name());
                    setS(st, 4, w.geom().wkt());
                    setD(st, 5, w.breiteM());
                    st.addBatch();
                }
                st.executeBatch();
            }
            return null;
        });
        Protokoll.info("Siedlung", "Siedlung „" + s.name() + "“ gespeichert: " + haeuser.size() + " Häuser, " + wege.size() + " Wege");
    }

    @Override public void aktivieren(String siedlung) throws Fehler {
        zusammen("Siedlung aktiv setzen", c -> {
            if (zahl(c, "SELECT COUNT(*) FROM HB_SIEDLUNG WHERE NAME = ?", siedlung) == 0) throw new SQLException("Siedlung „" + siedlung + "“ gibt es nicht");
            try (PreparedStatement st = c.prepareStatement("UPDATE HB_SIEDLUNG SET AKTIV = CASE WHEN NAME = ? THEN 1 ELSE 0 END")) { st.setString(1, siedlung); st.executeUpdate(); }
            return null;
        });
    }

    @Override public void aendern(String siedlung, Daten.Haus h) throws Fehler {
        zusammen("Haus ändern", c -> {
            if (mitgeliefert(c, "HB_SIEDLUNG", siedlung)) throw new SQLException("„" + siedlung + "“ ist mitgeliefert; die App speichert sie vorher unter eigenem Namen");
            Daten.Haustyp t = typen().get(h.haustyp());
            try (PreparedStatement st = c.prepareStatement("UPDATE HB_HAUS SET HAUSTYP_ID = (SELECT ID FROM HB_HAUSTYP WHERE NAME = ?), ROLLE = ?, NAME = ?, ZUSTAND = ?, "
                    + "RICHTUNG_GRAD = ?, LAENGE_FAKTOR = ?, BREITE_FAKTOR = ?, GRUNDRISS = MDSYS.SDO_GEOMETRY(?, 8307), BEMERKUNG = ?, VON_HAND = 1 "
                    + "WHERE NR = ? AND SIEDLUNG_ID = (SELECT ID FROM HB_SIEDLUNG WHERE NAME = ?)")) {
                st.setString(1, h.haustyp());
                st.setString(2, h.rolle());
                st.setString(3, h.name());
                st.setDouble(4, Math.round(h.zustand() * 1000) / 1000.0);
                st.setDouble(5, Math.round(h.richtungGrad() * 100) / 100.0);
                st.setDouble(6, Math.round(h.laengeFaktor() * 1000) / 1000.0);
                st.setDouble(7, Math.round(h.breiteFaktor() * 1000) / 1000.0);
                setS(st, 8, h.grundriss(t).wkt());
                setS(st, 9, h.bemerkung());
                st.setInt(10, h.nr());
                st.setString(11, siedlung);
                if (st.executeUpdate() != 1) throw new SQLException("Haus " + h.nr() + " gibt es in „" + siedlung + "“ nicht");
            }
            return null;
        });
    }

    @Override public void entfernen(String siedlung, int nr) throws Fehler {
        zusammen("Haus entfernen", c -> {
            if (mitgeliefert(c, "HB_SIEDLUNG", siedlung)) throw new SQLException("„" + siedlung + "“ ist mitgeliefert; die App speichert sie vorher unter eigenem Namen");
            try (PreparedStatement st = c.prepareStatement("DELETE FROM HB_HAUS WHERE NR = ? AND SIEDLUNG_ID = (SELECT ID FROM HB_SIEDLUNG WHERE NAME = ?)")) {
                st.setInt(1, nr);
                st.setString(2, siedlung);
                st.executeUpdate();
            }
            try (PreparedStatement st = c.prepareStatement("UPDATE HB_SIEDLUNG s SET HAEUSER = (SELECT COUNT(*) FROM HB_HAUS h WHERE h.SIEDLUNG_ID = s.ID) WHERE NAME = ?")) {
                st.setString(1, siedlung);
                st.executeUpdate();
            }
            return null;
        });
    }

    @Override public void loeschenSiedlung(String name) throws Fehler {
        zusammen("Siedlung löschen", c -> {
            if (mitgeliefert(c, "HB_SIEDLUNG", name)) throw new SQLException("„" + name + "“ ist mitgeliefert und wird nicht gelöscht");
            boolean aktiv = zahl(c, "SELECT COUNT(*) FROM HB_SIEDLUNG WHERE NAME = ? AND AKTIV = 1", name) > 0;
            try (PreparedStatement st = c.prepareStatement("DELETE FROM HB_SIEDLUNG WHERE NAME = ? AND HERKUNFT = 'EIGEN'")) { st.setString(1, name); st.executeUpdate(); }
            if (aktiv) try (Statement st = c.createStatement()) { st.executeUpdate("UPDATE HB_SIEDLUNG SET AKTIV = 1 WHERE HERKUNFT = 'MITGELIEFERT'"); }
            return null;
        });
    }

    // ------------------------------------------------------------------ Lageplan und Quellen

    /** WKT in Länge und Breite → Geometrie in Szenenmetern. */
    static Daten.Geom geom(String wkt) {
        String art = wkt.startsWith("POINT") ? "PUNKT" : wkt.startsWith("POLYGON") ? "FLAECHE" : "LINIE";
        double[][] ll = Wkt.punkte(wkt);
        int n = art.equals("FLAECHE") && ll.length > 3 ? ll.length - 1 : ll.length;
        double[][] xz = new double[n][];
        for (int i = 0; i < n; i++) xz[i] = Daten.xz(ll[i][0], ll[i][1]);
        return new Daten.Geom(art, xz);
    }

    @Override public List<Daten.Bauwerk> bauwerke() throws Fehler {
        return mit("Lageplan", c -> {
            List<Daten.Bauwerk> l = new ArrayList<>();
            try (Statement st = c.createStatement(); ResultSet r = st.executeQuery("SELECT w.ART, w.NAME, MDSYS.SDO_UTIL.TO_WKTGEOMETRY(w.GEOM) AS WKT, w.HOEHE_M, w.BREITE_M, "
                    + "w.BEFUND, b.GEGENSTAND, w.BESCHREIBUNG FROM HB_BAUWERK w LEFT JOIN HB_BEFUND b ON b.ID = w.BEFUND_ID ORDER BY w.ART, w.NAME")) {
                while (r.next())
                    l.add(new Daten.Bauwerk(r.getString(1), r.getString(2), geom(clob(r, "WKT")), dbl(r, "HOEHE_M"), dbl(r, "BREITE_M"), r.getString(6), r.getString(7), r.getString(8)));
            }
            return l;
        });
    }

    @Override public Daten.Gelaende gelaende() throws Fehler {
        return mit("Gelände", c -> {
            try (Statement st = c.createStatement(); ResultSet r = st.executeQuery("SELECT NAME, QUELLE, MDSYS.SDO_UTIL.TO_WKTGEOMETRY(AUSSCHNITT) AS WKT, g.URSPRUNG.SDO_POINT.X AS LON, "
                    + "g.URSPRUNG.SDO_POINT.Y AS LAT, RASTER_M, SPALTEN, ZEILEN, ANTEIL_GEMESSEN_PROZ, DATEI, PRUEFSUMME, EINGRIFFE FROM HB_GELAENDE g ORDER BY ID")) {
                if (!r.next()) return null;
                String w = clob(r, "WKT");
                return new Daten.Gelaende(r.getString(1), r.getString(2), w == null ? null : geom(w), d(r, "LON"), d(r, "LAT"), d(r, "RASTER_M"), r.getInt("SPALTEN"),
                        r.getInt("ZEILEN"), d(r, "ANTEIL_GEMESSEN_PROZ"), r.getString("DATEI"), r.getString("PRUEFSUMME"), r.getString("EINGRIFFE"));
            }
        });
    }

    @Override public List<Daten.Quelle> quellen() throws Fehler {
        return mit("Quellen", c -> {
            List<Daten.Quelle> l = new ArrayList<>();
            try (Statement st = c.createStatement(); ResultSet r = st.executeQuery("SELECT KURZ, TITEL, URL, ART, ABGERUFEN, BEMERKUNG FROM HB_QUELLE ORDER BY ID")) {
                while (r.next()) {
                    java.sql.Date ab = r.getDate(5);
                    l.add(new Daten.Quelle(r.getString(1), r.getString(2), r.getString(3), r.getString(4), ab == null ? null : ab.toLocalDate(), r.getString(6)));
                }
            }
            return l;
        });
    }

    @Override public List<Daten.Befund> befunde() throws Fehler {
        return mit("Befunde", c -> {
            Map<Long, List<String>> q = new LinkedHashMap<>();
            try (Statement st = c.createStatement(); ResultSet r = st.executeQuery("SELECT x.BEFUND_ID, q.KURZ FROM HB_BEFUND_QUELLE x JOIN HB_QUELLE q ON q.ID = x.QUELLE_ID ORDER BY x.ID")) {
                while (r.next()) q.computeIfAbsent(r.getLong(1), k -> new ArrayList<>()).add(r.getString(2));
            }
            List<Daten.Befund> l = new ArrayList<>();
            try (Statement st = c.createStatement(); ResultSet r = st.executeQuery("SELECT ID, THEMA, GEGENSTAND, BEFUND, TEXT FROM HB_BEFUND ORDER BY ID")) {
                while (r.next()) l.add(new Daten.Befund(r.getString(2), r.getString(3), r.getString(4), r.getString(5), q.getOrDefault(r.getLong(1), List.of())));
            }
            return l;
        });
    }

    // ------------------------------------------------------------------ Wetterlagen

    @Override public List<Daten.Wetterlage> wetterlagen() throws Fehler {
        return mit("Wetterlagen", c -> {
            List<Daten.Wetterlage> l = new ArrayList<>();
            StringBuilder cols = new StringBuilder();
            for (String s : Verbindung.WETTER.values()) cols.append(", ").append(s);
            try (Statement st = c.createStatement(); ResultSet r = st.executeQuery("SELECT NAME, BEAUFORT, PHASE, MONATE, BESCHREIBUNG, HERKUNFT" + cols
                    + " FROM HB_WETTERLAGE ORDER BY CASE HERKUNFT WHEN 'MITGELIEFERT' THEN 0 ELSE 1 END, ID")) {
                while (r.next()) {
                    double[] v = new double[Weather.Var.values().length];
                    java.util.Arrays.fill(v, Double.NaN);
                    for (Map.Entry<Weather.Var, String> e : Verbindung.WETTER.entrySet()) {
                        if (e.getKey() == Weather.Var.CLOUD) {
                            String k = r.getString(e.getValue());
                            if (k != null) try { v[e.getKey().ordinal()] = Weather.CloudKind.valueOf(k).ordinal(); } catch (IllegalArgumentException ex) { /* leer */ }
                        } else v[e.getKey().ordinal()] = d(r, e.getValue());
                    }
                    l.add(new Daten.Wetterlage(r.getString(1), dbl(r, "BEAUFORT"), r.getString(3), v, r.getString(4), r.getString(5), r.getString(6)));
                }
            }
            return l;
        });
    }

    @Override public void speichern(Daten.Wetterlage w) throws Fehler {
        zusammen("Wetterlage speichern", c -> {
            if (mitgeliefert(c, "HB_WETTERLAGE", w.name())) throw new SQLException("„" + w.name() + "“ ist mitgeliefert; bitte unter einem eigenen Namen speichern");
            try (PreparedStatement st = c.prepareStatement("DELETE FROM HB_WETTERLAGE WHERE NAME = ? AND HERKUNFT = 'EIGEN'")) { st.setString(1, w.name()); st.executeUpdate(); }
            StringBuilder cols = new StringBuilder("NAME, BEAUFORT, PHASE, MONATE, BESCHREIBUNG, HERKUNFT"), q = new StringBuilder("?, ?, ?, ?, ?, 'EIGEN'");
            for (String s : Verbindung.WETTER.values()) { cols.append(", ").append(s); q.append(", ?"); }
            try (PreparedStatement st = c.prepareStatement("INSERT INTO HB_WETTERLAGE (" + cols + ") VALUES (" + q + ")")) {
                st.setString(1, w.name());
                setD(st, 2, w.beaufort());
                setS(st, 3, w.phase());
                setS(st, 4, w.monate());
                setS(st, 5, w.beschreibung());
                int i = 6;
                for (Weather.Var v : Verbindung.WETTER.keySet()) {
                    double x = w.werte()[v.ordinal()];
                    if (v == Weather.Var.CLOUD) setS(st, i++, Double.isNaN(x) ? null : Weather.CloudKind.values()[(int) Math.max(0, Math.min(4, Math.round(x)))].name());
                    else setD(st, i++, x);
                }
                st.executeUpdate();
            }
            return null;
        });
    }

    @Override public void loeschenWetterlage(String name) throws Fehler { loeschen("HB_WETTERLAGE", name); }

    private void loeschen(String tabelle, String name) throws Fehler {
        zusammen("Löschen", c -> {
            if (mitgeliefert(c, tabelle, name)) throw new SQLException("„" + name + "“ ist mitgeliefert und wird nicht gelöscht");
            try (PreparedStatement st = c.prepareStatement("DELETE FROM " + tabelle + " WHERE NAME = ? AND HERKUNFT = 'EIGEN'")) { st.setString(1, name); st.executeUpdate(); }
            return null;
        });
    }

    // ------------------------------------------------------------------ Regiebücher

    @Override public List<Daten.Regiebuch> regiebuecher() throws Fehler {
        return mit("Regiebücher", c -> {
            List<Daten.Regiebuch> l = new ArrayList<>();
            Map<Long, List<Regie.Zeile>> z = new LinkedHashMap<>();
            try (Statement st = c.createStatement(); ResultSet r = st.executeQuery("SELECT REGIEBUCH_ID, SEKUNDE, BEFEHL, ARGUMENTE, TEXT FROM HB_STICHWORT ORDER BY REGIEBUCH_ID, NR")) {
                while (r.next())
                    z.computeIfAbsent(r.getLong(1), k -> new ArrayList<>()).add(new Regie.Zeile(r.getDouble(2), r.getString(3).toLowerCase(java.util.Locale.ROOT),
                            r.getString(4) == null ? "" : r.getString(4), r.getString(5) == null ? "" : r.getString(5)));
            }
            try (Statement st = c.createStatement(); ResultSet r = st.executeQuery("SELECT ID, NAME, BESCHREIBUNG, LAENGE_S, WETTER, HERKUNFT FROM HB_REGIEBUCH "
                    + "ORDER BY CASE HERKUNFT WHEN 'MITGELIEFERT' THEN 0 ELSE 1 END, ID")) {
                while (r.next()) {
                    String text = Regie.toText(r.getString(2), r.getString(3), r.getDouble(4), r.getString(5), z.getOrDefault(r.getLong(1), List.of()));
                    l.add(new Daten.Regiebuch(r.getString(2), text, r.getString(3), r.getString(6)));
                }
            }
            return l;
        });
    }

    @Override public void speichern(Daten.Regiebuch rb) throws Fehler {
        Regie.Book b;
        try { b = Regie.parse(rb.text()); } catch (RuntimeException e) { throw new Fehler("Regiebuch nicht lesbar: " + e.getMessage(), e); }
        if (!b.name().equals(rb.name())) throw new Fehler("Der Name im Text („" + b.name() + "“) passt nicht zu „" + rb.name() + "“");
        StartdatenSql.Kopf k = StartdatenSql.Kopf.aus(b);
        zusammen("Regiebuch speichern", c -> {
            if (mitgeliefert(c, "HB_REGIEBUCH", b.name())) throw new SQLException("„" + b.name() + "“ ist mitgeliefert; bitte unter einem eigenen Namen speichern");
            try (PreparedStatement st = c.prepareStatement("DELETE FROM HB_REGIEBUCH WHERE NAME = ? AND HERKUNFT = 'EIGEN'")) { st.setString(1, b.name()); st.executeUpdate(); }
            try (PreparedStatement st = c.prepareStatement("INSERT INTO HB_REGIEBUCH (NAME, BESCHREIBUNG, SZ_JAHR, SZ_MONAT, SZ_TAG, SZ_STUNDE, ZEITRAFFER, LAENGE_S, BLATT, WETTER, HERKUNFT) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, 'EIGEN')")) {
                st.setString(1, b.name());
                setS(st, 2, b.about());
                setI(st, 3, k.jahr().equals("NULL") ? null : Integer.parseInt(k.jahr()));
                setI(st, 4, k.monat().equals("NULL") ? null : Integer.parseInt(k.monat()));
                setI(st, 5, k.tag().equals("NULL") ? null : Integer.parseInt(k.tag()));
                setD(st, 6, k.stunde());
                setD(st, 7, k.raffer());
                st.setDouble(8, b.length());
                setS(st, 9, Regie.wetterBlock(rb.text()));
                st.executeUpdate();
            }
            long id = Long.parseLong(Db.einWert(c, "SELECT TO_CHAR(ID) FROM HB_REGIEBUCH WHERE NAME = ?", b.name()));
            try (PreparedStatement st = c.prepareStatement("INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) VALUES (?, ?, ?, ?, ?, ?)")) {
                int nr = 0;
                for (Regie.Zeile z : b.zeilen()) {
                    st.setLong(1, id);
                    st.setInt(2, ++nr);
                    st.setDouble(3, z.sekunde());
                    st.setString(4, z.befehl().toUpperCase(java.util.Locale.ROOT));
                    setS(st, 5, z.argumente());
                    setS(st, 6, z.text());
                    st.addBatch();
                }
                st.executeBatch();
            }
            return null;
        });
    }

    @Override public void loeschenRegiebuch(String name) throws Fehler { loeschen("HB_REGIEBUCH", name); }

    // ------------------------------------------------------------------ Fahrten

    @Override public List<Daten.Fahrt> fahrten() throws Fehler {
        return mit("Fahrten", c -> {
            Map<Long, List<Daten.Stuetzpunkt>> p = new LinkedHashMap<>();
            try (Statement st = c.createStatement(); ResultSet r = st.executeQuery("SELECT FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD "
                    + "FROM HB_STUETZPUNKT ORDER BY FAHRT_ID, NR")) {
                while (r.next())
                    p.computeIfAbsent(r.getLong(1), k -> new ArrayList<>()).add(new Daten.Stuetzpunkt(r.getInt(2), r.getDouble(3), d(r, "KAM_X"), d(r, "KAM_Y"), d(r, "KAM_Z"),
                            d(r, "KAM_GIER_GRAD"), d(r, "KAM_NICK_GRAD"), d(r, "KAM_FOV_GRAD")));
            }
            List<Daten.Fahrt> l = new ArrayList<>();
            try (Statement st = c.createStatement(); ResultSet r = st.executeQuery("SELECT ID, NAME, TASTE, ART, SCHLEIFE, BESCHREIBUNG, HERKUNFT FROM HB_FAHRT "
                    + "ORDER BY CASE HERKUNFT WHEN 'MITGELIEFERT' THEN 0 ELSE 1 END, ID")) {
                while (r.next())
                    l.add(new Daten.Fahrt(r.getString(2), integer(r, "TASTE"), r.getString(4), r.getInt(5) == 1, r.getString(6), r.getString(7), p.getOrDefault(r.getLong(1), List.of())));
            }
            return l;
        });
    }

    @Override public void speichern(Daten.Fahrt f) throws Fehler {
        zusammen("Fahrt speichern", c -> {
            if (mitgeliefert(c, "HB_FAHRT", f.name())) throw new SQLException("„" + f.name() + "“ ist mitgeliefert; bitte unter einem eigenen Namen speichern");
            try (PreparedStatement st = c.prepareStatement("DELETE FROM HB_FAHRT WHERE NAME = ? AND HERKUNFT = 'EIGEN'")) { st.setString(1, f.name()); st.executeUpdate(); }
            try (PreparedStatement st = c.prepareStatement("INSERT INTO HB_FAHRT (NAME, TASTE, ART, SCHLEIFE, BESCHREIBUNG, HERKUNFT) VALUES (?, ?, ?, ?, ?, 'EIGEN')")) {
                st.setString(1, f.name());
                setI(st, 2, f.taste());
                st.setString(3, f.art());
                st.setInt(4, f.schleife() ? 1 : 0);
                setS(st, 5, f.beschreibung());
                st.executeUpdate();
            }
            long id = Long.parseLong(Db.einWert(c, "SELECT TO_CHAR(ID) FROM HB_FAHRT WHERE NAME = ?", f.name()));
            try (PreparedStatement st = c.prepareStatement("INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                for (Daten.Stuetzpunkt p : f.punkte()) {
                    st.setLong(1, id);
                    st.setInt(2, p.nr());
                    st.setDouble(3, Math.round(p.zeitS() * 100) / 100.0);
                    setD(st, 4, p.x());
                    setD(st, 5, p.y());
                    setD(st, 6, p.z());
                    setD(st, 7, p.gier());
                    setD(st, 8, p.nick());
                    setD(st, 9, p.fov());
                    st.addBatch();
                }
                st.executeBatch();
            }
            return null;
        });
    }

    @Override public void loeschenFahrt(String name) throws Fehler { loeschen("HB_FAHRT", name); }

    // ------------------------------------------------------------------ Ansichten

    private static final String ANSICHT_SQL = "SELECT ID, NAME, TASTE, ART, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD, AUGE_UEBER_GRUND_M, ORBIT, ABSTAND_M, "
            + "SZ_JAHR, SZ_MONAT, SZ_TAG, SZ_STUNDE, HERKUNFT";

    private static Daten.Ansicht ansicht(ResultSet r, String zustand, byte[] png) throws SQLException {
        double[] k = {d(r, "KAM_X"), d(r, "KAM_Y"), d(r, "KAM_Z"), d(r, "KAM_GIER_GRAD"), d(r, "KAM_NICK_GRAD"), d(r, "KAM_FOV_GRAD")};
        return new Daten.Ansicht(r.getLong("ID"), r.getString("NAME"), integer(r, "TASTE"), r.getString("ART"), k, dbl(r, "AUGE_UEBER_GRUND_M"), r.getInt("ORBIT") == 1,
                dbl(r, "ABSTAND_M"), sz(r), zustand, png, r.getString("HERKUNFT"));
    }

    @Override public List<Daten.Ansicht> ansichten() throws Fehler {
        return mit("Ansichten", c -> {
            List<Daten.Ansicht> l = new ArrayList<>();
            try (Statement st = c.createStatement(); ResultSet r = st.executeQuery(ANSICHT_SQL + " FROM HB_ANSICHT ORDER BY CASE ART WHEN 'FEST' THEN 0 ELSE 1 END, TASTE, ID DESC")) {
                while (r.next()) l.add(ansicht(r, null, null));
            }
            return l;
        });
    }

    @Override public Daten.Ansicht ansicht(long id) throws Fehler {
        return mit("Ansicht", c -> {
            try (PreparedStatement st = c.prepareStatement(ANSICHT_SQL + ", ZUSTAND, VORSCHAU FROM HB_ANSICHT WHERE ID = ?")) {
                st.setLong(1, id);
                try (ResultSet r = st.executeQuery()) {
                    if (!r.next()) throw new SQLException("Ansicht " + id + " gibt es nicht");
                    return ansicht(r, clob(r, "ZUSTAND"), r.getBytes("VORSCHAU"));
                }
            }
        });
    }

    @Override public long speichern(Daten.Ansicht a, Long sitzung) throws Fehler {
        long[] id = {0};
        zusammen("Ansicht merken", c -> {
            try (PreparedStatement st = c.prepareStatement("INSERT INTO HB_ANSICHT (NAME, ART, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD, SZ_JAHR, SZ_MONAT, "
                    + "SZ_TAG, SZ_STUNDE, ZUSTAND, VORSCHAU, SITZUNG_ID, HERKUNFT) VALUES (?, 'GEMERKT', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'EIGEN')")) {
                st.setString(1, a.name());
                for (int i = 0; i < 6; i++) setD(st, 2 + i, Math.round(a.kamera()[i] * 100) / 100.0);
                setSz(st, 8, a.szenenzeit());
                if (a.zustand() == null) st.setNull(12, Types.CLOB); else st.setCharacterStream(12, new StringReader(a.zustand()), a.zustand().length());
                if (a.vorschau() == null) st.setNull(13, Types.BLOB); else st.setBytes(13, a.vorschau());
                if (sitzung == null || sitzung < 0) st.setNull(14, Types.NUMERIC); else st.setLong(14, sitzung);
                st.executeUpdate();
            }
            id[0] = Long.parseLong(Db.einWert(c, "SELECT TO_CHAR(HB_ANSICHT_SEQ.CURRVAL) FROM DUAL"));
            return null;
        });
        return id[0];
    }

    @Override public void loeschenAnsicht(long id) throws Fehler {
        zusammen("Ansicht löschen", c -> {
            try (PreparedStatement st = c.prepareStatement("DELETE FROM HB_ANSICHT WHERE ID = ? AND HERKUNFT = 'EIGEN'")) { st.setLong(1, id); st.executeUpdate(); }
            return null;
        });
    }

    // ------------------------------------------------------------------ Presets

    @Override public List<Daten.PaketPreset> presets(String paket, String klasse) throws Fehler {
        return mit("Presets", c -> {
            Map<Long, Map<String, String>> w = new LinkedHashMap<>();
            try (Statement st = c.createStatement(); ResultSet r = st.executeQuery("SELECT PAKET_PRESET_ID, FELD, WERT FROM HB_PAKET_WERT ORDER BY PAKET_PRESET_ID, ID")) {
                while (r.next()) w.computeIfAbsent(r.getLong(1), k -> new LinkedHashMap<>()).put(r.getString(2), r.getString(3) == null ? "" : r.getString(3));
            }
            List<Daten.PaketPreset> l = new ArrayList<>();
            try (PreparedStatement st = c.prepareStatement("SELECT ID, PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT FROM HB_PAKET_PRESET WHERE (? IS NULL OR PAKET = ?) "
                    + "AND (? IS NULL OR KLASSE = ?) ORDER BY PAKET, KLASSE, CASE HERKUNFT WHEN 'MITGELIEFERT' THEN 0 ELSE 1 END, NAME")) {
                st.setString(1, paket);
                st.setString(2, paket);
                st.setString(3, klasse);
                st.setString(4, klasse);
                try (ResultSet r = st.executeQuery()) {
                    while (r.next())
                        l.add(new Daten.PaketPreset(r.getString(2), r.getString(3), r.getString(4), r.getString(5), r.getString(6), w.getOrDefault(r.getLong(1), Map.of())));
                }
            }
            return l;
        });
    }

    @Override public void speichern(Daten.PaketPreset p) throws Fehler {
        Map<String, String> typ = StartdatenSql.typen(p);
        zusammen("Preset speichern", c -> {
            if (zahl(c, "SELECT COUNT(*) FROM HB_PAKET_PRESET WHERE PAKET = ? AND KLASSE = ? AND NAME = ? AND HERKUNFT = 'MITGELIEFERT'", p.paket(), p.klasse(), p.name()) > 0)
                throw new SQLException("„" + p.name() + "“ ist mitgeliefert; bitte unter einem eigenen Namen speichern");
            try (PreparedStatement st = c.prepareStatement("DELETE FROM HB_PAKET_PRESET WHERE PAKET = ? AND KLASSE = ? AND NAME = ? AND HERKUNFT = 'EIGEN'")) {
                st.setString(1, p.paket()); st.setString(2, p.klasse()); st.setString(3, p.name()); st.executeUpdate();
            }
            try (PreparedStatement st = c.prepareStatement("INSERT INTO HB_PAKET_PRESET (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES (?, ?, ?, ?, 'EIGEN')")) {
                st.setString(1, p.paket()); st.setString(2, p.klasse()); st.setString(3, p.name()); setS(st, 4, p.beschreibung()); st.executeUpdate();
            }
            long id = Long.parseLong(Db.einWert(c, "SELECT TO_CHAR(ID) FROM HB_PAKET_PRESET WHERE PAKET = ? AND KLASSE = ? AND NAME = ?", p.paket(), p.klasse(), p.name()));
            try (PreparedStatement st = c.prepareStatement("INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) VALUES (?, ?, ?, ?)")) {
                for (Map.Entry<String, String> e : p.felder().entrySet()) {
                    st.setLong(1, id);
                    st.setString(2, e.getKey());
                    st.setString(3, typ.getOrDefault(e.getKey(), "STRING"));
                    setS(st, 4, e.getValue());
                    st.addBatch();
                }
                st.executeBatch();
            }
            return null;
        });
    }

    @Override public void loeschenPreset(String paket, String klasse, String name) throws Fehler {
        zusammen("Preset löschen", c -> {
            try (PreparedStatement st = c.prepareStatement("DELETE FROM HB_PAKET_PRESET WHERE PAKET = ? AND KLASSE = ? AND NAME = ? AND HERKUNFT = 'EIGEN'")) {
                st.setString(1, paket); st.setString(2, klasse); st.setString(3, name);
                if (st.executeUpdate() == 0) throw new SQLException("„" + name + "“ ist mitgeliefert oder gibt es nicht");
            }
            return null;
        });
    }

    // ------------------------------------------------------------------ Sitzungen

    @Override public long sitzungBeginnen(String version, String gpu, String qualitaet) throws Fehler {
        long[] id = {0};
        zusammen("Sitzung beginnen", c -> {
            try (PreparedStatement st = c.prepareStatement("INSERT INTO HB_SITZUNG (RECHNER, BENUTZER, APP_VERSION, GPU, QUALITAET) VALUES (?, ?, ?, ?, ?)")) {
                setS(st, 1, com.dan.store.DateiAblage.rechner());
                setS(st, 2, System.getProperty("user.name", ""));
                st.setString(3, version.length() > 20 ? version.substring(0, 20) : version);
                setS(st, 4, gpu == null ? null : gpu.length() > 120 ? gpu.substring(0, 120) : gpu);
                setS(st, 5, qualitaet);
                st.executeUpdate();
            }
            id[0] = Long.parseLong(Db.einWert(c, "SELECT TO_CHAR(HB_SITZUNG_SEQ.CURRVAL) FROM DUAL"));
            // das Protokoll hält 90 Tage (F36: wie Lighthouse F43)
            try (Statement st = c.createStatement()) { st.executeUpdate("DELETE FROM HB_LOG WHERE ZEIT < SYSTIMESTAMP - INTERVAL '90' DAY"); }
            return null;
        });
        return id[0];
    }

    @Override public void sitzungSichern(long id, Sicherung s) throws Fehler {
        Map<String, String> sp = s.spalten();
        Daten.Szenenzeit z = sp.get(SZ) == null ? null : Zustand.szenenzeit(sp.get(SZ));
        double rs = com.dan.store.Zahl.lies(sp.get(REGIE_SEKUNDE));
        zusammen("Sitzung sichern", c -> {
            try (PreparedStatement st = c.prepareStatement("UPDATE HB_SITZUNG SET ZUSTAND = ?, ZUSTAND_ZEIT = SYSTIMESTAMP, SIEDLUNG_ID = (SELECT MAX(ID) FROM HB_SIEDLUNG WHERE NAME = ?), "
                    + "REGIEBUCH_ID = (SELECT MAX(ID) FROM HB_REGIEBUCH WHERE NAME = ?), REGIE_SEKUNDE = ?, SZ_JAHR = ?, SZ_MONAT = ?, SZ_TAG = ?, SZ_STUNDE = ? WHERE ID = ?")) {
                st.setCharacterStream(1, new StringReader(s.zustand()), s.zustand().length());
                setS(st, 2, sp.get(SIEDLUNG));
                setS(st, 3, sp.get(REGIEBUCH));
                setD(st, 4, Double.isNaN(rs) ? null : rs);
                setSz(st, 5, z);
                st.setLong(9, id);
                st.executeUpdate();
            }
            return null;
        });
    }

    @Override public void sitzungBeenden(long id) throws Fehler {
        zusammen("Sitzung beenden", c -> {
            try (PreparedStatement st = c.prepareStatement("UPDATE HB_SITZUNG SET ENDE = SYSTIMESTAMP, SAUBER_BEENDET = 1 WHERE ID = ?")) { st.setLong(1, id); st.executeUpdate(); }
            return null;
        });
    }

    private static Daten.Sitzung letzte(Connection c, long ausser) throws SQLException {
        try (PreparedStatement st = c.prepareStatement("SELECT s.ID, s.BEGINN, s.ENDE, s.SAUBER_BEENDET, s.ZUSTAND, s.ZUSTAND_ZEIT, d.NAME AS SIEDLUNG, r.NAME AS REGIEBUCH, "
                + "s.REGIE_SEKUNDE, s.SZ_JAHR, s.SZ_MONAT, s.SZ_TAG, s.SZ_STUNDE FROM HB_SITZUNG s LEFT JOIN HB_SIEDLUNG d ON d.ID = s.SIEDLUNG_ID "
                + "LEFT JOIN HB_REGIEBUCH r ON r.ID = s.REGIEBUCH_ID WHERE s.ZUSTAND IS NOT NULL AND s.ID <> ? "
                + "ORDER BY s.ZUSTAND_ZEIT DESC NULLS LAST, s.ID DESC FETCH FIRST 1 ROWS ONLY")) {
            st.setLong(1, ausser);
            try (ResultSet r = st.executeQuery()) {
                if (!r.next()) return null;
                Timestamp b = r.getTimestamp(2), e = r.getTimestamp(3), zz = r.getTimestamp(6);
                return new Daten.Sitzung(r.getLong(1), b.getTime(), e == null ? null : e.getTime(), r.getInt(4) == 1, clob(r, "ZUSTAND"), zz == null ? null : zz.getTime(),
                        r.getString(7), r.getString(8), dbl(r, "REGIE_SEKUNDE"), sz(r));
            }
        }
    }

    @Override public Daten.Sitzung letzteSitzung(long ausser) throws Fehler { return mit("Letzte Sitzung", c -> letzte(c, ausser)); }

    // ------------------------------------------------------------------ Protokoll

    @Override public void protokoll(List<Protokoll.Zeile> zeilen, Long sitzung) throws Fehler {
        if (zeilen.isEmpty()) return;
        zusammen("Protokoll", c -> {
            List<Long> ids = new ArrayList<>();
            try (PreparedStatement st = c.prepareStatement("SELECT HB_LOG_SEQ.NEXTVAL FROM DUAL CONNECT BY LEVEL <= ?")) {
                st.setInt(1, zeilen.size());
                try (ResultSet r = st.executeQuery()) { while (r.next()) ids.add(r.getLong(1)); }
            }
            try (PreparedStatement st = c.prepareStatement("INSERT INTO HB_LOG (ID, SITZUNG_ID, ZEIT, STUFE, QUELLE, TEXT, SZENENZEIT, ORT, DETAIL) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                for (int i = 0; i < zeilen.size(); i++) {
                    Protokoll.Zeile z = zeilen.get(i);
                    st.setLong(1, ids.get(i));
                    if (sitzung == null) st.setNull(2, Types.NUMERIC); else st.setLong(2, sitzung);
                    st.setTimestamp(3, new Timestamp(z.zeitMs()));
                    st.setString(4, z.stufe());
                    st.setString(5, z.quelle().length() > 60 ? z.quelle().substring(0, 60) : z.quelle());
                    st.setString(6, z.text().length() > 1000 ? z.text().substring(0, 997) + " …" : z.text());
                    setS(st, 7, z.szenenzeit());
                    setS(st, 8, z.ort() == null ? null : z.ort().length() > 40 ? z.ort().substring(0, 40) : z.ort());
                    if (z.detail() == null) st.setNull(9, Types.CLOB); else st.setCharacterStream(9, new StringReader(z.detail()), z.detail().length());
                    st.addBatch();
                }
                st.executeBatch();
            }
            return null;
        });
    }

    @Override public List<String> letzteZeilen(int n) throws Fehler {
        return mit("Protokoll lesen", c -> {
            List<String> l = new ArrayList<>();
            try (PreparedStatement st = c.prepareStatement("SELECT ZEIT, STUFE, QUELLE, TEXT FROM HB_LOG ORDER BY ID DESC FETCH FIRST ? ROWS ONLY")) {
                st.setInt(1, n);
                try (ResultSet r = st.executeQuery()) {
                    while (r.next())
                        l.add(0, Protokoll.zeile(new Protokoll.Zeile(r.getTimestamp(1).getTime(), r.getString(2), r.getString(3), r.getString(4), null, null, null)));
                }
            }
            return l;
        });
    }

    @Override public synchronized void schliessen() {
        try { if (c != null) c.close(); } catch (SQLException e) { /* zu */ }
        c = null;
    }
}
