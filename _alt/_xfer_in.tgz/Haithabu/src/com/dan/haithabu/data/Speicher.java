package com.dan.haithabu.data;

import com.dan.store.Ablage;

import java.util.List;

/**
 * Wohin die App speichert: in das Schema HAITHABU ({@link DbSpeicher}) oder, ohne Datenbank, in Dateien im Ordner
 * {@code daten/} ({@link DateiSpeicher}, F36 A). Beide können dasselbe; die Oberfläche kennt nur diese Schnittstelle.
 * Sitzung und Protokoll kommen aus {@link Ablage} (com.dan.store).
 * <p>
 * Namen sind eindeutig je Art. Speichern unter einem vorhandenen Namen ersetzt den Eintrag; ein mitgelieferter Eintrag
 * wird nicht überschrieben, sondern abgelehnt (der Einrichter stellt ihn sonst beim nächsten Lauf wieder her).
 */
public interface Speicher extends Ablage {

    /** Schlüssel der Werte, die eine {@link Ablage.Sicherung} über die Sitzung mitbringt. */
    String SIEDLUNG = "siedlung", REGIEBUCH = "regiebuch", REGIE_SEKUNDE = "regieSekunde", SZ = "szenenzeit";

    Daten.Stand stand() throws Fehler;

    // ------------------------------------------------------------------ Siedlung (F27, F28)

    List<Daten.Siedlung> siedlungen() throws Fehler;

    /** Die aktive Siedlung oder null. */
    Daten.Siedlung aktiveSiedlung() throws Fehler;

    /** Die Häuser einer Siedlung; leer heißt: alle aus dem Startwert (die mitgelieferte ohne Datenbank). */
    List<Daten.Haus> haeuser(String siedlung) throws Fehler;

    /** Eine eigene Siedlung mit Häusern und Wegen speichern (ersetzt eine gleichnamige eigene). */
    void speichern(Daten.Siedlung s, List<Daten.Haus> haeuser, List<Daten.Weg> wege) throws Fehler;

    /** Diese Siedlung aktiv setzen (alle anderen nicht). */
    void aktivieren(String siedlung) throws Fehler;

    /** Ein Haus einer eigenen Siedlung ändern (Typ, Zustand …); VON_HAND wird gesetzt. */
    void aendern(String siedlung, Daten.Haus h) throws Fehler;

    /** Ein Haus einer eigenen Siedlung entfernen. */
    void entfernen(String siedlung, int nr) throws Fehler;

    void loeschenSiedlung(String name) throws Fehler;

    // ------------------------------------------------------------------ Lageplan, Quellen (F29, F30, F34)

    List<Daten.Bauwerk> bauwerke() throws Fehler;

    Daten.Gelaende gelaende() throws Fehler;

    List<Daten.Quelle> quellen() throws Fehler;

    List<Daten.Befund> befunde() throws Fehler;

    // ------------------------------------------------------------------ Regie (F31, F36)

    List<Daten.Wetterlage> wetterlagen() throws Fehler;
    void speichern(Daten.Wetterlage w) throws Fehler;
    void loeschenWetterlage(String name) throws Fehler;

    List<Daten.Regiebuch> regiebuecher() throws Fehler;
    void speichern(Daten.Regiebuch r) throws Fehler;
    void loeschenRegiebuch(String name) throws Fehler;

    List<Daten.Fahrt> fahrten() throws Fehler;
    void speichern(Daten.Fahrt f) throws Fehler;
    void loeschenFahrt(String name) throws Fehler;

    /** Ansichten ohne Zustand und Vorschau (für Listen): feste zuerst, dann gemerkte, neueste zuerst. */
    List<Daten.Ansicht> ansichten() throws Fehler;
    /** Eine gemerkte Ansicht ganz, mit Zustand und Vorschau. */
    Daten.Ansicht ansicht(long id) throws Fehler;
    /** Speichert eine neue gemerkte Ansicht und gibt ihre Nummer zurück. */
    long speichern(Daten.Ansicht a, Long sitzung) throws Fehler;
    void loeschenAnsicht(long id) throws Fehler;

    // ------------------------------------------------------------------ Packages

    /** Presets eines Package (paket = „com.dan.ocean“, klasse = „Ocean“); null für alle. */
    List<Daten.PaketPreset> presets(String paket, String klasse) throws Fehler;
    void speichern(Daten.PaketPreset p) throws Fehler;
    void loeschenPreset(String paket, String klasse, String name) throws Fehler;

    // ------------------------------------------------------------------ Betrieb

    /** Die letzte Sitzung mit Zustand vor der laufenden (oder null). */
    Daten.Sitzung letzteSitzung(long ausser) throws Fehler;

    /** Die letzten n Zeilen des Protokolls zum Anzeigen. */
    List<String> letzteZeilen(int n) throws Fehler;
}
