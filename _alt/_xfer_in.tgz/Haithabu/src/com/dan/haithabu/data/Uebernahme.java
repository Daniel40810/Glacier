package com.dan.haithabu.data;

import com.dan.haithabu.scene.Siedlung;
import com.dan.haithabu.scene.Terrain;
import com.dan.store.Ablage;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * „In die Datenbank übernehmen“ (F36 A): was ohne Datenbank in daten/ entstanden ist, kommt in einen anderen Speicher —
 * eigene Siedlungen mit ihren Häusern (die Wege rechnet der Startwert neu), eigene Wetterlagen, Regiebücher, Fahrten
 * und Presets, gemerkte Ansichten. Mitgeliefertes bringt der Einrichter selbst mit. Was es dort unter dem Namen schon
 * gibt, bleibt unberührt; die Dateien bleiben liegen.
 */
public final class Uebernahme {
    private Uebernahme() { }

    /** Übernimmt alles Eigene von → nach und gibt je Art eine Zeile zurück. */
    public static List<String> uebernehmen(Speicher von, Speicher nach, Terrain t) throws Ablage.Fehler {
        List<String> z = new ArrayList<>();
        // Siedlungen
        Set<String> da = new HashSet<>();
        for (Daten.Siedlung s : nach.siedlungen()) da.add(s.name());
        int n = 0, hz = 0, ueber = 0;
        for (Daten.Siedlung s : von.siedlungen()) {
            if (!Daten.EIGEN.equals(s.herkunft())) continue;
            if (da.contains(s.name())) { ueber++; continue; }
            List<Daten.Haus> hs = von.haeuser(s.name());
            List<Siedlung.Haus> l = new ArrayList<>();
            for (Daten.Haus h : hs) l.add(Datenseite.haus(h));
            List<Daten.Weg> wege = t != null ? Startdaten.wege(Siedlung.mitHaeusern(t, s.startwert(), l, s.name())) : List.of();
            nach.speichern(new Daten.Siedlung(s.name(), s.startwert(), false, hs.size(), s.beschreibung(), Daten.EIGEN), hs, wege);
            n++;
            hz += hs.size();
        }
        z.add("Siedlungen: " + n + " übernommen (" + hz + " Häuser)" + (ueber > 0 ? ", " + ueber + " gab es schon" : ""));
        // Wetterlagen
        da.clear();
        for (Daten.Wetterlage w : nach.wetterlagen()) da.add(w.name());
        n = 0;
        for (Daten.Wetterlage w : von.wetterlagen()) if (Daten.EIGEN.equals(w.herkunft()) && da.add(w.name())) { nach.speichern(w); n++; }
        z.add("Wetterlagen: " + n);
        // Regiebücher
        da.clear();
        for (Daten.Regiebuch r : nach.regiebuecher()) da.add(r.name());
        n = 0;
        for (Daten.Regiebuch r : von.regiebuecher()) if (Daten.EIGEN.equals(r.herkunft()) && da.add(r.name())) { nach.speichern(r); n++; }
        z.add("Regiebücher: " + n);
        // Fahrten
        da.clear();
        for (Daten.Fahrt f : nach.fahrten()) da.add(f.name());
        n = 0;
        for (Daten.Fahrt f : von.fahrten()) if (Daten.EIGEN.equals(f.herkunft()) && da.add(f.name())) { nach.speichern(f); n++; }
        z.add("Fahrten: " + n);
        // gemerkte Ansichten
        da.clear();
        for (Daten.Ansicht a : nach.ansichten()) da.add(a.art() + "|" + a.name());
        n = 0;
        for (Daten.Ansicht a : von.ansichten()) {
            if (!"GEMERKT".equals(a.art()) || !da.add(a.art() + "|" + a.name())) continue;
            Daten.Ansicht voll = a.zustand() == null && a.id() > 0 ? von.ansicht(a.id()) : a;
            nach.speichern(new Daten.Ansicht(0, voll.name(), voll.taste(), voll.art(), voll.kamera(), voll.augeUeberGrund(), voll.orbit(), voll.abstandM(),
                    voll.szenenzeit(), voll.zustand(), voll.vorschau(), Daten.EIGEN), null);
            n++;
        }
        z.add("Ansichten: " + n);
        // Presets
        n = 0;
        for (String k : Startdaten.PAKETE) {
            int p = k.lastIndexOf('.');
            String paket = k.substring(0, p), klasse = k.substring(p + 1);
            da.clear();
            for (Daten.PaketPreset x : nach.presets(paket, klasse)) da.add(x.name());
            for (Daten.PaketPreset x : von.presets(paket, klasse)) if (Daten.EIGEN.equals(x.herkunft()) && da.add(x.name())) { nach.speichern(x); n++; }
        }
        z.add("Presets: " + n);
        return z;
    }
}
