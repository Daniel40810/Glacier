# com.dan.haithabu – die App

„Rauch über dem Noor“: Haithabu um 950 als 3D-Szene. Die App stellt die Element-Packages unter `com.dan` zu einer Szene zusammen; sie verdrahtet, zeichnet, bedient und (ab Phase 16) speichert. Jedes Package bleibt für sich übersetzbar (`check-packages`, Paketvertrag Punkt 9).

| Teil | Aufgabe |
|---|---|
| `app/HaithabuApp` | Einstieg: Startbild (Datenbank oder `daten/`), FFrame maximiert, Szene links, Bedienfeld rechts, Statuszeile mit dem Speicherort; Sitzung, Protokoll und Sicherung über `com.dan.store.Dienst`. Schalter: `-Dhaithabu.splash=false`, `-Dhaithabu.gljpanel=true`, `-Dhaithabu.shaders=<ordner>`, `-Dhaithabu.db.dir=<ordner>` |
| `scene/` | `Site` (Bachmund als Ursprung, Maße aus dem Werkbuch), `SceneClock` (Datum, Start 16.10.950 17:30 MEZ), `Sun` |
| `wiring/` | Alle Schnittstellen zwischen den Packages und die Verdrahtung ([README](wiring/README.md)) |
| `gl/` | `Renderer` (aus Lighthouse entschlackt: Himmel, Bühne, Nachbearbeitung, HUD), `Quality`, `SceneView`, `HudOverlay`, `ComputeProbe`, `Shader`, `Mat4`, Shader in `gl/shader` |
| `camera/` | Kamera: Kreisen und Frei, Ansichten 1–7 (`Ansichten`), Fahrten (`Fahrt`, Phase 7: „Über den Wall“, Phase 11: „Durch die Gasse“) |
| `ui/` | `ControlPanel` (zehn Blöcke: ZEIT, WETTER, KAMERA, SIEDLUNG, HAFEN, FEUER, LEBEN, BILD, DATEN, TECHNIK), `Startbild` (Stand der Datenbank, Einrichten), `Hauskarte` (Klick auf ein Haus), `Dialoge` (Regiebuch bearbeiten, „Was ist belegt?“), `Weiter`, `AppIcon` (gemalt), `Theme` |
| `data/` | Phase 16: `Daten` (Datensätze), `Startdaten` (was mitkommt, aus der Szene gerechnet), `Speicher` mit `DbSpeicher` (Oracle, Schema HAITHABU) und `DateiSpeicher` (`daten/`), `Verbindung` (Einrichter, Skripte, Zahlen), `Zustand` (die ganze Szene als Text), `Datenseite` (welcher Speicher gilt, Siedlung laden), `Uebernahme`, `StartdatenSql` (schreibt `db/sql/04_startdaten.sql`) |
| `tools/` | `Tempo`: Tempo-Probe und Standbild ohne Fenster; `StartdatenSql`; `Hoerproben`; `GelaendeImport` |

## Stand Phase 1

Flache Bühne auf dem Wasserspiegel von 950 mit Marken [G]: Platzhalter-Noor, Halbkreiswall mit 26 ha (Radius 407 m), Bach, Hochburg, Raster 100 m, Marke am Bachmund. Himmel als Verlauf nach der Sonnenhöhe. Die Packages aus Lighthouse liegen kopiert und unverdrahtet im Build.

## Stand Phase 2b

Wald und Erlenbruch aus `com.dan.forest` (`scene/Vegetation`: im Wall gerodet, Felder bis gut 1 km, Eichen-Buchen-Wald am Gegenufer mit Lichtungen und Gehöft, Schwarzerlen im nassen Saum), Bodendecke aus `com.dan.ground` (`scene/Bodendecke`), eine Sonnenschattenkarte um den Blickpunkt (`gl/SunShadow`), Waldboden und Kronendach im Gelände.

## Stand Phase 5

Die sieben Häuser am Ufer (`scene/Siedlung`, Typen aus `com.dan.timber`): Versammlungshaus, Herberge, Haus des Kammmachers mit Werkstatt, Haus des Tuchhändlers, Haus des Fischers, zwei Wohnhäuser [G], quer zum Bach auf schmalen Grundstücken; Bohlenwege an beiden Ufern, Brücke, Zäune, Ziehbrunnen, Fischgestelle, Boote am Strand. Hofboden im Gelände, keine Halme in Häusern und auf Wegen, Häuser im Sonnenschatten, Nässe nach Regen aus `com.dan.weathering`. Block SIEDLUNG im Bedienfeld.

## Stand Phase 6

Die übrige Siedlung im Wall aus einem Startwert (`Siedlung.haithabu(terrain, seed)`): der Kamm des Halbkreiswalls wird im Gelände gemessen (Halbmesser je 2°), Gassen aus Bohlen laufen alle 40 m parallel zum Bach und folgen seinen Krümmungen, Quergassen zum Wall; an den Gassen schmale Grundstücke (11–17 m), das Haus mit dem Giebel zur Gasse, dahinter Grubenhaus, Schuppen oder Garten, Zäune an gut der Hälfte der Grenzen. Am Ufer Bohlen- und Uferhäuser, am Hang Grubenhäuser, Schmiede, Glasmacher und Bronzegießer im Nordwesten am Wall [G]. Frei bleiben die Höfe am Bach, das Ufer für den Hafen (Phase 8), 18 m am Wall (Phase 7) und die Standpunkte. Vor dem Wall Felder in langen Streifen im Gelände-Shader (gepflügt, Stoppeln, Wintersaat, Brache), Gärten als Beete. Im Bedienfeld: Startwert ±1, „Neu würfeln“, „Siedlung speichern“ nach `daten/siedlung.csv`, die beim Start geladen wird.

## Stand Phase 7

Wall, Tore, Hochburg (`scene/Befestigung`). Der Kamm des Halbkreiswalls ist im DGM1 gemessen (1 402 m, 86 % gemessen; Tabelle `KAMM`), ergänzt [G] sind der Bogen im Nordwesten, wo eine moderne Straße den Wall schneidet, und die beiden Enden bis an das Ufer von 950. `Befestigung.formen` ändert das Gelände gleich beim Laden (`Terrain.load`; `-Dhaithabu.befestigung=false` lässt es wie im DGM): Wallkörper, wo er fehlt, an den Toren in voller Höhe; ein Graben 17 m vor dem Kamm (2 m tief [G]), so dass der Wall von der Grabensohle bis zum Kamm rund 9 m misst; die Torgassen eben; die Hochburg als Rechteck 240 × 72 m mit niedrigem Wall und Tor im Nordosten [G], darin 80 Grabhügel an den Kuppen, die das DGM zeigt; der Verbindungswall (um 968) für 950 eingeebnet (F24 A). Darauf aus `com.dan.timber` die Palisade (3 m) auf der Außenkante, der Wehrgang dahinter, Torbauten mit Turm am Nord-, West- und Südtor und der Durchlass des Bachs neben dem Westtor. Die Siedlung nimmt Wall und Innenraum aus der Kammlinie (vorher ein Kreis, der im Norden zu weit reichte). Fahrt „Über den Wall“ (Taste 8, `camera/Fahrt`) auf dem Wehrgang vom Südende bis zum Nordende; im Block KAMERA auch als Bildfolge aus sechs Bildern nach `docs/status`.

## Stand Phase 8

Der Hafen (`scene/Hafen`, gebaut mit der Siedlung). Das Ufer von 950 wird zwischen den Wallenden im Gelände gesucht. Davor eine Plattform 13 m breit (Deck 0,9 m) nördlich des Bachs und südlich des Fischerstrands; neun Landebrücken bis 1,9 m Wassertiefe (55–62 m lang, einige mit Querkopf), ein Umschlagplatz 18 m breit zwischen zwei Brücken; die Hafenpalisade im Wasser im Bogen von Wallende zu Wallende, so weit draußen, dass das Becken 10 ha hat, mit einer Durchfahrt von 14 m nach Nordost; Uferbefestigung aus Bohlen, wo keine Plattform steht; Waren auf den Brücken. Unter Brücken und Plattform wächst kein Schilf. Alle Pfähle im Wasser gehen als Abstandsraster an `com.dan.ocean` (Brandungsring auch bei Bft 5 im Noor), der Wasserstand an `com.dan.timber` (Algenlinie). Ansicht „Hafen“ steht auf der Plattform an der Wurzel der dritten Brücke.

## Stand Phase 9

Die Schiffe (`scene/Flotte`, Package `com.dan.longship`): ein Langschiff (Haithabu 1) längsseits an der dritten Brücke, eine Knorr vor dem südlichen Querkopf, ein Faering im Süden; eine zweite Knorr läuft auf Wunsch ein („Knorr einlaufen“ im Block KAMERA oder Taste 9 mit Mitfahrt am Steuer). Sie segelt aus dem Noor heran, wenn der Wind es zulässt (sonst rudert sie), birgt 75 m vor der Durchfahrt das Segel, rudert auf der Linie durch die Lücke der Palisade und legt am nördlichen Querkopf an. Fahrt und Segel rechnet `longship`, Tauchen, Stampfen und Rollen `buoyancy` aus den Säulen des Rumpfs gegen die Höhe des Noors. Kielwasser und Riemenschläge laufen als Ringwellen ins Noor, die Blätter spritzen beim Einsetzen (`spray`, F22). Der Umriss jedes Rumpfs in der Wasserlinie (`ocean.HullMask`) hält das Wasser aus den offenen Booten. Die Funde sind jünger als 950; die Schiffe stehen hier als Typen [G].

## Stand Phase 10

Feuer und Rauch (`scene/Feuer`, Packages `com.dan.hearth` und `com.dan.smoke`):
- Jedes Haus mit Rauchloch hat einen Herd mit Tagesgang. Dazu kommen die Essen der Gewerke, zehn Fackeln an Toren und Brückenköpfen und die Feuerstelle am Strand.
- Der Rauch steigt nach Briggs auf und legt sich in der Abendinversion flach.
- Die acht hellsten Feuer leuchten auf Häuser, Gelände und Rauch.

## Stand Phase 11

Das Versammlungshaus innen (`scene/Versammlungshaus`):
- Hülle und Einrichtung: Das Haus aus Phase 5 hat offene Türen und offene Rauchlöcher und ist eingerichtet (`timber.Interior`). `TimberGl.setSpecial` zeichnet dieses eigene Netz statt der Stufe des Typs.
- Licht innen: Innen fällt die Sonne nur durch Tür und Rauchloch, den Himmel sieht man nur durch die Öffnungen. Dazu kommen Rückstrahlung sowie Herd, Glut und Lampen als Lichter des Raums.
- Rauch: Der Rauch des Langfeuers sammelt sich unter dem Dach als Schicht (`smoke.RoomSmoke`, Zwei-Zonen-Modell). Er zieht durch die Rauchlöcher ab und wird als Volumen mit Lichtstrahlen gezeichnet (`smoke.gl.RoomSmokeGl`).
- Tageslauf [G]: Das Feuer brennt morgens, mittags und abends, nachts bleibt die Glut.
- Gelände: Unter dem Haus blendet der Gelände-Shader den Boden aus (`uHole`); dort liegt der Lehmboden.
- Kamera: Taste 7 „Im Haus“ steht am Südende. Taste 0 fährt „Durch die Gasse“ vom Bohlenweg durch die Osttür hinein.
- Außerdem, aus den Befunden von Phase 10:
  - Feuer, Rauch und Haus sind eigene Zeitposten im HUD.
  - Die Rauchbälle rechnen ihr Licht je Ball, das Rauschen kommt aus einer Textur; die Abendfahnen sind dichter.
  - Das Auge passt sich an Feuerlicht und an das Licht im Haus an. Hell Erleuchtetes behält nachts seine Farbe.
  - Herde leuchten nur noch aus der Tür nach draußen.

## Stand Phase 16

Oberfläche und Datenbank (F25–F36 A):
- Neues Package `com.dan.store` (aus Lighthouse herausgelöst): Verbindung, Einrichter, Feldleser, Textformat, Sitzung, Protokoll, Dateiablage, WKT.
- Schema HAITHABU auf PDBORCL, Präfix `HB_`, 22 Tabellen, SRID 8307 ([db/README](../../../../db/README.md)). Häuser als Zeilen mit Punkt und Grundriss, mehrere Siedlungen, eine aktiv; Wege, Zäune und Gärten rechnet der Startwert, in die Datenbank kommen sie für den Lageplan. Lageplan (Wall, Graben, Palisaden, Hochburg mit Grabhügeln, Ufer von 950, Hafenbecken, Brücken, Plattform, Bach) nur zum Lesen; das Gelände bleibt Datei, in `HB_GELAENDE` stehen Ausschnitt und Prüfsumme.
- Regiebücher als Text (`scene/regie/*.txt`, in der Datenbank zerlegt in `HB_REGIEBUCH` und `HB_STICHWORT`), mit Fenster zum Bearbeiten. Szenenzeit als Zahlen (`SZ_JAHR` bis `SZ_STUNDE`), nie als Oracle-DATE.
- „Weiter wie zuletzt“ mit Uhr, Wetter, Kamera, Regiebuch an seiner Stelle, Brand und Schiffen; gesichert alle 2 min und beim Ende.
- Befunde (`HB_BEFUND`, belegt, gemessen, gestaltet) mit Quellen; „Was ist belegt?“ im Block TECHNIK, der Befund zum Haustyp in der Hauskarte.
- Ohne Datenbank dasselbe in `daten/` (Siedlungen als CSV, Sitzungen, Protokoll, Ansichten mit PNG); „In die Datenbank übernehmen“ im Block DATEN.
- Aus den Befunden der Abnahme Phase 15: nach einem Sprung der Uhr stehen die Herde gleich auf der neuen Stunde (vorher rauchten die Herde des Abends noch eine Minute nach); die geplanten Verbindungen sind abgeglichen.

## Stand Phase 17

Schliff:
- Programmsymbol als `icon/haithabu.ico` und als PNGs im Jar (`tools/Symbol`); `Haithabu.bat` startet das Jar, `Verknuepfung.bat` legt eine Verknüpfung auf den Desktop.
- Qualitätsstufen reichen jetzt auch in Rauch, Rauch im Haus, Klang, Nässekarte, Spritzer, Vögel und Bodendecke; „Mittel“ bleibt, wie es war.
- Nachts passt sich das Auge auch an das an, was im Bild hell ist (Mittel einer kleinen Mip-Stufe des HDR-Bilds, viermal je Sekunde, ohne Warten); ein ferner Brand blendet nicht mehr weiß. Regler im Block BILD.
- `tools/Dauerlauf`: eine halbe Stunde ohne Fenster; `tools/Quellenliste` schreibt `docs/QUELLEN.md`.
- Die erweiterten Packages (`ocean`, `weather`, `soundscape`, `flock`, `fog`, `forest`, `ground`, `river`, `road`) gehen zurück nach Lighthouse.

## Prüfen

- `test/…/Pruefung` (Ant-Target `pruefung`) endet mit „ERGEBNIS: alles in Ordnung“; sie prüft auch die Datenseite ohne Datenbank (`PruefungDaten`).
- `test/…/DbPruefung` („Run File“) prüft gegen Oracle und räumt danach auf; Ende „Alles in Ordnung.“
- `tools/PaketPruefung.java` (Ant-Target `check-packages`, läuft nach jedem Übersetzen) übersetzt jedes Package für sich.
- `com.dan.haithabu.tools.Tempo 120 1920 1080 docs/status/Tempo.png MITTEL` misst und schreibt ein Standbild.
- `com.dan.haithabu.tools.Dauerlauf` („Run File“, 30 Minuten ohne Fenster) schreibt `docs/status/Dauerlauf.txt`; letzte Zeile „Dauerlauf bestanden“.
