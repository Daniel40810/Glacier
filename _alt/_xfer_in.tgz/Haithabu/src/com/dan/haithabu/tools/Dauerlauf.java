package com.dan.haithabu.tools;

import com.dan.haithabu.camera.Ansichten;
import com.dan.haithabu.data.DateiSpeicher;
import com.dan.haithabu.data.Speicher;
import com.dan.haithabu.data.Zustand;
import com.dan.haithabu.gl.Quality;
import com.dan.haithabu.gl.Renderer;
import com.dan.haithabu.scene.Regie;
import com.dan.haithabu.scene.SceneClock;
import com.dan.haithabu.scene.Siedlung;
import com.dan.haithabu.scene.Terrain;
import com.dan.haithabu.ui.Hauskarte;
import com.dan.haithabu.wiring.Wiring;
import com.dan.store.Ablage;
import com.dan.store.Felder;
import com.dan.weather.Weather;
import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLDrawableFactory;
import com.jogamp.opengl.GLOffscreenAutoDrawable;
import com.jogamp.opengl.GLProfile;

import java.io.File;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/**
 * Phase 17: der Dauerlauf (nach Lighthouse). Die ganze Szene läuft ohne Fenster so lange wie angegeben (Vorgabe 30
 * Minuten) durch Tage, Nächte und Monate: alle drei Regiebücher, an zufälliger Stelle fortgesetzt, der Brander mit
 * dem Brand und „Brand löschen“, die Knorr ein und aus, alle Ansichten, freie Wetterlagen, Blitze, Monatssprünge,
 * Zeitraffer, alle vier Qualitätsstufen, die Regelung der Auflösung, alle vier Minuten eine neu gewürfelte Siedlung
 * (Häuser, Hafen, Feuer und Tiere werden neu hochgeladen), Klicks der Hauskarte, der Klang (offline gerechnet) und
 * jede Minute der ganze Zustand hin und zurück samt Sicherung in eine Dateiablage. Gemessen werden Bilder je Sekunde,
 * das schlechteste Bild, der Speicher nach dem Aufräumen und jede Ausnahme in irgendeinem Faden.
 * <p>
 * Bestanden heißt: keine Ausnahme, kein Grafikfehler, der Speicher nach der fünften Minute nicht mehr als 25 %
 * gewachsen (plus 64 MB), kein Bild über 2 s (oder das 20-fache des Mittels; die zwei Sekunden nach einem Stufen- oder
 * Siedlungswechsel zählen getrennt und dürfen bis 8 s brauchen), und am Ende ist der Zustand noch herstellbar. Das
 * Protokoll steht in {@code docs/status/Dauerlauf.txt} (oder dem angegebenen Pfad); die letzte Zeile ist „Dauerlauf
 * bestanden“ oder „Dauerlauf NICHT bestanden“ mit dem Grund. Fotos und Blätter der Regiebücher gehen in einen
 * Ordner auf Zeit, nicht nach docs/status.
 * <pre>
 * Dauerlauf [Minuten] [Breite] [Datei]
 * </pre>
 * In NetBeans: Rechtsklick auf die Datei, „Run File“ (läuft eine halbe Stunde, ohne Fenster).
 */
public final class Dauerlauf {
    private Dauerlauf() { }

    static final List<String> FEHLER = new ArrayList<>();

    public static void main(String[] a) throws Exception {
        double minuten = a.length > 0 ? Double.parseDouble(a[0].replace(',', '.')) : 30;
        int width = a.length > 1 ? Integer.parseInt(a[1]) : 1280;
        File out = new File(a.length > 2 ? a[2] : "docs/status/Dauerlauf.txt");
        if (out.getParentFile() != null) out.getParentFile().mkdirs();
        int height = width * 9 / 16;
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> { synchronized (FEHLER) { FEHLER.add("Faden " + t.getName() + ": " + e); } e.printStackTrace(); });
        PrintWriter pw = new PrintWriter(Files.newBufferedWriter(out.toPath(), StandardCharsets.UTF_8));
        java.util.function.Consumer<String> say = s -> { System.out.println(s); pw.println(s); pw.flush(); };
        say.accept(String.format(Locale.GERMAN, "Haithabu · Dauerlauf · %s · %.0f Minuten · %d×%d · %s", Renderer.VERSION, minuten, width, height,
                java.time.LocalDateTime.now().withNano(0)));
        say.accept("Rechner: " + System.getProperty("os.name") + " · Java " + System.getProperty("java.version") + " · " + Runtime.getRuntime().availableProcessors() + " Kerne · Xmx "
                + Runtime.getRuntime().maxMemory() / 1048576 + " MB");

        GLProfile prof = GLProfile.get(GLProfile.GL4);
        GLCapabilities caps = new GLCapabilities(prof);
        caps.setOnscreen(false);
        caps.setFBO(true);
        caps.setDepthBits(24);
        GLOffscreenAutoDrawable d = GLDrawableFactory.getFactory(prof).createOffscreenAutoDrawable(null, caps, null, width, height);
        d.setAutoSwapBufferMode(false);
        Terrain terrain = Terrain.load(Terrain.defaultDir());
        Renderer.siedlungsLader = Siedlung::haithabu;
        SceneClock clock = new SceneClock();
        clock.lapse = 600;
        Wiring wiring = new Wiring(clock);
        wiring.regie = true;
        wiring.yearOn = true;
        wiring.startFree(Weather.Phase.KLAR);
        Renderer r = new Renderer(clock, wiring, terrain);
        File fotos = Files.createTempDirectory("haithabu-dauerlauf-fotos").toFile();
        r.photoDir = fotos;
        r.showHud = true;
        r.autoScale = true;
        r.targetFps = 60;
        r.setQuality(Quality.MITTEL);
        d.addGLEventListener(r);
        d.display();
        if (r.error() != null) { say.accept("FEHLER Grafik: " + r.error()); say.accept("Dauerlauf NICHT bestanden"); pw.close(); System.exit(2); }
        say.accept("Grafik: " + r.glInfo());
        float[] ton = new float[2 * 2048];
        List<Regie.Book> buecher = Regie.all();
        Quality[] qs = Quality.values();
        Random rnd = new Random(950);
        File daten = Files.createTempDirectory("haithabu-dauerlauf").toFile();
        Speicher ds = new DateiSpeicher(daten);
        long sid = ds.sitzungBeginnen(Renderer.VERSION, r.glInfo(), r.quality().name());

        long start = System.nanoTime(), ende = start + (long) (minuten * 60e9), lastMinute = start, lastShot = start;
        long frames = 0;
        double worst = 0, worstAll = 0, worstSwitch = 0;
        long switchUntil = 0;
        long heap5 = -1, heapEnd = -1;
        int minute = 0, aktionen = 0, buchStarts = 0, brande = 0, stufen = 0, siedlungen = 0, zustaende = 0, treffer = 0, blitze = 0;
        double sumFps = 0;
        int fpsN = 0;
        long lastNanos = System.nanoTime();
        while (System.nanoTime() < ende) {
            long t0 = System.nanoTime();
            d.display();
            long t1 = System.nanoTime();
            double ms = (t1 - t0) / 1e6;
            frames++;
            if (frames > 30 && t1 < switchUntil) worstSwitch = Math.max(worstSwitch, ms);
            else if (frames > 30) { worst = Math.max(worst, ms); worstAll = Math.max(worstAll, ms); }
            double dt = (t1 - lastNanos) / 1e9;
            lastNanos = t1;
            int n = Math.min(2048, (int) Math.round(dt * r.sound.sampleRate()));
            if (n > 0) r.sound.render(ton, n);
            if (r.error() != null) { synchronized (FEHLER) { FEHLER.add("Grafik: " + r.error()); } break; }
            // alle 12 s etwas tun
            if (t1 - lastShot > 12_000_000_000L) {
                lastShot = t1;
                int k = aktionen++ % 14;
                switch (k) {
                    case 0, 5, 10 -> {
                        Ansichten.Ansicht v = Ansichten.ALLE.get(rnd.nextInt(Ansichten.ALLE.size()));
                        if (!v.orbit() && Ansichten.ready(v)) Ansichten.apply(v, r.camera, r.terrain); else r.camera.home();
                    }
                    case 1 -> {
                        Regie.Book b = buecher.get(rnd.nextInt(buecher.size()));
                        r.regieFortsetzen(b, rnd.nextDouble() * b.length() * 0.9);
                        buchStarts++;
                    }
                    case 2 -> { r.branderLos(); brande++; }
                    case 3 -> { r.triggerLightning(com.dan.lightning.Bolt.Kind.CLOUD_GROUND); blitze++; }
                    case 4 -> { r.setQuality(qs[rnd.nextInt(qs.length)]); stufen++; switchUntil = System.nanoTime() + 2_000_000_000L; }
                    case 6 -> { wiring.resumeRegie(); wiring.startFree(Weather.Phase.values()[rnd.nextInt(Weather.Phase.values().length)]); }
                    case 7 -> { if (rnd.nextBoolean()) r.knorrEinlaufen(); else r.knorrAuslaufen(); }
                    case 8 -> { clock.set(LocalDate.of(950, 1 + rnd.nextInt(12), 16), rnd.nextDouble() * 24); clock.lapse = new double[]{1, 60, 600, 3600}[rnd.nextInt(4)]; }
                    case 9 -> { if (Hauskarte.treffer(r, width / 2, height / 2, width, height) != null) treffer++; }
                    case 11 -> { r.clearBrand(); r.startRegie(null); }
                    case 12 -> {
                        if (aktionen % 28 == 13) {
                            r.setSiedlung(Siedlung.haithabu(terrain, 950 + rnd.nextInt(1000)));
                            siedlungen++;
                            switchUntil = System.nanoTime() + 2_000_000_000L;
                        }
                    }
                    case 13 -> { r.camera.autoOrbit = true; }
                    default -> { }
                }
            }
            // jede Minute: Zustand hin und zurück, Sicherung, Speicher, Zeile
            if (t1 - lastMinute > 60_000_000_000L) {
                lastMinute = t1;
                minute++;
                LinkedHashMap<String, String> z = Zustand.erfassen(r, false, "Dauerlauf");
                String text = Felder.alsText(z, "Dauerlauf");
                List<String> f = Zustand.anwenden(r, Felder.ausText(text));
                if (!f.isEmpty()) synchronized (FEHLER) { FEHLER.add("Minute " + minute + ": Zustand nicht ganz hergestellt: " + f); }
                Map<String, String> sp = new HashMap<>();
                sp.put(Speicher.SZ, z.get("uhr.datum") + " " + z.get("uhr.stunde"));
                ds.sitzungSichern(sid, new Ablage.Sicherung(text, sp));
                zustaende++;
                System.gc();
                Thread.sleep(50);
                long heap = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1048576;
                if (minute == 5) heap5 = heap;
                heapEnd = heap;
                double fps = r.fps();
                sumFps += fps;
                fpsN++;
                var fe = r.feuer;
                say.accept(String.format(Locale.GERMAN, "Minute %2d · %s · %.0f Bilder/s · Grafikkarte %.1f ms · Prozessor %.1f ms · schlechtestes Bild %.0f ms · Auflösung %.0f %% (%s) · Speicher %d MB · %s · %s · %d Werte",
                        minute, clock.label(), fps, r.gpuMs(), r.cpuMs(), worst, r.renderScale * 100, r.quality().label, heap,
                        fe != null && fe.brand != null ? fe.brand.describe() : "kein Brand", r.regieLine(), z.size()));
                worst = 0;
            }
        }
        ds.sitzungBeenden(sid);
        boolean lesbar;
        try {
            LinkedHashMap<String, String> z = Zustand.erfassen(r, false, "Dauerlauf");
            lesbar = z.size() > 100 && Zustand.anwenden(r, z).isEmpty();
        } catch (RuntimeException e) {
            lesbar = false;
            synchronized (FEHLER) { FEHLER.add("Zustand am Ende: " + e); }
        }
        double sek = (System.nanoTime() - start) / 1e9;
        say.accept(String.format(Locale.GERMAN, "Ende nach %.1f Minuten: %d Bilder, im Mittel %.1f Bilder/s, schlechtestes Bild %.0f ms, %d Aktionen, %d Regiebücher, %d Brander, %d Blitze, "
                        + "%d Stufenwechsel, %d neue Siedlungen, %d Treffer der Hauskarte, %d× Zustand hin und zurück, Auflösung %d× geregelt, Speicher Minute 5: %d MB, Ende: %d MB, größter Ruck beim Wechsel %.0f ms",
                sek / 60, frames, fpsN > 0 ? sumFps / fpsN : frames / sek, worstAll, aktionen, buchStarts, brande, blitze, stufen, siedlungen, treffer, zustaende, r.scaleSteps(),
                heap5, heapEnd, worstSwitch));
        List<String> gruende = new ArrayList<>();
        synchronized (FEHLER) { gruende.addAll(FEHLER); }
        if (heap5 > 0 && heapEnd > heap5 * 1.25 + 64) gruende.add(String.format(Locale.GERMAN, "Speicher wächst: %d MB nach Minute 5, %d MB am Ende", heap5, heapEnd));
        double mean = sek / Math.max(1, frames) * 1000;
        if (worstAll > Math.max(2000, 20 * mean)) gruende.add(String.format(Locale.GERMAN, "ein Bild brauchte %.0f ms (Mittel %.0f ms)", worstAll, mean));
        if (worstSwitch > 8000) gruende.add(String.format(Locale.GERMAN, "ein Wechsel brauchte %.0f ms", worstSwitch));
        if (!lesbar) gruende.add("Zustand am Ende nicht mehr herstellbar");
        if (minute < 1) gruende.add("keine volle Minute gelaufen");
        for (String g : gruende) say.accept("FEHLER " + g);
        say.accept(gruende.isEmpty() ? "Dauerlauf bestanden" : "Dauerlauf NICHT bestanden (" + gruende.size() + " Gründe)");
        pw.close();
        System.exit(gruende.isEmpty() ? 0 : 1);
    }
}
