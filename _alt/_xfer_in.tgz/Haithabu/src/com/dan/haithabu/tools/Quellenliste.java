package com.dan.haithabu.tools;

import com.dan.haithabu.data.Daten;
import com.dan.haithabu.data.Startdaten;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Phase 17: schreibt {@code docs/QUELLEN.md} aus denselben Quellen und Befunden, die als {@code HB_QUELLE} und
 * {@code HB_BEFUND} in der Datenbank stehen (Startdaten), dazu die Verfahren hinter den Packages. Die Prüfung
 * meldet, wenn die Datei nicht mehr zu den Startdaten passt.
 * <pre>
 * Quellenliste [projektordner]
 * </pre>
 */
public final class Quellenliste {
    private Quellenliste() { }

    /** Verfahren und Modelle hinter den Packages (keine Belege für Haithabu, sondern für die Rechnung). */
    static final String[] VERFAHREN = {
            "Himmel (`sky`): Hillaire, „A Scalable and Production Ready Sky and Atmosphere Rendering Technique“ (EGSR 2020); Meeus, „Astronomical Algorithms“; HYG-Sternkatalog; Präzession für das Jahr 950",
            "Wolken, Regen, Nebel, Blitz, Wetter (`cloud`, `rain`, `fog`, `lightning`, `weather`): wie in Lighthouse; Marshall–Palmer für Tropfengrößen, WMO-Beaufortskala, Magnus-Formel für den Taupunkt",
            "Noor (`ocean`): Wellenspektrum mit FFT auf der Grafikkarte, Flachwasser und kurzes Fetch wie im Werkbuch (F7); Windstau [G]",
            "Rauch (`smoke`): Aufstieg der Fahne nach Briggs, Abendinversion aus Sonnenhöhe, Wind und Bedeckung; Zwei-Zonen-Modell im Haus und Massenstrom nach Heskestad (SFPE Handbook)",
            "Feuer (`hearth`): Flammenhöhe nach Heskestad (L = 0,23 · Q^0,4), Lichtstrom ≈ 150 · Q^0,9 lm bei etwa 1 800 K; Brand der Häuser mit Wärmestrahlung, Zündung von Reet ab 300 kJ/m² [G] und Flugfeuer",
            "Holzbau (`timber`): Bauweisen nach den Befunden unten; Maße der sechs Haustypen gestaltet [G] nach Literatur und den Museumshäusern",
            "Schiffe (`longship`, `buoyancy`, `spray`): Maße von Haithabu 1 (Hedeby 1), Knorr und Faering als Typen [G]; Auftrieb aus Säulen des Rumpfs gegen die Höhe des Noors",
            "Jahr (`season`): Klima von Schleswig als Monatstabelle, gewürfeltes Jahr; Eisdicke nach Stefan; Schnee mit Setzung und Schmelze [G]",
            "Tiere und Klang (`flock`, `herd`, `soundscape`): Fluchtdistanzen und Rufe gestaltet [G]; Klang erzeugt, ohne Aufnahmen; Schallgeschwindigkeit nach der Lufttemperatur",
            "Bild: Filmkurve ACES nach Narkowicz; Augenanpassung nach dem Himmel (com.dan.sky), dem Licht der Feuer und nachts dem mittleren Bild (Phase 17)",
            "Kalender: gregorianisch zurückgerechnet wie `java.time` (F21); Oracle rechnet vor 1582 julianisch, darum steht die Szenenzeit in der Datenbank als Zahlen (F32)"};

    public static void main(String[] a) throws IOException {
        File base = new File(a.length > 0 ? a[0] : ".");
        File f = new File(base, "docs/QUELLEN.md");
        f.getParentFile().mkdirs();
        Files.writeString(f.toPath(), text(), StandardCharsets.UTF_8);
        System.out.println("Quellen: " + f + " (" + Startdaten.quellen().size() + " Quellen, " + Startdaten.befunde().size() + " Befunde)");
    }

    /** Der ganze Text der Datei. */
    public static String text() {
        StringBuilder b = new StringBuilder();
        b.append("# Haithabu – Quellen\n\n");
        b.append("Was in der Szene auf einer Veröffentlichung, einer Messung oder einem Foto beruht, steht hier. Jede Aussage über das Vorbild trägt eine von drei Marken: "
                + "**belegt** (aus Literatur und Fund), **gemessen** (aus dem Gelände, DGM1) oder **gestaltet** (eine begründete Annahme der Szene, im Werkbuch [G]). "
                + "Dieselben Einträge stehen in der Datenbank als `HB_QUELLE` und `HB_BEFUND`; in der App zeigt sie „Was ist belegt?“ im Block TECHNIK. "
                + "Diese Datei schreibt `tools.Quellenliste` aus `data/quellen.txt` und `data/befunde.txt`; bitte dort ändern.\n\n");
        b.append("## Quellen\n\n");
        for (Daten.Quelle q : Startdaten.quellen()) {
            b.append("- **").append(q.kurz()).append("**: ");
            if (q.url() != null && !q.url().isBlank() && !q.url().equals("-")) b.append('[').append(q.titel()).append("](").append(q.url()).append(')');
            else b.append(q.titel());
            if (q.abgerufen() != null) b.append(", abgerufen ").append(q.abgerufen());
            if (q.bemerkung() != null && !q.bemerkung().isBlank()) b.append(". ").append(q.bemerkung());
            b.append('\n');
        }
        Map<String, Integer> zahl = new LinkedHashMap<>();
        for (Daten.Befund x : Startdaten.befunde()) zahl.merge(x.befund(), 1, Integer::sum);
        b.append(String.format(Locale.GERMAN, "%n## Befunde%n%n%d Befunde: %d belegt, %d gemessen, %d gestaltet.%n",
                Startdaten.befunde().size(), zahl.getOrDefault("BELEGT", 0), zahl.getOrDefault("GEMESSEN", 0), zahl.getOrDefault("GESTALTET", 0)));
        String thema = null;
        for (Daten.Befund x : Startdaten.befunde()) {
            if (!x.thema().equals(thema)) {
                thema = x.thema();
                String t = thema.charAt(0) + thema.substring(1).toLowerCase(Locale.GERMAN).replace("ae", "ä").replace("oe", "ö").replace("ue", "ü");
                b.append("\n### ").append(t).append("\n\n");
            }
            b.append("- **").append(x.gegenstand()).append("** (").append(x.befund().toLowerCase(Locale.GERMAN)).append(x.befund().equals("GESTALTET") ? ", [G]" : "")
                    .append("): ").append(x.text());
            List<String> q = x.quellen();
            if (!q.isEmpty()) b.append(" — ").append(String.join(", ", q));
            b.append('\n');
        }
        b.append("\n## Verfahren hinter den Packages\n\n");
        for (String v : VERFAHREN) b.append("- ").append(v).append('\n');
        return b.toString();
    }
}
