# com.dan.haithabu.wiring – die Verdrahtung

Hier reden die Packages miteinander, und nur hier. Kein Element-Package (die zehn aus Lighthouse, die vier aus Geyser und die sechs neuen) kennt ein anderes oder die App. Jedes bietet Eingänge an und meldet Ereignisse; die App verbindet sie in `Wiring`.

Stand Phase 1: alle Schnittstellen stehen, verbunden ist noch nichts. `Wiring.planned()` nennt die Verbindungen aus dem Phasenplan.

## Die Schnittstellen

| Schnittstelle | Inhalt | Gibt | Nimmt | ab Phase |
|---|---|---|---|---|
| `Clock` | Laufzeit, Schritt, Uhrzeit, Ort | App (`SceneClock`) | alle | 1 |
| `Wind` | Geschwindigkeit, Richtung, Böigkeit, Bft | weather (bis dahin von Hand) | ocean, cloud, rain, fog, smoke, hearth, reed, forest, longship, flock, soundscape | 1 |
| `WaterLevel` | Wasserspiegel des Noors (Windstau, keine Tide) | weather über die App | ocean, buoyancy, weathering, longship, reed, Kamera | 1 |
| `Terrain` | Höhe, Wassertiefe, Normale am Ort | Gelände aus den Höhendaten | timber, reed, forest, ground, river, smoke, Kamera | 2 |
| `Lighting` | Sonne, Mond, Himmel, Dunst | sky | ocean, cloud, smoke, rain, timber, Szene | 3 |
| `Flash` | Blitz | lightning | cloud, ocean, weathering, sky, hearth, soundscape | 3 |
| `HeatSource` | Rauchaustritt, Wärme, Rauchmenge, Schwärze | timber (Rauchlöcher), hearth | smoke | 4 |
| `Collider` | fester Körper als Abstandsfeld | timber, longship | ocean, rain, smoke, buoyancy | 4 |
| `SurfaceHit` | Einschlag: Tropfen, Riemen, Funke | rain, longship, hearth | ocean, weathering, hearth | 5 |
| `FireLight` | Licht eines Feuers | hearth | Szene, smoke, ocean, fog | 10 |
| `ScatterField` | Streudichte am Ort | fog, rain, smoke | Lichtstrahlen im Haus, Nebel-Durchgang | 11 |
| `Season` | Laub, Färbung, Schnee, Eisrand | season | forest, reed, timber, ground, ocean, weather | 12 |
| `SoundEvent` | Klangereignis | longship, hearth, flock, herd, lightning, Gewerke | soundscape | 14 (verbunden) |

`Beaufort` gibt die gemeinsame Sprache für alle Presets: Grenzen nach WMO und die deutschen Bezeichnungen.

## Regeln

- Jede Schnittstelle besteht nur aus Zahlen, Aufzählungen und Funktionen. Keine Klassen aus anderen Packages.
- Braucht ein Package dieselbe Form, bringt es eine eigene Kopie mit gleichem Namen mit. `Wiring` übersetzt mit einer Zeile.
- Jede neue Verbindung wird mit `link(von, an, über, Phase)` eingetragen. Das Bedienfeld zeigt die Liste.
