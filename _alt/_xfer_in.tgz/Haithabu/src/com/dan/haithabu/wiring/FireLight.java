package com.dan.haithabu.wiring;

/**
 * Licht eines Feuers: Herd, Fackel, Talglampe, Brand. Gibt: {@code hearth} (Phase 10). Nimmt: die Szene (Licht in
 * Türen und auf Wänden), smoke (von unten angestrahlter Rauch), ocean (Spiegelung im Noor), fog.
 */
public interface FireLight {
    double[] position();

    /** Farbe (linear, RGB) und Lichtstrom in Lumen, beide in diesem Augenblick (Flackern eingerechnet). */
    double[] color();
    double lumen();

    /** Reichweite in m, ab der das Licht nicht mehr gerechnet wird. */
    default double range() { return 25; }
}
