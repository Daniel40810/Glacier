package com.dan.haithabu.test;

import com.dan.haithabu.gl.Quality;
import com.dan.haithabu.gl.Renderer;
import com.dan.haithabu.scene.SceneClock;
import com.dan.haithabu.scene.Siedlung;
import com.dan.haithabu.scene.Terrain;
import com.dan.haithabu.tools.Quellenliste;
import com.dan.haithabu.tools.Symbol;
import com.dan.haithabu.ui.AppIcon;
import com.dan.haithabu.wiring.Wiring;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Phase 17: Schliff (nach Lighthouse). Programmsymbol und Verknüpfung, READMEs und Bilder, Quellen, Qualitätsstufen
 * durchgängig, Regelung der Auflösung, Augenanpassung an das Bild, Dauerlauf.
 */
final class PruefungSchliff {
    private PruefungSchliff() { }

    static void check(boolean c, String w) { Pruefung.check(c, w); }

    public static void main(String[] a) throws Exception { alles(Terrain.load(new File("daten/gelaende"))); }

    static void alles(Terrain t) throws Exception {
        System.out.println("Schliff (Phase 17): Programmsymbol und Verknüpfung");
        File ico = new File("icon/haithabu.ico");
        check(ico.isFile(), "icon/haithabu.ico vorhanden");
        int[] s = ico.isFile() ? Symbol.icoGroessen(ico) : new int[0];
        check(Arrays.equals(s, AppIcon.SIZES), "ICO mit PNG-Einträgen in den Größen " + Arrays.toString(s));
        boolean pngs = true;
        for (int n : AppIcon.SIZES) pngs &= new File("src/com/dan/haithabu/ui/icon/haithabu_" + n + ".png").isFile() && AppIcon.load(n).getWidth() == n;
        check(pngs, "PNGs des Symbols im Jar, AppIcon.load liefert jede Größe");
        java.awt.image.BufferedImage ic = AppIcon.load(64);
        int edge = ic.getRGB(32, 1);
        check(((edge >> 16) & 255) > 150 && ((edge >> 8) & 255) > 100 && (edge & 255) < 150, "Goldkante am Rand des Symbols (F18)");
        String ps1 = lies("Verknuepfung.ps1"), bat = lies("Verknuepfung.bat"), start = lies("Haithabu.bat");
        check(ps1.contains("dist\\Haithabu.jar") && ps1.contains("icon\\haithabu.ico") && ps1.contains("CreateShortcut") && ps1.contains("WorkingDirectory = $root")
                        && ps1.contains("$PSScriptRoot"), "Verknuepfung.ps1 legt die Verknüpfung auf das Jar mit Symbol, Arbeitsordner ist der Projektordner (daten/, db/)");
        check(bat.contains("Verknuepfung.ps1") && bat.contains("ExecutionPolicy Bypass") && bat.contains("\r\n"), "Verknuepfung.bat ruft das Skript (CRLF)");
        check(start.contains("dist\\Haithabu.jar") && start.contains("\r\n"), "Haithabu.bat startet das Jar");
        // Befund nach Phase 17: mit java -jar fand JOGL keine GraphicsConfiguration (ohne Zugriff auf sun.awt.windows)
        java.util.jar.Manifest mf;
        try (var in = new java.io.FileInputStream("manifest.mf")) { mf = new java.util.jar.Manifest(in); }
        String opens = mf.getMainAttributes().getValue("Add-Opens");
        check(opens != null && opens.contains("java.desktop/sun.awt.windows") && opens.contains("java.desktop/sun.awt ") && opens.contains("java.desktop/sun.java2d")
                        && "ALL-UNNAMED".equals(mf.getMainAttributes().getValue("Enable-Native-Access")) && start.contains("sun.awt.windows=ALL-UNNAMED") && ps1.contains("sun.awt.windows=ALL-UNNAMED"),
                "Das Jar öffnet sun.awt, sun.awt.windows und sun.java2d für JOGL (Manifest Add-Opens, dazu in Haithabu.bat und der Verknüpfung), wie run.jvmargs in NetBeans");

        System.out.println("Schliff: READMEs, Bilder, Quellen");
        List<String> ohne = new ArrayList<>();
        File[] pk = new File("src/com/dan").listFiles(File::isDirectory);
        int n = 0;
        if (pk != null) for (File p : pk) {
            n++;
            if (!new File(p, "README.md").isFile()) ohne.add(p.getName());
        }
        check(n >= 25 && ohne.isEmpty(), "README.md in allen " + n + " Packages" + (ohne.isEmpty() ? "" : "; fehlt: " + ohne));
        String readme = lies("README.md");
        List<String> kaputt = new ArrayList<>();
        int links = 0;
        Matcher m = Pattern.compile("\\]\\(([^)#]+)\\)").matcher(readme);
        while (m.find()) {
            String z = m.group(1);
            if (z.startsWith("http")) continue;
            links++;
            if (!new File(z).isFile()) kaputt.add(z);
        }
        check(links >= 30 && kaputt.isEmpty(), "GitHub-README: " + links + " Verweise auf Dateien im Projekt, alle vorhanden" + (kaputt.isEmpty() ? "" : "; fehlt: " + kaputt));
        int bilder = 0;
        Matcher b = Pattern.compile("!\\[[^\\]]*\\]\\(docs/bilder/([^)]+)\\)").matcher(readme);
        while (b.find()) bilder++;
        File[] bf = new File("docs/bilder").listFiles((d, f) -> f.endsWith(".jpg") || f.endsWith(".png"));
        long bytes = 0;
        if (bf != null) for (File f : bf) bytes += f.length();
        check(bilder >= 12 && bf != null && bf.length >= bilder && bytes < 6_000_000,
                String.format(Locale.GERMAN, "%d Bilder in der README aus docs/bilder (%d Dateien, %.1f MB)", bilder, bf == null ? 0 : bf.length, bytes / 1e6));
        List<String> fehlt = new ArrayList<>();
        if (pk != null) for (File p : pk) if (!readme.contains("`com.dan." + p.getName() + "`") && !p.getName().equals("river") && !p.getName().equals("road")) fehlt.add(p.getName());
        check(fehlt.isEmpty(), "Alle Packages stehen in der README" + (fehlt.isEmpty() ? "" : "; fehlt: " + fehlt));
        String q = lies("docs/QUELLEN.md");
        check(q.equals(Quellenliste.text()), "docs/QUELLEN.md ist aktuell (" + q.lines().filter(z -> z.startsWith("- ")).count() + " Einträge, aus quellen.txt und befunde.txt)");

        System.out.println("Schliff: Qualitätsstufen durchgängig");
        Quality[] qs = Quality.values();
        boolean steigt = true;
        for (int i = 1; i < qs.length; i++) {
            Quality x = qs[i - 1], c = qs[i];
            steigt &= c.ocean.ordinal() > x.ocean.ordinal() && c.reed.ordinal() > x.reed.ordinal() && c.rain.ordinal() > x.rain.ordinal() && c.fog.ordinal() > x.fog.ordinal()
                    && c.lightning.ordinal() > x.lightning.ordinal() && c.forest.ordinal() > x.forest.ordinal() && c.timber.ordinal() > x.timber.ordinal()
                    && c.smoke.ordinal() > x.smoke.ordinal() && c.roomSteps > x.roomSteps && c.sound.ordinal() > x.sound.ordinal() && c.weathering.ordinal() >= x.weathering.ordinal()
                    && c.groundRadius > x.groundRadius && c.spray.ordinal() >= x.spray.ordinal() && c.flock.ordinal() >= x.flock.ordinal() && c.clouds.ordinal() >= x.clouds.ordinal()
                    && c.renderScale >= x.renderScale && c.terrainRange > x.terrainRange;
        }
        check(steigt && Quality.ULTRA.spray.ordinal() > Quality.NIEDRIG.spray.ordinal() && Quality.ULTRA.flock.ordinal() > Quality.NIEDRIG.flock.ordinal(),
                "Jede Stufe hebt alle Teile: Gelände, Noor, Halme, Wolken, Regen, Nebel, Blitz, Wald, Häuser, Rauch, Rauch im Haus, Klang, Nässe, Bodendecke, Spritzer, Vögel");
        Renderer.siedlungsLader = Siedlung::haithabu;
        SceneClock clock = new SceneClock();
        Renderer r = new Renderer(clock, new Wiring(clock), t);
        r.setQuality(Quality.NIEDRIG);
        check(r.smoke.quality == com.dan.smoke.Smoke.Quality.LOW && r.sound.quality == com.dan.soundscape.Soundscape.Quality.LOW
                        && r.weathering.quality == com.dan.weathering.Weathering.Quality.LOW && r.flotte.spray.quality == com.dan.spray.Spray.Quality.LOW
                        && r.leben.flock.quality == com.dan.flock.Flock.Quality.MEDIUM && r.meadow.radius == 16f && r.renderScale == Quality.NIEDRIG.renderScale,
                "setQuality reicht die Stufe bis in Rauch, Klang, Nässe, Spritzer, Vögel und Bodendecke");
        r.setQuality(Quality.MITTEL);
        check(r.sound.quality == com.dan.soundscape.Soundscape.Quality.MEDIUM && r.meadow.radius == 24f && r.leben.flock.quality == com.dan.flock.Flock.Quality.HIGH
                        && r.flotte.spray.quality == com.dan.spray.Spray.Quality.LOW, "„Mittel“ bleibt wie bis Phase 16 (Klang mittel, Bodendecke 24 m, Möwen hoch, Spritzer niedrig)");
        check(Quality.HOCH.summary().contains("Klang 44,1 kHz") && Quality.ULTRA.summary().contains("Bodendecke 36 m"), "Quality.summary nennt alle Teile: " + Quality.HOCH.summary().substring(0, 70) + " …");

        System.out.println("Schliff: Auflösung regelt sich selbst");
        r.setQuality(Quality.HOCH);
        r.autoScale = true;
        r.targetFps = 60;
        long t0 = 10_000_000_000L;
        r.regulateForTest(30, t0);
        double s1 = r.renderScale;
        check(s1 < 1.0 && s1 >= 0.85, String.format(Locale.GERMAN, "Grafikkarte 30 ms bei Ziel 60: Auflösung sinkt von 100 auf %.0f %% (höchstens 15 Punkte je Schritt)", s1 * 100));
        r.regulateForTest(30, t0 + 1_000_000_000L);
        check(r.renderScale == s1, "Innerhalb von 1,5 s wird nicht noch einmal geregelt");
        for (int i = 0; i < 20; i++) r.regulateForTest(40, t0 + (i + 2) * 2_000_000_000L);
        check(r.renderScale == Renderer.MIN_SCALE, String.format(Locale.GERMAN, "Bei dauerhaft 40 ms bleibt sie bei %.0f %% stehen, nie darunter", Renderer.MIN_SCALE * 100));
        for (int i = 0; i < 30; i++) r.regulateForTest(6, t0 + (i + 30) * 2_000_000_000L);
        check(r.renderScale == Quality.HOCH.renderScale, "Mit 6 ms steigt sie in Schritten von 5 % wieder auf die Stufe (100 %)");
        r.autoScale = false;
        r.renderScale = 0.7;
        r.regulateForTest(40, t0 + 200_000_000_000L);
        check(r.renderScale == 0.7, "Ausgeschaltet regelt nichts, der Regler gilt");

        System.out.println("Schliff: Befunde aus den Statusbildern");
        double nachtZiel = 1e-4, hell = 0.2;
        double z1 = Renderer.bildZiel(nachtZiel, hell, 0.5, 1), z2 = Renderer.bildZiel(nachtZiel, hell, 0.5, 0), z3 = Renderer.bildZiel(nachtZiel, 2e-4, 0.5, 1),
                z4 = Renderer.bildZiel(nachtZiel, -1, 0.5, 1);
        check(Math.abs(z1 - Math.sqrt(nachtZiel * hell)) < 1e-9 && z2 == nachtZiel && z3 == nachtZiel && z4 == nachtZiel,
                String.format(Locale.GERMAN, "Augenanpassung an das Bild (Befund 15b, von der Hochburg war der Brand weiß): nachts zieht ein 2 000-fach helleres Bild das Ziel auf das geometrische Mittel "
                        + "(%.0f-fach heller, also %.1f Blenden weniger); am Tag, bei nur doppelt hellem Bild und ohne Messung nicht", z1 / nachtZiel, Math.log(z1 / nachtZiel) / Math.log(2)));
        File dl = new File("docs/status/Dauerlauf.txt");
        if (dl.isFile()) {
            List<String> z = Files.readAllLines(dl.toPath(), StandardCharsets.UTF_8);
            String letzte = z.isEmpty() ? "" : z.get(z.size() - 1);
            check(letzte.equals("Dauerlauf bestanden"), "docs/status/Dauerlauf.txt endet mit „Dauerlauf bestanden“ (" + z.size() + " Zeilen)");
        } else {
            check(true, "Noch kein Dauerlauf-Protokoll (tools.Dauerlauf braucht die Grafikkarte und läuft nicht in der Prüfung)");
        }
        Renderer.siedlungsLader = Siedlung::startup;
    }

    static String lies(String f) throws java.io.IOException {
        File x = new File(f);
        return x.isFile() ? Files.readString(x.toPath(), StandardCharsets.UTF_8) : "";
    }
}
