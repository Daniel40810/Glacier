package com.dan.haithabu.test;

import com.dan.haithabu.data.DateiSpeicher;
import com.dan.haithabu.data.Daten;
import com.dan.haithabu.data.Datenseite;
import com.dan.haithabu.data.DbSpeicher;
import com.dan.haithabu.data.Speicher;
import com.dan.haithabu.data.Startdaten;
import com.dan.haithabu.data.Uebernahme;
import com.dan.haithabu.data.Verbindung;
import com.dan.haithabu.scene.Siedlung;
import com.dan.haithabu.scene.Terrain;
import com.dan.haithabu.tools.StartdatenSql;
import com.dan.store.Ablage;
import com.dan.store.Db;
import com.dan.store.Einrichter;
import com.dan.store.Felder;
import com.dan.store.Protokoll;

import java.io.File;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Phase 16: die Prüfung gegen die echte Datenbank (PDBORCL, Schema HAITHABU aus {@code db/db.properties}). In
 * NetBeans: Rechtsklick, „Run File“. Sie richtet ein (wiederholbar), läuft den Einrichter ein zweites Mal (muss ohne
 * Fehler durchgehen), prüft mit ihm, rechnet den Lageplan räumlich nach (Flächen, Längen, Sichten, gültige
 * Geometrien), speichert und lädt jede Art von Daten unter Namen „~Prüfung …“, prüft die Hauskarte an einer Kopie der
 * Siedlung, übernimmt Dateien aus einem leeren Ordner und räumt hinterher auf: die aktive Siedlung ist danach wieder
 * dieselbe. Ende: „Alles in Ordnung.“
 * <p>
 * Die Ausgabe bitte als Text oder Bildschirmfoto schicken; jede Zeile mit FEHLER sagt, was nicht ging.
 */
public final class DbPruefung {
    private static int ok, bad;
    private static final String P = "~Prüfung ";

    static void check(boolean c, String was) {
        if (c) ok++; else bad++;
        System.out.println((c ? "  ok     " : "  FEHLER ") + was);
    }

    static double zahl(Connection c, String sql) throws Exception {
        try (Statement st = c.createStatement(); ResultSet r = st.executeQuery(sql)) { return r.next() ? r.getDouble(1) : Double.NaN; }
    }

    static String text(Connection c, String sql) throws Exception {
        try (Statement st = c.createStatement(); ResultSet r = st.executeQuery(sql)) { return r.next() ? r.getString(1) : null; }
    }

    public static void main(String[] args) throws Exception {
        long t0 = System.nanoTime();
        System.out.println("Haithabu · Prüfung der Datenbank (Phase 16)");
        Db.Konfig k = Verbindung.konfig();
        System.out.println("Verbindung " + k.kurz());
        if (!k.hatPasswort()) {
            System.out.println("  FEHLER Kein Passwort in db/db.properties und keine Umgebungsvariable " + Verbindung.ENV
                    + ". Einmal mit dem Startbild verbinden (es trägt das Passwort ein) oder es von Hand eintragen.");
            System.exit(1);
        }
        DbSpeicher db = new DbSpeicher(k);
        System.out.println(db.wo());
        Connection c = db.verbindung();
        Einrichter ein = Verbindung.einrichter();

        System.out.println("Einrichter");
        Einrichter.Ergebnis e1 = ein.einrichten(c, Verbindung.skripte(), (t, a) -> { });
        for (String z : e1.zeilen()) if (!z.startsWith("ok")) System.out.println("    " + z);
        check(e1.ok(), "Erster Lauf: " + e1.kurz() + " (" + e1.ausgefuehrt() + " ausgeführt, " + e1.vorhanden() + " schon da)");
        Einrichter.Ergebnis e2 = ein.einrichten(c, Verbindung.skripte(), (t, a) -> { });
        check(e2.ok() && e2.fehler() == 0, "Zweiter Lauf geht ohne Fehler durch (wiederholbar): " + e2.kurz());
        Einrichter.Ergebnis pr = ein.pruefen(c, Verbindung.skripte());
        for (String z : pr.zeilen()) System.out.println("    " + z);
        check(pr.ok(), "Einrichter prüft: " + pr.kurz());
        check(ein.stufe(c) == Verbindung.VERSION, "Ausbaustufe " + ein.stufe(c));

        Daten.Siedlung aktivVorher = db.aktiveSiedlung();
        Set<String> siedlungenVorher = new HashSet<>();
        for (Daten.Siedlung s : db.siedlungen()) siedlungenVorher.add(s.name());
        System.out.println("Aktive Siedlung: " + (aktivVorher == null ? "keine" : aktivVorher.name()) + " · " + siedlungenVorher.size() + " Siedlungen");

        System.out.println("Trigger und Spatial");
        try (Statement st = c.createStatement()) {
            st.executeUpdate("INSERT INTO HB_WETTERLAGE (NAME, HERKUNFT) VALUES ('" + P + "Trigger', 'EIGEN')");
            try (ResultSet r = st.executeQuery("SELECT ID, ANGELEGT, GEAENDERT FROM HB_WETTERLAGE WHERE NAME = '" + P + "Trigger'")) {
                check(r.next() && r.getLong(1) > 0 && r.getTimestamp(2) != null && r.getTimestamp(3) != null, "Trigger setzt ID, ANGELEGT und GEAENDERT");
            }
            st.executeUpdate("DELETE FROM HB_WETTERLAGE WHERE NAME = '" + P + "Trigger'");
            c.commit();
        }
        double wall = zahl(c, "SELECT FLAECHE_HA FROM HB_BAUWERK_V WHERE ART = 'WALLFLAECHE'"), becken = zahl(c, "SELECT FLAECHE_HA FROM HB_BAUWERK_V WHERE ART = 'HAFENBECKEN'"),
                kamm = zahl(c, "SELECT LAENGE_M FROM HB_BAUWERK_V WHERE ART = 'WALLKAMM'");
        check(Math.abs(wall - 28.2) < 0.4 && Math.abs(becken - 10.0) < 0.3 && Math.abs(kamm - 1399) < 8, String.format(Locale.GERMAN,
                "Auf dem Ellipsoid gerechnet (SDO_AREA, SDO_LENGTH): Wallfläche %.1f ha, Hafenbecken %.1f ha, Kammlinie %.0f m (in der Szene 28,2 ha, 10,0 ha, 1399 m)", wall, becken, kamm));
        double ungueltig = zahl(c, "SELECT COUNT(*) FROM HB_BAUWERK WHERE MDSYS.SDO_GEOM.VALIDATE_GEOMETRY_WITH_CONTEXT(GEOM, 0.05) <> 'TRUE'")
                + zahl(c, "SELECT COUNT(*) FROM HB_HAUS WHERE GRUNDRISS IS NOT NULL AND MDSYS.SDO_GEOM.VALIDATE_GEOMETRY_WITH_CONTEXT(GRUNDRISS, 0.05) <> 'TRUE'")
                + zahl(c, "SELECT COUNT(*) FROM HB_WEG WHERE MDSYS.SDO_GEOM.VALIDATE_GEOMETRY_WITH_CONTEXT(GEOM, 0.05) <> 'TRUE'");
        check(ungueltig == 0, "Alle Geometrien gültig (VALIDATE_GEOMETRY_WITH_CONTEXT): Bauwerke, Grundrisse, Wege");
        double haus = zahl(c, "SELECT COUNT(*) FROM HB_HAUS_V WHERE AKTIV = 1"), imWall = zahl(c, "SELECT COUNT(*) FROM HB_IM_WALL_V"),
                ufer = zahl(c, "SELECT COUNT(*) FROM HB_UFERZEILE_V"), plan = zahl(c, "SELECT COUNT(*) FROM HB_LAGEPLAN_V");
        check(haus > 0 && imWall >= haus * 0.98 && ufer > 5 && ufer < haus / 3, String.format(Locale.GERMAN,
                "Räumliche Sichten: %.0f Häuser der aktiven Siedlung, %.0f davon in der Wallfläche (SDO_RELATE), %.0f in der Uferzeile bis 60 m (SDO_WITHIN_DISTANCE)", haus, imWall, ufer));
        check(plan > haus + 100, String.format(Locale.GERMAN, "HB_LAGEPLAN_V: %.0f Objekte in einer Ebene (für QGIS)", plan));
        String wkt = text(c, "SELECT SDO_UTIL.TO_WKTGEOMETRY(GEOM) FROM HB_BAUWERK WHERE ART = 'HOCHBURG'");
        check(wkt != null && wkt.startsWith("POLYGON"), "Hochburg als WKT zurück: " + (wkt == null ? "—" : wkt.substring(0, Math.min(60, wkt.length())) + " …"));
        String befund = text(c, "SELECT QUELLEN FROM HB_BEFUND_V WHERE GEGENSTAND = 'Höhe und Fläche des Walls'");
        check("WIKI_HAITHABU".equals(befund), "HB_BEFUND_V mit Quellen: „Höhe und Fläche des Walls“ ← " + befund);

        System.out.println("Speichern und laden");
        Terrain t = Terrain.load(new File("daten/gelaende"));
        Startdaten.Szene sz = StartdatenSql.szene(new File("daten/gelaende"));
        Siedlung s = Siedlung.haithabu(t);
        List<Daten.Haus> hs = Startdaten.haeuser(s);
        db.speichern(new Daten.Siedlung(P + "Siedlung", 950, false, hs.size(), "Prüfung", Daten.EIGEN), hs, sz.wege());
        List<Daten.Haus> zurueck = db.haeuser(P + "Siedlung");
        double err = 0;
        for (int i = 0; i < Math.min(hs.size(), zurueck.size()); i++)
            err = Math.max(err, Math.hypot(hs.get(i).x() - zurueck.get(i).x(), hs.get(i).z() - zurueck.get(i).z()));
        check(zurueck.size() == hs.size() && err < 0.01, String.format(Locale.GERMAN, "Siedlung mit %d Häusern hin und zurück, Abweichung %.1f mm (Lage als Punkt in 8307, X_M/Z_M)", zurueck.size(), err * 1000));
        double grund = zahl(c, "SELECT COUNT(*) FROM HB_HAUS h JOIN HB_SIEDLUNG s ON s.ID = h.SIEDLUNG_ID WHERE s.NAME = '" + P + "Siedlung' AND h.GRUNDRISS IS NOT NULL");
        check(grund == hs.size(), "Jedes Haus mit Grundriss (Polygon aus Typ, Faktoren und Richtung)");
        // Hauskarte: die mitgelieferte bleibt, eine Kopie nimmt Änderungen
        Datenseite.setzen(db);
        boolean geschuetzt = false;
        try { db.aendern(Startdaten.SIEDLUNG, hs.get(10)); } catch (Ablage.Fehler e) { geschuetzt = true; }
        db.aktivieren(P + "Siedlung");
        Datenseite.siedlungName = P + "Siedlung";
        Daten.Haus h = db.haeuser(P + "Siedlung").get(20);
        db.aendern(P + "Siedlung", new Daten.Haus(h.nr(), h.name(), "WOHNHAUS", h.rolle(), h.x(), h.y(), h.z(), h.richtungGrad(), h.laengeFaktor(), h.breiteFaktor(),
                0.9, h.zufall(), h.museum(), true, "geändert in der Prüfung"));
        db.entfernen(P + "Siedlung", h.nr() + 1);
        List<Daten.Haus> nach = db.haeuser(P + "Siedlung");
        Daten.Haus g = nach.stream().filter(x -> x.nr() == h.nr()).findFirst().orElseThrow();
        check(geschuetzt && g.vonHand() && g.haustyp().equals("WOHNHAUS") && g.zustand() == 0.9 && nach.size() == hs.size() - 1,
                "Hauskarte: „" + Startdaten.SIEDLUNG + "“ ist geschützt; die Kopie nimmt Typ, Zustand und Bemerkung und verliert ein Haus");
        Siedlung geladen = Datenseite.laden(t);
        check(geladen.haeuser.size() == nach.size() && geladen.haeuser.stream().anyMatch(x -> x.house().type().name().equals("WOHNHAUS") && x.name().equals(h.name())),
                "Die aktive Siedlung lädt aus der Datenbank: " + geladen.haeuser.size() + " Häuser");
        // Wetterlage, Regiebuch, Fahrt, Ansicht, Preset
        double[] wv = Startdaten.wetterlagen().get(0).werte();
        wv[0] = 3.3;
        db.speichern(new Daten.Wetterlage(P + "Brise", 2.0, "KLAR", wv, "4-9", "Prüfung", Daten.EIGEN));
        String rt = "Regiebuch: " + P + "Abend\nLänge: 0:30\n0:00 zeit 16.10.950 19:00 | Abend\n0:05 ansicht Hafen\n0:29 blatt\n";
        db.speichern(new Daten.Regiebuch(P + "Abend", rt, "", Daten.EIGEN));
        db.speichern(new Daten.Fahrt(P + "Fahrt", null, "STUETZPUNKTE", false, "drei Punkte", Daten.EIGEN,
                List.of(new Daten.Stuetzpunkt(1, 0, 0, 5, 0, 10, 3, Double.NaN), new Daten.Stuetzpunkt(2, 4, 20, 5, 0, 20, 3, Double.NaN), new Daten.Stuetzpunkt(3, 8, 40, 6, 10, 30, 2, Double.NaN))));
        byte[] png = new byte[5000];
        for (int i = 0; i < png.length; i++) png[i] = (byte) (i * 7);
        long aid = db.speichern(new Daten.Ansicht(0, P + "Ansicht", null, "GEMERKT", new double[]{1, 2, 3, 45, 5, 55}, null, false, null,
                Daten.Szenenzeit.of(LocalDate.of(950, 10, 16), 19.25), "a=1\nb=2\n", png, Daten.EIGEN), null);
        var oc = com.dan.ocean.Ocean.noor(4);
        db.speichern(new Daten.PaketPreset("com.dan.ocean", "Ocean", P + "Noor", "Prüfung", Daten.EIGEN, Felder.lesen(oc)));
        Daten.Wetterlage wl = db.wetterlagen().stream().filter(x -> x.name().equals(P + "Brise")).findFirst().orElseThrow();
        Daten.Regiebuch rb = db.regiebuecher().stream().filter(x -> x.name().equals(P + "Abend")).findFirst().orElseThrow();
        Daten.Fahrt fa = db.fahrten().stream().filter(x -> x.name().equals(P + "Fahrt")).findFirst().orElseThrow();
        Daten.Ansicht an = db.ansicht(aid);
        var oc2 = com.dan.ocean.Ocean.calm();
        Felder.schreiben(oc2, db.presets("com.dan.ocean", "Ocean").stream().filter(x -> x.name().equals(P + "Noor")).findFirst().orElseThrow().felder());
        check(wl.werte()[0] == 3.3 && com.dan.haithabu.scene.Regie.parse(rb.text()).cues().size() == 3 && fa.punkte().size() == 3 && an.vorschau().length == png.length
                        && java.util.Arrays.equals(an.vorschau(), png) && an.szenenzeit().equals(Daten.Szenenzeit.of(LocalDate.of(950, 10, 16), 19.25)) && Felder.lesen(oc2).equals(Felder.lesen(oc)),
                "Wetterlage, Regiebuch (Text in HB_STICHWORT zerlegt), Fahrt, Ansicht mit Vorschau (BLOB) und Szenenzeit, Preset gespeichert und gelesen");
        boolean abgelehnt = false;
        try { db.speichern(new Daten.Wetterlage("Klar", 1.0, "KLAR", wv, null, null, Daten.EIGEN)); } catch (Ablage.Fehler e) { abgelehnt = true; }
        check(abgelehnt, "Eine mitgelieferte Wetterlage („Klar“) wird nicht überschrieben");
        // Sitzung, Szenenzeit, Protokoll
        long sid = db.sitzungBeginnen(P.strip(), "Prüfung", "MITTEL");
        Map<String, String> sp = new LinkedHashMap<>();
        sp.put(Speicher.SIEDLUNG, P + "Siedlung");
        sp.put(Speicher.REGIEBUCH, P + "Abend");
        sp.put(Speicher.REGIE_SEKUNDE, "12.5");
        sp.put(Speicher.SZ, "1050-10-16 1.6");
        db.sitzungSichern(sid, new Ablage.Sicherung("uhr.datum=1050-10-16\nuhr.stunde=1.6\n", sp));
        double jahr = zahl(c, "SELECT SZ_JAHR FROM HB_SITZUNG WHERE ID = " + sid), stunde = zahl(c, "SELECT SZ_STUNDE FROM HB_SITZUNG WHERE ID = " + sid);
        Daten.Sitzung ls = db.letzteSitzung(-1);
        check(jahr == 1050 && Math.abs(stunde - 1.6) < 1e-6 && ls != null && ls.id() == sid && !ls.sauber() && (P + "Abend").equals(ls.regiebuch()),
                "Sitzung gesichert: Szenenzeit als Zahlen (SZ_JAHR 1050, SZ_STUNDE 1,6), Regiebuch mit Stelle, noch nicht sauber beendet");
        Protokoll.info("DbPrüfung", "eine Zeile aus der Prüfung");
        db.protokoll(Protokoll.abholen(), sid);
        db.sitzungBeenden(sid);
        double logz = zahl(c, "SELECT COUNT(*) FROM HB_LOG WHERE SITZUNG_ID = " + sid);
        check(logz >= 1 && zahl(c, "SELECT SAUBER_BEENDET FROM HB_SITZUNG WHERE ID = " + sid) == 1, "Protokoll in HB_LOG (" + (int) logz + " Zeilen), Sitzung sauber beendet");
        // Übernahme aus Dateien
        File dir = Files.createTempDirectory("haithabu-dbpruefung").toFile();
        DateiSpeicher d = new DateiSpeicher(dir);
        d.szene = () -> sz;
        d.speichern(new Daten.Regiebuch(P + "aus Datei", rt.replace(P + "Abend", P + "aus Datei"), "", Daten.EIGEN));
        List<String> ue = Uebernahme.uebernehmen(d, db, t);
        check(db.regiebuecher().stream().anyMatch(x -> x.name().equals(P + "aus Datei")), "In die Datenbank übernehmen: " + String.join(" · ", ue));
        Daten.Stand st = db.stand();
        check(st.befunde() == 45 && st.bauwerke() == sz.bauwerke().size() && st.presets() >= 52, "Stand für das Startbild: " + st.siedlungen() + " Siedlungen, "
                + st.haeuser() + " Häuser, " + st.bauwerke() + " Bauwerke, " + st.regiebuecher() + " Regiebücher, " + st.befunde() + " Befunde");

        System.out.println("Aufräumen");
        if (aktivVorher != null) db.aktivieren(aktivVorher.name());
        for (Daten.Siedlung x : db.siedlungen()) if (!siedlungenVorher.contains(x.name()) && Daten.EIGEN.equals(x.herkunft())) db.loeschenSiedlung(x.name());
        db.loeschenWetterlage(P + "Brise");
        db.loeschenRegiebuch(P + "Abend");
        db.loeschenRegiebuch(P + "aus Datei");
        db.loeschenFahrt(P + "Fahrt");
        db.loeschenAnsicht(aid);
        db.loeschenPreset("com.dan.ocean", "Ocean", P + "Noor");
        try (Statement x = c.createStatement()) {
            x.executeUpdate("DELETE FROM HB_LOG WHERE SITZUNG_ID = " + sid);
            x.executeUpdate("DELETE FROM HB_SITZUNG WHERE ID = " + sid);
            c.commit();
        }
        double rest = zahl(c, "SELECT (SELECT COUNT(*) FROM HB_SIEDLUNG WHERE NAME LIKE '~%') + (SELECT COUNT(*) FROM HB_WETTERLAGE WHERE NAME LIKE '~%') "
                + "+ (SELECT COUNT(*) FROM HB_REGIEBUCH WHERE NAME LIKE '~%') + (SELECT COUNT(*) FROM HB_FAHRT WHERE NAME LIKE '~%') + (SELECT COUNT(*) FROM HB_ANSICHT WHERE NAME LIKE '~%') "
                + "+ (SELECT COUNT(*) FROM HB_PAKET_PRESET WHERE NAME LIKE '~%') FROM DUAL");
        Daten.Siedlung aktivNachher = db.aktiveSiedlung();
        check(rest == 0 && (aktivVorher == null || aktivVorher.name().equals(aktivNachher.name())), "Aufgeräumt: nichts mit „~“ bleibt, aktiv ist wieder „"
                + (aktivNachher == null ? "—" : aktivNachher.name()) + "“");
        db.schliessen();

        System.out.printf(Locale.GERMAN, "%d geprüft, %d Fehler · %.1f s%n", ok + bad, bad, (System.nanoTime() - t0) / 1e9);
        System.out.println(bad == 0 ? "Alles in Ordnung." : "Nicht alles in Ordnung.");
        System.exit(bad == 0 ? 0 : 1);
    }
}
