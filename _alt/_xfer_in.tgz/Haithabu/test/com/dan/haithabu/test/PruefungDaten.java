package com.dan.haithabu.test;

import com.dan.haithabu.data.DateiSpeicher;
import com.dan.haithabu.data.Daten;
import com.dan.haithabu.data.Datenseite;
import com.dan.haithabu.data.Startdaten;
import com.dan.haithabu.data.Verbindung;
import com.dan.haithabu.data.Zustand;
import com.dan.haithabu.gl.Renderer;
import com.dan.haithabu.scene.Regie;
import com.dan.haithabu.scene.SceneClock;
import com.dan.haithabu.scene.Siedlung;
import com.dan.haithabu.scene.Terrain;
import com.dan.haithabu.wiring.Wiring;
import com.dan.store.Ablage;
import com.dan.store.Felder;
import com.dan.store.Skript;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Phase 16: die Datenseite ohne Datenbank und ohne Grafikkarte. Skripte, Startdaten, Regiebücher als Text,
 * Szenenzeit, Dateien mit Siedlung, Hauskarte, Wetterlagen, Regiebüchern, Fahrten, Ansichten, Presets, Sitzung und
 * Protokoll, der Zustand der Szene hin und zurück mit Brand. Die Datenbank prüft {@code DbPruefung} auf dem Rechner mit
 * Oracle.
 */
final class PruefungDaten {
    private PruefungDaten() { }

    static void check(boolean c, String w) { Pruefung.check(c, w); }

    /** Nur dieser Teil (schneller beim Arbeiten an der Datenseite). */
    public static void main(String[] a) throws Exception {
        Terrain t = Terrain.load(new File("daten/gelaende"));
        alles(t, Siedlung.haithabu(t));
    }

    static void alles(Terrain t, Siedlung s) throws Exception {
        System.out.println("Datenseite (Phase 16)");
        int sb = com.dan.store.demo.StoreCheck.pruefen();
        check(sb == 0, "com.dan.store: StoreCheck ohne Verstoß (Felder, Textformat, Skripte, WKT, Dateiablage, Sitzung, Protokoll)");
        skripte();
        startdaten(t, s);
        regiebuecher();
        szenenzeit();
        dateien(t, s);
        zustand(t);
        oberflaeche(t);
    }

    // ------------------------------------------------------------------ Skripte

    static File sql() { return new File("db/sql"); }

    static void skripte() throws Exception {
        Map<String, Integer> n = new LinkedHashMap<>();
        List<Skript.Anweisung> t01 = null;
        int alle = 0;
        for (String f : new String[]{"01_tabellen.sql", "02_spatial.sql", "03_sichten.sql", "04_startdaten.sql", "99_entfernen.sql"}) {
            List<Skript.Anweisung> as = Skript.zerlegen(Files.readString(new File(sql(), f).toPath(), StandardCharsets.UTF_8));
            n.put(f, as.size());
            alle += as.size();
            if (f.startsWith("01")) t01 = as;
        }
        int tab = 0, seq = 0, trg = 0, idx = 0;
        for (Skript.Anweisung a : t01) {
            String o = Skript.objekt(a.sql());
            if (o == null) continue;
            if (o.startsWith("TABLE")) tab++;
            if (o.startsWith("SEQUENCE")) seq++;
            if (o.startsWith("TRIGGER")) trg++;
            if (o.startsWith("INDEX")) idx++;
        }
        List<Skript.Spalte> sp = Skript.spalten(t01);
        boolean identity = t01.stream().anyMatch(a -> a.sql().toUpperCase(Locale.ROOT).contains("IDENTITY"));
        check(tab == 22 && seq == 21 && trg == 20 && idx == 13 && !identity,
                String.format(Locale.GERMAN, "01_tabellen.sql: %d Tabellen, %d Sequenzen und %d Trigger (HB_SCHEMA ohne beides, HB_LOG ohne Trigger), %d Indizes, %d Spalten, nie IDENTITY", tab, seq, trg, idx, sp.size()));
        boolean dates = sp.stream().noneMatch(x -> x.name().startsWith("SZ_") && !x.typ().startsWith("NUMBER"))
                && sp.stream().filter(x -> x.typ().equals("DATE")).allMatch(x -> x.name().equals("ABGERUFEN"));
        check(dates, "Szenenzeit nur als Zahlen (F32): kein DATE außer HB_QUELLE.ABGERUFEN (echte Zeit)");
        check(n.get("02_spatial.sql") == 8 && n.get("03_sichten.sql") == Verbindung.SICHTEN.length,
                "02_spatial.sql: Metadaten für 7 Spalten und 7 räumliche Indizes; 03_sichten.sql: " + Verbindung.SICHTEN.length + " Sichten");
        check(alle > 2000, "Alle Skripte zerlegen sich in " + alle + " Anweisungen: " + n);
    }

    // ------------------------------------------------------------------ Startdaten

    static void startdaten(Terrain t, Siedlung s) throws Exception {
        long t0 = System.nanoTime();
        String neu = com.dan.haithabu.tools.StartdatenSql.erzeugen(new File("daten/gelaende"));
        String alt = Files.readString(new File(sql(), "04_startdaten.sql").toPath(), StandardCharsets.UTF_8);
        check(neu.equals(alt), String.format(Locale.GERMAN, "04_startdaten.sql ist aktuell (neu erzeugt in %.1f s, %d kB gleich)", (System.nanoTime() - t0) / 1e9, alt.length() / 1024));
        Map<String, Integer> z = Verbindung.zahlen(sql());
        check(z.getOrDefault("Häuser", 0) == s.haeuser.size() && z.get("Quellen") == 12 && z.get("Befunde") == 45 && z.get("Regiebücher") == 3 && z.get("Ansichten") == 7,
                "Zahlen der Startdaten für den Einrichter: " + z);
        // Längen gegen die Spalten
        Map<String, Integer> len = new HashMap<>();
        for (Skript.Spalte x : Skript.spalten(Skript.zerlegen(Files.readString(new File(sql(), "01_tabellen.sql").toPath())))) len.put(x.tabelle() + "." + x.name(), Skript.laenge(x));
        int zu = 0;
        List<String> lang = new ArrayList<>();
        for (Daten.Haus h : Startdaten.haeuser(s)) { if (h.name().length() > len.get("HB_HAUS.NAME")) { zu++; lang.add(h.name()); } if (h.rolle().length() > len.get("HB_HAUS.ROLLE")) { zu++; lang.add(h.rolle()); } }
        for (Daten.Befund b : Startdaten.befunde()) { if (b.gegenstand().length() > len.get("HB_BEFUND.GEGENSTAND") || b.text().length() > len.get("HB_BEFUND.TEXT")) { zu++; lang.add(b.gegenstand()); } }
        for (Daten.Quelle q : Startdaten.quellen()) if (q.titel().length() > len.get("HB_QUELLE.TITEL") || (q.url() != null && q.url().length() > len.get("HB_QUELLE.URL"))) { zu++; lang.add(q.kurz()); }
        for (Daten.Regiebuch r : Startdaten.regiebuecher()) {
            Regie.Book b = Regie.parse(r.text());
            String w = Regie.wetterBlock(r.text());
            if (w != null && w.length() > len.get("HB_REGIEBUCH.WETTER")) { zu++; lang.add(r.name() + " (Wetter)"); }
            for (Regie.Zeile q : b.zeilen()) if (q.argumente().length() > len.get("HB_STICHWORT.ARGUMENTE") || q.text().length() > len.get("HB_STICHWORT.TEXT")) { zu++; lang.add(q.text()); }
        }
        for (Daten.PaketPreset p : Startdaten.presets()) for (String v : p.felder().values()) if (v.length() > len.get("HB_PAKET_WERT.WERT")) { zu++; lang.add(p.name()); }
        check(zu == 0, "Jeder mitgelieferte Text passt in seine Spalte" + (zu > 0 ? ": " + lang : ""));
        // Lageplan
        Startdaten.Szene sz = com.dan.haithabu.tools.StartdatenSql.szene(new File("daten/gelaende"));
        double wall = 0, becken = 0, kamm = 0;
        int grab = 0;
        for (Daten.Bauwerk b : sz.bauwerke()) {
            if (b.art().equals("WALLFLAECHE")) wall = b.geom().flaecheM2() / 10_000;
            if (b.art().equals("HAFENBECKEN")) becken = b.geom().flaecheM2() / 10_000;
            if (b.art().equals("WALLKAMM")) kamm = b.geom().laenge();
            if (b.art().equals("GRABHUEGEL")) grab++;
        }
        check(Math.abs(wall - 26) < 4 && Math.abs(becken - 10) < 0.6 && Math.abs(kamm - 1402) < 15 && grab == 80,
                String.format(Locale.GERMAN, "Lageplan: Wallfläche %.1f ha (Literatur 26), Becken %.1f ha, Kammlinie %.0f m, %d Grabhügel, %d Bauwerke", wall, becken, kamm, grab, sz.bauwerke().size()));
        int innen = 0, aussen = 0;
        Daten.Bauwerk wf = sz.bauwerke().stream().filter(b -> b.art().equals("WALLFLAECHE")).findFirst().orElseThrow();
        for (Daten.Haus h : sz.haeuser()) if (innen(wf.geom().xz(), h.x(), h.z())) innen++; else aussen++;
        check(innen > 0.9 * sz.haeuser().size(), String.format(Locale.GERMAN, "%d von %d Häusern liegen in der Wallfläche, %d außerhalb", innen, sz.haeuser().size(), aussen));
        // WKT hin und zurück: Grundriss des Versammlungshauses
        Daten.Haus h1 = sz.haeuser().get(0);
        Daten.Haustyp typ = Startdaten.haustypen().stream().filter(x -> x.name().equals(h1.haustyp())).findFirst().orElseThrow();
        Daten.Geom g = h1.grundriss(typ);
        double[][] ll = com.dan.store.Wkt.punkte(g.wkt());
        double err = 0;
        for (double[] p : g.xz()) {
            double best = 1e9;
            for (double[] q : ll) { double[] xz = Daten.xz(q[0], q[1]); best = Math.min(best, Math.hypot(xz[0] - p[0], xz[1] - p[1])); }
            err = Math.max(err, best);
        }
        check(err < 0.02 && Math.abs(g.flaecheM2() - typ.laengeM() * h1.laengeFaktor() * typ.breiteM() * h1.breiteFaktor()) < 1e-6,
                String.format(Locale.GERMAN, "Grundriss als WKT in 8307 und zurück in die Szene: %.1f mm Abweichung", err * 1000));
    }

    static boolean innen(double[][] p, double x, double z) {
        boolean in = false;
        for (int i = 0, j = p.length - 1; i < p.length; j = i++)
            if ((p[i][1] > z) != (p[j][1] > z) && x < (p[j][0] - p[i][0]) * (z - p[i][1]) / (p[j][1] - p[i][1]) + p[i][0]) in = !in;
        return in;
    }

    // ------------------------------------------------------------------ Regiebücher

    static void regiebuecher() {
        int ok = 0;
        for (Daten.Regiebuch r : Startdaten.regiebuecher()) {
            Regie.Book a = Regie.parse(r.text());
            // wie die Datenbank: Kopf, Wetter und Stichworte getrennt und wieder zusammen
            String t = Regie.toText(a.name(), a.about(), a.length(), Regie.wetterBlock(r.text()), a.zeilen());
            Regie.Book b = Regie.parse(t);
            if (b.name().equals(a.name()) && b.about().equals(a.about()) && b.length() == a.length() && b.cues().size() == a.cues().size()
                    && b.zeilen().equals(a.zeilen()) && (a.weather() == null) == (b.weather() == null)
                    && (a.weather() == null || a.weather().toText().equals(b.weather().toText()))) ok++;
        }
        check(ok == 3, "Drei Regiebücher als Text hin und zurück (Kopf, Wetter, Stichworte getrennt wie in HB_REGIEBUCH und HB_STICHWORT)");
        String[] falsch = {"Regiebuch: X\n0:00 tanzen", "0:00 brander", "Regiebuch: X\n0:00 wetter", "Regiebuch: X\n0:00 zeit 16.10.950", "Regiebuch: X\nx:1 brander"};
        int erkannt = 0;
        for (String f : falsch) try { Regie.parse(f); } catch (IllegalArgumentException e) { erkannt++; }
        check(erkannt == falsch.length, "Fehler im Text werden gemeldet: unbekannter Befehl, kein Name, wetter ohne Wetter, Zeit unvollständig, falsche Zeit");
        Regie.Book eigen = Regie.parse("Regiebuch: Kurz\n0:00 zeit 1.5.950 12:00 | Mittag im Mai\n0:10 foto Hafen\n0:20 blatt\n");
        List<String> spur = new ArrayList<>();
        Regie r = new Regie();
        Regie.Ctx c = new Regie.Ctx() {
            public void time(LocalDate d, double h) { spur.add("zeit " + d + " " + h); }
            public void lapse(double x) { }
            public void weather(com.dan.weather.Scenario s) { }
            public void weatherFree(com.dan.weather.Weather.Phase p, double b, double f) { }
            public void view(String n) { }
            public void fahrt(String n) { }
            public void einlaufen() { }
            public void auslaufen() { }
            public void brander() { }
            public void igniteNearBrander() { }
            public void capture(String x) { spur.add("foto " + x); }
            public void sheet(String n) { spur.add("blatt " + n); }
            public void say(String x) { }
        };
        r.start(eigen, c);
        for (int i = 0; i < 25; i++) r.step(1, c);
        check(spur.equals(List.of("zeit 0950-05-01 12.0", "foto Hafen", "blatt Kurz")) && !r.running(), "Ein eigenes Regiebuch läuft: " + spur);
        Regie f = new Regie();
        List<String> s2 = new ArrayList<>();
        Regie.Ctx c2 = new Regie.Ctx() {
            public void time(LocalDate d, double h) { s2.add("zeit"); }
            public void lapse(double x) { }
            public void weather(com.dan.weather.Scenario s) { }
            public void weatherFree(com.dan.weather.Weather.Phase p, double b, double ff) { }
            public void view(String n) { }
            public void fahrt(String n) { }
            public void einlaufen() { }
            public void auslaufen() { }
            public void brander() { }
            public void igniteNearBrander() { }
            public void capture(String x) { s2.add("foto"); }
            public void sheet(String n) { s2.add("blatt"); }
            public void say(String x) { }
        };
        f.fortsetzen(eigen, 15);
        for (int i = 0; i < 10; i++) f.step(1, c2);
        check(s2.equals(List.of("blatt")), "Fortsetzen bei 0:15 wiederholt Zeit und Foto nicht, das Blatt kommt");
    }

    // ------------------------------------------------------------------ Szenenzeit

    static void szenenzeit() {
        Daten.Szenenzeit z = Daten.Szenenzeit.of(LocalDate.of(950, 10, 16), 17.5);
        Daten.Szenenzeit back = Zustand.szenenzeit(Zustand.text(z));
        // Oracle rechnet vor 1582 julianisch: derselbe Kalendertag liegt dort 5 Tage später im Sonnenjahr
        java.util.GregorianCalendar jul = new java.util.GregorianCalendar(java.util.TimeZone.getTimeZone("UTC"));
        jul.clear();
        jul.set(950, java.util.Calendar.OCTOBER, 16);
        long tageJul = Math.floorDiv(jul.getTimeInMillis(), 86_400_000L), tageGreg = LocalDate.of(950, 10, 16).toEpochDay();
        check(z.toString().equals("16.10.950 17:30") && back.equals(z) && tageJul - tageGreg == 5,
                "Szenenzeit 16.10.950 17:30 als Zahlen hin und zurück; julianisch (wie Oracle) wäre derselbe Kalendertag " + (tageJul - tageGreg) + " Tage später (F32)");
    }

    // ------------------------------------------------------------------ Dateien

    static void dateien(Terrain t, Siedlung s) throws Exception {
        File dir = Files.createTempDirectory("haithabu-daten").toFile();
        DateiSpeicher d = new DateiSpeicher(dir);
        Startdaten.Szene sz = com.dan.haithabu.tools.StartdatenSql.szene(new File("daten/gelaende"));
        d.szene = () -> sz;
        // alte siedlung.csv aus Phase 6
        s.save(new File(dir, "siedlung.csv"));
        List<Daten.Siedlung> l = d.siedlungen();
        check(l.size() == 2 && l.get(1).name().equals("Gespeichert in siedlung.csv") && l.get(1).aktiv() && l.get(1).haeuser() == s.haeuser.size(),
                "Ohne Datenbank: die alte daten/siedlung.csv wird als eigene, aktive Siedlung übernommen (" + l.get(1).haeuser() + " Häuser)");
        Datenseite.setzen(d);
        Siedlung geladen = Datenseite.laden(t);
        double err = 0;
        for (int i = 0; i < s.haeuser.size(); i++) {
            var a = s.haeuser.get(i).house();
            var b = geladen.haeuser.get(i).house();
            err = Math.max(err, Math.hypot(a.x() - b.x(), a.z() - b.z()) + Math.abs(a.headingDeg() - b.headingDeg()));
        }
        check(geladen.haeuser.size() == s.haeuser.size() && err < 0.002, String.format(Locale.GERMAN, "Siedlung geladen: %d Häuser, Abweichung %.1f mm", geladen.haeuser.size(), err * 1000));
        // Hauskarte: mitgeliefert ist geschützt, die eigene nimmt Änderungen
        boolean geschuetzt = false;
        try { d.aendern(Startdaten.SIEDLUNG, sz.haeuser().get(10)); } catch (Ablage.Fehler e) { geschuetzt = true; }
        Datenseite.speichernUnter(s, "Haithabu 950 (bearbeitet)", "Prüfung");
        Daten.Haus h = d.haeuser("Haithabu 950 (bearbeitet)").get(20);
        d.aendern("Haithabu 950 (bearbeitet)", new Daten.Haus(h.nr(), h.name(), "WOHNHAUS", h.rolle(), h.x(), h.y(), h.z(), h.richtungGrad(), h.laengeFaktor(),
                h.breiteFaktor(), 0.9, h.zufall(), h.museum(), false, "geändert in der Prüfung"));
        d.entfernen("Haithabu 950 (bearbeitet)", h.nr() + 1);
        List<Daten.Haus> hs = d.haeuser("Haithabu 950 (bearbeitet)");
        Daten.Haus g = hs.stream().filter(x -> x.nr() == h.nr()).findFirst().orElseThrow();
        check(geschuetzt && g.vonHand() && g.haustyp().equals("WOHNHAUS") && g.zustand() == 0.9 && "geändert in der Prüfung".equals(g.bemerkung())
                        && hs.size() == s.haeuser.size() - 1 && d.aktiveSiedlung().name().equals("Haithabu 950 (bearbeitet)"),
                "Hauskarte: „Haithabu 950“ ist geschützt; die bearbeitete Fassung nimmt Typ, Zustand und Bemerkung (von Hand) und verliert ein Haus");
        // Wetterlage, Regiebuch, Fahrt, Ansicht, Preset
        Daten.Wetterlage w0 = Startdaten.wetterlagen().get(0);
        double[] wv = w0.werte();
        wv[0] = 3.3;
        d.speichern(new Daten.Wetterlage("Meine Brise", 2.0, "KLAR", wv, "4-9", "aus der Prüfung", Daten.EIGEN));
        String rt = "Regiebuch: Mein Abend\nLänge: 0:30\n0:00 zeit 16.10.950 19:00 | Abend\n0:05 ansicht Hafen\n0:29 blatt\n";
        d.speichern(new Daten.Regiebuch("Mein Abend", rt, "", Daten.EIGEN));
        d.speichern(new Daten.Fahrt("Meine Fahrt", null, "STUETZPUNKTE", false, "drei Punkte", Daten.EIGEN,
                List.of(new Daten.Stuetzpunkt(1, 0, 0, 5, 0, 10, 3, Double.NaN), new Daten.Stuetzpunkt(2, 4, 20, 5, 0, 20, 3, Double.NaN), new Daten.Stuetzpunkt(3, 8, 40, 6, 10, 30, 2, Double.NaN))));
        long aid = d.speichern(new Daten.Ansicht(0, "Abend am Hafen", null, "GEMERKT", new double[]{1, 2, 3, 45, 5, 55}, null, false, null,
                Daten.Szenenzeit.of(LocalDate.of(950, 10, 16), 19.25), "a=1\nb=2\n", new byte[]{1, 2, 3}, Daten.EIGEN), null);
        var oc = com.dan.ocean.Ocean.noor(4);
        d.speichern(new Daten.PaketPreset("com.dan.ocean", "Ocean", "Noor Bft 4", "aus der Prüfung", Daten.EIGEN, Felder.lesen(oc)));
        boolean ablehnung = false;
        try { d.speichern(new Daten.Wetterlage("Klar", 1.0, "KLAR", wv, null, null, Daten.EIGEN)); } catch (Ablage.Fehler e) { ablehnung = true; }
        Daten.Ansicht an = d.ansicht(aid);
        var oc2 = com.dan.ocean.Ocean.calm();
        Felder.schreiben(oc2, d.presets("com.dan.ocean", "Ocean").stream().filter(p -> p.name().equals("Noor Bft 4")).findFirst().orElseThrow().felder());
        check(d.wetterlagen().size() == Startdaten.wetterlagen().size() + 1 && d.wetterlagen().get(Startdaten.wetterlagen().size()).werte()[0] == 3.3
                        && d.regiebuecher().size() == 4 && d.fahrten().size() == 4 && d.fahrten().get(3).punkte().size() == 3
                        && an.szenenzeit().equals(Daten.Szenenzeit.of(LocalDate.of(950, 10, 16), 19.25)) && an.zustand().equals("a=1\nb=2\n") && an.vorschau().length == 3
                        && Felder.lesen(oc2).equals(Felder.lesen(oc)) && ablehnung,
                "Wetterlage, Regiebuch, Fahrt, Ansicht mit Zustand und Vorschau, Preset gespeichert und gelesen; „Klar“ ist mitgeliefert und wird abgelehnt");
        // Sitzung und Protokoll über com.dan.store.Dienst
        long sid = d.sitzungBeginnen("Phase 16", "Prüfung", "MITTEL");
        Map<String, String> sp = new LinkedHashMap<>();
        sp.put(com.dan.haithabu.data.Speicher.SIEDLUNG, "Haithabu 950 (bearbeitet)");
        sp.put(com.dan.haithabu.data.Speicher.REGIEBUCH, "Die Nacht von 1050");
        sp.put(com.dan.haithabu.data.Speicher.REGIE_SEKUNDE, "123.4");
        sp.put(com.dan.haithabu.data.Speicher.SZ, "1050-10-16 1.6");
        d.sitzungSichern(sid, new Ablage.Sicherung("uhr.datum=1050-10-16\n", sp));
        Daten.Sitzung ls = d.letzteSitzung(-1);
        check(ls != null && ls.id() == sid && !ls.sauber() && "Die Nacht von 1050".equals(ls.regiebuch()) && ls.regieSekunde() == 123.4
                        && ls.szenenzeit().equals(Daten.Szenenzeit.of(LocalDate.of(1050, 10, 16), 1.6)) && ls.zustand().startsWith("uhr.datum=1050"),
                "Sitzung gesichert, noch nicht sauber beendet: „Weiter wie zuletzt“ findet Siedlung, Regiebuch mit Stelle und Szenenzeit");
        Daten.Stand st = d.stand();
        check(st.siedlungen() == 3 && st.regiebuecher() == 4 && "Haithabu 950 (bearbeitet)".equals(st.aktiveSiedlung()) && st.befunde() == 45 && st.bauwerke() == sz.bauwerke().size(),
                "Stand für das Startbild: " + st.siedlungen() + " Siedlungen, " + st.regiebuecher() + " Regiebücher, " + st.ansichten() + " Ansichten, aktiv „" + st.aktiveSiedlung() + "“");
        // „In die Datenbank übernehmen“ (hier in einen zweiten Dateispeicher): alles Eigene, und beim zweiten Mal nichts mehr
        DateiSpeicher ziel = new DateiSpeicher(Files.createTempDirectory("haithabu-ziel").toFile());
        ziel.szene = () -> sz;
        List<String> ue = com.dan.haithabu.data.Uebernahme.uebernehmen(d, ziel, t);
        List<String> ue2 = com.dan.haithabu.data.Uebernahme.uebernehmen(d, ziel, t);
        var zs = ziel.siedlungen().stream().filter(x -> x.name().equals("Haithabu 950 (bearbeitet)")).findFirst().orElse(null);
        boolean alle = zs != null && ziel.haeuser(zs.name()).size() == s.haeuser.size() - 1
                && ziel.regiebuecher().stream().anyMatch(x -> x.name().equals("Mein Abend")) && ziel.wetterlagen().stream().anyMatch(x -> x.name().equals("Meine Brise"))
                && ziel.fahrten().stream().anyMatch(x -> x.name().equals("Meine Fahrt") && x.punkte().size() == 3)
                && ziel.ansichten().stream().anyMatch(x -> x.name().equals("Abend am Hafen"))
                && ziel.presets("com.dan.ocean", "Ocean").stream().anyMatch(x -> x.name().equals("Noor Bft 4"))
                && ziel.ansicht(ziel.ansichten().stream().filter(x -> x.name().equals("Abend am Hafen")).findFirst().orElseThrow().id()).vorschau().length == 3;
        check(alle && String.join(" ", ue2).matches("Siedlungen: 0 übernommen \\(0 Häuser\\), \\d+ gab es schon Wetterlagen: 0 Regiebücher: 0 Fahrten: 0 Ansichten: 0 Presets: 0"),
                "In die Datenbank übernehmen: " + String.join(" · ", ue) + "; beim zweiten Mal nichts doppelt");
        Datenseite.setzen(new DateiSpeicher(Files.createTempDirectory("haithabu-leer").toFile()));
    }

    // ------------------------------------------------------------------ Oberfläche

    /** Hauskarte (Strahl durch den Bildpunkt) und Feuer nach einem Sprung der Uhr (Befund der Abnahme Phase 15). */
    static void oberflaeche(Terrain t) {
        SceneClock clock = new SceneClock();
        Wiring w = new Wiring(clock);
        Renderer.siedlungsLader = Siedlung::haithabu;
        Renderer r = new Renderer(clock, w, t);
        Siedlung.Haus h = r.siedlung.haeuser.stream().filter(Siedlung.Haus::museum).findFirst().orElseThrow();
        var o = h.house();
        double[] az = o.axisZ();
        double ex = o.x() + az[0] * 25, ez = o.z() + az[1] * 25, ey = o.y() + 3;
        double yaw = Math.toDegrees(Math.atan2(o.x() - ex, -(o.z() - ez))), pitch = Math.toDegrees(Math.atan2(ey - (o.y() + 2), 25));
        r.camera.place(ex, ey, ez, yaw, pitch);
        r.camera.snap();
        var hit = com.dan.haithabu.ui.Hauskarte.treffer(r, 640, 360, 1280, 720);
        var himmel = com.dan.haithabu.ui.Hauskarte.treffer(r, 640, 3, 1280, 720);
        var rand = com.dan.haithabu.ui.Hauskarte.treffer(r, 3, 360, 1280, 720);
        check(hit == h && himmel == null, "Hauskarte: der Klick in die Bildmitte trifft „" + h.name() + "“ aus 25 m, der Himmel darüber nichts"
                + (rand != null ? " (am Rand: „" + rand.name() + "“)" : ""));
        var fe = r.feuer;
        for (int i = 0; i < 30 * 120; i++) fe.step(1 / 30.0, 17.5, 2);
        int vor = fe.sources().size();
        fe.springen(1.5, -30);
        int nach = fe.sources().size(), brennen = fe.burningHerds();
        check(vor > 100 && nach < vor / 3 && nach <= brennen + 6, String.format(Locale.GERMAN,
                "Sprung der Uhr von 17:30 auf 1:30: gleich %d Rauchfahnen statt %d (es brennen %d Herde); vorher rauchten die Herde des Abends noch eine Minute nach", nach, vor, brennen));
        Renderer.siedlungsLader = Siedlung::startup;
    }

    // ------------------------------------------------------------------ Zustand

    static void zustand(Terrain t) throws Exception {
        SceneClock clock = new SceneClock();
        Wiring w = new Wiring(clock);
        w.regie = true;
        w.yearOn = true;
        w.startFree(com.dan.weather.Weather.Phase.KLAR);
        Renderer.siedlungsLader = Siedlung::haithabu;
        Renderer r = new Renderer(clock, w, t);
        clock.set(LocalDate.of(1050, 10, 16), 1.5);
        r.ocean.windSpeed = 7.25;
        r.reed.density = 0.8;
        w.hand(com.dan.weather.Weather.Var.FOG, 0.4);
        r.camera.place(10, 4, -80, 65, 4);
        r.camera.snap();
        // Brand: Brander, drei Häuser, 90 s
        r.startRegie(Regie.nacht1050());
        var fe = r.feuer;
        var fl = r.flotte;
        fe.brand = com.dan.haithabu.scene.Brand.of(r.siedlung, fl, 1050);
        r.timber.burn = fe.brand::burnOf;
        fe.brand.igniteNear(fl.brander.x, fl.brander.z, 3);
        fe.brand.step(90, 80, 7, 0);
        for (int i = 0; i < 40; i++) r.regie.step(1, new Regie.Ctx() {
            public void time(LocalDate d, double h) { }
            public void lapse(double x) { }
            public void weather(com.dan.weather.Scenario s) { }
            public void weatherFree(com.dan.weather.Weather.Phase p, double b, double f) { }
            public void view(String n) { }
            public void fahrt(String n) { }
            public void einlaufen() { }
            public void auslaufen() { }
            public void brander() { }
            public void igniteNearBrander() { }
            public void capture(String x) { }
            public void sheet(String n) { }
            public void say(String x) { }
        });
        fl.langschiff.x += 3;
        LinkedHashMap<String, String> z = Zustand.erfassen(r, true, "Haithabu 950");
        String text = Felder.alsText(z, "Prüfung");
        int burning = fe.brand.burning();
        // zweite Szene, alles anders, dann herstellen
        SceneClock c2 = new SceneClock();
        Wiring w2 = new Wiring(c2);
        w2.regie = true;
        w2.yearOn = true;
        w2.startFree(com.dan.weather.Weather.Phase.STURM);
        Renderer r2 = new Renderer(c2, w2, t);
        List<String> fehler = Zustand.anwenden(r2, Felder.ausText(text));
        LinkedHashMap<String, String> z2 = Zustand.erfassen(r2, true, "Haithabu 950");
        List<String> diff = new ArrayList<>();
        for (Map.Entry<String, String> e : z.entrySet()) if (!e.getValue().equals(z2.get(e.getKey()))) diff.add(e.getKey());
        check(fehler.isEmpty() && diff.isEmpty() && r2.clock.date().equals(LocalDate.of(1050, 10, 16)) && r2.feuer.brand != null && r2.feuer.brand.burning() == burning
                        && r2.regie.running() && Math.abs(r2.regie.time() - 40) < 1e-9 && Math.abs(r2.flotte.langschiff.x - fl.langschiff.x) < 0.01,
                String.format(Locale.GERMAN, "Zustand der Szene hin und zurück: %d Schlüssel gleich (%d kB), 16.10.1050, Brand mit %d brennenden Häusern, Regiebuch bei 0:40%s",
                        z.size(), text.length() / 1024, burning, fehler.isEmpty() && diff.isEmpty() ? "" : " · " + fehler + " " + diff.subList(0, Math.min(8, diff.size()))));
        Renderer.siedlungsLader = Siedlung::startup;
    }
}
