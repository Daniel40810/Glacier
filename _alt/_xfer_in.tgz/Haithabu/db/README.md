# db – Datenbank von Haithabu

Schema `HAITHABU` auf PDBORCL (angelegt mit `USER.sql`, Rolle DB_CONNECT), Präfix `HB_`, Spatial mit SRID 8307 (WGS 84, Länge und Breite). Der Zugang steht in `db.properties` (Vorlage `db.properties.example`, nie ins Git); fehlt die Datei, legt die App sie aus der Vorlage an, fragt im Startbild nach dem Passwort und trägt es nach dem ersten erfolgreichen Verbinden ein. Ohne Datenbank läuft die App weiter und speichert in den Ordner `daten/` des Projekts.

## Einrichten

Startbild oder Block DATEN, Knopf **Einrichten**. Der Einrichter (`com.dan.store.Einrichter`) führt die Skripte in `sql/` der Reihe nach aus und prüft danach alles: Tabellen, Spalten, Sequenzen, Trigger, Sichten, Spatial-Metadaten, räumliche Indizes und die Zahl der mitgelieferten Zeilen. Am Ende steht „alles in Ordnung“ oder genau, was fehlt. Er löscht nie etwas und lässt sich beliebig oft wiederholen.

| Skript | Inhalt |
|---|---|
| `sql/01_tabellen.sql` | 22 Tabellen, 21 Sequenzen, 20 Trigger (Sequence + Trigger, nie IDENTITY), 13 Indizes |
| `sql/02_spatial.sql` | Metadaten für sieben Geometriespalten und sieben räumliche Indizes |
| `sql/03_sichten.sql` | Acht Sichten: `HB_HAUS_V`, `HB_BAUWERK_V`, `HB_SCHIFF_V` (Länge und Breite als Zahl, Längen und Flächen auf dem Ellipsoid), `HB_LAGEPLAN_V` (alles als eine Ebene für QGIS), `HB_UFERZEILE_V` und `HB_IM_WALL_V` (räumlich gerechnet), `HB_BEFUND_V`, `HB_LETZTE_SITZUNG_V` |
| `sql/04_startdaten.sql` | Quellen und Befunde, Haustypen, die Siedlung „Haithabu 950“ mit 540 Häusern und 506 Wegen, Zäunen und Gärten, der Lageplan mit 111 Bauwerken, das Gelände, Schiffstypen und acht Schiffe, zwölf Wetterlagen, drei Regiebücher, sieben Ansichten, drei Fahrten, 52 Presets. Erzeugt aus `com.dan.haithabu.data.Startdaten` mit `tools.StartdatenSql`, nicht von Hand ändern |
| `sql/99_entfernen.sql` | Entfernt alle `HB_`-Objekte samt Inhalt. Nur von Hand für einen Neuanfang, die App führt es nie aus |

Dieselben Skripte lassen sich in SQL Developer als Skript ausführen (F5). Bei einem zweiten Lauf meldet Oracle ORA-00955 (Name schon vergeben); das ist harmlos.

Meldet der räumliche Index ORA-01031 oder ORA-13249, fehlt dem Schema ein direkt erteiltes Recht (eine Rolle reicht dafür nicht). Als DBA: `GRANT CREATE TABLE, CREATE SEQUENCE TO HAITHABU;`, dann noch einmal einrichten.

## Prüfen

`test/com/dan/haithabu/test/DbPruefung.java` in NetBeans mit „Run File“ starten. Sie richtet ein, läuft den Einrichter ein zweites Mal, prüft mit ihm, rechnet den Lageplan auf dem Ellipsoid nach (Wallfläche, Hafenbecken, Kammlinie), prüft alle Geometrien auf Gültigkeit und die räumlichen Sichten, speichert und lädt jede Art von Daten unter Namen „~Prüfung …“, prüft die Hauskarte an einer Kopie der Siedlung, übernimmt eine Datei und räumt danach auf; die aktive Siedlung ist danach wieder dieselbe. Ende: „Alles in Ordnung.“

## Tabellen

| Tabelle | Inhalt |
|---|---|
| `HB_SCHEMA` | Ausbaustufe (Phase 16 = 1) |
| `HB_QUELLE`, `HB_BEFUND`, `HB_BEFUND_QUELLE` | Quellen; Befunde je Gegenstand: `BELEGT`, `GEMESSEN` oder `GESTALTET`, mit ihren Quellen |
| `HB_HAUSTYP` | Sechs Haustypen mit Maßen, Wand, Dachneigung und Befund |
| `HB_SIEDLUNG`, `HB_HAUS`, `HB_WEG` | Siedlungen (eine aktiv) mit Startwert; Häuser mit Lage (Punkt), Grundriss (Polygon), Szenenmetern, Richtung, Zustand, `VON_HAND`; Wege, Zäune und Gärten für den Lageplan |
| `HB_BAUWERK` | Lageplan: Wallkamm, Graben, Palisaden, Wallfläche, Hochburg, Grabhügel, Ufer von 950, Hafenbecken, Durchfahrt, Brücken, Plattform, Umschlagplatz, Bach, entfernte Dämme. Nur zum Lesen |
| `HB_GELAENDE` | Ausschnitt und Ursprung des Geländes, Raster, SHA-256 der Dateien in `daten/gelaende` |
| `HB_SCHIFFSTYP`, `HB_SCHIFF` | Langschiff, Knorr, Faering; Schiffe mit Liegeplatz |
| `HB_WETTERLAGE` | Wetterlagen, je Größe der Regie eine Spalte (leer = die Regie entscheidet) |
| `HB_REGIEBUCH`, `HB_STICHWORT` | Regiebücher als ganzer Text und zerlegt in Stichworte |
| `HB_SITZUNG` | Sitzungen; Zustand (CLOB) alle zwei Minuten und beim Ende, Szenenzeit als Zahlen `SZ_JAHR`, `SZ_MONAT`, `SZ_TAG`, `SZ_STUNDE` (nie DATE: Oracle rechnet vor 1582 julianisch) |
| `HB_ANSICHT` | Feste Ansichten (Tasten 1–7) und gemerkte (Taste V) mit Zustand und Vorschau (PNG im BLOB) |
| `HB_FAHRT`, `HB_STUETZPUNKT` | Kamerafahrten mit Stützpunkten in Szenenmetern (eigene: Aufnahme mit P) |
| `HB_PAKET_PRESET`, `HB_PAKET_WERT` | Presets je Package, ein öffentliches Feld je Zeile |
| `HB_LOG` | Protokoll mit Szenenzeit und Ort; älter als 90 Tage räumt die App beim Start weg |

Mitgelieferte Zeilen (`HERKUNFT = 'MITGELIEFERT'`) stellt der Einrichter bei jedem Lauf wieder her; eigene Zeilen (`EIGEN`) fasst er nie an. Die App überschreibt Mitgeliefertes nicht: eine mitgelieferte Siedlung wird beim ersten Ändern in der Hauskarte als „… (bearbeitet)“ gespeichert, ein Regiebuch oder eine Wetterlage bekommt einen eigenen Namen.

## QGIS

Neue Verbindung zu Oracle (Datenbank `PDBORCL`, Benutzer `Haithabu`), Ebene `HB_LAGEPLAN_V` mit Geometriespalte `GEOM` und Schlüssel `OBJEKT_ID`; Stil nach `EBENE` und `ART`.
