-- =====================================================================================================
-- Haithabu · Datenbank · 03_sichten.sql
-- Acht Sichten: Häuser, Bauwerke und Schiffe mit Länge und Breite als Zahl, der ganze Lageplan als eine
-- Ebene für QGIS, die Uferzeile und die Häuser im Wall (räumlich gerechnet), die Befunde mit ihren Quellen
-- und die letzte Sitzung für „Weiter wie zuletzt“. CREATE OR REPLACE: beliebig oft wiederholbar.
-- =====================================================================================================

-- Häuser ohne Spatial-Typ: so lesen SQL Developer und die App die Lage als Zahlen. Maße = Typ × Faktor.
CREATE OR REPLACE VIEW HB_HAUS_V AS
SELECT h.ID,
       s.NAME AS SIEDLUNG,
       s.AKTIV,
       h.NR,
       h.NAME,
       t.NAME AS HAUSTYP,
       t.BEZEICHNUNG AS TYP_BEZEICHNUNG,
       h.ROLLE,
       h.LAGE.SDO_POINT.X AS LAENGE,
       h.LAGE.SDO_POINT.Y AS BREITE,
       h.X_M,
       h.Z_M,
       h.BODEN_M,
       h.RICHTUNG_GRAD,
       ROUND(t.LAENGE_M * h.LAENGE_FAKTOR, 2) AS LAENGE_M,
       ROUND(t.BREITE_M * h.BREITE_FAKTOR, 2) AS BREITE_M,
       h.ZUSTAND,
       h.MUSEUM,
       h.VON_HAND,
       t.BEFUND,
       b.TEXT AS BEFUND_TEXT,
       h.BEMERKUNG
FROM HB_HAUS h
JOIN HB_SIEDLUNG s ON s.ID = h.SIEDLUNG_ID
JOIN HB_HAUSTYP t ON t.ID = h.HAUSTYP_ID
LEFT JOIN HB_BEFUND b ON b.ID = t.BEFUND_ID;

-- Bauwerke mit Länge (Linien) oder Fläche (Flächen), auf dem Ellipsoid gerechnet, Toleranz 5 cm.
CREATE OR REPLACE VIEW HB_BAUWERK_V AS
SELECT w.ID,
       w.ART,
       w.NAME,
       w.GEOM.SDO_GTYPE AS GTYPE,
       CASE WHEN w.GEOM.SDO_GTYPE IN (2002, 2006) THEN ROUND(MDSYS.SDO_GEOM.SDO_LENGTH(w.GEOM, 0.05, 'unit=M'), 1) END AS LAENGE_M,
       CASE WHEN w.GEOM.SDO_GTYPE IN (2003, 2007) THEN ROUND(MDSYS.SDO_GEOM.SDO_AREA(w.GEOM, 0.05, 'unit=SQ_M') / 10000, 3) END AS FLAECHE_HA,
       CASE WHEN w.GEOM.SDO_GTYPE = 2001 THEN w.GEOM.SDO_POINT.X END AS LAENGE,
       CASE WHEN w.GEOM.SDO_GTYPE = 2001 THEN w.GEOM.SDO_POINT.Y END AS BREITE,
       w.HOEHE_M,
       w.BREITE_M,
       w.BEFUND,
       w.BESCHREIBUNG,
       w.HERKUNFT
FROM HB_BAUWERK w;

-- Schiffe mit Typ und Liegeplatz als Zahlen.
CREATE OR REPLACE VIEW HB_SCHIFF_V AS
SELECT s.ID,
       s.NAME,
       t.NAME AS SCHIFFSTYP,
       t.BEZEICHNUNG AS TYP_BEZEICHNUNG,
       t.LAENGE_M,
       t.BREITE_M,
       s.ROLLE,
       s.LIEGEPLATZ.SDO_POINT.X AS LAENGE,
       s.LIEGEPLATZ.SDO_POINT.Y AS BREITE,
       s.RICHTUNG_GRAD,
       s.BRUECKE,
       s.LADUNG,
       t.BEFUND
FROM HB_SCHIFF s
JOIN HB_SCHIFFSTYP t ON t.ID = s.SCHIFFSTYP_ID;

-- Der ganze Lageplan der aktiven Siedlung als eine Ebene (QGIS: eine Verbindung, Stil nach EBENE und ART).
-- OBJEKT_ID ist eindeutig: Ebene × 10^9 + ID.
CREATE OR REPLACE VIEW HB_LAGEPLAN_V AS
SELECT 1000000000 + h.ID AS OBJEKT_ID, 'HAUS' AS EBENE, h.ROLLE AS ART, h.NAME, h.GRUNDRISS AS GEOM
FROM HB_HAUS h JOIN HB_SIEDLUNG s ON s.ID = h.SIEDLUNG_ID AND s.AKTIV = 1 WHERE h.GRUNDRISS IS NOT NULL
UNION ALL
SELECT 2000000000 + w.ID, 'WEG', w.ART, w.NAME, w.GEOM
FROM HB_WEG w JOIN HB_SIEDLUNG s ON s.ID = w.SIEDLUNG_ID AND s.AKTIV = 1
UNION ALL
SELECT 3000000000 + b.ID, 'BAUWERK', b.ART, b.NAME, b.GEOM
FROM HB_BAUWERK b
UNION ALL
SELECT 4000000000 + s.ID, 'SCHIFF', s.ROLLE, s.NAME, s.LIEGEPLATZ
FROM HB_SCHIFF s WHERE s.LIEGEPLATZ IS NOT NULL;

-- Die Uferzeile: Häuser der aktiven Siedlung bis 60 m an der Uferlinie von 950, die ersten im Brand von 1050.
CREATE OR REPLACE VIEW HB_UFERZEILE_V AS
SELECT h.ID,
       h.NAME,
       h.ROLLE,
       ROUND(MDSYS.SDO_GEOM.SDO_DISTANCE(h.LAGE, u.GEOM, 0.05, 'unit=M'), 1) AS ABSTAND_M
FROM HB_HAUS h
JOIN HB_SIEDLUNG s ON s.ID = h.SIEDLUNG_ID AND s.AKTIV = 1
JOIN HB_BAUWERK u ON u.ART = 'UFER_950'
WHERE MDSYS.SDO_WITHIN_DISTANCE(h.LAGE, u.GEOM, 'distance=60 unit=M') = 'TRUE';

-- Die Häuser der aktiven Siedlung in der Wallfläche (26 ha nach der Literatur).
CREATE OR REPLACE VIEW HB_IM_WALL_V AS
SELECT h.ID,
       h.NAME,
       h.ROLLE
FROM HB_HAUS h
JOIN HB_SIEDLUNG s ON s.ID = h.SIEDLUNG_ID AND s.AKTIV = 1
JOIN HB_BAUWERK w ON w.ART = 'WALLFLAECHE'
WHERE MDSYS.SDO_RELATE(h.LAGE, w.GEOM, 'mask=INSIDE+COVEREDBY') = 'TRUE';

-- Befunde mit ihren Quellen (Kurzzeichen) in einer Zeile.
CREATE OR REPLACE VIEW HB_BEFUND_V AS
SELECT b.ID,
       b.THEMA,
       b.GEGENSTAND,
       b.BEFUND,
       b.TEXT,
       (SELECT LISTAGG(q.KURZ, ', ') WITHIN GROUP (ORDER BY q.KURZ)
          FROM HB_BEFUND_QUELLE bq JOIN HB_QUELLE q ON q.ID = bq.QUELLE_ID
         WHERE bq.BEFUND_ID = b.ID) AS QUELLEN
FROM HB_BEFUND b;

-- Die jüngste Sitzung mit gesichertem Zustand, ob sauber beendet oder abgebrochen.
CREATE OR REPLACE VIEW HB_LETZTE_SITZUNG_V AS
SELECT *
FROM (SELECT s.ID, s.BEGINN, s.ENDE, s.SAUBER_BEENDET, s.APP_VERSION, s.SIEDLUNG_ID, s.REGIEBUCH_ID, s.REGIE_SEKUNDE,
             s.SZ_JAHR, s.SZ_MONAT, s.SZ_TAG, s.SZ_STUNDE, s.ZUSTAND_ZEIT
      FROM HB_SITZUNG s
      WHERE s.ZUSTAND IS NOT NULL
      ORDER BY s.ZUSTAND_ZEIT DESC NULLS LAST, s.ID DESC)
WHERE ROWNUM = 1;

-- Ende 03_sichten.sql
