-- =====================================================================================================
-- Haithabu · Datenbank · 04_startdaten.sql
-- ERZEUGT aus com.dan.haithabu.data.Startdaten (tools.StartdatenSql) – nicht von Hand ändern.
-- Mitgelieferte Zeilen (HERKUNFT = 'MITGELIEFERT') werden angelegt oder wiederhergestellt; eigene Zeilen
-- bleiben unberührt. Beliebig oft wiederholbar. Die Siedlung „Haithabu 950“ und der Lageplan sind aus der
-- Szene gerechnet (Startwert 950, Gelände aus daten/gelaende, Prüfsumme in HB_GELAENDE).
-- =====================================================================================================
-- ZAHLEN: Quellen=12; Befunde=45; Belege=48; Haustypen=6; Siedlungen=1; Häuser=540; Wege=506; Bauwerke=111; Gelände=1; Schiffstypen=3; Schiffe=8; Wetterlagen=12; Regiebücher=3; Stichworte=57; Ansichten=7; Fahrten=3; Stützpunkte=24; Presets=52; Presetwerte=738;

-- Die Quellen enthalten „&“: in SQL Developer keine Ersetzungsvariablen
SET DEFINE OFF

-- ----------------------------------------------------------------------------------------- Ausbaustufe
MERGE INTO HB_SCHEMA t USING (SELECT 1 AS VERSION FROM DUAL) q ON (t.VERSION = q.VERSION)
WHEN NOT MATCHED THEN INSERT (VERSION, APP_VERSION, TEXT) VALUES (1, 'Phase 16', 'Oberfläche und Datenbank: 22 Tabellen, Lageplan, Regiebücher als Text, Befunde');

-- --------------------------------------------------------------------------------------------- Quellen
MERGE INTO HB_QUELLE t USING (SELECT 'WIKI_HAITHABU' AS KURZ FROM DUAL) q ON (t.KURZ = q.KURZ)
WHEN MATCHED THEN UPDATE SET t.TITEL = 'Haithabu (Wikipedia, deutsch)', t.URL = 'https://de.wikipedia.org/wiki/Haithabu', t.ART = 'WEB', t.ABGERUFEN = DATE '2026-10-16', t.BEMERKUNG = 'Gründung, Zerstörung 1050 und 1066, Wall, Verbindungswall, Hafenbecken, Hausmaße, Bauweisen, Einwohner, Bach' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (KURZ, TITEL, URL, ART, ABGERUFEN, BEMERKUNG, HERKUNFT) VALUES ('WIKI_HAITHABU', 'Haithabu (Wikipedia, deutsch)', 'https://de.wikipedia.org/wiki/Haithabu', 'WEB', DATE '2026-10-16', 'Gründung, Zerstörung 1050 und 1066, Wall, Verbindungswall, Hafenbecken, Hausmaße, Bauweisen, Einwohner, Bach', 'MITGELIEFERT');
MERGE INTO HB_QUELLE t USING (SELECT 'KULADIG_HAITHABU' AS KURZ FROM DUAL) q ON (t.KURZ = q.KURZ)
WHEN MATCHED THEN UPDATE SET t.TITEL = 'Haithabu (KuLaDig)', t.URL = 'https://www.kuladig.de/Objektansicht/Drucken/KLD-271240', t.ART = 'WEB', t.ABGERUFEN = DATE '2026-10-16', t.BEMERKUNG = 'Koordinaten, Landenge, Landebrücken als Plattformen um 900, sieben rekonstruierte Häuser' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (KURZ, TITEL, URL, ART, ABGERUFEN, BEMERKUNG, HERKUNFT) VALUES ('KULADIG_HAITHABU', 'Haithabu (KuLaDig)', 'https://www.kuladig.de/Objektansicht/Drucken/KLD-271240', 'WEB', DATE '2026-10-16', 'Koordinaten, Landenge, Landebrücken als Plattformen um 900, sieben rekonstruierte Häuser', 'MITGELIEFERT');
MERGE INTO HB_QUELLE t USING (SELECT 'KULADIG_HOCHBURG' AS KURZ FROM DUAL) q ON (t.KURZ = q.KURZ)
WHEN MATCHED THEN UPDATE SET t.TITEL = 'Hochburg von Haithabu (KuLaDig)', t.URL = 'https://www.kuladig.de/Objektansicht/Drucken/KLD-275677', t.ART = 'WEB', t.ABGERUFEN = DATE '2026-10-16', t.BEMERKUNG = 'Moränenkuppe 25 m, Innenfläche 240 × 60–80 m, über 70 Grabhügel, Tor im Nordosten' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (KURZ, TITEL, URL, ART, ABGERUFEN, BEMERKUNG, HERKUNFT) VALUES ('KULADIG_HOCHBURG', 'Hochburg von Haithabu (KuLaDig)', 'https://www.kuladig.de/Objektansicht/Drucken/KLD-275677', 'WEB', DATE '2026-10-16', 'Moränenkuppe 25 m, Innenfläche 240 × 60–80 m, über 70 Grabhügel, Tor im Nordosten', 'MITGELIEFERT');
MERGE INTO HB_QUELLE t USING (SELECT 'MASS_HEDEBY' AS KURZ FROM DUAL) q ON (t.KURZ = q.KURZ)
WHEN MATCHED THEN UPDATE SET t.TITEL = 'Hedeby (MASS, Maritime Archaeology)', t.URL = 'https://mass.cultureelerfgoed.nl/hedeby', t.ART = 'WEB', t.ABGERUFEN = DATE '2026-10-16', t.BEMERKUNG = 'Landebrücken ab den 860ern, Tiefgang 1,3–1,5 m, Hafen 8 ha, Schiffe Haithabu I–IV' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (KURZ, TITEL, URL, ART, ABGERUFEN, BEMERKUNG, HERKUNFT) VALUES ('MASS_HEDEBY', 'Hedeby (MASS, Maritime Archaeology)', 'https://mass.cultureelerfgoed.nl/hedeby', 'WEB', DATE '2026-10-16', 'Landebrücken ab den 860ern, Tiefgang 1,3–1,5 m, Hafen 8 ha, Schiffe Haithabu I–IV', 'MITGELIEFERT');
MERGE INTO HB_QUELLE t USING (SELECT 'WIKI_HEDEBY1' AS KURZ FROM DUAL) q ON (t.KURZ = q.KURZ)
WHEN MATCHED THEN UPDATE SET t.TITEL = 'Hedeby 1 (Wikipedia, englisch)', t.URL = 'https://en.wikipedia.org/wiki/Hedeby_1', t.ART = 'WEB', t.ABGERUFEN = DATE '2026-10-16', t.BEMERKUNG = '30,9 × 2,7 m, 35 Spanten, 31 Riemenpaare, um 985 gebaut, Brander 990–1010' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (KURZ, TITEL, URL, ART, ABGERUFEN, BEMERKUNG, HERKUNFT) VALUES ('WIKI_HEDEBY1', 'Hedeby 1 (Wikipedia, englisch)', 'https://en.wikipedia.org/wiki/Hedeby_1', 'WEB', DATE '2026-10-16', '30,9 × 2,7 m, 35 Spanten, 31 Riemenpaare, um 985 gebaut, Brander 990–1010', 'MITGELIEFERT');
MERGE INTO HB_QUELLE t USING (SELECT 'WIKI_NOOR' AS KURZ FROM DUAL) q ON (t.KURZ = q.KURZ)
WHEN MATCHED THEN UPDATE SET t.TITEL = 'Haddebyer Noor (Wikipedia, englisch)', t.URL = 'https://en.wikipedia.org/wiki/Haddebyer_Noor', t.ART = 'WEB', t.ABGERUFEN = DATE '2026-10-16', t.BEMERKUNG = '1 km², 1,6 × 0,9 km, 3 m im Mittel, 5,2 m höchstens' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (KURZ, TITEL, URL, ART, ABGERUFEN, BEMERKUNG, HERKUNFT) VALUES ('WIKI_NOOR', 'Haddebyer Noor (Wikipedia, englisch)', 'https://en.wikipedia.org/wiki/Haddebyer_Noor', 'WEB', DATE '2026-10-16', '1 km², 1,6 × 0,9 km, 3 m im Mittel, 5,2 m höchstens', 'MITGELIEFERT');
MERGE INTO HB_QUELLE t USING (SELECT 'PLANET_WISSEN' AS KURZ FROM DUAL) q ON (t.KURZ = q.KURZ)
WHEN MATCHED THEN UPDATE SET t.TITEL = 'Haithabu (Planet Wissen)', t.URL = 'https://www.planet-wissen.de/kultur/voelker/wikinger/wikinger-dorf-haithabu-102.html', t.ART = 'WEB', t.ABGERUFEN = DATE '2026-10-16', t.BEMERKUNG = 'Pfostenspuren, Uferhäuser, Grubenhäuser, Feuergewerbe abseits, Einwohner, ausgegrabener Anteil' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (KURZ, TITEL, URL, ART, ABGERUFEN, BEMERKUNG, HERKUNFT) VALUES ('PLANET_WISSEN', 'Haithabu (Planet Wissen)', 'https://www.planet-wissen.de/kultur/voelker/wikinger/wikinger-dorf-haithabu-102.html', 'WEB', DATE '2026-10-16', 'Pfostenspuren, Uferhäuser, Grubenhäuser, Feuergewerbe abseits, Einwohner, ausgegrabener Anteil', 'MITGELIEFERT');
MERGE INTO HB_QUELLE t USING (SELECT 'DAMALS' AS KURZ FROM DUAL) q ON (t.KURZ = q.KURZ)
WHEN MATCHED THEN UPDATE SET t.TITEL = 'Die Wikinger sind wieder los (Damals)', t.URL = 'https://damals.de/artikel/die-wikinger-sind-wieder-los', t.ART = 'WEB', t.ABGERUFEN = DATE '2026-10-16', t.BEMERKUNG = 'Museumshäuser mit Kammmacher, Fischer, Tuchhändler' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (KURZ, TITEL, URL, ART, ABGERUFEN, BEMERKUNG, HERKUNFT) VALUES ('DAMALS', 'Die Wikinger sind wieder los (Damals)', 'https://damals.de/artikel/die-wikinger-sind-wieder-los', 'WEB', DATE '2026-10-16', 'Museumshäuser mit Kammmacher, Fischer, Tuchhändler', 'MITGELIEFERT');
MERGE INTO HB_QUELLE t USING (SELECT 'HESKESTAD' AS KURZ FROM DUAL) q ON (t.KURZ = q.KURZ)
WHEN MATCHED THEN UPDATE SET t.TITEL = 'Zwei-Zonen-Modell und Massenstrom der Fahne nach Heskestad (SFPE Handbook of Fire Protection Engineering)', t.URL = NULL, t.ART = 'BUCH', t.ABGERUFEN = NULL, t.BEMERKUNG = 'Werte für das offene Herdfeuer gewählt [G]' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (KURZ, TITEL, URL, ART, ABGERUFEN, BEMERKUNG, HERKUNFT) VALUES ('HESKESTAD', 'Zwei-Zonen-Modell und Massenstrom der Fahne nach Heskestad (SFPE Handbook of Fire Protection Engineering)', NULL, 'BUCH', NULL, 'Werte für das offene Herdfeuer gewählt [G]', 'MITGELIEFERT');
MERGE INTO HB_QUELLE t USING (SELECT 'DGM1_SH' AS KURZ FROM DUAL) q ON (t.KURZ = q.KURZ)
WHEN MATCHED THEN UPDATE SET t.TITEL = 'DGM1 Schleswig-Holstein (Landesamt für Vermessung und Geoinformation, offene Daten)', t.URL = NULL, t.ART = 'DATEN', t.ABGERUFEN = DATE '2026-10-17', t.BEMERKUNG = 'GeoTIFF-Ausschnitt 8 × 6 km, ETRS89/UTM32, eingelesen in Phase 2' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (KURZ, TITEL, URL, ART, ABGERUFEN, BEMERKUNG, HERKUNFT) VALUES ('DGM1_SH', 'DGM1 Schleswig-Holstein (Landesamt für Vermessung und Geoinformation, offene Daten)', NULL, 'DATEN', DATE '2026-10-17', 'GeoTIFF-Ausschnitt 8 × 6 km, ETRS89/UTM32, eingelesen in Phase 2', 'MITGELIEFERT');
MERGE INTO HB_QUELLE t USING (SELECT 'MESSUNG_P7' AS KURZ FROM DUAL) q ON (t.KURZ = q.KURZ)
WHEN MATCHED THEN UPDATE SET t.TITEL = 'Gemessen im DGM1 (Haithabu Phase 7)', t.URL = NULL, t.ART = 'MESSUNG', t.ABGERUFEN = DATE '2026-10-17', t.BEMERKUNG = 'Kammlinie des Halbkreiswalls, Lücken im Süden und Westen, Kuppen der Grabhügel' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (KURZ, TITEL, URL, ART, ABGERUFEN, BEMERKUNG, HERKUNFT) VALUES ('MESSUNG_P7', 'Gemessen im DGM1 (Haithabu Phase 7)', NULL, 'MESSUNG', DATE '2026-10-17', 'Kammlinie des Halbkreiswalls, Lücken im Süden und Westen, Kuppen der Grabhügel', 'MITGELIEFERT');
MERGE INTO HB_QUELLE t USING (SELECT 'MUSEUM_FOTOS' AS KURZ FROM DUAL) q ON (t.KURZ = q.KURZ)
WHEN MATCHED THEN UPDATE SET t.TITEL = 'Fotos der Museumshäuser (templates/Museumsdorf1–12.jpg)', t.URL = NULL, t.ART = 'DATEN', t.ABGERUFEN = DATE '2026-10-17', t.BEMERKUNG = 'Reet, Bohlen, Lehm, Höfe und Zäune des Wikinger Museums Haithabu, verglichen in Phase 5' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (KURZ, TITEL, URL, ART, ABGERUFEN, BEMERKUNG, HERKUNFT) VALUES ('MUSEUM_FOTOS', 'Fotos der Museumshäuser (templates/Museumsdorf1–12.jpg)', NULL, 'DATEN', DATE '2026-10-17', 'Reet, Bohlen, Lehm, Höfe und Zäune des Wikinger Museums Haithabu, verglichen in Phase 5', 'MITGELIEFERT');

-- --------------------------------------------------------------------------------------------- Befunde
MERGE INTO HB_BEFUND t USING (SELECT 'GELAENDE' AS THEMA, 'Lage und Noor' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Am Südwestende der Schlei am Haddebyer Noor, 54°29′28″ N, 9°33′55″ E; das Noor misst rund 1 km² (1,6 × 0,9 km).' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('GELAENDE', 'Lage und Noor', 'BELEGT', 'Am Südwestende der Schlei am Haddebyer Noor, 54°29′28″ N, 9°33′55″ E; das Noor misst rund 1 km² (1,6 × 0,9 km).', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'GELAENDE' AS THEMA, 'Höhen des Geländes' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GEMESSEN', t.TEXT = 'DGM1 Schleswig-Holstein, Ausschnitt 8 × 6 km; 76 % der Szene sind gemessen, der Rest ist Grund unter Wasser.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('GELAENDE', 'Höhen des Geländes', 'GEMESSEN', 'DGM1 Schleswig-Holstein, Ausschnitt 8 × 6 km; 76 % der Szene sind gemessen, der Rest ist Grund unter Wasser.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'GELAENDE' AS THEMA, 'Grund des Noors' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Unter Wasser modelliert, um 950 im Mittel 2,5 m tief (heute 3 m, höchstens 5,2 m).' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('GELAENDE', 'Grund des Noors', 'GESTALTET', 'Unter Wasser modelliert, um 950 im Mittel 2,5 m tief (heute 3 m, höchstens 5,2 m).', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'GELAENDE' AS THEMA, 'Uferlinie von 950' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Rund 1 m unter dem heutigen Wasserspiegel angenommen; die Uferlinie der Wikingerzeit liegt heute unter Wasser.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('GELAENDE', 'Uferlinie von 950', 'GESTALTET', 'Rund 1 m unter dem heutigen Wasserspiegel angenommen; die Uferlinie der Wikingerzeit liegt heute unter Wasser.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'GELAENDE' AS THEMA, 'Damm zwischen Noor und Schlei' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Der Damm von Straße und Bahn ist für 950 im Gelände entfernt, ebenso der Straßendamm zum Selker Noor (F23).' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('GELAENDE', 'Damm zwischen Noor und Schlei', 'GESTALTET', 'Der Damm von Straße und Bahn ist für 950 im Gelände entfernt, ebenso der Straßendamm zum Selker Noor (F23).', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'GELAENDE' AS THEMA, 'Haithabu-Bach' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Der Bach fließt von Westen durch die Mitte der Siedlung ins Noor; sein Lauf ist aus dem Gelände gefunden.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('GELAENDE', 'Haithabu-Bach', 'BELEGT', 'Der Bach fließt von Westen durch die Mitte der Siedlung ins Noor; sein Lauf ist aus dem Gelände gefunden.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'GELAENDE' AS THEMA, 'Wald und Felder' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Im Wall gerodet, Felder und Weiden bis gut 1 km vor dem Wall, das Gegenufer bewaldet mit einem Gehöft.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('GELAENDE', 'Wald und Felder', 'GESTALTET', 'Im Wall gerodet, Felder und Weiden bis gut 1 km vor dem Wall, das Gegenufer bewaldet mit einem Gehöft.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'WALL' AS THEMA, 'Kammlinie des Halbkreiswalls' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GEMESSEN', t.TEXT = 'Im DGM1 auf 1 402 m verfolgt, 86 % gemessen; Nordwestbogen und Enden am Ufer sind ergänzt.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('WALL', 'Kammlinie des Halbkreiswalls', 'GEMESSEN', 'Im DGM1 auf 1 402 m verfolgt, 86 % gemessen; Nordwestbogen und Enden am Ufer sind ergänzt.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'WALL' AS THEMA, 'Höhe und Fläche des Walls' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Nach 930 aufgeworfen, Mitte des 10. Jahrhunderts fertig, rund 9 m hoch mit Palisade, umschließt 26 ha.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('WALL', 'Höhe und Fläche des Walls', 'BELEGT', 'Nach 930 aufgeworfen, Mitte des 10. Jahrhunderts fertig, rund 9 m hoch mit Palisade, umschließt 26 ha.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'WALL' AS THEMA, 'Tore' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Tore nach Norden, Süden und Westen und der Durchlass des Bachs; die Lücken im Süden und Westen zeigt das DGM, die Torbauten sind gestaltet.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('WALL', 'Tore', 'GESTALTET', 'Tore nach Norden, Süden und Westen und der Durchlass des Bachs; die Lücken im Süden und Westen zeigt das DGM, die Torbauten sind gestaltet.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'WALL' AS THEMA, 'Graben, Palisade, Wehrgang' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Graben 2 m tief vor dem Wall, Palisade 3 m hoch, Wehrgang dahinter.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('WALL', 'Graben, Palisade, Wehrgang', 'GESTALTET', 'Graben 2 m tief vor dem Wall, Palisade 3 m hoch, Wehrgang dahinter.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'WALL' AS THEMA, 'Hochburg' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Auf einer Moränenkuppe von rund 25 m nördlich des Walls, innen 240 × 60–80 m, Tor im Nordosten; Lage und Wall im Einzelnen gestaltet.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('WALL', 'Hochburg', 'BELEGT', 'Auf einer Moränenkuppe von rund 25 m nördlich des Walls, innen 240 × 60–80 m, Tor im Nordosten; Lage und Wall im Einzelnen gestaltet.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'WALL' AS THEMA, 'Grabhügel der Hochburg' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GEMESSEN', t.TEXT = 'Über 70 Grabhügel sind belegt; 80 Kuppen findet das DGM, ihre Höhen um 950 sind gestaltet.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('WALL', 'Grabhügel der Hochburg', 'GEMESSEN', 'Über 70 Grabhügel sind belegt; 80 Kuppen findet das DGM, ihre Höhen um 950 sind gestaltet.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'WALL' AS THEMA, 'Verbindungswall' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Der Verbindungswall zum Danewerk entstand um 968 und stand um 950 noch nicht; im Gelände eingeebnet (F24).' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('WALL', 'Verbindungswall', 'BELEGT', 'Der Verbindungswall zum Danewerk entstand um 968 und stand um 950 noch nicht; im Gelände eingeebnet (F24).', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'SIEDLUNG' AS THEMA, 'Hausmaße' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Grundflächen von 3,5 × 17 m bis 7 × 17,5 m.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('SIEDLUNG', 'Hausmaße', 'BELEGT', 'Grundflächen von 3,5 × 17 m bis 7 × 17,5 m.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'SIEDLUNG' AS THEMA, 'Bauweisen' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Wände aus Spaltbohlen oder lehmverputztem Flechtwerk zwischen Wandständern, Dächer aus Reet oder Stroh.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('SIEDLUNG', 'Bauweisen', 'BELEGT', 'Wände aus Spaltbohlen oder lehmverputztem Flechtwerk zwischen Wandständern, Dächer aus Reet oder Stroh.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'SIEDLUNG' AS THEMA, 'Hallenhaus' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Wie das Versammlungshaus des Museums: 17,5 × 7 m, Flechtwerk, Schrägstützen, zwei Türen.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('SIEDLUNG', 'Hallenhaus', 'GESTALTET', 'Wie das Versammlungshaus des Museums: 17,5 × 7 m, Flechtwerk, Schrägstützen, zwei Türen.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'SIEDLUNG' AS THEMA, 'Wohnhaus' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Wie Haus 1 des Museums (um 870): 12 × 5 m, drei Räume, Flechtwerk.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('SIEDLUNG', 'Wohnhaus', 'GESTALTET', 'Wie Haus 1 des Museums (um 870): 12 × 5 m, drei Räume, Flechtwerk.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'SIEDLUNG' AS THEMA, 'Spaltbohlenhaus' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Haus eines Händlers, 9 × 4,5 m, senkrechte Bohlen auf der Schwelle.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('SIEDLUNG', 'Spaltbohlenhaus', 'GESTALTET', 'Haus eines Händlers, 9 × 4,5 m, senkrechte Bohlen auf der Schwelle.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'SIEDLUNG' AS THEMA, 'Uferhaus' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Am Ufer standen leichte Holzhäuser, weil das Wasser stieg; Maße 17 × 3,5 m gestaltet.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('SIEDLUNG', 'Uferhaus', 'BELEGT', 'Am Ufer standen leichte Holzhäuser, weil das Wasser stieg; Maße 17 × 3,5 m gestaltet.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'SIEDLUNG' AS THEMA, 'Grubenhaus' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Höher am Hang lagen eingetiefte Grubenhäuser; Maße 4 × 3 m, 0,7 m tief, gestaltet.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('SIEDLUNG', 'Grubenhaus', 'BELEGT', 'Höher am Hang lagen eingetiefte Grubenhäuser; Maße 4 × 3 m, 0,7 m tief, gestaltet.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'SIEDLUNG' AS THEMA, 'Werkstattschuppen' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Offene Schuppen der Gewerke, 6 × 4 m, mit Rückwand aus Flechtwerk.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('SIEDLUNG', 'Werkstattschuppen', 'GESTALTET', 'Offene Schuppen der Gewerke, 6 × 4 m, mit Rückwand aus Flechtwerk.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'SIEDLUNG' AS THEMA, 'Die sieben Museumshäuser' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Seit 2008 hat das Museum sieben Häuser rekonstruiert, darunter Versammlungshaus, Herberge, Kammmacher, Fischer und Tuchhändler; ihre Stellung am Bach ist gestaltet.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('SIEDLUNG', 'Die sieben Museumshäuser', 'BELEGT', 'Seit 2008 hat das Museum sieben Häuser rekonstruiert, darunter Versammlungshaus, Herberge, Kammmacher, Fischer und Tuchhändler; ihre Stellung am Bach ist gestaltet.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'SIEDLUNG' AS THEMA, 'Zahl und Anordnung der Häuser' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Aus Startwert, sechs Haustypen und einer Parzellenlogik erzeugt; rund 95 % der Siedlung sind nie ausgegraben.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('SIEDLUNG', 'Zahl und Anordnung der Häuser', 'GESTALTET', 'Aus Startwert, sechs Haustypen und einer Parzellenlogik erzeugt; rund 95 % der Siedlung sind nie ausgegraben.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'SIEDLUNG' AS THEMA, 'Feuergewerbe abseits' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Schmiede, Glasmacher und Bronzegießer arbeiteten abseits; in der Szene im Nordwesten.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('SIEDLUNG', 'Feuergewerbe abseits', 'BELEGT', 'Schmiede, Glasmacher und Bronzegießer arbeiteten abseits; in der Szene im Nordwesten.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'SIEDLUNG' AS THEMA, 'Bohlenwege und Zäune' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Am Bach liegt die älteste Bebauung mit Bohlenwegen und Zäunen; die Gassen der übrigen Siedlung sind gestaltet.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('SIEDLUNG', 'Bohlenwege und Zäune', 'BELEGT', 'Am Bach liegt die älteste Bebauung mit Bohlenwegen und Zäunen; die Gassen der übrigen Siedlung sind gestaltet.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'SIEDLUNG' AS THEMA, 'Einwohner' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = '1 500 bis 2 000 Menschen in der Blütezeit; die Szene zeigt keine Figuren (F9).' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('SIEDLUNG', 'Einwohner', 'BELEGT', '1 500 bis 2 000 Menschen in der Blütezeit; die Szene zeigt keine Figuren (F9).', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'HAFEN' AS THEMA, 'Landebrücken und Plattformen' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Ab den 860ern große Pfahlbrücken, um 900 zu Plattformen entlang der ganzen Uferlinie ausgebaut; Breiten und Pfahlraster gestaltet.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('HAFEN', 'Landebrücken und Plattformen', 'BELEGT', 'Ab den 860ern große Pfahlbrücken, um 900 zu Plattformen entlang der ganzen Uferlinie ausgebaut; Breiten und Pfahlraster gestaltet.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'HAFEN' AS THEMA, 'Hafenpalisade' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Das Hafenbecken von 8 bis 11 ha war von einer Palisade im Wasser gefasst, Reste 1949 und 1953 gefunden.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('HAFEN', 'Hafenpalisade', 'BELEGT', 'Das Hafenbecken von 8 bis 11 ha war von einer Palisade im Wasser gefasst, Reste 1949 und 1953 gefunden.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'HAFEN' AS THEMA, 'Durchfahrt' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Eine Durchfahrt von 14 m nach Nordost.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('HAFEN', 'Durchfahrt', 'GESTALTET', 'Eine Durchfahrt von 14 m nach Nordost.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'HAFEN' AS THEMA, 'Tiefgang an den Brücken' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Schiffe mit 1,3 bis 1,5 m Tiefgang konnten anlegen; die Brücken reichen bis 1,9 m Wassertiefe.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('HAFEN', 'Tiefgang an den Brücken', 'BELEGT', 'Schiffe mit 1,3 bis 1,5 m Tiefgang konnten anlegen; die Brücken reichen bis 1,9 m Wassertiefe.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'HAFEN' AS THEMA, 'Waren' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Fässer, Ballen, Mühlsteine aus Basalt und Specksteintöpfe aus der Fundliste; Menge und Lage gestaltet.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('HAFEN', 'Waren', 'BELEGT', 'Fässer, Ballen, Mühlsteine aus Basalt und Specksteintöpfe aus der Fundliste; Menge und Lage gestaltet.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'SCHIFFE' AS THEMA, 'Haithabu 1' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Königliches Langschiff, 30,9 × 2,7 m, 31 Riemenpaare, um 985 gebaut, jünger als 950.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('SCHIFFE', 'Haithabu 1', 'BELEGT', 'Königliches Langschiff, 30,9 × 2,7 m, 31 Riemenpaare, um 985 gebaut, jünger als 950.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'SCHIFFE' AS THEMA, 'Knorr' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Handelsschiff nach Haithabu 3 (um 1023), Maße rund 22 × 6 m nach der Literatur.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('SCHIFFE', 'Knorr', 'GESTALTET', 'Handelsschiff nach Haithabu 3 (um 1023), Maße rund 22 × 6 m nach der Literatur.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'SCHIFFE' AS THEMA, 'Faering' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Kleines Ruderboot für Fischer und Fähre.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('SCHIFFE', 'Faering', 'GESTALTET', 'Kleines Ruderboot für Fischer und Fähre.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'SCHIFFE' AS THEMA, 'Bemalung, Segel, Schilde' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Farben, Segel, Schilde und Takelung.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('SCHIFFE', 'Bemalung, Segel, Schilde', 'GESTALTET', 'Farben, Segel, Schilde und Takelung.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'LEBEN' AS THEMA, 'Rauch aus Reetdächern' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Herdfeuer unter Rauchlöchern in Reetdächern; Tagesgang und Menge gestaltet.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('LEBEN', 'Rauch aus Reetdächern', 'BELEGT', 'Herdfeuer unter Rauchlöchern in Reetdächern; Tagesgang und Menge gestaltet.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'LEBEN' AS THEMA, 'Rauch im Haus' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Zwei-Zonen-Modell und Fahne nach Heskestad, Werte für das offene Herdfeuer gewählt.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('LEBEN', 'Rauch im Haus', 'GESTALTET', 'Zwei-Zonen-Modell und Fahne nach Heskestad, Werte für das offene Herdfeuer gewählt.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'LEBEN' AS THEMA, 'Tiere' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Möwen, Krähen, Wasservögel, Hühner, Ziegen, Schweine und Hunde; Zahl und Verhalten gestaltet.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('LEBEN', 'Tiere', 'GESTALTET', 'Möwen, Krähen, Wasservögel, Hühner, Ziegen, Schweine und Hunde; Zahl und Verhalten gestaltet.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'LEBEN' AS THEMA, 'Klang' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Alles erzeugt, ohne Aufnahmen.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('LEBEN', 'Klang', 'GESTALTET', 'Alles erzeugt, ohne Aufnahmen.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'REGIE' AS THEMA, 'Der Brand von 1050' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Harald Hardrada brannte Haithabu 1050 nieder; 1066 plünderten Westslawen die Siedlung.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('REGIE', 'Der Brand von 1050', 'BELEGT', 'Harald Hardrada brannte Haithabu 1050 nieder; 1066 plünderten Westslawen die Siedlung.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'REGIE' AS THEMA, 'Brander im Hafen' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'BELEGT', t.TEXT = 'Haithabu 1 wurde zwischen 990 und 1010 als Brander gegen den Hafen eingesetzt.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('REGIE', 'Brander im Hafen', 'BELEGT', 'Haithabu 1 wurde zwischen 990 und 1010 als Brander gegen den Hafen eingesetzt.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'REGIE' AS THEMA, 'Abläufe der Regiebücher' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Zeiten, Wetter, Blickpunkte und die Ausbreitung des Feuers in den drei Regiebüchern.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('REGIE', 'Abläufe der Regiebücher', 'GESTALTET', 'Zeiten, Wetter, Blickpunkte und die Ausbreitung des Feuers in den drei Regiebüchern.', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'REGIE' AS THEMA, 'Kalender' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Gregorianisch zurückgerechnet wie java.time, MEZ ohne Sommerzeit (F21).' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('REGIE', 'Kalender', 'GESTALTET', 'Gregorianisch zurückgerechnet wie java.time, MEZ ohne Sommerzeit (F21).', 'MITGELIEFERT');
MERGE INTO HB_BEFUND t USING (SELECT 'REGIE' AS THEMA, 'Startdatum der Szene' AS GEGENSTAND FROM DUAL) q ON (t.THEMA = q.THEMA AND t.GEGENSTAND = q.GEGENSTAND)
WHEN MATCHED THEN UPDATE SET t.BEFUND = 'GESTALTET', t.TEXT = 'Die Szene beginnt am 16. Oktober 950 um 17:30 Uhr.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (THEMA, GEGENSTAND, BEFUND, TEXT, HERKUNFT) VALUES ('REGIE', 'Startdatum der Szene', 'GESTALTET', 'Die Szene beginnt am 16. Oktober 950 um 17:30 Uhr.', 'MITGELIEFERT');
DELETE FROM HB_BEFUND_QUELLE WHERE BEFUND_ID IN (SELECT ID FROM HB_BEFUND WHERE HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Lage und Noor' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'WIKI_HAITHABU';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Lage und Noor' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'KULADIG_HAITHABU';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Lage und Noor' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'WIKI_NOOR';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Höhen des Geländes' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'DGM1_SH';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Grund des Noors' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'WIKI_NOOR';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Uferlinie von 950' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'WIKI_NOOR';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Uferlinie von 950' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'MASS_HEDEBY';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Damm zwischen Noor und Schlei' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'DGM1_SH';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Haithabu-Bach' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'WIKI_HAITHABU';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Haithabu-Bach' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'DGM1_SH';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Kammlinie des Halbkreiswalls' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'MESSUNG_P7';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Kammlinie des Halbkreiswalls' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'DGM1_SH';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Höhe und Fläche des Walls' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'WIKI_HAITHABU';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Tore' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'MESSUNG_P7';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Hochburg' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'KULADIG_HOCHBURG';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Grabhügel der Hochburg' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'KULADIG_HOCHBURG';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Grabhügel der Hochburg' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'MESSUNG_P7';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Verbindungswall' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'WIKI_HAITHABU';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Hausmaße' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'WIKI_HAITHABU';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Bauweisen' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'WIKI_HAITHABU';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Bauweisen' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'PLANET_WISSEN';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Hallenhaus' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'DAMALS';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Hallenhaus' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'MUSEUM_FOTOS';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Wohnhaus' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'DAMALS';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Wohnhaus' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'MUSEUM_FOTOS';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Uferhaus' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'PLANET_WISSEN';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Grubenhaus' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'PLANET_WISSEN';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Die sieben Museumshäuser' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'KULADIG_HAITHABU';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Die sieben Museumshäuser' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'DAMALS';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Die sieben Museumshäuser' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'MUSEUM_FOTOS';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Zahl und Anordnung der Häuser' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'PLANET_WISSEN';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Feuergewerbe abseits' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'PLANET_WISSEN';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Bohlenwege und Zäune' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'WIKI_HAITHABU';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Einwohner' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'WIKI_HAITHABU';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Einwohner' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'PLANET_WISSEN';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Landebrücken und Plattformen' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'KULADIG_HAITHABU';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Landebrücken und Plattformen' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'MASS_HEDEBY';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Hafenpalisade' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'WIKI_HAITHABU';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Hafenpalisade' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'MASS_HEDEBY';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Tiefgang an den Brücken' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'MASS_HEDEBY';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Waren' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'PLANET_WISSEN';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Haithabu 1' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'WIKI_HEDEBY1';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Haithabu 1' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'MASS_HEDEBY';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Knorr' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'MASS_HEDEBY';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Rauch aus Reetdächern' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'PLANET_WISSEN';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Rauch im Haus' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'HESKESTAD';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Der Brand von 1050' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'WIKI_HAITHABU';
INSERT INTO HB_BEFUND_QUELLE (BEFUND_ID, QUELLE_ID) SELECT b.ID, q.ID FROM HB_BEFUND b, HB_QUELLE q WHERE b.GEGENSTAND = 'Brander im Hafen' AND b.HERKUNFT = 'MITGELIEFERT' AND q.KURZ = 'WIKI_HEDEBY1';

-- ------------------------------------------------------------------------------------------- Haustypen
MERGE INTO HB_HAUSTYP t USING (SELECT 'HALLE' AS NAME, (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Hallenhaus') AS BID FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEZEICHNUNG = 'Hallenhaus', t.LAENGE_M = 17.5, t.BREITE_M = 7, t.WANDHOEHE_M = 2.3, t.DACHNEIGUNG_GRAD = 48, t.WAND = 'DAUB', t.EINGETIEFT_M = 0, t.BEFUND = 'GESTALTET', t.BEFUND_ID = q.BID, t.BESCHREIBUNG = 'Wie das Versammlungshaus des Museums: 17,5 × 7 m, Flechtwerk, Schrägstützen, zwei Türen.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEZEICHNUNG, LAENGE_M, BREITE_M, WANDHOEHE_M, DACHNEIGUNG_GRAD, WAND, EINGETIEFT_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  VALUES ('HALLE', 'Hallenhaus', 17.5, 7, 2.3, 48, 'DAUB', 0, 'GESTALTET', q.BID, 'Wie das Versammlungshaus des Museums: 17,5 × 7 m, Flechtwerk, Schrägstützen, zwei Türen.', 'MITGELIEFERT');
MERGE INTO HB_HAUSTYP t USING (SELECT 'WOHNHAUS' AS NAME, (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Wohnhaus') AS BID FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEZEICHNUNG = 'Wohnhaus', t.LAENGE_M = 12, t.BREITE_M = 5, t.WANDHOEHE_M = 2, t.DACHNEIGUNG_GRAD = 47, t.WAND = 'DAUB', t.EINGETIEFT_M = 0, t.BEFUND = 'GESTALTET', t.BEFUND_ID = q.BID, t.BESCHREIBUNG = 'Wie Haus 1 des Museums (um 870): 12 × 5 m, drei Räume, Flechtwerk.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEZEICHNUNG, LAENGE_M, BREITE_M, WANDHOEHE_M, DACHNEIGUNG_GRAD, WAND, EINGETIEFT_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  VALUES ('WOHNHAUS', 'Wohnhaus', 12, 5, 2, 47, 'DAUB', 0, 'GESTALTET', q.BID, 'Wie Haus 1 des Museums (um 870): 12 × 5 m, drei Räume, Flechtwerk.', 'MITGELIEFERT');
MERGE INTO HB_HAUSTYP t USING (SELECT 'BOHLENHAUS' AS NAME, (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Spaltbohlenhaus') AS BID FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEZEICHNUNG = 'Spaltbohlenhaus', t.LAENGE_M = 9, t.BREITE_M = 4.5, t.WANDHOEHE_M = 2.1, t.DACHNEIGUNG_GRAD = 45, t.WAND = 'PLANK', t.EINGETIEFT_M = 0, t.BEFUND = 'GESTALTET', t.BEFUND_ID = q.BID, t.BESCHREIBUNG = 'Haus eines Händlers, 9 × 4,5 m, senkrechte Bohlen auf der Schwelle.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEZEICHNUNG, LAENGE_M, BREITE_M, WANDHOEHE_M, DACHNEIGUNG_GRAD, WAND, EINGETIEFT_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  VALUES ('BOHLENHAUS', 'Spaltbohlenhaus', 9, 4.5, 2.1, 45, 'PLANK', 0, 'GESTALTET', q.BID, 'Haus eines Händlers, 9 × 4,5 m, senkrechte Bohlen auf der Schwelle.', 'MITGELIEFERT');
MERGE INTO HB_HAUSTYP t USING (SELECT 'UFERHAUS' AS NAME, (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Uferhaus') AS BID FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEZEICHNUNG = 'Uferhaus', t.LAENGE_M = 17, t.BREITE_M = 3.5, t.WANDHOEHE_M = 1.9, t.DACHNEIGUNG_GRAD = 50, t.WAND = 'PLANK', t.EINGETIEFT_M = 0, t.BEFUND = 'BELEGT', t.BEFUND_ID = q.BID, t.BESCHREIBUNG = 'Am Ufer standen leichte Holzhäuser, weil das Wasser stieg; Maße 17 × 3,5 m gestaltet.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEZEICHNUNG, LAENGE_M, BREITE_M, WANDHOEHE_M, DACHNEIGUNG_GRAD, WAND, EINGETIEFT_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  VALUES ('UFERHAUS', 'Uferhaus', 17, 3.5, 1.9, 50, 'PLANK', 0, 'BELEGT', q.BID, 'Am Ufer standen leichte Holzhäuser, weil das Wasser stieg; Maße 17 × 3,5 m gestaltet.', 'MITGELIEFERT');
MERGE INTO HB_HAUSTYP t USING (SELECT 'GRUBENHAUS' AS NAME, (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grubenhaus') AS BID FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEZEICHNUNG = 'Grubenhaus', t.LAENGE_M = 4, t.BREITE_M = 3, t.WANDHOEHE_M = 0.35, t.DACHNEIGUNG_GRAD = 52, t.WAND = 'PLANK', t.EINGETIEFT_M = 0.7, t.BEFUND = 'BELEGT', t.BEFUND_ID = q.BID, t.BESCHREIBUNG = 'Höher am Hang lagen eingetiefte Grubenhäuser; Maße 4 × 3 m, 0,7 m tief, gestaltet.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEZEICHNUNG, LAENGE_M, BREITE_M, WANDHOEHE_M, DACHNEIGUNG_GRAD, WAND, EINGETIEFT_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  VALUES ('GRUBENHAUS', 'Grubenhaus', 4, 3, 0.35, 52, 'PLANK', 0.7, 'BELEGT', q.BID, 'Höher am Hang lagen eingetiefte Grubenhäuser; Maße 4 × 3 m, 0,7 m tief, gestaltet.', 'MITGELIEFERT');
MERGE INTO HB_HAUSTYP t USING (SELECT 'SCHUPPEN' AS NAME, (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Werkstattschuppen') AS BID FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEZEICHNUNG = 'Werkstattschuppen', t.LAENGE_M = 6, t.BREITE_M = 4, t.WANDHOEHE_M = 2, t.DACHNEIGUNG_GRAD = 40, t.WAND = 'WATTLE', t.EINGETIEFT_M = 0, t.BEFUND = 'GESTALTET', t.BEFUND_ID = q.BID, t.BESCHREIBUNG = 'Offene Schuppen der Gewerke, 6 × 4 m, mit Rückwand aus Flechtwerk.' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEZEICHNUNG, LAENGE_M, BREITE_M, WANDHOEHE_M, DACHNEIGUNG_GRAD, WAND, EINGETIEFT_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  VALUES ('SCHUPPEN', 'Werkstattschuppen', 6, 4, 2, 40, 'WATTLE', 0, 'GESTALTET', q.BID, 'Offene Schuppen der Gewerke, 6 × 4 m, mit Rückwand aus Flechtwerk.', 'MITGELIEFERT');

-- ----------------------------------------------------------------------------- Siedlung „Haithabu 950“
MERGE INTO HB_SIEDLUNG t USING (SELECT 'Haithabu 950' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.STARTWERT = 950, t.HAEUSER = 540, t.BESCHREIBUNG = 'Die Siedlung aus dem Startwert 950 mit den sieben Häusern am Bach (Phasen 5 bis 7)' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, STARTWERT, AKTIV, HAEUSER, BESCHREIBUNG, HERKUNFT) VALUES ('Haithabu 950', 950, 0, 540, 'Die Siedlung aus dem Startwert 950 mit den sieben Häusern am Bach (Phasen 5 bis 7)', 'MITGELIEFERT');
UPDATE HB_SIEDLUNG SET AKTIV = 1 WHERE NAME = 'Haithabu 950' AND NOT EXISTS (SELECT 1 FROM HB_SIEDLUNG WHERE AKTIV = 1);
DELETE FROM HB_HAUS WHERE SIEDLUNG_ID IN (SELECT ID FROM HB_SIEDLUNG WHERE NAME = 'Haithabu 950' AND HERKUNFT = 'MITGELIEFERT');
DELETE FROM HB_WEG WHERE SIEDLUNG_ID IN (SELECT ID FROM HB_SIEDLUNG WHERE NAME = 'Haithabu 950' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 1, 'Versammlungshaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'HALLE'), 'Versammlungshaus des Museums, größtes Haus am Bach',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567858, 54.491254, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5678114 54.491175, 9.5679043 54.491175, 9.5679043 54.4913322, 9.5678114 54.4913322, 9.5678114 54.491175))', 8307),
    -120, -21.473, 3.3, 0, 1, 0.86, 0.8, -3721, 1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 2, 'Herberge', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Gästehaus für Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568275, 54.491259, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.568236 54.4912024, 9.5683131 54.4912024, 9.5683131 54.4913156, 9.568236 54.4913156, 9.568236 54.4912024))', 8307),
    -93, -22.072, 3.14, 0, 1.05, 1, 0.7, -2884, 1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 3, 'Haus des Kammmachers', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Werkstatt für Kämme aus Geweih',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56866, 54.491253, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5686248 54.4912072, 9.5686958 54.4912072, 9.5686958 54.4912989, 9.5686248 54.4912989, 9.5686248 54.4912072))', 8307),
    -68, -21.412, 3.16, 0, 0.85, 0.92, 0.85, -2109, 1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 4, 'Wohnhaus am Hang', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus aus Spaltbohlen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567457, 54.491216, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5674219 54.4911758, 9.5674914 54.4911758, 9.5674914 54.4912567, 9.5674219 54.4912567, 9.5674219 54.4911758))', 8307),
    -146, -17.316, 4.12, 0, 1, 1, 0.6, -4527, 1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 5, 'Haus des Tuchhändlers', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Händler für Tuch und Wolle',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567966, 54.490913, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5679273 54.4908522, 9.5680045 54.4908522, 9.5680045 54.4909729, 9.5679273 54.4909729, 9.5679273 54.4908522))', 8307),
    -113, 16.487, 3, 0, 1.12, 1, 0.75, -3502, 1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 6, 'Wohnhaus am Bach', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus nach Haus 1 (um 870)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568383, 54.490952, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5683459 54.490902, 9.5684192 54.490902, 9.5684192 54.4910012, 9.5683459 54.4910012, 9.5683459 54.490902))', 8307),
    -86, 12.148, 2.78, 0, 0.92, 0.95, 0.95, -2665, 1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 7, 'Haus des Fischers', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Fischer am Strand',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568846, 54.490908, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5688108 54.4908693, 9.5688802 54.4908693, 9.5688802 54.4909461, 9.5688108 54.4909461, 9.5688108 54.4908693))', 8307),
    -56, 17.034, 1.97, 0, 0.95, 1, 0.9, -1735, 1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 8, 'Werkstatt des Kammmachers', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'offener Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568676, 54.491348, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5686341 54.4913644, 9.5686341 54.4913321, 9.5687174 54.4913321, 9.5687174 54.4913644, 9.5686341 54.4913644))', 8307),
    -67, -32.012, 3.16, 90, 0.9, 0.9, 0.75, 51, 1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 9, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561405, 54.491323, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5613925 54.4912742, 9.5614676 54.49129, 9.561417 54.4913717, 9.5613418 54.4913559, 9.5613925 54.4912742))', 8307),
    -538.171, -29.223, 13.83, -19.86, 1.073, 1.15, 0.63, -1493426009424763823, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 10, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561486, 54.491175, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5615 54.4911986, 9.5614497 54.4911883, 9.561472 54.4911515, 9.5615222 54.4911618, 9.5615 54.4911986))', 8307),
    -532.91, -12.759, 12.25, 160.65, 1.086, 1.15, 0.57, -8832192811955809969, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 11, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561579, 54.491314, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5615653 54.4912904, 9.5616154 54.4913009, 9.5615928 54.4913374, 9.5615427 54.4913269, 9.5615653 54.4912904))', 8307),
    -526.876, -28.211, 13.3, -19.76, 1.08, 1.15, 0.909, 8776500141360244417, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 12, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561808, 54.491367, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5617931 54.4913453, 9.5618434 54.4913554, 9.5618236 54.4913889, 9.5617733 54.4913788, 9.5617931 54.4913453))', 8307),
    -512.016, -34.139, 13.54, -19.01, 0.986, 1.15, 0.706, 9156892566458563109, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 13, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561887, 54.491234, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5619061 54.491288, 9.5618208 54.4912739, 9.5618671 54.491179, 9.5619524 54.4911931, 9.5619061 54.491288))', 8307),
    -506.947, -19.264, 12.32, 164.15, 0.915, 1.15, 0.475, -4017711182926717938, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 14, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562155, 54.491469, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5621509 54.4914471, 9.5621919 54.4914668, 9.5621584 54.4914904, 9.5621174 54.4914706, 9.5621509 54.4914471))', 8307),
    -489.575, -45.445, 13.13, -39.59, 0.85, 1.15, 0.565, 181874857542493932, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 15, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562303, 54.491534, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5623047 54.4915106, 9.5623425 54.4915324, 9.5623016 54.4915565, 9.5622638 54.4915347, 9.5623047 54.4915106))', 8307),
    -479.951, -52.658, 12.92, -44.72, 0.942, 1.15, 0.674, 2263692652473661937, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 16, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562621, 54.491521, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5626014 54.4915618, 9.5625495 54.4915265, 9.5626413 54.4914806, 9.5626933 54.4915159, 9.5626014 54.4915618))', 8307),
    -459.329, -51.282, 10.69, 130.6, 0.871, 1.15, 0.588, 8956018003928550111, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 17, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562707, 54.491748, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5626989 54.4917265, 9.5627436 54.4917434, 9.5627143 54.4917696, 9.5626697 54.4917527, 9.5626989 54.4917265))', 8307),
    -453.803, -76.539, 12.46, -33.03, 0.87, 1.15, 0.796, 4142586180383792305, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 18, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563009, 54.491875, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5630065 54.4918524, 9.5630485 54.4918715, 9.5630123 54.4918985, 9.5629703 54.4918794, 9.5630065 54.4918524))', 8307),
    -434.179, -90.713, 11.69, -37.93, 0.954, 1.15, 0.931, 3836765498075964926, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 19, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563227, 54.491991, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5632285 54.4919357, 9.5633063 54.4919606, 9.5632257 54.4920459, 9.563148 54.492021, 9.5632285 54.4919357))', 8307),
    -420.071, -103.554, 11.48, -28.79, 0.903, 1.15, 0.803, 1216281171465707046, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 20, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563146, 54.492065, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.563112 54.4920675, 9.5631321 54.4920462, 9.5631808 54.4920618, 9.5631607 54.4920831, 9.563112 54.4920675))', 8307),
    -425.301, -111.772, 12.09, 61.21, 0.9, 0.9, 0.803, 3842000638160231810, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 21, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563368, 54.491856, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.563373 54.4918793, 9.5633296 54.4918613, 9.5633638 54.4918333, 9.5634072 54.4918513, 9.563373 54.4918793))', 8307),
    -410.918, -88.579, 9.88, 144.64, 0.955, 1.15, 0.947, -7809601767873397684, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 22, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563741, 54.492096, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5637195 54.4920777, 9.563772 54.492083, 9.5637624 54.4921152, 9.5637099 54.4921099, 9.5637195 54.4920777))', 8307),
    -386.776, -115.309, 10.46, -9.83, 0.91, 1.15, 0.69, -4307597630542078448, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 23, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563804, 54.491941, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5638324 54.4919967, 9.5637449 54.4919879, 9.5637755 54.4918847, 9.563863 54.4918935, 9.5638324 54.4919967))', 8307),
    -382.695, -97.97, 9.11, 170.21, 0.972, 1.15, 0.513, -5830527755415699744, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 24, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563919, 54.492136, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5638804 54.4920877, 9.5639557 54.4920871, 9.563958 54.4921845, 9.5638827 54.4921851, 9.5638804 54.4920877))', 8307),
    -375.224, -119.722, 10.07, 0.81, 0.903, 0.976, 0.793, -3385698716447939331, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 25, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564209, 54.492071, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5641714 54.492069, 9.5642131 54.4920497, 9.5642458 54.4920737, 9.5642041 54.492093, 9.5641714 54.492069))', 8307),
    -356.471, -112.514, 8.53, 38.43, 0.853, 1.15, 0.451, -4727438246949654088, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 26, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564066, 54.491952, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5641466 54.4919771, 9.564072 54.492005, 9.5639862 54.4919275, 9.5640609 54.4918995, 9.5641466 54.4919771))', 8307),
    -365.685, -99.259, 8.47, -147.22, 0.855, 1.15, 0.855, 4673972625769997409, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 27, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56396, 54.491887, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5639718 54.4918678, 9.5639943 54.4918882, 9.5639476 54.4919057, 9.563925 54.4918853, 9.5639718 54.4918678))', 8307),
    -372.603, -91.965, 8.21, -57.22, 0.9, 0.9, 0.855, 29356170134868015, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 28, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564453, 54.492023, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5643583 54.4919883, 9.5644169 54.4919616, 9.5645477 54.4920585, 9.5644891 54.4920853, 9.5643583 54.4919883))', 8307),
    -340.635, -107.177, 7.98, 38.13, 1.143, 0.966, 0.585, 2907360058521551072, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 29, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564208, 54.491863, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5642981 54.4918934, 9.56424 54.4919206, 9.5641186 54.4918327, 9.5641766 54.4918055, 9.5642981 54.4918934))', 8307),
    -356.49, -89.329, 7.75, -141.19, 1.047, 0.966, 0.485, 4333432423613827739, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 30, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564899, 54.492054, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5648408 54.4920253, 9.5649166 54.4920106, 9.564958 54.4920833, 9.5648822 54.492098, 9.5648408 54.4920253))', 8307),
    -311.705, -110.613, 6.88, 18.35, 0.947, 1.15, 0.85, 3795338703803608086, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 31, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565257, 54.491893, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651456 54.4918782, 9.5651976 54.4918363, 9.5653682 54.4919081, 9.5653162 54.4919499, 9.5651456 54.4918782))', 8307),
    -288.543, -92.67, 6.39, 54.16, 1.137, 1.15, 0.808, -7609310619393851821, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 32, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565004, 54.49179, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5650475 54.4917893, 9.565016 54.4918143, 9.5649598 54.4917903, 9.5649913 54.4917653, 9.5650475 54.4917893))', 8307),
    -304.955, -81.168, 6.79, -126.29, 1.13, 1.15, 0.775, 2076509571874621582, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 33, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56556, 54.491608, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5655976 54.4916092, 9.5655579 54.4916298, 9.5655223 54.4916067, 9.565562 54.491586, 9.5655976 54.4916092))', 8307),
    -268.907, -60.924, 6.2, -138.22, 0.864, 1.15, 0.601, -3508514500908920584, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 34, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56572, 54.491503, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5657939 54.4915458, 9.5657106 54.4915635, 9.5656459 54.4914607, 9.5657292 54.4914429, 9.5657939 54.4915458))', 8307),
    -258.543, -49.265, 5.97, -159.89, 1.016, 1.15, 0.666, -3674892444103724280, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 35, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56564, 54.491416, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5656688 54.4914269, 9.5656297 54.4914352, 9.5656106 54.4914049, 9.5656497 54.4913965, 9.5656688 54.4914269))', 8307),
    -263.74, -39.544, 5.9, -159.89, 0.9, 0.9, 0.666, 9062773480523893181, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 36, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566015, 54.49166, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5659715 54.491606, 9.5660583 54.4916061, 9.5660579 54.491714, 9.5659711 54.4917139, 9.5659715 54.491606))', 8307),
    -239.439, -66.714, 5.84, -0.12, 1.001, 1.125, 0.722, 5906932546348232184, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 37, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565998, 54.491466, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5660461 54.4915222, 9.5659594 54.4915246, 9.56595 54.4914094, 9.5660367 54.491407, 9.5660461 54.4915222))', 8307),
    -240.516, -45.098, 5.59, -177.28, 1.069, 1.125, 0.709, -6188698825141852773, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 38, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566, 54.491359, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.56604 54.4913412, 9.5660427 54.4913735, 9.5659594 54.4913759, 9.5659568 54.4913435, 9.56604 54.4913412))', 8307),
    -240.409, -33.161, 5.33, -87.28, 0.9, 0.9, 0.709, -1610220814512666456, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 39, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566372, 54.491665, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5663385 54.4916124, 9.5664265 54.4916188, 9.5664049 54.4917184, 9.5663169 54.491712, 9.5663385 54.4916124))', 8307),
    -216.305, -67.318, 5.36, -7.18, 0.931, 1.15, 0.673, 1359051131773385897, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 40, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566352, 54.491758, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5663351 54.4917403, 9.5663765 54.4917433, 9.5663695 54.4917754, 9.5663282 54.4917724, 9.5663351 54.4917403))', 8307),
    -217.559, -77.61, 5.33, -7.18, 0.9, 0.9, 0.673, -3428314825141712953, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 41, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56641, 54.491475, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5664432 54.4915241, 9.5663553 54.4915171, 9.5663768 54.4914255, 9.5664647 54.4914326, 9.5664432 54.4915241))', 8307),
    -213.823, -46.101, 4.9, 172.2, 0.857, 1.15, 0.886, 9011018838612000480, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 42, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566455, 54.491387, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5664853 54.4913771, 9.5664796 54.4914011, 9.5664246 54.4913967, 9.5664302 54.4913727, 9.5664853 54.4913771))', 8307),
    -210.914, -36.318, 4.65, 262.2, 0.9, 0.9, 0.886, 1363102936570601034, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 43, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566701, 54.491616, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5666277 54.491602, 9.5666885 54.4915719, 9.5667738 54.4916303, 9.5667129 54.4916604, 9.5666277 54.491602))', 8307),
    -194.983, -61.834, 4.56, 40.38, 0.948, 1.15, 0.56, 2394734749587982333, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 44, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566768, 54.491685, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5667345 54.4916806, 9.5667663 54.4916649, 9.5668023 54.4916895, 9.5667705 54.4917052, 9.5667345 54.4916806))', 8307),
    -190.597, -69.502, 4.57, 40.38, 0.9, 0.9, 0.56, 7483468498307752043, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 45, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566734, 54.491403, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5667872 54.4914312, 9.5667156 54.4914432, 9.5666815 54.4913744, 9.5667532 54.4913624, 9.5667872 54.4914312))', 8307),
    -192.805, -38.083, 4.87, -163.94, 0.886, 1.074, 0.619, 7125575303178231099, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 46, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566992, 54.491546, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5669706 54.4915277, 9.5670228 54.4915337, 9.5670125 54.4915641, 9.5669602 54.4915581, 9.5669706 54.4915277))', 8307),
    -176.14, -54.01, 4.04, -11.18, 0.863, 1.15, 0.772, -741884404931413844, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 47, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567036, 54.491405, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5670576 54.4914609, 9.5669715 54.4914483, 9.5670145 54.4913484, 9.5671006 54.491361, 9.5670576 54.4914609))', 8307),
    -173.255, -38.29, 4.56, 165.95, 0.956, 1.15, 0.513, 3892963474617779240, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 48, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567043, 54.491303, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5670904 54.4912936, 9.5670769 54.491325, 9.5669961 54.4913132, 9.5670096 54.4912819, 9.5670904 54.4912936))', 8307),
    -172.788, -27.022, 4.68, 255.95, 0.9, 0.9, 0.513, 3241502437508409618, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 49, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567208, 54.491579, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5671371 54.4915374, 9.5672182 54.4915206, 9.5672791 54.4916203, 9.567198 54.4916371, 9.5671371 54.4915374))', 8307),
    -162.104, -57.68, 3.91, 19.59, 0.981, 1.116, 0.839, -1966746067865706787, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 50, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567274, 54.491673, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5672549 54.4916896, 9.567241 54.4916667, 9.5672933 54.4916559, 9.5673073 54.4916787, 9.5672549 54.4916896))', 8307),
    -157.828, -68.131, 3.97, 109.59, 0.9, 0.9, 0.839, -6926997993261457565, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 51, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567402, 54.491535, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5673275 54.4915101, 9.567395 54.4914852, 9.5674756 54.4915594, 9.5674082 54.4915843, 9.5673275 54.4915101))', 8307),
    -149.569, -52.773, 3.8, 32.33, 1.086, 1.15, 0.513, -7595497901177781639, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 52, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567555, 54.491465, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5675288 54.4914491, 9.567582 54.4914497, 9.5675808 54.4914819, 9.5675276 54.4914812, 9.5675288 54.4914491))', 8307),
    -139.638, -45.06, 3.67, -1.24, 0.896, 1.15, 0.922, -1650136663235282755, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 53, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567542, 54.491301, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5675842 54.4913385, 9.5675086 54.4913415, 9.5674994 54.4912628, 9.5675751 54.4912598, 9.5675842 54.4913385))', 8307),
    -140.48, -26.715, 3.66, -176.11, 0.975, 1.092, 0.837, 6677026259864781425, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 54, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567913, 54.491506, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5678877 54.4914663, 9.5679655 54.491477, 9.5679376 54.4915456, 9.5678599 54.4915349, 9.5678877 54.4914663))', 8307),
    -116.448, -49.566, 3.26, -13.28, 0.872, 1.15, 0.61, 5173777790322569292, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 55, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568146, 54.491551, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5681114 54.4915007, 9.5681937 54.4915045, 9.5681807 54.4916022, 9.5680983 54.4915984, 9.5681114 54.4915007))', 8307),
    -101.327, -54.628, 3.12, -4.44, 0.909, 1.071, 0.931, 1953590608999877129, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 56, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568386, 54.491542, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5683481 54.4915014, 9.568428 54.4915025, 9.5684247 54.4915831, 9.5683448 54.491582, 9.5683481 54.4915014))', 8307),
    -85.751, -53.604, 3.06, -1.35, 0.998, 1.15, 0.562, 6993358021288570781, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 57, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568409, 54.491392, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5684461 54.4914319, 9.5683663 54.4914298, 9.5683723 54.4913519, 9.5684521 54.4913539, 9.5684461 54.4914319))', 8307),
    -84.272, -36.868, 3.18, 177.43, 0.966, 1.15, 0.867, 607729839985230887, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 58, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568399, 54.49131, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5684277 54.491299, 9.5684258 54.4913232, 9.5683703 54.4913218, 9.5683722 54.4912975, 9.5684277 54.491299))', 8307),
    -84.936, -27.792, 3.2, 267.43, 0.9, 0.9, 0.867, 6489927918812541490, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 59, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568578, 54.491559, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5685303 54.4915212, 9.5686097 54.4915158, 9.5686258 54.491597, 9.5685465 54.4916023, 9.5685303 54.4915212))', 8307),
    -73.33, -55.479, 2.85, 6.61, 1.01, 1.15, 0.491, -7721051876171422034, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 60, 'Uferhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'UFERHAUS'), 'Uferhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569058, 54.49147, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5689539 54.4914072, 9.5690067 54.4913881, 9.5691611 54.4915335, 9.5691083 54.4915525, 9.5689539 54.4914072))', 8307),
    -42.262, -45.597, 2.48, 31.74, 1.119, 1.15, 0.892, -955379675408615880, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 61, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569179, 54.491584, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5691332 54.4915721, 9.5691805 54.491555, 9.5692243 54.4915963, 9.5691771 54.4916133, 9.5691332 54.4915721))', 8307),
    -34.405, -58.27, 2.33, 31.74, 0.9, 0.9, 0.892, -3202301884441129115, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 62, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569172, 54.491211, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5692094 54.4912557, 9.5691296 54.491254, 9.569135 54.4911668, 9.5692148 54.4911684, 9.5692094 54.4912557))', 8307),
    -34.833, -16.756, 1.94, 177.94, 1.08, 1.15, 0.83, 7989879433915272376, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 63, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.560978, 54.491266, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5609863 54.4913125, 9.5609131 54.491294, 9.5609691 54.491219, 9.5610424 54.4912376, 9.5609863 54.4913125))', 8307),
    -565.842, -22.862, 14.84, 156.49, 1.011, 1.15, 0.65, 1471578716980323636, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 64, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561087, 54.491324, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5610742 54.4913475, 9.5610453 54.4913214, 9.561099 54.4913013, 9.5611279 54.4913274, 9.5610742 54.4913475))', 8307),
    -558.787, -29.389, 14.82, 122.78, 1.035, 1.15, 0.469, -2874340828895743663, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 65, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561416, 54.491683, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5614002 54.4916339, 9.5614765 54.4916477, 9.561432 54.4917313, 9.5613558 54.4917176, 9.5614002 54.4916339))', 8307),
    -537.428, -69.259, 15.23, -17.19, 1.083, 1.15, 0.796, 4022386807918403493, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 66, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561495, 54.491527, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5615122 54.4915682, 9.561437 54.4915526, 9.5614782 54.4914849, 9.5615534 54.4915004, 9.5615122 54.4915682))', 8307),
    -532.307, -51.883, 14.93, 160.51, 0.889, 1.15, 0.78, -7202012683454536472, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 67, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561753, 54.491556, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5617615 54.4916108, 9.5616795 54.491591, 9.561744 54.4915008, 9.5618259 54.4915206, 9.5617615 54.4916108))', 8307),
    -515.619, -55.141, 14.61, 157.42, 0.906, 1.15, 0.78, 6595265376692863434, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 68, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561868, 54.491792, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5618454 54.4917415, 9.5619293 54.4917541, 9.5618898 54.4918431, 9.5618058 54.4918304, 9.5618454 54.4917415))', 8307),
    -508.173, -81.463, 14.88, -14.5, 0.852, 1.124, 0.913, -6005201322601646337, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 69, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561832, 54.491881, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5617847 54.4918909, 9.5617986 54.4918596, 9.5618793 54.4918718, 9.5618654 54.4919031, 9.5617847 54.4918909))', 8307),
    -510.479, -91.378, 14.86, 75.5, 0.9, 0.9, 0.913, -2919091405712192985, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 70, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561946, 54.491651, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5619623 54.4916732, 9.5619114 54.491664, 9.5619304 54.4916285, 9.5619813 54.4916377, 9.5619623 54.4916732))', 8307),
    -503.07, -65.724, 14.6, 162.74, 1.035, 1.15, 0.833, 441782464038101136, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 71, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562162, 54.491652, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5621506 54.4917118, 9.5620749 54.4916849, 9.562173 54.4915915, 9.5622487 54.4916184, 9.5621506 54.4917118))', 8307),
    -489.107, -65.809, 14.16, 148.56, 1.016, 1.15, 0.617, 5685626984943902376, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 72, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562223, 54.491909, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5622441 54.4918681, 9.5622946 54.4918994, 9.5622012 54.4919504, 9.5621508 54.4919191, 9.5622441 54.4918681))', 8307),
    -485.16, -94.478, 14.36, -46.83, 0.922, 1.062, 0.61, -9142175044651804041, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 73, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562586, 54.492129, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5626247 54.4920757, 9.5626802 54.4921109, 9.5625467 54.4921822, 9.5624912 54.492147, 9.5626247 54.4920757))', 8307),
    -461.634, -118.936, 13.59, -47.44, 0.978, 1.063, 0.606, -4987040309149015951, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 74, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562797, 54.492, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5627625 54.4920568, 9.562702 54.4920245, 9.5628307 54.4919429, 9.5628911 54.4919752, 9.5627625 54.4920568))', 8307),
    -447.971, -104.561, 12.86, 137.44, 1.027, 1.063, 0.479, 1764045600168234512, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 75, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562746, 54.492223, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5627652 54.4921652, 9.5628364 54.4921961, 9.5627276 54.4922812, 9.5626564 54.4922503, 9.5627652 54.4921652))', 8307),
    -451.221, -129.427, 13.18, -36.66, 0.984, 1.15, 0.666, 1305789316405800790, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 76, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562652, 54.492317, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5626548 54.4922876, 9.5626993 54.4923069, 9.5626496 54.4923458, 9.562605 54.4923265, 9.5626548 54.4922876))', 8307),
    -457.324, -139.835, 13.42, -36.66, 0.9, 0.9, 0.666, -3971786634755392847, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 77, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.5629, 54.492098, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5629003 54.4921233, 9.5628586 54.492104, 9.5629001 54.4920736, 9.5629418 54.4920929, 9.5629003 54.4921233))', 8307),
    -441.254, -115.539, 12.78, 141.5, 1.08, 1.15, 0.571, -5936818597478893769, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 78, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563082, 54.492141, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5630737 54.4921852, 9.5630101 54.4921571, 9.5630899 54.4920959, 9.5631535 54.492124, 9.5630737 54.4921852))', 8307),
    -429.487, -120.221, 12.41, 142.78, 0.95, 1.15, 0.632, -354549253338167858, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 79, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56334, 54.492416, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5633312 54.4923925, 9.5633779 54.4924074, 9.5633486 54.4924386, 9.5633019 54.4924237, 9.5633312 54.4923925))', 8307),
    -412.758, -150.833, 12.39, -28.71, 0.99, 1.15, 0.826, 7594983938808142632, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 80, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56359, 54.492473, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.563573 54.4924526, 9.5636236 54.4924623, 9.563606 54.4924933, 9.5635555 54.4924836, 9.563573 54.4924526))', 8307),
    -396.582, -157.221, 11.67, -18.27, 0.907, 1.15, 0.892, 779337026946252753, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 81, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563659, 54.492338, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5636711 54.4923927, 9.5635878 54.4923749, 9.5636459 54.4922828, 9.5637292 54.4923006, 9.5636711 54.4923927))', 8307),
    -392.115, -142.169, 11.21, 159.82, 0.91, 1.15, 0.699, 3843903737759852630, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 82, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563718, 54.492254, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5637516 54.4922477, 9.5637372 54.4922705, 9.5636851 54.4922593, 9.5636994 54.4922366, 9.5637516 54.4922477))', 8307),
    -388.24, -132.796, 11.01, 249.82, 0.9, 0.9, 0.699, 5575983740792171880, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 83, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56403, 54.492553, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5639812 54.4925177, 9.5640603 54.4925111, 9.5640793 54.4925888, 9.5640002 54.4925953, 9.5639812 54.4925177))', 8307),
    -368.023, -166.154, 10.47, 8.09, 0.97, 1.15, 0.904, 2679003696584395152, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 84, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564065, 54.492633, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5640407 54.4926471, 9.5640349 54.4926231, 9.5640899 54.4926186, 9.5640958 54.4926426, 9.5640407 54.4926471))', 8307),
    -365.751, -175.017, 10.3, 98.09, 0.9, 0.9, 0.904, -109980829835732375, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 85, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564347, 54.492454, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5642731 54.4924469, 9.564326 54.4924121, 9.5644202 54.4924606, 9.5643673 54.4924954, 9.5642731 54.4924469))', 8307),
    -347.524, -155.081, 9.04, 48.48, 0.906, 1.15, 0.574, -3788083826701195132, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 86, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564342, 54.492211, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5644054 54.4922509, 9.5643193 54.4922635, 9.5642792 54.4921705, 9.5643653 54.4921579, 9.5644054 54.4922509))', 8307),
    -347.807, -128.027, 8.85, -165.91, 0.889, 1.15, 0.465, 5672696850451845750, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 87, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564778, 54.492425, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5647506 54.4924092, 9.5648038 54.4924085, 9.5648051 54.4924408, 9.5647519 54.4924415, 9.5647506 54.4924092))', 8307),
    -319.58, -151.88, 7.31, 1.33, 0.899, 1.15, 0.813, 209270784845730228, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 88, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565137, 54.492351, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.565051 54.4923456, 9.5650948 54.4923068, 9.5652237 54.492356, 9.5651799 54.4923949, 9.565051 54.4923456))', 8307),
    -296.288, -143.618, 5.91, 56.72, 1.11, 1.15, 0.465, -3972693137897844763, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 89, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564863, 54.492236, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5649754 54.4922467, 9.5649281 54.4922904, 9.5647513 54.4922256, 9.5647986 54.4921819, 9.5649754 54.4922467))', 8307),
    -314.042, -130.859, 6.82, -122.2, 1.128, 1.15, 0.516, -4258973447103095556, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 90, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565261, 54.492243, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651644 54.4922147, 9.5652334 54.4921822, 9.5653571 54.4922714, 9.565288 54.4923038, 9.5651644 54.4922147))', 8307),
    -288.294, -131.619, 5.56, 38.92, 1.063, 1.15, 0.587, 2089313165646741539, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 91, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565277, 54.492026, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5653366 54.4920772, 9.5652491 54.4920859, 9.5652165 54.4919746, 9.565304 54.4919659, 9.5653366 54.4920772))', 8307),
    -287.269, -107.451, 5.95, -170.34, 1.048, 1.15, 0.828, 7729549651451296826, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 92, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565648, 54.492143, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5655569 54.4921152, 9.5656278 54.4920841, 9.565739 54.4921701, 9.5656682 54.4922011, 9.5655569 54.4921152))', 8307),
    -263.199, -120.441, 5.01, 36.99, 0.998, 1.15, 0.761, 8016715813259486951, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 93, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565618, 54.491909, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5656991 54.4919445, 9.5656326 54.4919673, 9.5655368 54.4918726, 9.5656033 54.4918498, 9.5656991 54.4919445))', 8307),
    -265.145, -94.388, 5.76, -149.51, 1.02, 1.001, 0.696, 8922106966889348886, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 94, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565536, 54.491822, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5655809 54.4918342, 9.5655331 54.4918506, 9.5654908 54.4918088, 9.5655386 54.4917924, 9.5655809 54.4918342))', 8307),
    -270.467, -84.696, 6.08, -149.51, 0.9, 0.9, 0.696, 6003448844823908411, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 95, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566075, 54.492024, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5660505 54.492003, 9.5661037 54.492005, 9.5660992 54.4920452, 9.5660461 54.4920431, 9.5660505 54.492003))', 8307),
    -235.537, -107.244, 4.65, -3.72, 1.119, 1.15, 0.583, 8619451105333585788, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 96, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566095, 54.491845, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5661361 54.4919048, 9.5660549 54.4919048, 9.5660548 54.4917847, 9.566136 54.4917847, 9.5661361 54.4919048))', 8307),
    -234.207, -87.281, 5.42, 180.03, 1.114, 1.053, 0.453, -256636631331499513, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 97, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566456, 54.492084, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5664202 54.4920322, 9.5665085 54.4920376, 9.566491 54.4921361, 9.5664027 54.4921308, 9.5664202 54.4920322))', 8307),
    -210.867, -113.931, 4.22, -5.9, 0.919, 1.15, 0.802, 4016739076621748362, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 98, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566789, 54.492009, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.56672 54.4919959, 9.5667821 54.4919667, 9.566859 54.4920221, 9.5667968 54.4920513, 9.56672 54.4919959))', 8307),
    -189.231, -105.562, 4.37, 38.89, 0.881, 1.15, 0.943, 9175924124145765971, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 99, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566619, 54.491882, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5666951 54.4918997, 9.5666331 54.491929, 9.5665426 54.491864, 9.5666047 54.4918347, 9.5666951 54.4918997))', 8307),
    -200.286, -91.408, 5, -140.98, 1.034, 1.15, 0.633, 626289551509245873, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 100, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566508, 54.491819, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5665225 54.491791, 9.5665575 54.4918162, 9.5664927 54.4918467, 9.5664578 54.4918216, 9.5665225 54.491791))', 8307),
    -207.497, -84.401, 5.12, -50.98, 0.9, 0.9, 0.633, 7513389340344780593, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 101, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566974, 54.491816, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5669984 54.4918607, 9.5669202 54.4918511, 9.5669492 54.4917706, 9.5670274 54.4917801, 9.5669984 54.4918607))', 8307),
    -177.288, -84.038, 4.43, 168.15, 1.018, 1.15, 0.683, -271832683850540842, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 102, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567011, 54.491728, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.56703 54.4917549, 9.5669756 54.4917483, 9.5669927 54.4917008, 9.5670471 54.4917074, 9.56703 54.4917549))', 8307),
    -174.855, -74.267, 4.27, 168.15, 0.9, 0.9, 0.683, -3286723195506731641, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 103, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567095, 54.492017, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5670429 54.4919742, 9.5671312 54.4919691, 9.5671468 54.4920604, 9.5670585 54.4920655, 9.5670429 54.4919742))', 8307),
    -169.445, -106.488, 3.72, 5.69, 0.851, 1.15, 0.501, 5261266393474817603, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 104, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567415, 54.491964, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5673366 54.4919371, 9.5674013 54.4919116, 9.5674937 54.491991, 9.567429 54.4920165, 9.5673366 54.4919371))', 8307),
    -148.688, -100.558, 3.51, 34.08, 0.89, 1.012, 0.485, -972499851243538883, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 105, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567513, 54.492031, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5675021 54.4920497, 9.5674788 54.4920296, 9.5675248 54.4920115, 9.5675481 54.4920316, 9.5675021 54.4920497))', 8307),
    -142.316, -107.965, 3.09, 124.08, 0.9, 0.9, 0.485, -5285825500591641690, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 106, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56724, 54.491812, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5673125 54.4918385, 9.5672481 54.4918613, 9.5671679 54.4917846, 9.5672323 54.4917618, 9.5673125 54.4918385))', 8307),
    -160.024, -83.583, 3.95, -148.64, 1.11, 1.085, 0.473, -2587601223354359490, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 107, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567428, 54.491745, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5674839 54.491779, 9.5674063 54.4917901, 9.567373 54.4917109, 9.5674506 54.4916998, 9.5674839 54.491779))', 8307),
    -147.826, -76.17, 3.76, -166.26, 1.009, 1.15, 0.616, 8058582472532788860, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 108, 'Hof eines reichen Händlers', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'HALLE'), 'Hof eines reichen Händlers',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567745, 54.491922, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5677223 54.4918499, 9.5678125 54.4918599, 9.5677685 54.4919942, 9.5676783 54.4919842, 9.5677223 54.4918499))', 8307),
    -127.284, -95.879, 3.16, -10.8, 0.87, 0.85, 0.94, -6517352662310020634, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 109, 'Hof eines reichen Händlers', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'HALLE'), 'Hof eines reichen Händlers',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567825, 54.49168, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5678394 54.4917676, 9.5677497 54.4917561, 9.5678115 54.4915924, 9.5679012 54.4916039, 9.5678394 54.4917676))', 8307),
    -122.101, -68.939, 3.26, 167.61, 1.066, 0.85, 0.759, -1710709991970250780, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 110, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56808, 54.491929, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5680461 54.4918923, 9.5681211 54.4918946, 9.5681145 54.4919661, 9.5680395 54.4919637, 9.5680461 54.4918923))', 8307),
    -105.585, -96.676, 2.58, -3.08, 0.885, 1.081, 0.519, 6305934113048178448, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 111, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568072, 54.492014, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5680467 54.4919891, 9.5681022 54.4919909, 9.5680977 54.4920393, 9.5680423 54.4920376, 9.5680467 54.4919891))', 8307),
    -106.108, -106.141, 2.53, -3.08, 0.9, 0.9, 0.519, -468419710941210986, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 112, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568098, 54.49175, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5681347 54.4917875, 9.5680597 54.4917868, 9.5680615 54.4917116, 9.5681365 54.4917122, 9.5681347 54.4917875))', 8307),
    -104.432, -76.678, 2.96, 179.21, 0.931, 1.081, 0.511, 3563948522055125228, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 113, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568094, 54.491663, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.568121 54.4916877, 9.5680654 54.4916873, 9.5680666 54.4916388, 9.5681221 54.4916392, 9.568121 54.4916877))', 8307),
    -104.713, -67.072, 3.11, 179.21, 0.9, 0.9, 0.511, 427473790008424147, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 114, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568481, 54.491944, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5684362 54.4919006, 9.5685159 54.4918976, 9.5685259 54.4919866, 9.5684462 54.4919896, 9.5684362 54.4919006))', 8307),
    -79.616, -98.28, 2.19, 3.76, 1.104, 1.15, 0.921, 390587025037974980, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 115, 'Uferhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'UFERHAUS'), 'Uferhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568467, 54.491714, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5685082 54.4917946, 9.5684462 54.4917973, 9.5684255 54.4916339, 9.5684874 54.4916312, 9.5685082 54.4917946))', 8307),
    -80.538, -72.75, 2.65, -175.78, 1.073, 1.15, 0.515, -5444008192580915364, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 116, 'Uferhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'UFERHAUS'), 'Uferhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568812, 54.491918, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5687199 54.4918557, 9.5687747 54.4918388, 9.5689035 54.4919795, 9.5688486 54.4919965, 9.5687199 54.4918557))', 8307),
    -58.193, -95.388, 2.12, 28.04, 1.044, 1.15, 0.554, -6618453272173520585, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 117, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568781, 54.491691, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5688597 54.4917132, 9.5687964 54.4917415, 9.5687016 54.4916697, 9.5687649 54.4916413, 9.5688597 54.4917132))', 8307),
    -60.203, -70.209, 2.56, -142.45, 1.121, 1.15, 0.588, -384504246461253176, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 118, 'Uferhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'UFERHAUS'), 'Uferhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569127, 54.491817, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5690688 54.4917402, 9.5691297 54.491733, 9.5691855 54.4918941, 9.5691246 54.4919013, 9.5690688 54.4917402))', 8307),
    -37.749, -84.205, 1.82, 11.41, 1.076, 1.15, 0.813, -8428134427819139651, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 119, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561434, 54.491807, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5614447 54.4918528, 9.561371 54.4918349, 9.5614233 54.4917616, 9.5614971 54.4917794, 9.5614447 54.4918528))', 8307),
    -536.268, -83.126, 15.12, 157.45, 0.982, 1.15, 0.558, -2272331535488422200, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 120, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561501, 54.49198, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5614851 54.4919561, 9.5615361 54.491965, 9.5615161 54.4920038, 9.5614651 54.4919949, 9.5614851 54.4919561))', 8307),
    -531.95, -102.354, 15.06, -16.71, 1.128, 1.15, 0.638, -3062633850826510841, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 121, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561879, 54.492075, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5618646 54.4920545, 9.5619141 54.492066, 9.5618942 54.4920953, 9.5618447 54.4920839, 9.5618646 54.4920545))', 8307),
    -507.404, -112.926, 14.72, -21.6, 0.879, 1.15, 0.616, -3209591111251543048, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 122, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562118, 54.492199, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5621457 54.4921379, 9.5622146 54.4921705, 9.5620903 54.4922595, 9.5620215 54.4922269, 9.5621457 54.4921379))', 8307),
    -491.94, -126.704, 14.3, -39.09, 1.064, 1.15, 0.575, 4878608066800330828, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 123, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562294, 54.49208, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5622981 54.4921023, 9.5622568 54.4920828, 9.5622905 54.4920586, 9.5623318 54.4920782, 9.5622981 54.4921023))', 8307),
    -480.518, -113.542, 14.12, 140.88, 0.866, 1.15, 0.907, -5331349902442969281, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 124, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562273, 54.49227, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5622941 54.4922251, 9.5623509 54.4922578, 9.5622526 54.4923157, 9.5621958 54.492283, 9.5622941 54.4922251))', 8307),
    -481.876, -134.683, 14.05, -44.66, 1.007, 1.15, 0.823, 2304525478122948404, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 125, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562614, 54.492456, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5626201 54.4924306, 9.5626568 54.4924531, 9.5626072 54.4924804, 9.5625706 54.4924579, 9.5626201 54.4924306))', 8307),
    -459.817, -155.286, 13.6, -46.56, 1.105, 1.15, 0.517, -6352681045014346826, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 126, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562832, 54.492599, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5628357 54.4925528, 9.5629026 54.4925782, 9.5628281 54.4926448, 9.5627612 54.4926194, 9.5628357 54.4925528))', 8307),
    -445.676, -171.232, 13.37, -33.06, 0.983, 1.15, 0.822, -2203982539248771365, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 127, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563003, 54.492453, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5630027 54.4924946, 9.5629367 54.4924685, 9.5630042 54.4924107, 9.5630702 54.4924369, 9.5630027 54.4924946))', 8307),
    -434.56, -154.967, 13.02, 145.77, 0.864, 1.15, 0.758, -741353881154437077, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 128, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563069, 54.492688, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5630799 54.4926407, 9.5631437 54.4926686, 9.5630579 54.492735, 9.5629941 54.492707, 9.5630799 54.4926407))', 8307),
    -430.317, -181.142, 13.14, -36.98, 1.027, 1.15, 0.946, -3792019004389201848, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 129, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563354, 54.49263, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5633578 54.4926553, 9.5633135 54.4926381, 9.5633507 54.4926055, 9.5633951 54.4926227, 9.5633578 54.4926553))', 8307),
    -411.826, -174.749, 12.64, 146.4, 1.09, 1.15, 0.919, 2360095525120518555, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 130, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563756, 54.492835, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5637314 54.4928165, 9.5637845 54.4928187, 9.5637803 54.492853, 9.5637272 54.4928508, 9.5637314 54.4928165))', 8307),
    -385.803, -197.494, 11.77, -4.12, 0.956, 1.15, 0.694, -2436663848587755026, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 131, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564035, 54.492852, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5639764 54.4928196, 9.5640527 54.4928058, 9.5640945 54.4928841, 9.5640182 54.4928979, 9.5639764 54.4928196))', 8307),
    -367.683, -199.396, 10.28, 17.26, 1.015, 1.15, 0.495, -4536016325594648877, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 132, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564366, 54.492763, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5642601 54.4927516, 9.564311 54.4927093, 9.5644729 54.4927753, 9.5644219 54.4928176, 9.5642601 54.4927516))', 8307),
    -346.235, -189.558, 8.61, 54.99, 1.067, 1.15, 0.911, 2487809468025063800, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 133, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564494, 54.492822, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5644593 54.4928231, 9.5644832 54.4928032, 9.5645287 54.4928218, 9.5645048 54.4928416, 9.5644593 54.4928231))', 8307),
    -337.972, -196.116, 7.92, 54.99, 0.9, 0.9, 0.911, -1794644019399090851, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 134, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564152, 54.492666, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5641919 54.4926659, 9.5641573 54.4926895, 9.5641119 54.4926669, 9.5641464 54.4926434, 9.5641919 54.4926659))', 8307),
    -360.142, -178.753, 9.8, -130.46, 0.967, 1.15, 0.726, -3564732268927887043, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 135, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564353, 54.492539, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5643874 54.4925487, 9.5643375 54.4925594, 9.5643179 54.4925284, 9.5643679 54.4925177, 9.5643874 54.4925487))', 8307),
    -347.132, -164.521, 9.08, -159.84, 0.919, 1.15, 0.691, -1226016274125030792, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 136, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564615, 54.492514, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.564616 54.4925727, 9.564536 54.4925503, 9.5646143 54.4924555, 9.5646943 54.4924779, 9.564616 54.4925727))', 8307),
    -330.123, -161.797, 7.93, 154.33, 0.976, 1.15, 0.67, 894064816015335896, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 137, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565117, 54.49262, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5650453 54.4926181, 9.5650924 54.4925805, 9.565189 54.4926216, 9.5651419 54.4926592, 9.5650453 54.4926181))', 8307),
    -297.595, -173.564, 5.88, 53.86, 0.862, 1.15, 0.8, 8478484529570793678, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 138, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565241, 54.492662, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.565239 54.4926908, 9.5651941 54.4926717, 9.5652433 54.4926325, 9.5652881 54.4926516, 9.565239 54.4926908))', 8307),
    -289.56, -178.215, 5.53, 143.86, 0.9, 0.9, 0.8, 7028011986785352694, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 139, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564985, 54.492493, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5650236 54.4924899, 9.5649929 54.4925152, 9.5649473 54.4924964, 9.564978 54.4924711, 9.5650236 54.4924899))', 8307),
    -306.129, -159.462, 6.53, -125.2, 0.904, 1.15, 0.829, 6085051130120627681, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 140, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56533, 54.492494, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5652996 54.4924773, 9.5653523 54.4924731, 9.5653612 54.492511, 9.5653085 54.4925152, 9.5652996 54.4924773))', 8307),
    -283.776, -159.57, 5.29, 7.76, 1.065, 1.15, 0.754, -3930693948751832876, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 141, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56564, 54.492463, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.565551 54.4924316, 9.5656251 54.4924032, 9.5657284 54.4924944, 9.5656544 54.4925228, 9.565551 54.4924316))', 8307),
    -263.732, -156.103, 4.66, 33.42, 1.013, 1.15, 0.574, -3259023878471827963, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 142, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565996, 54.492361, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.565974 54.4923408, 9.5660267 54.4923453, 9.5660179 54.4923802, 9.5659652 54.4923758, 9.565974 54.4923408))', 8307),
    -240.648, -144.694, 3.94, -8.32, 0.984, 1.15, 0.671, 710535699598849262, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 143, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566013, 54.492236, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5660389 54.4922527, 9.5659856 54.4922516, 9.5659875 54.4922201, 9.5660407 54.4922212, 9.5660389 54.4922527))', 8307),
    -239.533, -130.88, 4.06, 178.01, 0.876, 1.15, 0.602, 2857541037314044625, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 144, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566211, 54.492392, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.566179 54.4923479, 9.5662585 54.4923527, 9.5662436 54.4924352, 9.5661642 54.4924304, 9.566179 54.4923479))', 8307),
    -226.693, -148.149, 3.61, -5.98, 1.026, 1.15, 0.931, 7778431475964677588, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 145, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566457, 54.492424, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5664154 54.4923675, 9.5665041 54.4923691, 9.5664982 54.4924813, 9.5664096 54.4924798, 9.5664154 54.4923675))', 8307),
    -210.786, -151.808, 3.3, -1.72, 1.042, 1.15, 0.544, 8908334399698873700, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 146, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566483, 54.492218, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5665201 54.4922768, 9.5664316 54.492273, 9.5664459 54.4921597, 9.5665344 54.4921635, 9.5665201 54.4922768))', 8307),
    -209.089, -128.857, 3.81, 175.8, 1.054, 1.15, 0.517, 226035362070154207, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 147, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566846, 54.49229, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5668245 54.4922704, 9.5668772 54.4922749, 9.5668683 54.4923105, 9.5668156 54.4923061, 9.5668245 54.4922704))', 8307),
    -185.542, -136.897, 3.16, -8.29, 1.002, 1.15, 0.845, 3620317100083603202, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 148, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566868, 54.492152, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5669093 54.4922001, 9.5668206 54.4921981, 9.5668268 54.4921034, 9.5669155 54.4921053, 9.5669093 54.4922001))', 8307),
    -184.14, -121.453, 3.62, 177.82, 0.88, 1.15, 0.668, 7052625774331978384, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 149, 'Uferhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'UFERHAUS'), 'Uferhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567113, 54.492384, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.567055 54.4923011, 9.5671161 54.4922945, 9.567171 54.4924662, 9.5671099 54.4924728, 9.567055 54.4923011))', 8307),
    -168.266, -147.263, 2.65, 10.55, 1.144, 1.15, 0.741, -8268527400736067480, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 150, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567469, 54.492239, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5673977 54.4922158, 9.5674656 54.4921912, 9.567541 54.492262, 9.5674732 54.4922865, 9.5673977 54.4922158))', 8307),
    -145.174, -131.151, 2.61, 31.83, 1.03, 1.15, 0.493, -804032983306516857, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 151, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567558, 54.492317, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5675123 54.4923046, 9.5675595 54.4922875, 9.5676034 54.4923287, 9.5675562 54.4923458, 9.5675123 54.4923046))', 8307),
    -139.438, -139.806, 2.36, 31.83, 0.9, 0.9, 0.493, -4626283823614682211, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 152, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567317, 54.492097, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5673864 54.4921167, 9.5673193 54.4921419, 9.5672469 54.4920764, 9.5673141 54.4920513, 9.5673864 54.4921167))', 8307),
    -155.067, -115.311, 3.13, -147.25, 0.963, 1.15, 0.646, 9089728686046587186, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 153, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567843, 54.492209, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5678079 54.4921677, 9.5678876 54.4921708, 9.5678784 54.4922501, 9.5677988 54.492247, 9.5678079 54.4921677))', 8307),
    -120.951, -127.813, 2.19, -3.84, 0.983, 1.15, 0.87, -8197507439943922434, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 154, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567845, 54.492298, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.56782 54.4922722, 9.5678754 54.4922744, 9.5678698 54.4923228, 9.5678144 54.4923206, 9.56782 54.4922722))', 8307),
    -120.838, -137.677, 2.14, -3.84, 0.9, 0.9, 0.87, 2311366240954696140, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 155, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567873, 54.492041, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5679085 54.4920888, 9.5678287 54.4920864, 9.567837 54.4919937, 9.5679168 54.4919961, 9.5679085 54.4920888))', 8307),
    -119.034, -109.153, 2.57, 177.02, 1.148, 1.15, 0.676, 1657739199559341276, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 156, 'Uferhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'UFERHAUS'), 'Uferhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568233, 54.492272, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5682122 54.4921896, 9.5682742 54.4921921, 9.5682546 54.4923537, 9.5681926 54.4923512, 9.5682122 54.4921896))', 8307),
    -95.663, -134.798, 1.97, -4.04, 1.061, 1.15, 0.876, -2691886134737771343, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 157, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568476, 54.492231, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5684375 54.4921908, 9.5685173 54.4921918, 9.5685144 54.4922715, 9.5684346 54.4922706, 9.5684375 54.4921908))', 8307),
    -79.947, -130.294, 1.96, -1.22, 0.986, 1.15, 0.47, 51513366597925532, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 158, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568496, 54.49232, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5684541 54.492336, 9.5684552 54.4923037, 9.5685386 54.4923047, 9.5685374 54.4923371, 9.5684541 54.492336))', 8307),
    -78.627, -140.22, 1.74, 88.78, 0.9, 0.9, 0.47, 6550820191322847507, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 159, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568779, 54.492195, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5687139 54.4921697, 9.5687861 54.4921498, 9.5688433 54.49222, 9.5687711 54.4922399, 9.5687139 54.4921697))', 8307),
    -60.336, -126.248, 1.45, 25.35, 0.962, 1.15, 0.527, -4689603397591469095, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 160, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569, 54.492109, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5689406 54.4920878, 9.5690051 54.4920683, 9.5690603 54.4921301, 9.5689958 54.4921497, 9.5689406 54.4920878))', 8307),
    -45.958, -116.688, 1.24, 27.46, 0.862, 1.047, 0.902, 6395769284383404147, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 161, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561815, 54.49233, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5618196 54.4923537, 9.5617754 54.4923364, 9.5618099 54.4923065, 9.5618541 54.4923238, 9.5618196 54.4923537))', 8307),
    -511.589, -141.334, 14.66, 146.12, 1.003, 1.15, 0.497, 538032652935511595, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 162, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561867, 54.492495, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5618544 54.4924741, 9.5619022 54.4924878, 9.5618787 54.4925156, 9.5618309 54.4925019, 9.5618544 54.4924741))', 8307),
    -508.232, -159.671, 14.62, -26.22, 0.862, 1.15, 0.629, -4334835314757620605, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 163, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562226, 54.492625, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5622264 54.4926026, 9.5622644 54.4926243, 9.5622263 54.4926469, 9.5621883 54.4926252, 9.5622264 54.4926026))', 8307),
    -484.916, -174.13, 14.19, -44.43, 0.882, 1.15, 0.655, 7523791624373782693, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 164, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562446, 54.492767, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5624517 54.4927419, 9.5624888 54.4927642, 9.562441 54.4927911, 9.562404 54.4927688, 9.5624517 54.4927419))', 8307),
    -470.656, -189.907, 14.25, -45.94, 1.077, 1.15, 0.796, -7884732550900913485, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 165, 'Bronzegießer', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Bronzegießer',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56261, 54.492871, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5626111 54.4928478, 9.5626494 54.4928694, 9.5626097 54.4928933, 9.5625714 54.4928717, 9.5626111 54.4928478))', 8307),
    -460.027, -201.485, 14.12, -44.04, 0.925, 1.15, 0.67, -1647336639140351785, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 166, 'Glasmacher', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Glasmacher',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56286, 54.492984, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5628532 54.4929508, 9.5629134 54.4929727, 9.562866 54.4930168, 9.5628059 54.4929948, 9.5628532 54.4929508))', 8307),
    -443.875, -214.087, 13.75, -32.05, 0.964, 1.15, 0.772, -4650890461771405963, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 167, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562979, 54.492871, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5629876 54.4928935, 9.5629411 54.4928785, 9.5629706 54.4928475, 9.5630172 54.4928626, 9.5629876 54.4928935))', 8307),
    -436.133, -201.481, 13.51, 150.91, 0.986, 1.15, 0.618, -4487780363420411806, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 168, 'Glasmacher', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Glasmacher',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563019, 54.493032, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.563016 54.4930076, 9.5630594 54.4930256, 9.5630218 54.4930564, 9.5629784 54.4930384, 9.563016 54.4930076))', 8307),
    -433.554, -219.453, 13.55, -35.39, 1.051, 1.15, 0.786, -228773713680802849, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 169, 'Bronzegießer', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Bronzegießer',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563173, 54.493097, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5631673 54.4930736, 9.5632119 54.4930906, 9.5631783 54.4931205, 9.5631337 54.4931035, 9.5631673 54.4930736))', 8307),
    -423.579, -226.694, 13.32, -33.17, 0.994, 1.15, 0.614, -4545783338245260651, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 170, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563282, 54.492986, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.563287 54.4930097, 9.5632422 54.4929929, 9.5632761 54.4929623, 9.5633208 54.4929791, 9.563287 54.4930097))', 8307),
    -416.536, -214.331, 13.02, 147.19, 1.013, 1.15, 0.529, -8618570862615815587, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 171, 'Bronzegießer', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Bronzegießer',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56343, 54.493168, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5634103 54.4931484, 9.5634623 54.493155, 9.5634502 54.4931873, 9.5633981 54.4931807, 9.5634103 54.4931484))', 8307),
    -406.899, -234.575, 12.91, -12.32, 0.92, 1.15, 0.74, 3823966739594749767, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 172, 'Glasmacher', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Glasmacher',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563676, 54.493204, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5636483 54.4931721, 9.5637159 54.4931768, 9.5637037 54.4932356, 9.5636361 54.4932309, 9.5636483 54.4931721))', 8307),
    -390.974, -238.58, 12.47, -6.87, 1.099, 1.103, 0.707, 4941176553607382202, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 173, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563704, 54.493076, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.563728 54.4930949, 9.5636749 54.4930925, 9.5636795 54.493058, 9.5637326 54.4930604, 9.563728 54.4930949))', 8307),
    -389.176, -224.4, 12.16, 175.58, 0.964, 1.15, 0.631, -621047133786172616, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 174, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563847, 54.493215, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5638198 54.4931967, 9.5638731 54.4931963, 9.5638739 54.4932332, 9.5638206 54.4932336, 9.5638198 54.4931967))', 8307),
    -379.901, -239.812, 11.86, 0.72, 1.028, 1.15, 0.52, -6075622850635942517, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 175, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563844, 54.49306, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5638867 54.4930932, 9.563807 54.4930957, 9.5638004 54.4930262, 9.5638802 54.4930236, 9.5638867 54.4930932))', 8307),
    -380.117, -222.528, 11.53, -176.86, 0.862, 1.15, 0.553, -1517469695243915569, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 176, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563828, 54.492975, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5638677 54.4929579, 9.5638707 54.4929902, 9.5637875 54.4929928, 9.5637845 54.4929605, 9.5638677 54.4929579))', 8307),
    -381.153, -213.142, 11.5, -86.86, 0.9, 0.9, 0.553, -3983508987882893958, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 177, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564146, 54.493208, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5640821 54.4931819, 9.5641553 54.4931633, 9.564209 54.4932347, 9.5641359 54.4932534, 9.5640821 54.4931819))', 8307),
    -360.546, -239.074, 10.53, 23.66, 0.965, 1.15, 0.56, 6179197602170315260, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 178, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564345, 54.493119, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5642493 54.4931105, 9.5643013 54.4930687, 9.5644406 54.4931272, 9.5643886 54.4931691, 9.5642493 54.4931105))', 8307),
    -347.627, -229.117, 9.13, 54.18, 0.928, 1.15, 0.595, 4206997277107558373, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 179, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564123, 54.493017, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5642034 54.4930255, 9.5641525 54.4930613, 9.5640435 54.4930087, 9.5640944 54.4929729, 9.5642034 54.4930255))', 8307),
    -361.98, -217.792, 10.12, -129.62, 1.019, 1.15, 0.704, -5996666179693590764, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 180, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564897, 54.493122, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5648201 54.4930732, 9.5649036 54.4930557, 9.5649748 54.4931711, 9.5648913 54.4931885, 9.5648201 54.4930732))', 8307),
    -311.827, -229.478, 6.43, 19.76, 1.137, 1.15, 0.581, -6206476863905913073, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 181, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564928, 54.493225, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5648978 54.4932483, 9.564879 54.4932179, 9.5649574 54.4932015, 9.5649762 54.4932319, 9.5648978 54.4932483))', 8307),
    -309.872, -240.92, 6.54, 109.76, 0.9, 0.9, 0.581, -9187057299843226911, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 182, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565115, 54.493033, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5650319 54.4930224, 9.565084 54.4929872, 9.5651978 54.4930443, 9.5651456 54.4930796, 9.5650319 54.4930224))', 8307),
    -297.742, -219.599, 5.55, 49.23, 1.081, 1.15, 0.631, 6870380265564493425, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 183, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565239, 54.493089, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651896 54.4930854, 9.5652259 54.4930609, 9.565289 54.4930925, 9.5652527 54.493117, 9.5651896 54.4930854))', 8307),
    -289.674, -225.782, 5.15, 49.23, 0.9, 0.9, 0.631, 7796099780444804997, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 184, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565236, 54.492936, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651674 54.4929173, 9.565234 54.4928916, 9.5653048 54.4929538, 9.5652382 54.4929795, 9.5651674 54.4929173))', 8307),
    -289.882, -208.707, 5.12, 33.53, 0.923, 1.15, 0.547, 145868862519662252, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 185, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56506, 54.49278, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651519 54.4928188, 9.5650759 54.4928455, 9.564968 54.4927412, 9.565044 54.4927145, 9.5651519 54.4928188))', 8307),
    -301.3, -191.394, 5.93, -148.92, 1.129, 1.15, 0.621, -2339465995288579996, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 186, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565626, 54.492866, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5655495 54.4928417, 9.5656158 54.4928158, 9.5657021 54.4928906, 9.5656357 54.4929165, 9.5655495 54.4928417))', 8307),
    -264.632, -200.979, 4.46, 33.85, 1.115, 1.15, 0.462, -9199064071400521781, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 187, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565474, 54.492732, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5655138 54.4927385, 9.5654703 54.4927564, 9.5654337 54.4927262, 9.5654772 54.4927083, 9.5655138 54.4927385))', 8307),
    -274.485, -186.087, 4.73, -144.81, 1.03, 1.15, 0.883, 1770838505800349244, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 188, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565926, 54.492788, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5658896 54.4927521, 9.5659693 54.4927549, 9.5659621 54.492824, 9.5658824 54.4928212, 9.5658896 54.4927521))', 8307),
    -245.191, -192.288, 3.91, -3.47, 0.856, 1.15, 0.772, 2081337399035210304, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 189, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565907, 54.492872, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5658813 54.4928465, 9.5659368 54.4928485, 9.5659318 54.4928969, 9.5658763 54.492895, 9.5658813 54.4928465))', 8307),
    -246.439, -201.6, 4.05, -3.47, 0.9, 0.9, 0.772, -7467272430979903354, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 190, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565932, 54.492613, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.565973 54.4926655, 9.5658843 54.4926636, 9.5658908 54.4925614, 9.5659795 54.4925633, 9.565973 54.4926655))', 8307),
    -244.8, -172.851, 3.95, 177.89, 0.949, 1.15, 0.771, 7164244995420408137, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 191, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565912, 54.492513, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5659385 54.4925375, 9.565883 54.4925363, 9.5658861 54.4924878, 9.5659416 54.492489, 9.5659385 54.4925375))', 8307),
    -246.068, -161.632, 4.07, 177.89, 0.9, 0.9, 0.771, -5788480225259973249, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 192, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56622, 54.492793, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5661921 54.4927525, 9.5662619 54.4927566, 9.5662488 54.492833, 9.566179 54.4928289, 9.5661921 54.4927525))', 8307),
    -226.099, -192.809, 3.55, -5.72, 0.95, 1.01, 0.716, -1139800080670661547, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 193, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566224, 54.492882, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5661793 54.4928952, 9.5661849 54.492863, 9.5662678 54.4928678, 9.5662623 54.4929, 9.5661793 54.4928952))', 8307),
    -225.896, -202.688, 3.51, 84.28, 0.9, 0.9, 0.716, 7272682231857128586, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 194, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566254, 54.492641, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5662832 54.4926779, 9.5662134 54.4926743, 9.5662239 54.4926048, 9.5662938 54.4926084, 9.5662832 54.4926779))', 8307),
    -223.954, -175.951, 3.58, 174.96, 0.863, 1.01, 0.903, 7664538954104221928, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 195, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566713, 54.492783, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5666239 54.4927637, 9.56669 54.4927292, 9.5668019 54.4928019, 9.5667358 54.4928364, 9.5666239 54.4927637))', 8307),
    -194.189, -191.696, 2.44, 41.88, 0.906, 1.15, 0.513, -1851094681212379758, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 196, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566826, 54.492854, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5667917 54.4928504, 9.5668228 54.4928342, 9.5668599 54.4928583, 9.5668288 54.4928745, 9.5667917 54.4928504))', 8307),
    -186.873, -199.66, 2.42, 41.88, 0.9, 0.9, 0.513, 5977550264373195306, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 197, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566506, 54.492635, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5666007 54.4926649, 9.5665304 54.4926965, 9.5664104 54.4926059, 9.5664806 54.4925744, 9.5666007 54.4926649))', 8307),
    -207.627, -175.295, 2.98, -142.35, 1.061, 1.15, 0.586, 475521723546197600, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 198, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566718, 54.492553, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5667895 54.4925962, 9.5667054 54.4926127, 9.5666461 54.4925101, 9.5667302 54.4924936, 9.5667895 54.4925962))', 8307),
    -193.87, -166.133, 2.71, -161.4, 1.004, 1.15, 0.916, -5491830532468764745, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 199, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567003, 54.492706, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5669785 54.4926853, 9.5670316 54.4926873, 9.567027 54.4927273, 9.5669739 54.4927252, 9.5669785 54.4926853))', 8307),
    -175.407, -183.179, 2.34, -3.79, 1.114, 1.15, 0.91, -526971480798955722, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 200, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567016, 54.492553, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5670493 54.4925983, 9.5669697 54.4925944, 9.5669822 54.4925077, 9.5670618 54.4925115, 9.5670493 54.4925983))', 8307),
    -174.566, -166.115, 2.42, 175.24, 1.077, 1.15, 0.521, 3663517120312582576, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 201, 'Uferhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'UFERHAUS'), 'Uferhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567373, 54.492712, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5672726 54.4926526, 9.5673255 54.4926336, 9.5674726 54.4927722, 9.5674197 54.4927912, 9.5672726 54.4926526))', 8307),
    -151.441, -183.86, 1.88, 31.71, 1.067, 1.15, 0.789, 4839348127204949209, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 202, 'Uferhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'UFERHAUS'), 'Uferhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56763, 54.492606, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5675968 54.492519, 9.567659 54.4925186, 9.5676624 54.4926938, 9.5676003 54.4926943, 9.5675968 54.492519))', 8307),
    -134.786, -172.062, 1.58, 0.66, 1.148, 1.15, 0.578, -5173102150494465036, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 203, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567624, 54.492397, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5676576 54.4924344, 9.5675877 54.4924334, 9.5675908 54.49236, 9.5676607 54.492361, 9.5676576 54.4924344))', 8307),
    -135.139, -148.775, 2.01, -181.4, 0.907, 1.007, 0.731, -7073593853477809698, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 204, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567923, 54.492576, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5678938 54.4925317, 9.5679727 54.4925387, 9.5679513 54.4926203, 9.5678723 54.4926132, 9.5678938 54.4925317))', 8307),
    -115.807, -168.672, 1.57, -8.71, 1.02, 1.15, 0.486, -3056420577486131575, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 205, 'Schmiede', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schmiede',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562282, 54.493058, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5622941 54.4930218, 9.5623439 54.4930512, 9.5622698 54.4930937, 9.56222 54.4930642, 9.5622941 54.4930218))', 8307),
    -481.309, -222.321, 15.02, -45.45, 1.123, 1.15, 0.618, 6564589814886001148, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 206, 'Schmiede', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schmiede',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562623, 54.493038, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5626145 54.4930729, 9.5625639 54.4930439, 9.5626323 54.4930034, 9.562683 54.4930323, 9.5626145 54.4930729))', 8307),
    -459.18, -220.138, 14.13, 135.52, 1.055, 1.15, 0.689, -5301414282548995959, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 207, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562703, 54.492985, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5626986 54.493005, 9.5626689 54.492988, 9.5627078 54.4929649, 9.5627375 54.4929819, 9.5626986 54.493005))', 8307),
    -454.01, -214.222, 14.06, 135.52, 0.9, 0.9, 0.689, -6209926501543071469, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 208, 'Bronzegießer', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Bronzegießer',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562713, 54.493262, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5627117 54.4932379, 9.5627538 54.4932569, 9.5627146 54.4932863, 9.5626725 54.4932673, 9.5627117 54.4932379))', 8307),
    -453.365, -245.071, 14.22, -37.74, 1.036, 1.15, 0.571, 1176598064044964547, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 209, 'Bronzegießer', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Bronzegießer',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.5631, 54.493404, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5630926 54.4933803, 9.5631391 54.4933953, 9.5631083 54.4934276, 9.5630617 54.4934126, 9.5630926 54.4933803))', 8307),
    -428.267, -260.858, 13.93, -29.04, 1.028, 1.15, 0.464, 7557782567301940920, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 210, 'Glasmacher', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Glasmacher',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563206, 54.493297, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5632123 54.493322, 9.5631661 54.4933066, 9.5632003 54.493272, 9.5632465 54.4932874, 9.5632123 54.493322))', 8307),
    -421.407, -248.952, 13.65, 150.11, 1.11, 1.15, 0.703, -567664918686880986, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 211, 'Glasmacher', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Glasmacher',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563262, 54.493457, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5632506 54.4934345, 9.5632985 54.4934482, 9.5632728 54.4934787, 9.563225 54.493465, 9.5632506 54.4934345))', 8307),
    -417.815, -266.717, 14.23, -26.1, 0.945, 1.15, 0.458, -3386143701948370263, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 212, 'Schmiede', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schmiede',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563428, 54.493508, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5634046 54.4934743, 9.563474 54.4934829, 9.5634524 54.4935414, 9.563383 54.4935327, 9.5634046 54.4934743))', 8307),
    -407.009, -272.418, 13.89, -12.13, 1.109, 1.15, 0.547, 2087123903028485803, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 213, 'Bronzegießer', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Bronzegießer',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563487, 54.49338, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.563507 54.4934013, 9.5634548 54.493395, 9.5634678 54.4933585, 9.5635199 54.4933648, 9.563507 54.4934013))', 8307),
    -403.193, -258.179, 13.54, 168.31, 1.036, 1.15, 0.621, -210546353660313836, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 214, 'Schmiede', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schmiede',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563754, 54.493554, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5637246 54.4935272, 9.5637949 54.4935331, 9.5637832 54.4935803, 9.5637129 54.4935744, 9.5637246 54.4935272))', 8307),
    -385.92, -277.525, 12.76, -8.19, 0.885, 1.15, 0.871, 1569853733827567439, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 215, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563733, 54.493618, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5637022 54.4936274, 9.5637082 54.4936034, 9.5637632 54.493608, 9.5637572 54.493632, 9.5637022 54.4936274))', 8307),
    -387.294, -284.644, 12.93, 81.81, 0.9, 0.9, 0.871, 1416729690611773412, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 216, 'Glasmacher', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Glasmacher',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564028, 54.493556, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5639849 54.493536, 9.5640544 54.4935276, 9.5640717 54.4935761, 9.5640021 54.4935845, 9.5639849 54.493536))', 8307),
    -368.143, -277.784, 11.98, 11.71, 0.918, 1.15, 0.89, -879641291452312836, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 217, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564028, 54.49363, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5639933 54.4936512, 9.563982 54.4936196, 9.5640636 54.4936097, 9.5640749 54.4936414, 9.5639933 54.4936512))', 8307),
    -368.131, -286.069, 12.11, 101.71, 0.9, 0.9, 0.89, -8411576750577015217, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 218, 'Bronzegießer', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Bronzegießer',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56398, 54.493426, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5640108 54.4934396, 9.5639583 54.4934448, 9.5639491 54.4934128, 9.5640015 54.4934077, 9.5640108 54.4934396))', 8307),
    -371.276, -263.331, 11.81, -170.4, 0.901, 1.15, 0.844, 1913325795231373320, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 219, 'Glasmacher', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Glasmacher',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564217, 54.4935, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.564162 54.4934897, 9.5642186 54.4934662, 9.5642727 54.4935102, 9.5642161 54.4935337, 9.564162 54.4934897))', 8307),
    -355.891, -271.538, 11.15, 35.59, 1.004, 1.127, 0.627, -8914194139839836176, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 220, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564422, 54.493431, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5643554 54.4933831, 9.5644412 54.4933701, 9.5644895 54.4934782, 9.5644036 54.4934912, 9.5643554 54.4933831))', 8307),
    -342.604, -263.822, 9.95, 14.58, 1.035, 1.15, 0.717, -4520994555640955503, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 221, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564363, 54.493258, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.564396 54.4932698, 9.5643445 54.4932776, 9.5643308 54.493247, 9.5643823 54.4932392, 9.564396 54.4932698))', 8307),
    -346.431, -244.65, 9.69, -165.36, 0.88, 1.15, 0.509, 3369866290419947917, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 222, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564894, 54.493512, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5648241 54.4934611, 9.5649056 54.4934471, 9.5649642 54.4935625, 9.5648828 54.4935765, 9.5648241 54.4934611))', 8307),
    -312.035, -272.852, 7.61, 16.48, 1.116, 1.101, 0.624, 2525938680495810158, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 223, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564812, 54.493322, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5648743 54.4933648, 9.564792 54.4933771, 9.5647487 54.4932791, 9.564831 54.4932668, 9.5648743 54.4933648))', 8307),
    -317.394, -251.721, 7.44, -165.58, 0.939, 1.101, 0.809, 764009397912840679, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 224, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565107, 54.493413, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5650304 54.493404, 9.5650838 54.4933694, 9.5651828 54.4934211, 9.5651295 54.4934557, 9.5650304 54.493404))', 8307),
    -298.269, -261.807, 6.3, 48.11, 0.958, 1.15, 0.879, -1662406745515599943, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 225, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565423, 54.493301, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.565366 54.4932532, 9.5654423 54.4932439, 9.5654798 54.493348, 9.5654035 54.4933573, 9.565366 54.4932532))', 8307),
    -277.776, -249.34, 4.68, 11.83, 0.986, 1.01, 0.606, -2863994376591694038, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 226, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565479, 54.493402, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.565443 54.493382, 9.5654974 54.4933754, 9.5655145 54.4934229, 9.5654601 54.4934295, 9.565443 54.493382))', 8307),
    -274.157, -260.68, 4.71, 11.83, 0.9, 0.9, 0.606, -1399012615180917582, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 227, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565365, 54.493146, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5653969 54.4931633, 9.5653443 54.4931679, 9.5653339 54.4931277, 9.5653865 54.4931231, 9.5653969 54.4931633))', 8307),
    -281.503, -232.076, 4.74, -171.42, 1.132, 1.15, 0.472, 4009589131948231143, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 228, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565648, 54.493266, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.565555 54.4932296, 9.5656297 54.4932016, 9.5657409 54.4933024, 9.5656663 54.4933303, 9.565555 54.4932296))', 8307),
    -263.191, -245.484, 3.97, 32.74, 1.111, 1.15, 0.862, -8476056495627736761, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 229, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565761, 54.493347, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.565715 54.4933351, 9.5657617 54.4933176, 9.5658068 54.4933584, 9.56576 54.4933759, 9.565715 54.4933351))', 8307),
    -255.877, -254.48, 3.79, 32.74, 0.9, 0.9, 0.862, 7371715340889449961, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 230, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565653, 54.493062, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5656883 54.4930704, 9.5656397 54.493083, 9.5656178 54.4930543, 9.5656664 54.4930417, 9.5656883 54.4930704))', 8307),
    -262.866, -222.822, 4.29, -156.03, 0.874, 1.15, 0.786, -8817973374634790151, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 231, 'Hof eines reichen Händlers', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'HALLE'), 'Hof eines reichen Händlers',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565939, 54.493199, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5658752 54.4931289, 9.5659994 54.4931279, 9.5660028 54.4932699, 9.5658786 54.4932709, 9.5658752 54.4931289))', 8307),
    -244.333, -238.073, 3.57, 0.8, 0.903, 1.15, 0.595, 5468370136632645010, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 232, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566231, 54.493153, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5661898 54.4931118, 9.5662697 54.4931111, 9.5662717 54.4931941, 9.5661919 54.4931948, 9.5661898 54.4931118))', 8307),
    -225.428, -232.905, 3.27, 0.83, 1.027, 1.15, 0.66, 2313635550310661443, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 233, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566479, 54.493177, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5664331 54.4931183, 9.5665219 54.4931177, 9.5665245 54.4932347, 9.5664358 54.4932354, 9.5664331 54.4931183))', 8307),
    -209.354, -235.524, 2.75, 0.77, 1.086, 1.15, 0.525, -3637021688511870127, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 234, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566519, 54.493277, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5664914 54.4932891, 9.5664908 54.4932648, 9.5665464 54.4932644, 9.566547 54.4932886, 9.5664914 54.4932891))', 8307),
    -206.758, -246.678, 2.56, 90.77, 0.9, 0.9, 0.525, -211225216735219078, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 235, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.5668, 54.493085, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5667085 54.493066, 9.5667735 54.4930308, 9.5668913 54.4931048, 9.5668263 54.4931399, 9.5667085 54.493066))', 8307),
    -188.55, -225.377, 2.21, 42.85, 0.935, 1.15, 0.453, -5058102174369878498, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 236, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566634, 54.492983, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5666736 54.4929834, 9.5666368 54.4930058, 9.5665945 54.4929822, 9.5666313 54.4929598, 9.5666736 54.4929834))', 8307),
    -199.296, -213.96, 2.6, -133.72, 0.947, 1.15, 0.693, -2455307910538861376, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 237, 'Uferhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'UFERHAUS'), 'Uferhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567126, 54.49309, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.567071 54.49301, 9.5671322 54.4930039, 9.5671813 54.4931708, 9.5671201 54.4931769, 9.567071 54.49301))', 8307),
    -167.411, -225.938, 1.85, 9.72, 1.109, 1.15, 0.901, 3190619943906176119, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 238, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567067, 54.492912, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5670999 54.4929283, 9.5670475 54.4929339, 9.567035 54.4928947, 9.5670874 54.4928891, 9.5670999 54.4929283))', 8307),
    -171.215, -206.024, 2.15, -169.47, 1.109, 1.15, 0.659, 2444127230021519330, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 239, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56723, 54.492841, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5673053 54.4928575, 9.5672439 54.4928872, 9.567155 54.4928251, 9.5672163 54.4927953, 9.5673053 54.4928575))', 8307),
    -160.672, -198.206, 1.98, -140.19, 1, 1.15, 0.819, -5416664937436142927, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 240, 'Bronzegießer', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Bronzegießer',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562376, 54.493256, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5623763 54.4932804, 9.5623348 54.493261, 9.5623757 54.4932314, 9.5624172 54.4932509, 9.5623763 54.4932804))', 8307),
    -475.211, -244.386, 14.97, 141.14, 1.056, 1.15, 0.728, 2399628897795135905, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 241, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562728, 54.493392, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5626966 54.4934391, 9.5626455 54.4934064, 9.5627598 54.4933459, 9.5628109 54.4933785, 9.5626966 54.4934391))', 8307),
    -452.387, -259.582, 14.45, 132.31, 1.113, 1.093, 0.93, -3586535456508116318, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 242, 'Glasmacher', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Glasmacher',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563793, 54.493736, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5638182 54.4937658, 9.5637501 54.4937579, 9.563768 54.4937055, 9.5638361 54.4937134, 9.5638182 54.4937658))', 8307),
    -383.381, -297.777, 13.19, 168.76, 0.991, 1.126, 0.451, 1784986038960848992, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 243, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563803, 54.493667, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5638184 54.4936848, 9.5637775 54.49368, 9.5637884 54.4936483, 9.5638292 54.493653, 9.5638184 54.4936848))', 8307),
    -382.715, -290.083, 12.9, 168.76, 0.9, 0.9, 0.451, 4359949416314878497, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 244, 'Glasmacher', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Glasmacher',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564039, 54.493757, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.564089 54.4937785, 9.5640218 54.4937919, 9.5639892 54.4937363, 9.5640563 54.4937229, 9.564089 54.4937785))', 8307),
    -367.442, -300.196, 12.49, -161.13, 1.089, 1.15, 0.662, -9030338064798426154, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 245, 'Schmiede', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schmiede',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564378, 54.493766, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5643256 54.4937605, 9.5643809 54.4937346, 9.5644311 54.4937708, 9.5643759 54.4937968, 9.5643256 54.4937605))', 8307),
    -345.456, -301.117, 11.32, 38.9, 0.864, 1.15, 0.687, -7686070405085541505, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 246, 'Glasmacher', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Glasmacher',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56423, 54.493664, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5642903 54.4936751, 9.5642347 54.4937009, 9.5641705 54.4936538, 9.564226 54.4936281, 9.5642903 54.4936751))', 8307),
    -355.047, -289.851, 11.56, -141.49, 1.115, 1.15, 0.767, 1214359115296028861, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 247, 'Bronzegießer', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Bronzegießer',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564507, 54.493616, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5645211 54.4936368, 9.5644717 54.4936253, 9.5644929 54.4935946, 9.5645423 54.4936062, 9.5645211 54.4936368))', 8307),
    -337.123, -284.424, 10.2, 158.08, 0.919, 1.15, 0.774, 1438355492278290414, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 248, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564761, 54.493833, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5647367 54.4938155, 9.5647898 54.4938176, 9.5647861 54.4938503, 9.564733 54.4938483, 9.5647367 54.4938155))', 8307),
    -320.635, -308.6, 9.82, -3.78, 0.913, 1.15, 0.743, -7488489792800044642, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 249, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565037, 54.493851, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5649399 54.4938211, 9.5650097 54.4937892, 9.5651335 54.4938811, 9.5650637 54.493913, 9.5649399 54.4938211))', 8307),
    -302.799, -310.621, 8.47, 38.11, 1.083, 1.15, 0.663, -7433598800804423559, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 250, 'Glasmacher', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Glasmacher',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564859, 54.493711, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5649156 54.4937209, 9.5648582 54.4937452, 9.5648023 54.4937004, 9.5648597 54.4936761, 9.5649156 54.4937209))', 8307),
    -314.315, -294.987, 8.71, -144.04, 1.028, 1.15, 0.572, -7072073216144350732, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 251, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565219, 54.493734, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651179 54.4937212, 9.5651724 54.4936804, 9.5653201 54.4937473, 9.5652656 54.493788, 9.5651179 54.4937212))', 8307),
    -290.984, -297.61, 6.91, 52.12, 1.01, 1.15, 0.807, 5907057180937321403, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 252, 'Bronzegießer', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Bronzegießer',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564983, 54.493631, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5650208 54.4936294, 9.5649862 54.493653, 9.5649447 54.4936324, 9.5649793 54.4936088, 9.5650208 54.4936294))', 8307),
    -306.294, -286.111, 7.59, -130.51, 0.883, 1.15, 0.579, 4592176647437762806, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 253, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565201, 54.493511, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5652352 54.4935261, 9.5651836 54.4935338, 9.5651673 54.4934966, 9.5652189 54.4934889, 9.5652352 54.4935261))', 8307),
    -292.137, -272.802, 6.1, -165.68, 1.069, 1.15, 0.693, 3259273827846750843, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 254, 'Hof eines reichen Händlers', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'HALLE'), 'Hof eines reichen Händlers',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565571, 54.493665, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5654649 54.4936107, 9.5655446 54.4935842, 9.565677 54.4937192, 9.5655973 54.4937457, 9.5654649 54.4936107))', 8307),
    -268.181, -289.894, 5.18, 29.73, 0.989, 0.85, 0.48, -4837351917222738044, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 255, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566016, 54.493488, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5659676 54.4934426, 9.5660498 54.4934381, 9.5660649 54.4935325, 9.5659827 54.4935369, 9.5659676 54.4934426))', 8307),
    -239.328, -270.147, 3.38, 5.32, 0.879, 1.07, 0.729, 3305330709639706687, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 256, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566235, 54.493496, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5661893 54.4934369, 9.5662753 54.4934354, 9.5662815 54.4935544, 9.5661955 54.4935559, 9.5661893 54.4934369))', 8307),
    -225.127, -271.053, 2.85, 1.75, 1.104, 1.116, 0.489, -1327736759943087149, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 257, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566252, 54.493605, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5662232 54.4935808, 9.5662788 54.4935798, 9.5662813 54.4936283, 9.5662258 54.4936293, 9.5662232 54.4935808))', 8307),
    -224.034, -283.168, 2.84, 1.75, 0.9, 0.9, 0.489, -1652730177840466355, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 258, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566239, 54.493321, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5662794 54.4933596, 9.5661995 54.49336, 9.5661984 54.4932819, 9.5662782 54.4932815, 9.5662794 54.4933596))', 8307),
    -224.902, -251.586, 2.88, 180.49, 0.966, 1.15, 0.472, 5515914440349685990, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 259, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566824, 54.493368, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5667865 54.4933547, 9.5668362 54.4933435, 9.5668612 54.4933812, 9.5668116 54.4933924, 9.5667865 54.4933547))', 8307),
    -186.995, -256.832, 2.01, 21.2, 1.123, 1.15, 0.507, -4810684492880483899, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 260, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566717, 54.493212, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5667851 54.4932425, 9.5667126 54.493262, 9.5666492 54.4931822, 9.5667217 54.4931627, 9.5667851 54.4932425))', 8307),
    -193.912, -239.512, 2.29, -155.18, 1.087, 1.15, 0.497, -9164763621326512765, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 261, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56702, 54.493225, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5670447 54.4932463, 9.5669915 54.4932448, 9.5669949 54.493204, 9.567048 54.4932055, 9.5670447 54.4932463))', 8307),
    -174.303, -240.937, 1.91, 177.25, 1.136, 1.15, 0.564, -3349153641071030948, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 262, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565143, 54.494104, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651028 54.4941061, 9.5651336 54.4940808, 9.565184 54.4941016, 9.5651533 54.4941269, 9.5651028 54.4941061))', 8307),
    -295.88, -338.754, 9.54, 54.72, 1.001, 1.15, 0.711, -5363451382425886279, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 263, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564949, 54.494019, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5649914 54.494017, 9.5649624 54.494043, 9.5649061 54.4940217, 9.564935 54.4939957, 9.5649914 54.494017))', 8307),
    -308.497, -329.353, 10, -122.96, 1.088, 1.15, 0.87, -5554203119063479970, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 264, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565277, 54.49401, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5652115 54.4939791, 9.5652851 54.493961, 9.5653425 54.4940403, 9.5652688 54.4940583, 9.5652115 54.4939791))', 8307),
    -287.226, -328.271, 8.26, 22.83, 1.064, 1.15, 0.504, 5870452005642770892, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 265, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565327, 54.494102, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5652994 54.4941266, 9.5652778 54.4940968, 9.5653546 54.494078, 9.5653762 54.4941078, 9.5652994 54.4941266))', 8307),
    -283.984, -338.584, 8.68, 112.83, 0.9, 0.9, 0.504, 8887900518339673021, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 266, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565526, 54.493955, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5654869 54.4939445, 9.5655341 54.4939303, 9.565566 54.4939659, 9.5655187 54.4939802, 9.5654869 54.4939445))', 8307),
    -271.063, -322.21, 6.7, 27.46, 1.118, 1.15, 0.534, 6946157559513195163, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 267, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.5663, 54.49384, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5662677 54.4937764, 9.5663558 54.4937824, 9.5663315 54.4939039, 9.5662434 54.4938979, 9.5662677 54.4937764))', 8307),
    -220.966, -309.398, 2.8, -6.64, 1.135, 1.15, 0.697, 1312677814838567023, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 268, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566467, 54.493636, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5665013 54.4936922, 9.5664262 54.4936908, 9.5664326 54.4935799, 9.5665077 54.4935814, 9.5665013 54.4936922))', 8307),
    -210.123, -286.68, 2.35, -181.93, 1.029, 0.974, 0.629, 523066822492593727, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 269, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566693, 54.49378, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5666552 54.4937774, 9.5666973 54.4937584, 9.5667301 54.4937831, 9.566688 54.493802, 9.5666552 54.4937774))', 8307),
    -195.497, -302.727, 1.91, 37.79, 0.867, 1.15, 0.635, 8409362820773428573, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 270, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566808, 54.49371, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5667733 54.4937014, 9.5668229 54.4936903, 9.566842 54.4937189, 9.5667923 54.4937301, 9.5667733 54.4937014))', 8307),
    -188.046, -294.927, 1.7, 21.17, 0.855, 1.15, 0.914, -8059826310426260776, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 271, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566735, 54.493579, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5667972 54.4936133, 9.5667216 54.4936282, 9.5666732 54.4935454, 9.5667488 54.4935304, 9.5667972 54.4936133))', 8307),
    -192.741, -280.364, 1.94, -161.24, 1.082, 1.15, 0.761, -5913416163451959066, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 272, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566674, 54.493502, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5667025 54.4935135, 9.566663 54.4935213, 9.5666451 54.4934906, 9.5666846 54.4934828, 9.5667025 54.4935135))', 8307),
    -196.719, -271.761, 2.05, -161.24, 0.9, 0.9, 0.761, 2809392623242831251, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 273, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56555, 54.494096, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5656162 54.4941161, 9.5655573 54.4941394, 9.5654832 54.494076, 9.5655421 54.4940527, 9.5656162 54.4941161))', 8307),
    -269.556, -337.885, 7.46, -145.75, 0.948, 1.026, 0.509, 4553098069280841287, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 274, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566331, 54.494038, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5663503 54.494059, 9.5662984 54.4940522, 9.566312 54.494017, 9.5663639 54.4940238, 9.5663503 54.494059))', 8307),
    -218.92, -331.417, 2.93, 167.33, 1.004, 1.15, 0.601, -1045332697428645437, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 275, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566531, 54.494031, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5666266 54.494058, 9.5665581 54.4940909, 9.5664358 54.4940046, 9.5665043 54.4939718, 9.5666266 54.494058))', 8307),
    -205.957, -330.678, 2.16, -140.46, 1.037, 1.15, 0.659, 8149817159182138902, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 276, 'Hof eines reichen Händlers', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'HALLE'), 'Hof eines reichen Händlers',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566726, 54.493927, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.566814 54.4939979, 9.5666922 54.4940121, 9.5666383 54.4938557, 9.5667601 54.4938415, 9.566814 54.4939979))', 8307),
    -193.326, -319.044, 1.59, -168.66, 1.014, 1.15, 0.748, 7436939670411309731, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 277, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561331, 54.490572, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5613155 54.4905495, 9.561366 54.4905593, 9.5613459 54.4905946, 9.5612954 54.4905849, 9.5613155 54.4905495))', 8307),
    -542.98, 54.358, 13.72, -18.31, 1.037, 1.15, 0.804, -2261943953130384564, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 278, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56149, 54.490626, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5614679 54.490581, 9.5615455 54.4905922, 9.5615119 54.4906715, 9.5614344 54.4906604, 9.5614679 54.490581))', 8307),
    -532.66, 48.329, 14.07, -13.84, 1.01, 1.15, 0.733, -626340947539957664, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 279, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561641, 54.490625, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5616292 54.4906033, 9.561677 54.490617, 9.5616521 54.4906465, 9.5616043 54.4906329, 9.5616292 54.4906033))', 8307),
    -522.893, 48.478, 14.45, -26.12, 0.915, 1.15, 0.701, 4838169816433840901, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 280, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561753, 54.490471, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5617634 54.4905263, 9.5616807 54.4905075, 9.5617421 54.4904161, 9.5618247 54.4904349, 9.5617634 54.4905263))', 8307),
    -515.632, 65.589, 14.95, 158.67, 0.91, 1.15, 0.706, 8460125023627879091, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 281, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561834, 54.490381, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5618827 54.4903747, 9.5618624 54.4904048, 9.5617848 54.4903872, 9.561805 54.490357, 9.5618827 54.4903747))', 8307),
    -510.383, 75.641, 15.11, 248.67, 0.9, 0.9, 0.706, -3919093650483711014, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 282, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561868, 54.490717, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5618487 54.4906585, 9.5619345 54.4906716, 9.5618873 54.490776, 9.5618015 54.4907629, 9.5618487 54.4906585))', 8307),
    -508.162, 38.204, 14.14, -14.74, 1.001, 1.15, 0.688, -8901758517069738295, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 283, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561966, 54.49052, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5619754 54.4905843, 9.5618912 54.490568, 9.5619561 54.4904549, 9.5620403 54.4904712, 9.5619754 54.4905843))', 8307),
    -501.826, 60.205, 14.86, 161.53, 1.106, 1.15, 0.809, 7109056541855626272, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 284, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562039, 54.49042, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5620502 54.4904396, 9.5620107 54.4904319, 9.5620283 54.4904012, 9.5620678 54.4904089, 9.5620502 54.4904396))', 8307),
    -497.067, 71.244, 15.04, 161.53, 0.9, 0.9, 0.809, 1420704388305377921, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 285, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56207, 54.490747, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5620692 54.4907031, 9.5621378 54.4907269, 9.5620716 54.4907913, 9.5620031 54.4907674, 9.5620692 54.4907031))', 8307),
    -495.041, 34.873, 14, -30.9, 0.928, 1.15, 0.729, -4689184473917114945, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 286, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562244, 54.490584, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.562235 54.4906452, 9.562158 54.4906196, 9.5622523 54.4905235, 9.5623294 54.4905491, 9.562235 54.4906452))', 8307),
    -483.816, 53.001, 14.77, 150.28, 1.027, 1.15, 0.63, 4835446894068009667, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 287, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562549, 54.49076, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5625315 54.4908047, 9.5624745 54.4907746, 9.5625656 54.4907161, 9.5626226 54.4907462, 9.5625315 54.4908047))', 8307),
    -464.055, 33.407, 14.06, 137.78, 0.976, 1.108, 0.884, -5276121979479248648, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 288, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562655, 54.490698, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5627044 54.4907026, 9.5626671 54.4907265, 9.5626054 54.4906939, 9.5626427 54.49067, 9.5627044 54.4907026))', 8307),
    -457.165, 40.322, 14.58, 227.78, 0.9, 0.9, 0.884, 5790148022694989929, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 289, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562551, 54.490954, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5625557 54.4909305, 9.5625909 54.4909538, 9.5625455 54.4909771, 9.5625103 54.4909538, 9.5625557 54.4909305))', 8307),
    -463.923, 11.875, 12.73, -48.59, 0.981, 1.15, 0.466, 5692339309070165211, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 290, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562692, 54.490873, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5626872 54.4908967, 9.5626507 54.4908741, 9.5626975 54.4908485, 9.562734 54.4908711, 9.5626872 54.4908967))', 8307),
    -454.737, 20.919, 13.58, 133.22, 1.041, 1.15, 0.888, 7858930480816821783, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 291, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562839, 54.491129, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5628395 54.4910735, 9.5629174 54.4910982, 9.5628376 54.4911835, 9.5627597 54.4911588, 9.5628395 54.4910735))', 8307),
    -445.26, -7.571, 11.95, -28.57, 0.901, 1.15, 0.879, 4032715930003917160, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 292, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562997, 54.490982, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5630029 54.4910233, 9.5629335 54.4910004, 9.5629917 54.4909405, 9.5630612 54.4909635, 9.5630029 54.4910233))', 8307),
    -434.972, 8.749, 13.03, 150.45, 0.851, 1.15, 0.519, 4677848566109263869, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 293, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563019, 54.491157, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5630139 54.4911348, 9.563057 54.491153, 9.5630237 54.4911796, 9.5629806 54.4911614, 9.5630139 54.4911348))', 8307),
    -433.579, -10.762, 11.95, -36, 0.917, 1.15, 0.847, -1114451220218486628, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 294, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563168, 54.491035, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5631515 54.4910937, 9.5630791 54.4910639, 9.563185 54.4909768, 9.5632574 54.4910067, 9.5631515 54.4910937))', 8307),
    -423.896, 2.811, 12.73, 144.71, 0.99, 1.15, 0.901, -6055840045075626816, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 295, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563222, 54.491285, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5632311 54.491237, 9.5632965 54.4912637, 9.5632123 54.4913337, 9.5631469 54.4913071, 9.5632311 54.491237))', 8307),
    -420.43, -25.03, 11.35, -34.99, 1.058, 1.15, 0.451, 4910547230017222247, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 296, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563125, 54.491355, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5631262 54.491326, 9.5631717 54.4913445, 9.5631239 54.4913843, 9.5630784 54.4913657, 9.5631262 54.491326))', 8307),
    -426.695, -32.795, 10.68, -34.99, 0.9, 0.9, 0.451, 7662782658618112963, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 297, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563418, 54.491315, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.563406 54.4912914, 9.5634551 54.4913035, 9.5634293 54.491339, 9.5633802 54.491327, 9.563406 54.4912914))', 8307),
    -407.734, -28.352, 11.04, -22.89, 1.074, 1.15, 0.766, -5086607957635580626, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 298, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563829, 54.491395, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.563805 54.4913745, 9.563858 54.4913771, 9.5638524 54.4914165, 9.5637993 54.4914139, 9.563805 54.4913745))', 8307),
    -381.097, -37.28, 9.56, -4.76, 1.1, 1.15, 0.82, -3512292840197412645, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 299, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563872, 54.491223, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5638976 54.4912856, 9.5638104 54.4912762, 9.5638469 54.4911608, 9.5639342 54.4911701, 9.5638976 54.4912856))', 8307),
    -378.272, -18.103, 10.91, 169.56, 1.089, 1.15, 0.785, -1621806479691959250, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 300, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564101, 54.491254, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5641421 54.4912586, 9.5641006 54.491278, 9.5640604 54.4912488, 9.5641019 54.4912294, 9.5641421 54.4912586))', 8307),
    -363.435, -21.499, 9.88, -141.27, 1.04, 1.15, 0.902, 6631690766045078873, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 301, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564365, 54.491133, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5643977 54.4911486, 9.5643455 54.4911547, 9.5643327 54.4911176, 9.5643849 54.4911115, 9.5643977 54.4911486))', 8307),
    -346.332, -8.075, 10.06, -168.68, 1.052, 1.15, 0.929, -3838095123565563010, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 302, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56515, 54.491265, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.565045 54.4912572, 9.5650926 54.4912136, 9.5652546 54.4912734, 9.5652071 54.4913171, 9.565045 54.4912572))', 8307),
    -295.485, -22.788, 6.72, 57.62, 1.036, 1.15, 0.825, -4324520047375493977, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 303, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565275, 54.490942, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5653415 54.4909831, 9.5652563 54.4909975, 9.5652082 54.4909013, 9.5652934 54.4908868, 9.5653415 54.4909831))', 8307),
    -287.387, 13.186, 8.92, -163.79, 0.93, 1.15, 0.701, 1866984534251501497, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 304, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565459, 54.490919, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5655344 54.4909347, 9.5654731 54.4909646, 9.5653839 54.4909025, 9.5654451 54.4908726, 9.5655344 54.4909347))', 8307),
    -275.444, 15.808, 8.66, -140.08, 1.002, 1.15, 0.481, 6712681150500125469, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 305, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565611, 54.49082, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5656908 54.49085, 9.5656132 54.490875, 9.5655321 54.4907898, 9.5656097 54.4907648, 9.5656908 54.49085))', 8307),
    -265.574, 26.798, 8.95, -151.01, 0.904, 1.15, 0.709, -7964155744085685159, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 306, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566085, 54.490936, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5660443 54.4908806, 9.5661329 54.4908827, 9.5661256 54.4909906, 9.5660369 54.4909886, 9.5660443 54.4908806))', 8307),
    -234.892, 13.916, 6.85, -2.28, 1.002, 1.15, 0.836, -1794106978483272501, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 307, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566087, 54.491031, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5660579 54.4910424, 9.5660596 54.4910182, 9.5661151 54.4910195, 9.5661134 54.4910437, 9.5660579 54.4910424))', 8307),
    -234.789, 3.304, 6.24, 87.72, 0.9, 0.9, 0.836, 1099059894804612475, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 308, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566082, 54.490762, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5661259 54.4907953, 9.5660462 54.4907987, 9.5660376 54.4907291, 9.5661172 54.4907258, 9.5661259 54.4907953))', 8307),
    -235.101, 33.218, 8.07, -175.85, 0.862, 1.15, 0.865, 6822311159528853147, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 309, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566299, 54.490938, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5662714 54.4908922, 9.5663502 54.4908999, 9.5663263 54.4909831, 9.5662476 54.4909754, 9.5662714 54.4908922))', 8307),
    -221.028, 13.692, 6.54, -9.46, 1.043, 1.15, 0.679, -5798407452171999486, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 310, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566333, 54.490748, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5663654 54.4908082, 9.5662773 54.490802, 9.5663009 54.4906877, 9.566389 54.4906938, 9.5663654 54.4908082))', 8307),
    -218.808, 34.81, 7.25, 173.16, 1.068, 1.15, 0.684, 6929738338449212461, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 311, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566872, 54.490676, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5668967 54.490728, 9.5668197 54.4907203, 9.5668481 54.4906244, 9.566925 54.4906321, 9.5668967 54.490728))', 8307),
    -183.865, 42.796, 5.37, 170.24, 0.902, 1.012, 0.661, 4032337823073214844, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 312, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567092, 54.490868, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5670531 54.490829, 9.567133 54.4908294, 9.5671316 54.4909071, 9.5670518 54.4909066, 9.5670531 54.490829))', 8307),
    -169.607, 21.442, 4.24, -0.59, 0.961, 1.15, 0.786, 4972128190532990285, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 313, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567079, 54.490694, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5671315 54.4907437, 9.5670432 54.4907484, 9.567027 54.4906435, 9.5671153 54.4906389, 9.5671315 54.4907437))', 8307),
    -170.459, 40.856, 4.56, -174.85, 0.977, 1.15, 0.738, 3060718278301130524, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 314, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567073, 54.490601, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5670961 54.4906156, 9.5670546 54.4906177, 9.5670496 54.4905855, 9.5670911 54.4905834, 9.5670961 54.4906156))', 8307),
    -170.872, 51.217, 4.7, -174.85, 0.9, 0.9, 0.738, 3262530348115056209, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 315, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567319, 54.490854, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5672452 54.4908192, 9.5673158 54.4907986, 9.5673927 54.4908878, 9.567322 54.4909085, 9.5672452 54.4908192))', 8307),
    -154.928, 23.06, 3.75, 26.61, 0.926, 1.024, 0.82, -7603055190892015162, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 316, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567407, 54.490937, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5673821 54.4909621, 9.5673572 54.4909332, 9.5674317 54.4909115, 9.5674566 54.4909404, 9.5673821 54.4909621))', 8307),
    -149.227, 13.789, 3.63, 116.61, 0.9, 0.9, 0.82, 8715666969220175776, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 317, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567318, 54.490629, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5673857 54.4906616, 9.5673122 54.4906798, 9.5672507 54.4905961, 9.5673241 54.4905778, 9.5673857 54.4906616))', 8307),
    -154.977, 48.071, 4, -156.84, 1.127, 1.15, 0.769, 6055266657239423555, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 318, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567229, 54.490551, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5672705 54.4905667, 9.5672194 54.4905795, 9.5671867 54.4905349, 9.5672377 54.4905221, 9.5672705 54.4905667))', 8307),
    -160.782, 56.757, 4.32, -156.84, 0.9, 0.9, 0.769, -3025788183669945830, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 319, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567607, 54.490772, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5675803 54.4907181, 9.5676519 54.4907225, 9.5676332 54.4908258, 9.5675615 54.4908214, 9.5675803 54.4907181))', 8307),
    -136.277, 32.141, 3.42, -6.04, 0.963, 0.934, 0.572, -6938447298122550950, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 320, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567608, 54.490871, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5675845 54.4908456, 9.5676398 54.490849, 9.567631 54.4908973, 9.5675757 54.4908939, 9.5675845 54.4908456))', 8307),
    -136.211, 21.064, 3.42, -6.04, 0.9, 0.9, 0.572, -3459182372816667421, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 321, 'Uferhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'UFERHAUS'), 'Uferhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567832, 54.490587, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.567827 54.4906589, 9.5677675 54.4906484, 9.567837 54.4905148, 9.5678965 54.4905252, 9.567827 54.4906589))', 8307),
    -121.679, 52.747, 3.05, 163.17, 0.915, 1.15, 0.897, -1723315954790319382, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 322, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.5679, 54.490473, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5679146 54.4905013, 9.5678614 54.4904919, 9.5678855 54.4904455, 9.5679387 54.4904548, 9.5679146 54.4905013))', 8307),
    -117.269, 65.376, 3.23, 163.17, 0.9, 0.9, 0.897, 4571997064200909561, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 323, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568033, 54.490644, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5680581 54.4906887, 9.5679812 54.4906804, 9.5680072 54.490599, 9.568084 54.4906073, 9.5680581 54.4906887))', 8307),
    -108.677, 46.399, 2.72, 169.49, 1.025, 1.125, 0.894, 5681326024523409716, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 324, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568033, 54.490555, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5680531 54.490582, 9.5679985 54.4905761, 9.5680137 54.4905284, 9.5680683 54.4905343, 9.5680531 54.490582))', 8307),
    -108.627, 56.271, 2.63, 169.49, 0.9, 0.9, 0.894, 9038916669140314015, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 325, 'Uferhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'UFERHAUS'), 'Uferhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568667, 54.490608, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5687656 54.4906621, 9.5687139 54.4906821, 9.568568 54.4905546, 9.5686197 54.4905345, 9.5687656 54.4906621))', 8307),
    -67.582, 50.356, 2.4, -146.33, 1.003, 1.15, 0.67, -3417158415148833009, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 326, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562129, 54.490211, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5621388 54.4902324, 9.5620918 54.4902179, 9.5621184 54.4901888, 9.5621654 54.4902033, 9.5621388 54.4902324))', 8307),
    -491.276, 94.602, 15.11, 151.98, 0.918, 1.15, 0.68, -7125859156452039338, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 327, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562334, 54.490244, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.562322 54.490299, 9.5622494 54.4902693, 9.5623452 54.4901899, 9.5624178 54.4902196, 9.562322 54.490299))', 8307),
    -477.991, 90.832, 15.04, 144.91, 0.9, 1.15, 0.482, -2301906318289539892, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 328, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562615, 54.490452, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5626083 54.4904767, 9.5625718 54.4904541, 9.562622 54.4904267, 9.5626584 54.4904492, 9.5626083 54.4904767))', 8307),
    -459.745, 67.771, 15.13, 133.27, 1.115, 1.15, 0.701, 4661081691406892440, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 329, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562763, 54.490548, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5627603 54.4905732, 9.5627198 54.4905531, 9.5627648 54.4905224, 9.5628053 54.4905426, 9.5627603 54.4905732))', 8307),
    -450.192, 57.069, 15.02, 139.5, 1.121, 1.15, 0.888, -685748061493261217, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 330, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562893, 54.490631, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5628951 54.4906545, 9.5628539 54.4906349, 9.5628918 54.4906078, 9.562933 54.4906274, 9.5628951 54.4906545))', 8307),
    -441.709, 47.793, 14.97, 140.78, 0.972, 1.15, 0.8, 4508906480748401389, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 331, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562979, 54.490845, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5630047 54.4907874, 9.5630706 54.490818, 9.5629536 54.4909035, 9.5628877 54.4908729, 9.5630047 54.4907874))', 8307),
    -436.153, 23.938, 14.1, -38.57, 1.014, 1.093, 0.462, 1441845713697530036, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 332, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563177, 54.490694, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5631572 54.4907427, 9.5630967 54.4907124, 9.5631971 54.4906446, 9.5632576 54.4906749, 9.5631572 54.4907427))', 8307),
    -423.324, 40.837, 14.68, 139.26, 1.107, 1.15, 0.695, -5841500981042173686, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 333, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563661, 54.490859, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.563676 54.4909164, 9.5635917 54.4909003, 9.5636467 54.4908026, 9.5637311 54.4908186, 9.563676 54.4909164))', 8307),
    -391.942, 22.381, 13.06, 161.86, 0.954, 1.15, 0.575, -3825504929262689392, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 334, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563832, 54.491071, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5637983 54.4910341, 9.5638777 54.4910391, 9.5638648 54.4911075, 9.5637854 54.4911025, 9.5637983 54.4910341))', 8307),
    -380.912, -1.14, 12.1, -6.25, 0.851, 1.15, 0.714, -4416809158731242132, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 335, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563857, 54.490915, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.563883 54.4909312, 9.5638298 54.4909303, 9.5638314 54.4908997, 9.5638846 54.4909006, 9.563883 54.4909312))', 8307),
    -379.252, 16.152, 12.51, 178.32, 0.85, 1.15, 0.753, 431201047290643898, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 336, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56413, 54.490878, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5642065 54.4908876, 9.5641528 54.490922, 9.5640528 54.4908691, 9.5641065 54.4908347, 9.5642065 54.4908876))', 8307),
    -361.598, 20.286, 12.18, -132.27, 0.973, 1.15, 0.516, 7076419703165395692, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 337, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564012, 54.490812, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5640198 54.4907833, 9.5640609 54.4908051, 9.5640049 54.490841, 9.5639638 54.4908192, 9.5640198 54.4907833))', 8307),
    -369.198, 27.652, 12.86, -42.27, 0.9, 0.9, 0.516, 3743817886303868375, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 338, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564427, 54.490912, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5643685 54.4908765, 9.5644455 54.4908643, 9.5644846 54.4909476, 9.5644076 54.4909599, 9.5643685 54.4908765))', 8307),
    -342.357, 16.532, 11.52, 15.3, 1.068, 1.15, 0.69, -6586612810424527727, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 339, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564462, 54.490994, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5644349 54.4909819, 9.564475 54.4909755, 9.5644897 54.4910066, 9.5644495 54.491013, 9.5644349 54.4909819))', 8307),
    -340.042, 7.384, 10.89, 15.3, 0.9, 0.9, 0.69, 4412737741291118222, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 340, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564341, 54.490735, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5644088 54.490773, 9.5643244 54.4907888, 9.5642739 54.4906977, 9.5643583 54.4906818, 9.5644088 54.490773))', 8307),
    -347.882, 36.206, 12.43, -162.11, 0.888, 1.15, 0.904, -6320067747274666142, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 341, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564618, 54.490745, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5646171 54.4908001, 9.5645391 54.4907756, 9.5646186 54.4906898, 9.5646967 54.4907144, 9.5646171 54.4908001))', 8307),
    -329.962, 35.133, 11.84, 151.63, 0.904, 1.15, 0.461, -2390169561113036427, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 342, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564778, 54.490953, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5647515 54.4909321, 9.5648047 54.4909321, 9.5648047 54.4909729, 9.5647515 54.4909729, 9.5647515 54.4909321))', 8307),
    -319.577, 12.032, 10.5, 0.02, 1.137, 1.15, 0.847, 5817019775265029577, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 343, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56523, 54.490791, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651554 54.4907879, 9.5652021 54.4907502, 9.5653045 54.4907932, 9.5652578 54.4908309, 9.5651554 54.4907879))', 8307),
    -290.296, 30.062, 9.82, 54.21, 0.909, 1.15, 0.692, 3440049821447473264, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 344, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565352, 54.490825, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5653177 54.4908257, 9.5653421 54.490806, 9.5653872 54.4908249, 9.5653628 54.4908446, 9.5653177 54.4908257))', 8307),
    -282.358, 26.191, 9.55, 54.21, 0.9, 0.9, 0.692, 6383008115396014264, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 345, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564971, 54.490686, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.565079 54.4907013, 9.5650257 54.4907426, 9.564863 54.4906714, 9.5649163 54.4906301, 9.565079 54.4907013))', 8307),
    -307.078, 41.662, 11.16, -126.94, 1.099, 1.15, 0.575, -8134621835831309280, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 346, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565517, 54.49067, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5654796 54.490664, 9.5655245 54.4906474, 9.5655553 54.4906755, 9.5655104 54.4906922, 9.5654796 54.490664))', 8307),
    -271.666, 43.507, 9.91, 32.52, 0.929, 1.15, 0.876, -5943793545864186883, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 347, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565407, 54.490557, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5654468 54.4905639, 9.565402 54.4905807, 9.5653674 54.4905493, 9.5654122 54.4905326, 9.5654468 54.4905639))', 8307),
    -278.817, 56.1, 10.43, -147.26, 1.037, 1.15, 0.655, 7758980382263628752, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 348, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565723, 54.490636, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5656326 54.4906073, 9.5657044 54.490577, 9.5658135 54.4906645, 9.5657417 54.4906948, 9.5656326 54.4906073))', 8307),
    -258.344, 47.279, 9.43, 35.96, 1.003, 1.15, 0.532, -2415036845592598323, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 349, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565565, 54.490514, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5656022 54.4905168, 9.5655594 54.4905352, 9.5655277 54.4905103, 9.5655705 54.4904918, 9.5656022 54.4905168))', 8307),
    -268.589, 60.901, 10.38, -143.48, 0.864, 1.15, 0.648, -2212190683431607835, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 350, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.5658, 54.490548, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5657652 54.490536, 9.5658155 54.4905258, 9.5658358 54.4905598, 9.5657855 54.49057, 9.5657652 54.490536))', 8307),
    -253.327, 57.079, 9.56, 19.16, 1.002, 1.15, 0.522, 7257464008811031862, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 351, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565728, 54.490411, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5657851 54.4904463, 9.5657076 54.4904577, 9.5656716 54.490375, 9.565749 54.4903636, 9.5657851 54.4904463))', 8307),
    -258.002, 72.356, 9.93, -165.77, 1.055, 1.15, 0.701, 1341801282326330456, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 352, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566009, 54.49041, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5660349 54.4904295, 9.5659817 54.4904286, 9.5659835 54.4903904, 9.5660367 54.4903912, 9.5660349 54.4904295))', 8307),
    -239.803, 72.433, 9.03, 178.41, 1.065, 1.15, 0.766, -6801563550497767363, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 353, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566258, 54.490406, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5662857 54.490454, 9.5662067 54.4904471, 9.5662294 54.4903588, 9.5663083 54.4903657, 9.5662857 54.490454))', 8307),
    -223.711, 72.828, 8.12, 171.49, 1.103, 1.15, 0.838, 5110263837394334667, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 354, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566482, 54.49041, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5665085 54.4904625, 9.5664347 54.4904572, 9.5664559 54.4903569, 9.5665297 54.4903622, 9.5665085 54.4904625))', 8307),
    -209.151, 72.46, 7.21, 172.97, 0.938, 0.964, 0.714, 8348367469571785571, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 355, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566878, 54.490328, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5669034 54.4903825, 9.5668166 54.4903718, 9.5668521 54.4902737, 9.566939 54.4902843, 9.5669034 54.4903825))', 8307),
    -183.516, 81.548, 6.13, 168.1, 0.93, 1.15, 0.473, 741312600227536368, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 356, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566899, 54.490235, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5669305 54.4902265, 9.5669219 54.4902503, 9.5668676 54.4902436, 9.5668762 54.4902199, 9.5669305 54.4902265))', 8307),
    -182.139, 91.902, 6.5, 258.1, 0.9, 0.9, 0.473, -6053629471860321609, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 357, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567419, 54.490494, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5673325 54.4904631, 9.5674074 54.4904354, 9.5675049 54.4905251, 9.5674299 54.4905527, 9.5673325 54.4904631))', 8307),
    -148.463, 63.071, 4.1, 32.34, 0.984, 1.15, 0.645, 2496025815501180046, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 358, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567217, 54.490318, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5673069 54.4903537, 9.5672315 54.4903809, 9.5671268 54.4902825, 9.5672022 54.4902553, 9.5673069 54.4903537))', 8307),
    -161.545, 82.66, 5.43, -148.23, 1.074, 1.15, 0.857, 427598529628387319, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 359, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567102, 54.490231, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.567123 54.4902046, 9.5671522 54.4902321, 9.5670814 54.4902576, 9.5670521 54.4902301, 9.567123 54.4902046))', 8307),
    -168.975, 92.345, 6.17, -58.23, 0.9, 0.9, 0.857, 578431664872196536, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 360, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567538, 54.490279, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5675674 54.4902929, 9.5675144 54.4902958, 9.5675094 54.4902642, 9.5675624 54.4902614, 9.5675674 54.4902929))', 8307),
    -140.705, 87.059, 4.86, -174.7, 0.882, 1.15, 0.727, -4216682479203453021, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 361, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567747, 54.490446, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5677301 54.490389, 9.5678026 54.4903983, 9.5677629 54.4905031, 9.5676904 54.4904938, 9.5677301 54.490389))', 8307),
    -127.22, 68.421, 3.69, -12.43, 0.996, 0.962, 0.666, 7684686769801028544, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 362, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567811, 54.490251, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5678315 54.4903049, 9.5677585 54.490297, 9.5677905 54.4901969, 9.5678635 54.4902048, 9.5678315 54.4903049))', 8307),
    -123.041, 90.14, 4.53, 169.45, 0.945, 0.962, 0.582, -773443556447003527, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 363, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567828, 54.49015, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5678745 54.4901383, 9.5678643 54.4901701, 9.5677824 54.4901612, 9.5677925 54.4901294, 9.5678745 54.4901383))', 8307),
    -121.913, 101.404, 5.23, 259.45, 0.9, 0.9, 0.582, 7612200885194412552, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 364, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568159, 54.490459, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5681225 54.4904197, 9.5682023 54.4904222, 9.5681953 54.4904977, 9.5681156 54.4904952, 9.5681225 54.4904197))', 8307),
    -100.493, 67.011, 2.79, -3.06, 0.935, 1.15, 0.579, 3057466748282267642, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 365, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568176, 54.49026, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5682157 54.4903156, 9.5681271 54.4903133, 9.5681354 54.4902042, 9.568224 54.4902065, 9.5682157 54.4903156))', 8307),
    -99.417, 89.14, 3.81, 177.48, 1.013, 1.15, 0.807, -7050456810161334049, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 366, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568481, 54.490467, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5684364 54.4904232, 9.5685161 54.4904204, 9.5685254 54.4905113, 9.5684457 54.490514, 9.5684364 54.4904232))', 8307),
    -79.63, 66.059, 2.77, 3.42, 1.126, 1.15, 0.935, 2159994225633529166, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 367, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56847, 54.490287, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.568513 54.490326, 9.5684332 54.4903283, 9.5684265 54.4902477, 9.5685062 54.4902455, 9.568513 54.490326))', 8307),
    -80.355, 86.136, 3.09, -177.22, 0.997, 1.15, 0.748, 5974490742953638670, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 368, 'Uferhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'UFERHAUS'), 'Uferhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56891, 54.490423, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.568799 54.4903618, 9.5688499 54.4903411, 9.5690211 54.4904836, 9.5689702 54.4905044, 9.568799 54.4903618))', 8307),
    -51.82, 71.017, 2.06, 34.95, 1.139, 1.15, 0.89, -9084283110057463436, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 369, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569036, 54.490533, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5689897 54.4905224, 9.5690353 54.4905038, 9.569083 54.4905436, 9.5690375 54.4905621, 9.5689897 54.4905224))', 8307),
    -43.633, 58.742, 1.81, 34.95, 0.9, 0.9, 0.89, 7772022281441608974, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 370, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568691, 54.49024, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5687666 54.4902644, 9.5686998 54.49029, 9.568615 54.4902148, 9.5686817 54.4901893, 9.5687666 54.4902644))', 8307),
    -66.029, 91.397, 2.79, -146.66, 1.112, 1.15, 0.661, 8851586329259823676, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 371, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56921, 54.490297, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5691829 54.4902557, 9.5692614 54.4902644, 9.5692369 54.4903389, 9.5691585 54.4903301, 9.5691829 54.4902557))', 8307),
    -32.386, 84.982, 1.67, -10.83, 0.938, 1.15, 0.534, -7031647996054916426, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 372, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569151, 54.490379, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5691049 54.4903907, 9.5691153 54.4903589, 9.5691972 54.490368, 9.5691868 54.4903998, 9.5691049 54.4903907))', 8307),
    -36.202, 75.843, 1.78, 79.17, 0.9, 0.9, 0.534, -2126222746911593689, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 373, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569279, 54.490129, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5693054 54.4901679, 9.5692272 54.4901583, 9.5692517 54.4900907, 9.5693298 54.4901002, 9.5693054 54.4901679))', 8307),
    -27.941, 103.681, 1.66, 168.11, 0.855, 1.15, 0.666, 3307585472895136415, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 374, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569318, 54.490051, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5693643 54.4900399, 9.5693528 54.4900716, 9.5692713 54.4900616, 9.5692828 54.4900299, 9.5693643 54.4900399))', 8307),
    -25.397, 112.421, 1.69, 258.11, 0.9, 0.9, 0.666, 8821717264516500343, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 375, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.561976, 54.490008, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5620059 54.4899446, 9.5620757 54.4899765, 9.5619466 54.4900722, 9.5618768 54.4900403, 9.5620059 54.4899446))', 8307),
    -501.153, 117.106, 15.66, -38.11, 1.129, 1.15, 0.694, 5253540107400278196, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 376, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562142, 54.489868, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5621337 54.4899123, 9.5620705 54.4898839, 9.5621501 54.4898237, 9.5622134 54.4898521, 9.5621337 54.4899123))', 8307),
    -490.419, 132.738, 16.05, 142.39, 0.94, 1.15, 0.623, -7080029682811986591, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 377, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562294, 54.489947, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5622944 54.4899692, 9.5622555 54.489948, 9.5622939 54.4899241, 9.5623328 54.4899452, 9.5622944 54.4899692))', 8307),
    -480.555, 123.989, 15.72, 136.95, 0.912, 1.15, 0.604, 132179991488024680, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 378, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562671, 54.490105, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5626251 54.490158, 9.5625718 54.4901167, 9.5627172 54.490053, 9.5627706 54.4900943, 9.5626251 54.490158))', 8307),
    -456.118, 106.306, 15.32, 126.96, 0.983, 1.15, 0.666, 5928939913651148773, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 379, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562606, 54.490326, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5626114 54.4903013, 9.5626486 54.4903235, 9.5626003 54.490351, 9.5625631 54.4903288, 9.5626114 54.4903013))', 8307),
    -460.347, 81.743, 15.18, -45.67, 1.094, 1.15, 0.496, -7770275695357208083, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 380, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562765, 54.490231, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5627634 54.4902537, 9.5627261 54.4902315, 9.5627665 54.4902085, 9.5628038 54.4902306, 9.5627634 54.4902537))', 8307),
    -450.038, 92.329, 15.22, 134.48, 0.917, 1.15, 0.856, 7472737576265610093, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 381, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562915, 54.490299, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5629151 54.4903241, 9.5628732 54.490305, 9.5629146 54.4902744, 9.5629565 54.4902935, 9.5629151 54.4903241))', 8307),
    -440.325, 84.738, 14.99, 141.87, 1.084, 1.15, 0.85, -1048189580157719786, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 382, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562944, 54.490464, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5629416 54.4904408, 9.5629836 54.4904598, 9.562946 54.4904879, 9.562904 54.4904688, 9.5629416 54.4904408))', 8307),
    -438.45, 66.364, 14.99, -37.92, 0.991, 1.15, 0.648, -4118529123277457431, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 383, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563095, 54.49034, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5630863 54.4903976, 9.5630107 54.4903705, 9.5631039 54.4902825, 9.5631795 54.4903096, 9.5630863 54.4903976))', 8307),
    -428.644, 80.195, 14.77, 148.35, 0.959, 1.15, 0.678, -3680078449530593972, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 384, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563167, 54.490572, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5631648 54.4905477, 9.5632075 54.4905662, 9.5631697 54.4905959, 9.5631269 54.4905774, 9.5631648 54.4905477))', 8307),
    -423.968, 54.401, 14.88, -36.58, 1.029, 1.15, 0.52, -4700203631938945302, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 385, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563276, 54.490474, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5632818 54.4904963, 9.563238 54.4904786, 9.56327 54.4904518, 9.5633137 54.4904695, 9.5632818 54.4904963))', 8307),
    -416.927, 65.28, 14.67, 145.21, 0.908, 1.15, 0.562, 3695274033564885251, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 386, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563663, 54.490725, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5636322 54.490673, 9.5637198 54.4906814, 9.5636928 54.4907769, 9.5636053 54.4907685, 9.5636322 54.490673))', 8307),
    -391.87, 37.355, 13.74, -9.32, 0.897, 1.15, 0.52, -4017444734707377515, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 387, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563709, 54.490572, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5637305 54.4905916, 9.5636779 54.4905868, 9.563687 54.4905531, 9.5637396 54.4905579, 9.5637305 54.4905916))', 8307),
    -388.875, 54.344, 14.05, 171.13, 0.949, 1.15, 0.451, -2260873443941688086, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 388, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56412, 54.490679, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5640843 54.4906705, 9.5641327 54.4906577, 9.5641565 54.4906881, 9.5641081 54.490701, 9.5640843 54.4906705))', 8307),
    -362.199, 42.438, 13.17, 24.53, 0.931, 1.15, 0.782, 933371781013980663, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 389, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564026, 54.490565, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5640648 54.4905749, 9.5640173 54.4905889, 9.5639878 54.490555, 9.5640353 54.490541, 9.5640648 54.4905749))', 8307),
    -368.298, 55.169, 13.26, -153.13, 1.056, 1.15, 0.9, -2638014135259681465, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 390, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564421, 54.49053, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5643669 54.4905029, 9.5644439 54.4904905, 9.5644755 54.4905572, 9.5643986 54.4905696, 9.5643669 54.4905029))', 8307),
    -342.705, 59.055, 12.64, 15.42, 0.856, 1.15, 0.53, -4175510496370350252, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 391, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564457, 54.490604, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5644355 54.4906202, 9.5644244 54.4905968, 9.564478 54.4905882, 9.564489 54.4906116, 9.5644355 54.4906202))', 8307),
    -340.405, 50.805, 12.55, 105.42, 0.9, 0.9, 0.53, 7331449531753074384, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 392, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564334, 54.49037, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5644044 54.4904185, 9.5643191 54.4904327, 9.5642639 54.4903208, 9.5643492 54.4903066, 9.5644044 54.4904185))', 8307),
    -348.351, 76.909, 13.12, -163.99, 1.08, 1.15, 0.719, 3643234520872893076, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 393, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564664, 54.490424, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5646746 54.4904472, 9.5646265 54.490434, 9.5646538 54.4904003, 9.564702 54.4904135, 9.5646746 54.4904472))', 8307),
    -326.96, 70.888, 12.38, 154.78, 1.038, 1.15, 0.716, -8454113459220066219, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 394, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565098, 54.4905, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.565056 54.4905013, 9.5650873 54.4904762, 9.5651402 54.4904986, 9.5651088 54.4905237, 9.565056 54.4905013))', 8307),
    -298.844, 62.41, 11.44, 53.97, 1.058, 1.15, 0.632, -4708817409530652803, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 395, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565232, 54.490395, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651912 54.490388, 9.5652348 54.4903703, 9.5652726 54.4904017, 9.5652289 54.4904194, 9.5651912 54.490388))', 8307),
    -290.175, 74.109, 11.35, 34.98, 1.067, 1.15, 0.658, 6719629006633957240, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 396, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565427, 54.490368, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5653721 54.4903333, 9.5654497 54.4903224, 9.5654826 54.4904018, 9.565405 54.4904127, 9.5653721 54.4903333))', 8307),
    -277.509, 77.147, 11.05, 13.57, 1.01, 1.15, 0.715, -2814820766105937905, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 397, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565345, 54.490185, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5654132 54.4902369, 9.5653272 54.4902497, 9.5652762 54.4901334, 9.5653622 54.4901206, 9.5654132 54.4902369))', 8307),
    -282.865, 97.455, 11.11, -165.66, 1.113, 1.15, 0.924, 4279469688566786440, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 398, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565313, 54.490091, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5653397 54.4901041, 9.5652993 54.4901102, 9.5652856 54.4900788, 9.5653259 54.4900728, 9.5653397 54.4901041))', 8307),
    -284.943, 107.879, 11.24, -165.66, 0.9, 0.9, 0.924, 1972337977481343274, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 399, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565991, 54.49026, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5659514 54.4902054, 9.56604 54.4902078, 9.5660315 54.4903151, 9.5659429 54.4903128, 9.5659514 54.4902054))', 8307),
    -240.954, 89.093, 9.11, -2.64, 0.997, 1.15, 0.574, 672412640674175643, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 400, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565967, 54.490354, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5659383 54.4903653, 9.5659402 54.4903411, 9.5659957 54.4903426, 9.5659938 54.4903668, 9.5659383 54.4903653))', 8307),
    -242.538, 78.665, 9.23, 87.36, 0.9, 0.9, 0.574, 2662622012121948621, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 401, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566016, 54.490087, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5660408 54.4901063, 9.5659876 54.490105, 9.5659902 54.4900674, 9.5660434 54.4900687, 9.5660408 54.4901063))', 8307),
    -239.395, 108.397, 9.25, 177.75, 1.047, 1.15, 0.95, -596125129564161810, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 402, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566219, 54.490233, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5662003 54.4902093, 9.5662523 54.4902159, 9.5662374 54.4902558, 9.5661854 54.4902492, 9.5662003 54.4902093))', 8307),
    -226.217, 92.178, 8.28, -12.29, 1.138, 1.15, 0.898, 1578828103191972979, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 403, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566264, 54.490081, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5662908 54.4901324, 9.5662039 54.4901219, 9.5662368 54.4900303, 9.5663236 54.4900409, 9.5662908 54.4901324))', 8307),
    -223.307, 109.007, 8.45, 168.21, 0.868, 1.15, 0.84, -4823926763231755564, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 404, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566364, 54.49027, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5663334 54.4902311, 9.5664124 54.490238, 9.5663943 54.4903091, 9.5663153 54.4903023, 9.5663334 54.4902311))', 8307),
    -216.819, 87.997, 7.72, -8.43, 0.89, 1.15, 0.787, -3174058617809800498, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 405, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566414, 54.490119, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5664347 54.4901413, 9.5663822 54.490136, 9.5663941 54.4900959, 9.5664466 54.4901011, 9.5664347 54.4901413))', 8307),
    -213.544, 104.867, 7.92, 170.23, 1.134, 1.15, 0.506, -6866842613013651548, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 406, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56671, 54.490255, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5666225 54.4902288, 9.5666939 54.4901982, 9.5667981 54.4902804, 9.5667267 54.490311, 9.5666225 54.4902288))', 8307),
    -194.369, 89.726, 6.7, 36.4, 0.948, 1.15, 0.585, -2828774526446120387, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 407, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566869, 54.490012, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5669066 54.4900618, 9.5668186 54.4900578, 9.5668314 54.4899628, 9.5669193 54.4899669, 9.5669066 54.4900618))', 8307),
    -184.088, 116.695, 7.71, 175.53, 0.883, 1.143, 0.842, -3663717784447357881, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 408, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567068, 54.490034, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5671261 54.4900831, 9.5670384 54.4900912, 9.5670096 54.489985, 9.5670972 54.4899769, 9.5671261 54.4900831))', 8307),
    -171.202, 114.279, 7.37, -171, 0.997, 1.15, 0.921, 2116095453649980959, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 409, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567415, 54.490145, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5673417 54.4901256, 9.5674061 54.4900981, 9.5674893 54.4901643, 9.5674248 54.4901917, 9.5673417 54.4901256))', 8307),
    -148.672, 101.934, 6.08, 36.2, 1.014, 1.15, 0.809, 3458572786001233660, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 410, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567264, 54.490027, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5673028 54.4900296, 9.5672618 54.4900494, 9.5672254 54.4900238, 9.5672664 54.4900041, 9.5673028 54.4900296))', 8307),
    -158.48, 115.092, 7.13, -140.36, 0.924, 1.15, 0.918, 6525260049644434794, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 411, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56742, 54.48993, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5674833 54.4899587, 9.5674094 54.4899764, 9.5673569 54.4899019, 9.5674308 54.4898843, 9.5674833 54.4899587))', 8307),
    -148.376, 125.826, 7.45, -157.69, 0.996, 1.15, 0.486, 2503322127513104053, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 412, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567691, 54.490054, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.567657 54.4900143, 9.5677366 54.4900184, 9.5677252 54.490094, 9.5676456 54.4900899, 9.567657 54.4900143))', 8307),
    -130.811, 112.042, 6.21, -5.03, 0.938, 1.15, 0.83, 327722865497015367, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 413, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568016, 54.489929, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5680431 54.4899451, 9.5679898 54.4899453, 9.5679894 54.489913, 9.5680427 54.4899128, 9.5680431 54.4899451))', 8307),
    -109.741, 125.966, 6.62, 180.44, 0.898, 1.15, 0.784, -6304535244418439129, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 414, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56816, 54.490108, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5681253 54.4900515, 9.5682136 54.4900569, 9.5681939 54.4901638, 9.5681057 54.4901583, 9.5681253 54.4900515))', 8307),
    -100.449, 106.092, 4.87, -6.1, 0.997, 1.15, 0.616, -7893242491629745660, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 415, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568171, 54.489933, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5681956 54.4899525, 9.5681424 54.4899505, 9.5681466 54.4899139, 9.5681997 54.489916, 9.5681956 54.4899525))', 8307),
    -99.709, 125.505, 6.27, 176.22, 1.019, 1.15, 0.813, 126348551004814297, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 416, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568388, 54.490112, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.568352 54.4900548, 9.5684377 54.4900585, 9.5684237 54.4901683, 9.5683379 54.4901646, 9.568352 54.4900548))', 8307),
    -85.662, 105.651, 3.98, -4.25, 1.022, 1.114, 0.719, -3773107652869893855, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 417, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568383, 54.490207, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5683642 54.49019, 9.5684057 54.4901918, 9.5684016 54.490224, 9.5683601 54.4902222, 9.5683642 54.49019))', 8307),
    -85.981, 95.026, 3.59, -4.25, 0.9, 0.9, 0.719, -3554568606048624307, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 418, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568407, 54.489912, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.568442 54.4899586, 9.5683623 54.4899554, 9.5683729 54.4898656, 9.5684526 54.4898688, 9.568442 54.4899586))', 8307),
    -84.39, 127.852, 5.07, 176.09, 1.113, 1.15, 0.709, -3023363989084688441, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 419, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568385, 54.489826, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5684043 54.489843, 9.5683627 54.4898413, 9.5683665 54.489809, 9.5684081 54.4898107, 9.5684043 54.489843))', 8307),
    -85.818, 137.439, 5.63, 176.09, 0.9, 0.9, 0.709, 4652368825814540864, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 420, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568573, 54.490084, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5685245 54.4900534, 9.5686034 54.4900462, 9.5686216 54.4901145, 9.5685427 54.4901216, 9.5685245 54.4900534))', 8307),
    -73.657, 108.728, 3.45, 8.83, 0.854, 1.15, 0.743, 293236966403013843, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 421, 'Uferhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'UFERHAUS'), 'Uferhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568881, 54.49005, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5687931 54.4900045, 9.5688451 54.4899847, 9.5689691 54.4900947, 9.5689172 54.4901146, 9.5687931 54.4900045))', 8307),
    -53.694, 112.546, 2.31, 33.28, 0.862, 1.15, 0.655, -6955508246169535735, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 422, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568983, 54.490151, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5689369 54.4901399, 9.5689833 54.4901221, 9.569029 54.4901627, 9.5689826 54.4901804, 9.5689369 54.4901399))', 8307),
    -47.095, 101.232, 2.2, 33.28, 0.9, 0.9, 0.655, 5813287481037356102, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 423, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568703, 54.489886, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5687859 54.4899145, 9.5687107 54.4899419, 9.5686197 54.4898574, 9.5686949 54.48983, 9.5687859 54.4899145))', 8307),
    -65.249, 130.765, 3.51, -147.92, 0.925, 1.15, 0.756, -5462712728349727645, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 424, 'Händler', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Händler',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568867, 54.489822, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5689379 54.4898478, 9.5688688 54.4898711, 9.5687952 54.4897971, 9.5688643 54.4897738, 9.5689379 54.4898478))', 8307),
    -54.638, 137.83, 3.14, -149.92, 1.058, 1.15, 0.673, -768679278118962484, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 425, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568808, 54.489738, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5688529 54.4897508, 9.5688049 54.489767, 9.5687631 54.489725, 9.5688112 54.4897088, 9.5688529 54.4897508))', 8307),
    -58.431, 147.245, 3.94, -149.92, 0.9, 0.9, 0.673, -6909723990644676124, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 426, 'Uferhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'UFERHAUS'), 'Uferhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569138, 54.489997, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5691357 54.4899143, 9.5691965 54.4899218, 9.5691395 54.4900791, 9.5690788 54.4900716, 9.5691357 54.4899143))', 8307),
    -37.073, 118.439, 1.92, -11.9, 1.053, 1.15, 0.774, 7658105676867246705, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 427, 'Uferhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'UFERHAUS'), 'Uferhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569196, 54.489754, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5692052 54.48983, 9.5691439 54.489824, 9.5691866 54.4896773, 9.5692479 54.4896834, 9.5692052 54.48983))', 8307),
    -33.295, 145.489, 2.34, 170.38, 0.974, 1.15, 0.949, -2277478291611602364, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 428, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569199, 54.489631, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5692443 54.489619, 9.569235 54.4896509, 9.5691529 54.4896428, 9.5691622 54.4896109, 9.5692443 54.489619))', 8307),
    -33.122, 159.156, 2.7, 260.38, 0.9, 0.9, 0.949, -3070267496852956196, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 429, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562482, 54.489709, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5624775 54.4897322, 9.5624417 54.4897093, 9.5624856 54.4896861, 9.5625213 54.4897091, 9.5624775 54.4897322))', 8307),
    -468.412, 150.419, 16.32, 132.24, 0.959, 1.15, 0.8, -2763128221384948498, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 430, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562536, 54.489922, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5625401 54.4898991, 9.5625758 54.4899221, 9.5625323 54.489945, 9.5624966 54.489922, 9.5625401 54.4898991))', 8307),
    -464.866, 126.724, 15.62, -47.95, 0.949, 1.15, 0.548, 462540055289898031, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 431, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562698, 54.489835, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5626899 54.4898598, 9.562655 54.4898364, 9.562707 54.4898102, 9.5627419 54.4898336, 9.5626899 54.4898598))', 8307),
    -454.355, 136.415, 15.7, 130.89, 1.114, 1.15, 0.557, -1044507055982230681, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 432, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56299, 54.489969, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5629938 54.4900135, 9.562924 54.4899909, 9.5629867 54.489925, 9.5630566 54.4899475, 9.5629938 54.4900135))', 8307),
    -435.441, 121.478, 15.1, 151.04, 0.933, 1.15, 0.718, -8596220778284724050, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 433, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563088, 54.490181, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.563085 54.4901566, 9.5631283 54.4901746, 9.5630901 54.4902057, 9.5630468 54.4901876, 9.563085 54.4901566))', 8307),
    -429.134, 97.888, 14.89, -35.6, 1.062, 1.15, 0.557, 6280713612614802508, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 434, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563219, 54.490058, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5632231 54.490083, 9.5631784 54.4900661, 9.5632154 54.490033, 9.56326 54.4900499, 9.5632231 54.490083))', 8307),
    -420.603, 111.598, 14.74, 146.97, 1.098, 1.15, 0.526, -2425630493817068722, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 435, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563384, 54.490084, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5633827 54.4901484, 9.5633017 54.4901273, 9.563385 54.4900189, 9.563466 54.49004, 9.5633827 54.4901484))', 8307),
    -409.936, 108.74, 14.6, 155.91, 1.102, 1.15, 0.566, 4343558755457823098, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 436, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563671, 54.490337, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5636356 54.4902817, 9.5637239 54.4902867, 9.5637067 54.4903918, 9.5636184 54.4903869, 9.5636356 54.4902817))', 8307),
    -391.315, 80.568, 14.06, -5.45, 0.979, 1.15, 0.696, -3736627618642612199, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 437, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56371, 54.49016, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5637397 54.4902125, 9.5636521 54.490204, 9.5636798 54.4901071, 9.5637673 54.4901156, 9.5637397 54.4902125))', 8307),
    -388.816, 100.268, 14.12, 170.57, 0.911, 1.15, 0.821, 2309850968722054189, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 438, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563737, 54.490071, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5637529 54.4900886, 9.5637118 54.4900847, 9.5637209 54.4900528, 9.563762 54.4900567, 9.5637529 54.4900886))', 8307),
    -387.056, 110.184, 14.22, 170.57, 0.9, 0.9, 0.821, 1201567594799917102, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 439, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563943, 54.490342, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.563884 54.4902926, 9.5639715 54.490284, 9.5640027 54.490391, 9.5639153 54.4903997, 9.563884 54.4902926))', 8307),
    -373.674, 80.005, 13.62, 9.66, 1.007, 1.15, 0.706, 7832967731993572526, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 440, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563991, 54.490446, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5639545 54.4904658, 9.5639452 54.490434, 9.5640274 54.4904258, 9.5640367 54.4904577, 9.5639545 54.4904658))', 8307),
    -370.59, 68.428, 13.46, 99.66, 0.9, 0.9, 0.706, -2223017048711349798, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 441, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563903, 54.490164, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5639505 54.4902054, 9.563871 54.4902102, 9.5638552 54.4901225, 9.5639346 54.4901177, 9.5639505 54.4902054))', 8307),
    -376.302, 99.806, 13.9, -173.99, 1.091, 1.15, 0.625, -2851772556697818147, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 442, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564078, 54.490158, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5641177 54.4901617, 9.5640765 54.4901813, 9.5640373 54.4901535, 9.5640785 54.4901339, 9.5641177 54.4901617))', 8307),
    -364.982, 100.513, 13.69, -140.65, 1.002, 1.15, 0.612, -2299846950361863659, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 443, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564229, 54.490071, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5642679 54.4900717, 9.5642306 54.4900938, 9.5641908 54.490071, 9.5642282 54.4900489, 9.5642679 54.4900717))', 8307),
    -355.142, 110.113, 13.48, -134.51, 0.903, 1.15, 0.858, 2543343112388830638, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 444, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564504, 54.489981, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5645222 54.4900328, 9.5644499 54.4900233, 9.5644867 54.4899282, 9.564559 54.4899377, 9.5645222 54.4900328))', 8307),
    -337.316, 120.227, 12.88, 167.31, 0.904, 0.961, 0.709, -2434716247739904269, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 445, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56453, 54.490203, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5645406 54.490139, 9.5646181 54.4901642, 9.5645195 54.4902669, 9.564442 54.4902416, 9.5645406 54.490139))', 8307),
    -335.657, 95.468, 13.03, -29.22, 1.091, 1.15, 0.92, 1551123971705210234, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 446, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565129, 54.490136, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5650543 54.4901338, 9.5650997 54.4900956, 9.5652033 54.4901373, 9.5651579 54.4901755, 9.5650543 54.4901338))', 8307),
    -296.856, 102.974, 11.56, 55.32, 0.907, 1.15, 0.85, 5047357942922276696, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 447, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564922, 54.490041, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5649626 54.4900386, 9.5649314 54.4900637, 9.5648808 54.4900425, 9.564912 54.4900173, 9.5649626 54.4900386))', 8307),
    -310.28, 113.548, 12.02, -125.83, 1.011, 1.15, 0.772, 5249458530415036398, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 448, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565299, 54.489852, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5653451 54.4898894, 9.5652656 54.4898939, 9.5652523 54.4898145, 9.5653317 54.48981, 9.5653451 54.4898894))', 8307),
    -285.849, 134.542, 11.1, -174.4, 0.987, 1.15, 0.813, 3319909122821700950, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 449, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565635, 54.489983, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5655497 54.4899563, 9.5656227 54.489927, 9.5657208 54.4900097, 9.5656478 54.4900391, 9.5655497 54.4899563))', 8307),
    -264.037, 119.954, 10.55, 34.64, 0.933, 1.15, 0.747, -5005114729603681106, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 450, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565638, 54.489763, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5656979 54.489787, 9.5656337 54.4898053, 9.5655776 54.4897386, 9.5656418 54.4897203, 9.5656979 54.489787))', 8307),
    -263.879, 144.466, 10.55, -153.92, 0.919, 1.03, 0.92, -278364250904535241, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 451, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565927, 54.48988, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5658996 54.4898624, 9.5659528 54.489862, 9.5659537 54.4898972, 9.5659005 54.4898977, 9.5658996 54.4898624))', 8307),
    -245.153, 131.442, 10.01, 0.85, 0.982, 1.15, 0.525, 3401524549806155260, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 452, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565933, 54.489709, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5659736 54.489764, 9.5658992 54.4897657, 9.5658916 54.4896549, 9.565966 54.4896531, 9.5659736 54.489764))', 8307),
    -244.771, 150.409, 10.26, 182.3, 1.029, 0.965, 0.757, 6024437838502563767, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 453, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566072, 54.489894, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5660348 54.4898519, 9.5661146 54.4898538, 9.5661086 54.4899364, 9.5660288 54.4899345, 9.5660348 54.4898519))', 8307),
    -235.755, 129.847, 9.58, -2.43, 1.023, 1.15, 0.863, -7227579844532827481, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 454, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566295, 54.48991, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5662675 54.4898709, 9.5663459 54.4898798, 9.5663225 54.48995, 9.5662441 54.4899411, 9.5662675 54.4898709))', 8307),
    -221.286, 128.034, 8.76, -10.99, 0.884, 1.15, 0.497, -7587507145638100291, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 455, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566341, 54.489725, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.566375 54.4897813, 9.5662867 54.4897759, 9.5663063 54.4896681, 9.5663945 54.4896735, 9.566375 54.4897813))', 8307),
    -218.328, 148.713, 9.36, 173.97, 1.006, 1.15, 0.808, -2156631876454291197, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 456, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566389, 54.48963, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5664069 54.4896469, 9.5663655 54.4896444, 9.5663713 54.4896122, 9.5664128 54.4896148, 9.5664069 54.4896469))', 8307),
    -215.185, 159.3, 9.42, 173.97, 0.9, 0.9, 0.808, 6376272057267648585, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 457, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566589, 54.489919, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5665226 54.4898818, 9.5666073 54.4898664, 9.5666555 54.4899566, 9.5665708 54.489972, 9.5665226 54.4898818))', 8307),
    -202.229, 127.061, 8.3, 17.31, 0.876, 1.15, 0.696, 2294020662253103416, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 458, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56665, 54.490003, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5666299 54.4900196, 9.5666175 54.4899965, 9.5666706 54.4899869, 9.566683 54.49001, 9.5666299 54.4900196))', 8307),
    -198.263, 117.704, 7.95, 107.31, 0.9, 0.9, 0.696, 984438006151778284, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 459, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566909, 54.489825, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5668841 54.4897679, 9.5669709 54.4897786, 9.566933 54.4898829, 9.5668462 54.4898722, 9.5668841 54.4897679))', 8307),
    -181.524, 137.503, 8.46, -11.94, 0.989, 1.15, 0.725, -3883107948222196937, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 460, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56695, 54.489665, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5669731 54.4896861, 9.5669202 54.4896831, 9.5669269 54.4896429, 9.5669799 54.4896459, 9.5669731 54.4896861))', 8307),
    -178.837, 155.411, 9, 174.43, 1.124, 1.15, 0.543, 5909581344191747911, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 461, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567226, 54.489813, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.567162 54.4897835, 9.5672356 54.4897655, 9.5672905 54.4898415, 9.5672169 54.4898595, 9.567162 54.4897835))', 8307),
    -160.936, 138.939, 8.46, 22.79, 1.02, 1.15, 0.491, -2895003126441818800, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 462, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567385, 54.489731, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5673418 54.4897249, 9.5673827 54.4897051, 9.5674272 54.4897362, 9.5673863 54.489756, 9.5673418 54.4897249))', 8307),
    -150.68, 148.062, 8.54, 39.76, 1.128, 1.15, 0.609, -4835285907033176347, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 463, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56725, 54.489632, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5672923 54.4896365, 9.5672518 54.4896566, 9.567208 54.4896267, 9.5672485 54.4896066, 9.5672923 54.4896365))', 8307),
    -159.388, 159.075, 8.97, -139.6, 1.095, 1.15, 0.836, 6767274243161951120, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 464, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567539, 54.489709, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5674635 54.4896753, 9.567544 54.4896535, 9.5676144 54.4897419, 9.567534 54.4897636, 9.5674635 54.4896753))', 8307),
    -140.671, 150.51, 8.46, 24.9, 0.903, 1.15, 0.792, 6584724715528101049, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 465, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567835, 54.489706, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5678069 54.4896428, 9.5678945 54.489651, 9.5678624 54.4897683, 9.5677748 54.4897602, 9.5678069 54.4896428))', 8307),
    -121.51, 150.842, 8.24, -9.06, 1.102, 1.15, 0.555, -5402019725723944059, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 466, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567879, 54.489505, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5679129 54.489547, 9.5678333 54.4895433, 9.5678441 54.4894638, 9.5679237 54.4894675, 9.5679129 54.489547))', 8307),
    -118.668, 173.126, 8.94, 175.48, 0.986, 1.15, 0.912, -3350468331657364735, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 467, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567892, 54.489425, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5679104 54.4894419, 9.5678689 54.48944, 9.5678733 54.4894077, 9.5679148 54.4894096, 9.5679104 54.4894419))', 8307),
    -117.804, 182.097, 9.15, 175.48, 0.9, 0.9, 0.912, 6228255943046577316, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 468, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568074, 54.489717, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5680348 54.4896561, 9.5681234 54.4896589, 9.5681122 54.4897778, 9.5680236 54.489775, 9.5680348 54.4896561))', 8307),
    -106.032, 149.577, 7.67, -3.16, 1.105, 1.15, 0.603, 6632674200239887466, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 469, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568052, 54.489816, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5680332 54.4897994, 9.5680748 54.4898007, 9.5680717 54.489833, 9.5680301 54.4898317, 9.5680332 54.4897994))', 8307),
    -107.396, 138.527, 7.24, -3.16, 0.9, 0.9, 0.603, -1997487452414607704, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 470, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568103, 54.489522, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5681452 54.4895759, 9.5680565 54.4895745, 9.5680612 54.4894687, 9.5681499 54.4894701, 9.5681452 54.4895759))', 8307),
    -104.109, 171.245, 8.38, 178.51, 0.982, 1.15, 0.843, -5700735426695263521, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 471, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568118, 54.489421, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5681607 54.4894057, 9.5681593 54.4894381, 9.568076 54.4894368, 9.5680774 54.4894045, 9.5681607 54.4894057))', 8307),
    -103.126, 182.489, 8.48, 268.51, 0.9, 0.9, 0.843, -2854969173346420422, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 472, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568305, 54.489702, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5682704 54.489664, 9.56835 54.4896676, 9.5683403 54.4897399, 9.5682606 54.4897363, 9.5682704 54.489664))', 8307),
    -91.009, 151.248, 6.91, -4.49, 0.897, 1.15, 0.73, -8746652241133544629, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 473, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568285, 54.489788, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5682417 54.4898021, 9.568246 54.4897699, 9.5683291 54.4897737, 9.5683247 54.4898059, 9.5682417 54.4898021))', 8307),
    -92.302, 141.68, 6.4, 85.51, 0.9, 0.9, 0.73, -1603406990957548698, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 474, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568344, 54.489515, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5683768 54.4895792, 9.5682885 54.4895739, 9.5683103 54.4894507, 9.5683986 54.489456, 9.5683768 54.4895792))', 8307),
    -88.532, 172.062, 7.59, 174.13, 1.148, 1.15, 0.826, -2293273689921527934, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 475, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568382, 54.489412, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5684 54.489429, 9.5683586 54.4894265, 9.5683642 54.4893943, 9.5684057 54.4893968, 9.5684 54.489429))', 8307),
    -86.033, 183.559, 7.66, 174.13, 0.9, 0.9, 0.826, -8219915690095954345, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 476, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568543, 54.489576, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5685731 54.4895941, 9.5685202 54.4895975, 9.5685129 54.4895588, 9.5685658 54.4895555, 9.5685731 54.4895941))', 8307),
    -75.608, 165.215, 6.47, -173.76, 1.082, 1.15, 0.847, 600303326907122659, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 477, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568715, 54.489529, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5687813 54.489552, 9.5687217 54.489574, 9.5686485 54.489507, 9.5687082 54.4894849, 9.5687813 54.489552))', 8307),
    -64.466, 170.448, 5.69, -147.57, 0.983, 1.018, 0.589, -5638379563191273016, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 478, 'Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569095, 54.489583, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5690683 54.4895681, 9.5691216 54.4895675, 9.5691226 54.4895985, 9.5690694 54.4895991, 9.5690683 54.4895681))', 8307),
    -39.804, 164.455, 3.3, 1.1, 0.865, 1.15, 0.675, 99983113493327172, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 479, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569088, 54.489425, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5691315 54.4894735, 9.5690428 54.4894729, 9.5690446 54.4893771, 9.5691333 54.4893777, 9.5691315 54.4894735))', 8307),
    -40.284, 182.043, 4.16, -180.62, 0.889, 1.15, 0.762, 3537345387673608139, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 480, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56276, 54.489707, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5627679 54.4896572, 9.5628344 54.4896813, 9.5627529 54.4897576, 9.5626865 54.4897336, 9.5627679 54.4896572))', 8307),
    -450.338, 150.616, 15.85, -31.84, 1.111, 1.126, 0.842, 5575587192237554999, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 481, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562945, 54.489729, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5629381 54.4897063, 9.5629832 54.4897228, 9.562952 54.4897517, 9.562907 54.4897352, 9.5629381 54.4897063))', 8307),
    -438.372, 148.215, 15.69, -32.1, 0.95, 1.15, 0.943, -7393894326718654300, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 482, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563075, 54.489598, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5630753 54.4896552, 9.5629958 54.4896323, 9.5630742 54.4895401, 9.5631537 54.489563, 9.5630753 54.4896552))', 8307),
    -429.97, 162.84, 15.77, 153.68, 0.954, 1.15, 0.739, 5688136844506577703, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 483, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563157, 54.489514, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5631912 54.4895101, 9.5631727 54.4895319, 9.5631229 54.4895175, 9.5631414 54.4894958, 9.5631912 54.4895101))', 8307),
    -424.638, 172.168, 15.92, 243.68, 0.9, 0.9, 0.739, -1117897933340540334, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 484, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563348, 54.489855, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5633329 54.4898315, 9.5633837 54.4898407, 9.5633637 54.489878, 9.5633129 54.4898687, 9.5633329 54.4898315))', 8307),
    -412.241, 134.225, 15.01, -17.32, 1.087, 1.15, 0.823, -3389397362121062454, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 485, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563415, 54.48975, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5634291 54.4897718, 9.5633791 54.4897611, 9.5634003 54.4897276, 9.5634503 54.4897382, 9.5634291 54.4897718))', 8307),
    -407.939, 145.916, 15.22, 159.82, 0.996, 1.15, 0.607, 5789452598993558589, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 486, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563631, 54.489782, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5636537 54.4898044, 9.5636008 54.4898008, 9.5636091 54.4897601, 9.5636619 54.4897637, 9.5636537 54.4898044))', 8307),
    -393.897, 142.292, 14.77, 173.28, 1.14, 1.15, 0.485, 6698501765464099096, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 487, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563752, 54.489942, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.563721 54.4899001, 9.5638002 54.4899059, 9.5637835 54.4899831, 9.5637043 54.4899773, 9.563721 54.4899001))', 8307),
    -386.062, 124.555, 14.29, -7.18, 0.962, 1.15, 0.671, 6053184960045383812, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 488, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564034, 54.489945, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5639684 54.489896, 9.5640548 54.4898843, 9.5640991 54.489995, 9.5640127 54.4900067, 9.5639684 54.489896))', 8307),
    -367.821, 124.127, 13.89, 13.1, 1.054, 1.15, 0.456, -919881896874575545, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 489, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564062, 54.490042, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.564035 54.4900289, 9.5640755 54.4900234, 9.5640881 54.4900549, 9.5640476 54.4900604, 9.564035 54.4900289))', 8307),
    -366.018, 113.388, 13.8, 13.1, 0.9, 0.9, 0.456, -6969112863358814513, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 490, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563973, 54.489783, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5640056 54.489799, 9.5639533 54.4898048, 9.5639406 54.489766, 9.5639929 54.4897602, 9.5640056 54.489799))', 8307),
    -371.753, 142.264, 14.17, -169.26, 1.099, 1.15, 0.632, 7919884811278328801, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 491, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564256, 54.489906, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5641732 54.4898839, 9.5642414 54.4898535, 9.5643397 54.489928, 9.5642715 54.4899585, 9.5641732 54.4898839))', 8307),
    -353.391, 128.524, 13.44, 37.52, 0.872, 1.114, 0.471, -3092456844006344043, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 492, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564417, 54.489809, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5643387 54.4897955, 9.5643962 54.4897632, 9.5644949 54.4898226, 9.5644375 54.4898549, 9.5643387 54.4897955))', 8307),
    -342.998, 139.313, 12.94, 44.02, 1.023, 1.15, 0.907, 1029637423450144245, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 493, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564236, 54.489692, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5642759 54.4896971, 9.5642341 54.4897163, 9.5641951 54.4896875, 9.5642369 54.4896683, 9.5642759 54.4896971))', 8307),
    -354.749, 152.306, 13.44, -141.71, 1.021, 1.15, 0.54, -5905544397614139109, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 494, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564518, 54.489604, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5645343 54.4896496, 9.5644585 54.4896349, 9.5645025 54.4895578, 9.5645783 54.4895725, 9.5645343 54.4896496))', 8307),
    -336.418, 162.17, 12.59, 161.63, 1.005, 1.15, 0.491, -4955912778494249472, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 495, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56458, 54.489533, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5646132 54.4895264, 9.5646001 54.4895494, 9.5645473 54.4895392, 9.5645605 54.4895162, 9.5646132 54.4895264))', 8307),
    -332.408, 170.061, 12.52, 251.63, 0.9, 0.9, 0.491, 2511319900062637676, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 496, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565028, 54.489855, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5649312 54.4898264, 9.5650001 54.4897939, 9.5651247 54.4898833, 9.5650558 54.4899158, 9.5649312 54.4898264))', 8307),
    -303.395, 134.219, 11.61, 39.06, 1.068, 1.15, 0.506, 9218950367163992407, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 497, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564839, 54.4897, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5649226 54.4897291, 9.5648474 54.4897566, 9.5647558 54.4896716, 9.564831 54.4896442, 9.5649226 54.4897291))', 8307),
    -315.626, 151.414, 12.09, -147.86, 0.93, 1.15, 0.79, -4332267377376358431, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 498, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56517, 54.48971, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651325 54.4897126, 9.5651657 54.4896883, 9.5652076 54.4897077, 9.5651744 54.489732, 9.5651325 54.4897126))', 8307),
    -294.186, 150.325, 11.34, 51.46, 0.867, 1.15, 0.752, 6246406159335007460, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 499, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565409, 54.489638, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5653767 54.4896227, 9.565429 54.4896168, 9.5654413 54.4896537, 9.565389 54.4896596, 9.5653767 54.4896227))', 8307),
    -278.7, 158.338, 10.93, 11, 1.046, 1.15, 0.647, 851901543333034013, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 500, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566007, 54.48952, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5659796 54.4895052, 9.5660328 54.4895039, 9.5660351 54.4895356, 9.5659819 54.4895369, 9.5659796 54.4895052))', 8307),
    -239.926, 171.45, 10.22, 2.43, 0.885, 1.15, 0.651, 6174930245264774520, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 501, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566005, 54.489375, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5660461 54.4894098, 9.5659663 54.4894107, 9.5659639 54.4893409, 9.5660438 54.48934, 9.5660461 54.4894098))', 8307),
    -240.079, 187.598, 10.34, -178.87, 0.864, 1.15, 0.763, -6526994179637824585, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 502, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56623, 54.489545, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5661965 54.4895041, 9.566276 54.4895087, 9.5662628 54.4895868, 9.5661834 54.4895822, 9.5661965 54.4895041))', 8307),
    -225.519, 168.662, 9.86, -5.59, 0.971, 1.15, 0.823, -9168193993230774246, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 503, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566247, 54.489345, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5662846 54.4894081, 9.566196 54.4894049, 9.566209 54.4892817, 9.5662976 54.4892849, 9.5662846 54.4894081))', 8307),
    -224.41, 190.985, 10.29, 176.48, 1.145, 1.15, 0.805, 9213808941507862241, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 504, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566476, 54.489522, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5664471 54.4895035, 9.5665003 54.4895015, 9.5665046 54.4895409, 9.5664515 54.4895429, 9.5664471 54.4895035))', 8307),
    -209.565, 171.252, 9.57, 3.69, 1.101, 1.15, 0.727, 4802378981854955784, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 505, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566737, 54.489515, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5666499 54.4894912, 9.5667202 54.4894596, 9.5668241 54.4895381, 9.5667538 54.4895696, 9.5666499 54.4894912))', 8307),
    -192.641, 172.096, 9.49, 37.63, 0.919, 1.15, 0.677, 5530949671021751296, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 506, 'Schuppen', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'SCHUPPEN'), 'Schuppen',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566869, 54.489595, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5668533 54.4896227, 9.5668194 54.4895971, 9.5668854 54.4895674, 9.5669193 54.4895931, 9.5668533 54.4896227))', 8307),
    -184.064, 163.143, 9.22, 127.63, 0.9, 0.9, 0.677, -3381783737706094307, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 507, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56655, 54.489391, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.56659 54.4893954, 9.5665477 54.4894142, 9.5665106 54.4893859, 9.566553 54.4893671, 9.56659 54.4893954))', 8307),
    -204.741, 185.892, 10.04, -142.66, 0.989, 1.15, 0.674, -8087829616579018523, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 508, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566853, 54.489264, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5668787 54.4892849, 9.5668255 54.4892845, 9.5668264 54.4892438, 9.5668797 54.4892443, 9.5668787 54.4892849))', 8307),
    -185.154, 199.955, 10.74, -180.79, 1.131, 1.15, 0.693, -3775861189442091832, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 509, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567104, 54.489398, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.567072 54.4893834, 9.5671242 54.4893776, 9.5671355 54.4894116, 9.5670833 54.4894175, 9.567072 54.4893834))', 8307),
    -168.877, 185.133, 10.19, 10.93, 0.965, 1.15, 0.544, -150973419164739822, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 510, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567057, 54.489255, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5671171 54.4893018, 9.5670299 54.4893113, 9.566997 54.4892085, 9.5670842 54.4891991, 9.5671171 54.4893018))', 8307),
    -171.904, 200.975, 10.61, -169.42, 0.97, 1.15, 0.582, 2717922996925667852, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 511, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567399, 54.489346, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5673279 54.4893256, 9.5673946 54.4893001, 9.5674693 54.4893662, 9.5674026 54.4893917, 9.5673279 54.4893256))', 8307),
    -149.768, 190.879, 10.11, 33.33, 0.979, 1.15, 0.935, 6055964483649059480, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 512, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567532, 54.489136, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.567564 54.4891478, 9.5675119 54.4891542, 9.5675007 54.4891235, 9.5675528 54.4891171, 9.567564 54.4891478))', 8307),
    -141.104, 214.282, 10.62, -168.01, 0.873, 1.15, 0.95, -21264969599145348, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 513, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567748, 54.489294, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5677202 54.4892476, 9.5677991 54.4892548, 9.5677763 54.4893399, 9.5676974 54.4893327, 9.5677202 54.4892476))', 8307),
    -127.112, 196.688, 9.72, -8.88, 1.065, 1.15, 0.942, 568983248715475316, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 514, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567806, 54.489142, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5678279 54.4891603, 9.5677754 54.489155, 9.5677849 54.4891231, 9.5678374 54.4891284, 9.5678279 54.4891603))', 8307),
    -123.342, 213.608, 10.03, 170.18, 0.902, 1.15, 0.774, 657533023957448326, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 515, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567957, 54.489152, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5679885 54.4891895, 9.567912 54.4891846, 9.5679252 54.4891154, 9.5680016 54.4891204, 9.5679885 54.4891895))', 8307),
    -113.594, 212.409, 9.56, 173.67, 0.861, 1.108, 0.524, -4624205625057124677, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 516, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568353, 54.489165, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.568376 54.4892193, 9.5682897 54.4892073, 9.5683295 54.4891107, 9.5684158 54.4891228, 9.568376 54.4892193))', 8307),
    -87.936, 211.013, 8.25, 166.5, 0.921, 1.15, 0.706, 2037585824076944960, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 517, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568848, 54.489322, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5687841 54.4893023, 9.5688539 54.4892798, 9.5689123 54.489341, 9.5688424 54.4893635, 9.5687841 54.4893023))', 8307),
    -55.831, 193.581, 6.01, 29.02, 0.866, 1.15, 0.824, 6670988240757176292, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 518, 'Handwerker', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Handwerker',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.568702, 54.489166, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5687915 54.4892063, 9.5687141 54.4892315, 9.5686133 54.4891266, 9.5686907 54.4891014, 9.5687915 54.4892063))', 8307),
    -65.278, 210.856, 7.25, -150.77, 1.115, 1.15, 0.48, 6542168338615614007, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 519, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563342, 54.489498, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5633282 54.4894773, 9.5633773 54.4894893, 9.5633562 54.4895185, 9.5633071 54.4895065, 9.5633282 54.4894773))', 8307),
    -412.639, 173.944, 15.54, -22.78, 0.883, 1.15, 0.583, -8051912214798975702, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 520, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563665, 54.489566, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5636459 54.4895452, 9.563698 54.4895517, 9.5636849 54.4895878, 9.5636328 54.4895813, 9.5636459 54.4895452))', 8307),
    -391.695, 166.31, 15.13, -11.97, 1.027, 1.15, 0.643, -8103625378827075130, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 521, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563713, 54.489444, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5637312 54.4894636, 9.5636798 54.4894554, 9.5636948 54.4894238, 9.5637461 54.4894321, 9.5637312 54.4894636))', 8307),
    -388.612, 179.974, 15.08, 164.56, 0.911, 1.15, 0.889, -6061597634185311520, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 522, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563829, 54.489606, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5637979 54.4895555, 9.5638856 54.4895633, 9.563861 54.4896567, 9.5637733 54.4896489, 9.5637979 54.4895555))', 8307),
    -381.064, 161.902, 14.56, -8.7, 0.876, 1.15, 0.691, -6728484735884229501, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 523, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.563857, 54.489456, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5638786 54.4894767, 9.563826 54.489472, 9.563836 54.4894346, 9.5638886 54.4894393, 9.5638786 54.4894767))', 8307),
    -379.259, 178.648, 14.45, 171.19, 1.054, 1.15, 0.504, -568544653389421130, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 524, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56411, 54.489572, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5640762 54.4895594, 9.5641271 54.4895504, 9.5641447 54.489584, 9.5640938 54.489593, 9.5640762 54.4895594))', 8307),
    -362.852, 165.73, 13.79, 16.93, 0.978, 1.15, 0.493, -3466770444292421786, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 525, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564042, 54.489455, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5640779 54.4894654, 9.5640289 54.4894775, 9.5640052 54.4894449, 9.5640542 54.4894328, 9.5640779 54.4894654))', 8307),
    -367.32, 178.707, 13.93, -157.02, 0.985, 1.15, 0.949, 2104445948074077535, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 526, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564368, 54.489459, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5643263 54.4894551, 9.5643662 54.4894345, 9.5644106 54.4894638, 9.5643708 54.4894843, 9.5643263 54.4894551))', 8307),
    -346.133, 178.232, 13.02, 41.49, 1.087, 1.15, 0.642, -7325956408070293495, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 527, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564213, 54.489353, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5642992 54.4893727, 9.5642312 54.4894059, 9.5641263 54.4893331, 9.5641943 54.4892999, 9.5642992 54.4893727))', 8307),
    -356.226, 190.087, 13.47, -140.03, 0.881, 1.15, 0.476, -4589227379010628972, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 528, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564527, 54.489283, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5645345 54.4893313, 9.5644611 54.489313, 9.5645196 54.4892337, 9.564593 54.489252, 9.5645345 54.4893313))', 8307),
    -335.858, 197.926, 12.94, 156.8, 1.068, 1.15, 0.478, -8270968185599185007, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 529, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564597, 54.489198, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5646308 54.4891935, 9.5646144 54.4892158, 9.5645633 54.4892031, 9.5645797 54.4891808, 9.5646308 54.4891935))', 8307),
    -331.324, 207.298, 13.17, 246.8, 0.9, 0.9, 0.478, -3054693290453436813, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 530, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564889, 54.489557, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.564821 54.4895087, 9.5649068 54.4894954, 9.5649571 54.4896052, 9.5648714 54.4896186, 9.564821 54.4895087))', 8307),
    -312.395, 167.374, 12.02, 14.95, 1.054, 1.15, 0.737, 3181069099780313914, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 531, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.564818, 54.489402, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5648521 54.4894143, 9.5648013 54.4894236, 9.564783 54.4893897, 9.5648338 54.4893804, 9.5648521 54.4894143))', 8307),
    -317.031, 184.627, 12.19, -162.58, 0.99, 1.15, 0.72, 143252582612850319, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 532, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565141, 54.489488, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5650376 54.4894694, 9.5650964 54.4894307, 9.5652451 54.4895073, 9.5651863 54.489546, 9.5650376 54.4894694))', 8307),
    -296.047, 175.017, 11.66, 48.51, 1.072, 1.15, 0.668, -7209954182678442990, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 533, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56493, 54.489391, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5649709 54.4893902, 9.5649376 54.4894144, 9.5648896 54.4893921, 9.5649229 54.4893679, 9.5649709 54.4893902))', 8307),
    -309.729, 185.834, 12.05, -128.67, 0.995, 1.15, 0.624, 5024713101549229263, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 534, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'BOHLENHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565228, 54.489368, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651596 54.4893513, 9.5652248 54.4893245, 9.5652972 54.4893842, 9.5652319 54.489411, 9.5651596 54.4893513))', 8307),
    -290.409, 188.436, 11.51, 35.2, 0.903, 1.15, 0.479, 3221012290837940089, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 535, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565326, 54.489434, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5652926 54.4894274, 9.5653266 54.4894134, 9.5653586 54.4894399, 9.5653246 54.4894539, 9.5652926 54.4894274))', 8307),
    -284.108, 181.105, 11.27, 35.2, 0.9, 0.9, 0.479, -2052970014993171990, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 536, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565434, 54.48935, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5653693 54.4893021, 9.5654556 54.4892902, 9.5654996 54.4893982, 9.5654132 54.4894101, 9.5653693 54.4893021))', 8307),
    -277.058, 190.403, 11.15, 13.33, 1.029, 1.15, 0.845, -1952254427333181804, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 537, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565454, 54.489445, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5654273 54.4894325, 9.5654678 54.4894269, 9.5654807 54.4894584, 9.5654401 54.489464, 9.5654273 54.4894325))', 8307),
    -275.788, 179.794, 11, 13.33, 0.9, 0.9, 0.845, 8984637332196695992, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 538, 'Wohnhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'WOHNHAUS'), 'Wohnhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565641, 54.489295, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5655432 54.4892661, 9.5656083 54.489234, 9.5657391 54.489324, 9.565674 54.489356, 9.5655432 54.4892661))', 8307),
    -263.658, 196.538, 10.89, 40.25, 1.093, 1.105, 0.949, 5611868865290122328, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 539, 'Grubenhaus (Werkraum)', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Grubenhaus (Werkraum)',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565749, 54.489377, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5657411 54.4893967, 9.5657142 54.4893782, 9.5657566 54.4893573, 9.5657835 54.4893758, 9.5657411 54.4893967))', 8307),
    -256.679, 187.415, 10.7, 130.25, 0.9, 0.9, 0.949, 2458542726050606178, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_HAUS (SIEDLUNG_ID, NR, NAME, HAUSTYP_ID, ROLLE, LAGE, GRUNDRISS, X_M, Z_M, BODEN_M, RICHTUNG_GRAD, LAENGE_FAKTOR, BREITE_FAKTOR, ZUSTAND, ZUFALL, MUSEUM)
  SELECT s.ID, 540, 'Weberin im Grubenhaus', (SELECT ID FROM HB_HAUSTYP WHERE NAME = 'GRUBENHAUS'), 'Weberin im Grubenhaus',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565742, 54.489199, NULL), NULL, NULL),
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5657024 54.4891908, 9.5657478 54.4891746, 9.5657824 54.4892073, 9.565737 54.4892235, 9.5657024 54.4891908))', 8307),
    -257.099, 207.221, 11.04, 31.63, 1.069, 1.15, 0.798, 6960005983670141187, 0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'BOHLENWEG', 'Bohlenweg 1',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5670554 54.4912168, 9.5671172 54.4912172, 9.5671789 54.49121, 9.5672406 54.4911949, 9.5673023 54.4911725, 9.5673641 54.4911469, 9.5674258 54.4911229, 9.5674875 54.4911045, 9.5675493 54.491093, 9.567611 54.491088, 9.5676727 54.4910884, 9.5677344 54.4910929, 9.5677962 54.4911, 9.5678579 54.4911076, 9.5679196 54.4911144, 9.5679813 54.4911197, 9.5680431 54.491124, 9.5681048 54.4911281, 9.5681665 54.4911323, 9.5682283 54.4911364, 9.56829 54.4911405, 9.5683517 54.4911447, 9.5684134 54.4911488, 9.5684752 54.4911529, 9.5685369 54.4911551, 9.5685986 54.4911528, 9.5686603 54.4911444, 9.5687221 54.4911291, 9.5687838 54.4911094, 9.5688455 54.4910871, 9.5689073 54.4910643, 9.568969 54.4910431, 9.5690307 54.4910259, 9.5690924 54.4910146, 9.5691542 54.4910099, 9.5692159 54.4910114, 9.5692776 54.4910182, 9.5693393 54.491029, 9.5694011 54.4910426)', 8307),
    2.2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'BOHLENWEG', 'Bohlenweg 2',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5673949 54.4910517, 9.5674567 54.4910303, 9.5675184 54.4910152, 9.5675801 54.4910071, 9.5676419 54.491005, 9.5677036 54.4910076, 9.5677653 54.4910135, 9.567827 54.4910212, 9.5678888 54.4910285, 9.5679505 54.4910346, 9.5680122 54.4910393, 9.5680739 54.4910434, 9.5681357 54.4910476, 9.5681974 54.4910517, 9.5682591 54.4910558, 9.5683208 54.49106, 9.5683826 54.491064, 9.5684443 54.4910682, 9.568506 54.4910718, 9.5685678 54.491072, 9.5686295 54.4910668, 9.5686912 54.4910548, 9.5687529 54.491037, 9.5688147 54.4910158, 9.5688764 54.4909929, 9.5689381 54.4909707, 9.5689998 54.4909512, 9.5690616 54.4909367, 9.5691233 54.4909288)', 8307),
    2.2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 1',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.567256 54.4912068, 9.5672622 54.4913595, 9.567256 54.4915122)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 2',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5676573 54.491105, 9.5676634 54.4912577, 9.5676573 54.4914104)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 3',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5680662 54.4911426, 9.5680724 54.4912953, 9.5680662 54.4914481)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 4',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5684674 54.4911695, 9.5684736 54.4913222, 9.5684674 54.4914749)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 5',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.568861 54.4910984, 9.5688671 54.4912511, 9.5688609 54.4914039)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 6',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5677653 54.4909965, 9.5677715 54.4908617, 9.5677653 54.490727)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 7',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5681742 54.4910331, 9.5681804 54.4908984, 9.5681743 54.4907636)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 8',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5686295 54.4910497, 9.5686357 54.490915, 9.5686295 54.4907802)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 9',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5690616 54.4909196, 9.5690677 54.4907849, 9.5690616 54.4906501)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 1',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5610679 54.4910408, 9.5611451 54.4911386, 9.5612222 54.491176, 9.5612994 54.4911969, 9.5613765 54.4912158, 9.5614537 54.4912338, 9.5615309 54.4912482, 9.561608 54.4912603, 9.5616852 54.4912744, 9.5617623 54.4912934, 9.5618395 54.491314, 9.5619166 54.4913293, 9.5619938 54.4913422, 9.5620709 54.4913597, 9.5621481 54.4913847, 9.5622253 54.4914126, 9.5623024 54.4914454, 9.5623796 54.4914851, 9.5624567 54.4915263, 9.5625339 54.4915697, 9.562611 54.4916169, 9.5626882 54.4916625, 9.5627653 54.4917018, 9.5628425 54.491735, 9.5629196 54.4917643, 9.5629968 54.4917926, 9.5630739 54.4918228, 9.5631511 54.4918549, 9.5632282 54.4918863, 9.5633054 54.4919163, 9.5633826 54.4919437, 9.5634597 54.4919668, 9.5635369 54.4919855, 9.563614 54.4920013, 9.5636912 54.4920158, 9.5637683 54.4920287, 9.5638455 54.4920392, 9.5639227 54.4920459, 9.5639998 54.4920469, 9.564077 54.4920411, 9.5641541 54.4920257, 9.5642313 54.4919945, 9.5643085 54.4919425, 9.5643856 54.4919026, 9.5644628 54.4918935, 9.564')
    || TO_CLOB('54 54.4919092, 9.5646171 54.4919372, 9.5646943 54.4919602, 9.5647714 54.4919727, 9.5648486 54.4919728, 9.5649258 54.4919565, 9.5650029 54.491919, 9.5650801 54.4918579, 9.5651573 54.4917938, 9.5652344 54.4917586, 9.5653116 54.4917425, 9.5653887 54.4917318, 9.5654659 54.4917156, 9.5655431 54.4916887, 9.5656202 54.4916517, 9.5656974 54.4916157, 9.5657746 54.4915893, 9.5658517 54.4915727, 9.5659289 54.4915636, 9.566006 54.4915588, 9.5660832 54.4915566, 9.5661604 54.4915561, 9.5662375 54.4915574, 9.5663147 54.4915605, 9.5663918 54.4915652, 9.566469 54.4915705, 9.5665462 54.491571, 9.5666233 54.4915577, 9.5667005 54.4915231, 9.5667776 54.4914861, 9.5668548 54.4914725, 9.566932 54.4914779, 9.5670091 54.4914901, 9.5670863 54.4914983, 9.5671634 54.4914963, 9.5672406 54.4914822, 9.5673178 54.4914572, 9.5673949 54.491429, 9.5674721 54.4914065, 9.5675492 54.4913947, 9.5676264 54.4913926, 9.5677036 54.4913983, 9.5677807 54.4914089, 9.5678579 54.4914209, 9.567935 54.4914312, 9.5680122 54.491439, 9.5')
    || TO_CLOB('680894 54.4914453, 9.5681665 54.4914512, 9.5682437 54.4914566, 9.5683208 54.4914615, 9.568398 54.4914659, 9.5684751 54.4914699, 9.5685523 54.4914702, 9.5686295 54.4914626, 9.5687066 54.4914442, 9.5687838 54.4914173, 9.5688609 54.4913862, 9.5689381 54.4913548, 9.5690153 54.4913278, 9.5690924 54.4913091, 9.5691696 54.4913006, 9.5692467 54.4913014, 9.5693239 54.4913096, 9.5694011 54.4913229)'), 8307),
    2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 2',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5609136 54.4913427, 9.5609907 54.4913645, 9.5610679 54.491427, 9.561145 54.4915218, 9.5612222 54.4915567, 9.5612993 54.4915752, 9.5613765 54.4915922, 9.5614536 54.4916086, 9.5615308 54.4916218, 9.5616079 54.4916333, 9.5616851 54.4916472, 9.5617622 54.4916666, 9.5618394 54.4916878, 9.5619166 54.4917044, 9.5619937 54.4917189, 9.5620709 54.4917384, 9.562148 54.4917658, 9.5622252 54.4917964, 9.5623023 54.4918322, 9.5623795 54.4918751, 9.5624566 54.4919196, 9.5625338 54.4919665, 9.5626109 54.4920172, 9.5626881 54.4920663, 9.5627652 54.492109, 9.5628424 54.4921453, 9.5629196 54.4921776, 9.5629967 54.4922086, 9.5630739 54.4922413, 9.563151 54.4922754, 9.5632282 54.4923085, 9.5633053 54.4923397, 9.5633825 54.4923679, 9.5634596 54.4923913, 9.5635368 54.4924098, 9.563614 54.4924251, 9.5636911 54.4924384, 9.5637683 54.4924498, 9.5638454 54.4924584, 9.5639226 54.4924627, 9.5639998 54.4924611, 9.5640769 54.4924524, 9.5641541 54.4924339, 9.5642313 54.4923994, 9.5643084 54.4923439, 9.56')
    || TO_CLOB('43856 54.4923005, 9.5644628 54.4922879, 9.5645399 54.4923002, 9.5646171 54.4923249, 9.5646942 54.4923449, 9.5647714 54.4923546, 9.5648486 54.4923522, 9.5649257 54.4923337, 9.5650029 54.4922946, 9.5650801 54.4922321, 9.5651572 54.4921671, 9.5652344 54.4921315, 9.5653115 54.4921154, 9.5653887 54.4921052, 9.5654659 54.49209, 9.565543 54.4920645, 9.5656202 54.4920294, 9.5656974 54.4919956, 9.5657745 54.4919718, 9.5658517 54.491958, 9.5659288 54.491952, 9.566006 54.4919505, 9.5660832 54.4919517, 9.5661603 54.4919547, 9.5662375 54.4919595, 9.5663146 54.491966, 9.5663918 54.491974, 9.566469 54.4919824, 9.5665461 54.4919858, 9.5666233 54.491975, 9.5667004 54.4919426, 9.5667776 54.4919076, 9.5668548 54.4918954, 9.5669319 54.4919018, 9.5670091 54.4919145, 9.5670863 54.4919228, 9.5671634 54.4919204, 9.5672406 54.4919054, 9.5673177 54.4918791, 9.5673949 54.4918491, 9.5674721 54.4918246, 9.5675492 54.4918102, 9.5676264 54.4918054, 9.5677035 54.4918081, 9.5677807 54.4918154, 9.5678579 54.491824, 9.5')
    || TO_CLOB('67935 54.4918308, 9.5680122 54.4918351, 9.5680893 54.491838, 9.5681665 54.4918406, 9.5682437 54.4918428, 9.5683208 54.4918448, 9.568398 54.4918465, 9.5684751 54.4918482, 9.5685523 54.4918465, 9.5686295 54.4918374, 9.5687066 54.4918178, 9.5687838 54.4917903, 9.5688609 54.491759, 9.5689381 54.4917279, 9.5690153 54.4917016, 9.5690924 54.4916841, 9.5691696 54.4916773, 9.5692467 54.4916801, 9.5693239 54.4916908)'), 8307),
    2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 3',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5613764 54.4918899, 9.5614536 54.4919081, 9.5615307 54.4919235, 9.5616079 54.4919375, 9.561685 54.4919543, 9.5617622 54.4919767, 9.5618393 54.4920012, 9.5619165 54.4920212, 9.5619937 54.4920392, 9.5620708 54.4920622, 9.562148 54.492093, 9.5622251 54.4921269, 9.5623023 54.4921659, 9.5623794 54.4922116, 9.5624566 54.4922588, 9.5625337 54.492308, 9.5626109 54.4923605, 9.562688 54.4924111, 9.5627652 54.4924548, 9.5628423 54.4924918, 9.5629195 54.4925242, 9.5629967 54.4925549, 9.5630738 54.4925867, 9.563151 54.4926196, 9.5632281 54.492651, 9.5633053 54.4926801, 9.5633824 54.4927059, 9.5634596 54.4927265, 9.5635368 54.492742, 9.5636139 54.492754, 9.5636911 54.4927639, 9.5637682 54.4927719, 9.5638454 54.492777, 9.5639226 54.4927779, 9.5639997 54.4927729, 9.5640769 54.4927611, 9.5641541 54.4927395, 9.5642312 54.4927023, 9.5643084 54.4926445, 9.5643856 54.4925991, 9.5644627 54.4925849, 9.5645399 54.4925961, 9.564617 54.4926201, 9.5646942 54.4926399, 9.5647714 54.4926497, 9.5648485')
    || TO_CLOB(' 54.492648, 9.5649257 54.4926307, 9.5650028 54.4925931, 9.56508 54.4925326, 9.5651572 54.49247, 9.5652344 54.4924371, 9.5653115 54.492424, 9.5653887 54.492417, 9.5654658 54.4924051, 9.565543 54.4923831, 9.5656202 54.4923514, 9.5656973 54.4923211, 9.5657745 54.4923006, 9.5658517 54.4922901, 9.5659288 54.4922872, 9.566006 54.4922884, 9.5660831 54.492292, 9.5661603 54.4922971, 9.5662375 54.4923036, 9.5663146 54.4923114, 9.5663918 54.4923202, 9.5664689 54.4923289, 9.5665461 54.4923323, 9.5666233 54.4923209, 9.5667004 54.4922875, 9.5667776 54.4922509, 9.5668547 54.4922369, 9.5669319 54.492241, 9.5670091 54.4922511, 9.5670862 54.4922565, 9.5671634 54.492251, 9.5672406 54.4922326, 9.5673177 54.4922029, 9.5673949 54.4921695, 9.567472 54.4921414, 9.5675492 54.4921237, 9.5676264 54.4921156, 9.5677035 54.4921152, 9.5677807 54.4921196, 9.5678578 54.4921257, 9.567935 54.4921304, 9.5680122 54.4921329, 9.5680893 54.4921344, 9.5681665 54.4921361, 9.5682436 54.4921378, 9.5683208 54.4921398, 9.568398 54')
    || TO_CLOB('.492142, 9.5684751 54.4921445, 9.5685523 54.4921443, 9.5686295 54.492137, 9.5687066 54.4921196, 9.5687838 54.4920946, 9.5688609 54.4920661, 9.5689381 54.4920381, 9.5690153 54.4920151, 9.5690924 54.492001, 9.5691696 54.4919976)'), 8307),
    2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 4',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5617621 54.4923805, 9.5618393 54.4924078, 9.5619164 54.4924302, 9.5619936 54.4924504, 9.5620707 54.4924751, 9.5621479 54.4925073, 9.562225 54.492542, 9.5623022 54.4925814, 9.5623794 54.492627, 9.5624565 54.4926737, 9.5625337 54.4927219, 9.5626108 54.492773, 9.562688 54.4928217, 9.5627651 54.4928632, 9.5628423 54.4928976, 9.5629194 54.4929271, 9.5629966 54.4929547, 9.5630737 54.4929832, 9.5631509 54.4930127, 9.5632281 54.4930406, 9.5633052 54.4930662, 9.5633824 54.4930886, 9.5634595 54.4931059, 9.5635367 54.4931183, 9.5636139 54.4931274, 9.563691 54.4931348, 9.5637682 54.4931405, 9.5638453 54.4931439, 9.5639225 54.4931433, 9.5639997 54.4931373, 9.5640768 54.493125, 9.564154 54.4931034, 9.5642312 54.4930666, 9.5643083 54.4930097, 9.5643855 54.4929656, 9.5644627 54.4929532, 9.5645398 54.4929665, 9.564617 54.492993, 9.5646942 54.4930156, 9.5647713 54.4930285, 9.5648485 54.49303, 9.5649256 54.4930161, 9.5650028 54.492982, 9.56508 54.492925, 9.5651571 54.4928658, 9.5652343 54.4')
    || TO_CLOB('928362, 9.5653115 54.4928263, 9.5653886 54.4928222, 9.5654658 54.492813, 9.565543 54.4927933, 9.5656201 54.4927635, 9.5656973 54.4927347, 9.5657745 54.4927154, 9.5658516 54.4927055, 9.5659288 54.4927027, 9.5660059 54.4927036, 9.5660831 54.4927065, 9.5661603 54.4927103, 9.5662374 54.4927152, 9.5663146 54.4927209, 9.5663917 54.4927273, 9.5664689 54.4927333, 9.5665461 54.4927336, 9.5666232 54.4927191, 9.5667004 54.4926823, 9.5667776 54.4926422, 9.5668547 54.4926247, 9.5669319 54.4926253, 9.567009 54.4926321, 9.5670862 54.4926343, 9.5671634 54.4926258, 9.5672405 54.4926048, 9.5673177 54.4925727, 9.5673949 54.4925372, 9.567472 54.4925075, 9.5675492 54.4924886, 9.5676263 54.4924797, 9.5677035 54.492479, 9.5677807 54.4924837, 9.5678578 54.4924904, 9.567935 54.4924962, 9.5680122 54.4925002, 9.5680893 54.4925037, 9.5681665 54.4925077, 9.5682436 54.4925121, 9.5683208 54.492517, 9.568398 54.4925223)'), 8307),
    2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 5',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5621478 54.4928874, 9.562225 54.4929197, 9.5623021 54.4929564, 9.5623793 54.4929991, 9.5624564 54.4930426, 9.5625336 54.4930874, 9.5626107 54.4931351, 9.5626879 54.4931803, 9.5627651 54.4932183, 9.5628422 54.4932494, 9.5629194 54.4932756, 9.5629965 54.4933002, 9.5630737 54.493326, 9.5631509 54.493353, 9.563228 54.4933789, 9.5633052 54.4934028, 9.5633823 54.493424, 9.5634595 54.4934405, 9.5635367 54.4934525, 9.5636138 54.4934618, 9.563691 54.4934698, 9.5637681 54.4934766, 9.5638453 54.4934814, 9.5639225 54.4934828, 9.5639996 54.4934791, 9.5640768 54.4934694, 9.564154 54.4934507, 9.5642311 54.493417, 9.5643083 54.4933634, 9.5643855 54.4933228, 9.5644626 54.4933139, 9.5645398 54.4933306, 9.5646169 54.4933605, 9.5646941 54.4933864, 9.5647713 54.4934024, 9.5648484 54.4934068, 9.5649256 54.4933954, 9.5650028 54.4933634, 9.5650799 54.4933082, 9.5651571 54.4932503, 9.5652343 54.4932216, 9.5653114 54.4932122, 9.5653886 54.493208, 9.5654658 54.4931984, 9.5655429 54.4931777, 9.56562')
    || TO_CLOB('01 54.4931465, 9.5656973 54.4931159, 9.5657744 54.4930944, 9.5658516 54.4930819, 9.5659287 54.4930763, 9.5660059 54.4930741, 9.5660831 54.4930737, 9.5661602 54.4930741, 9.5662374 54.4930755, 9.5663146 54.4930777, 9.5663917 54.4930807, 9.5664689 54.4930834, 9.566546 54.4930806, 9.5666232 54.4930632, 9.5667004 54.4930238, 9.5667775 54.4929815, 9.5668547 54.4929621, 9.5669319 54.4929613, 9.567009 54.492967, 9.5670862 54.4929687, 9.5671633 54.4929601, 9.5672405 54.4929394, 9.5673177 54.4929082, 9.5673948 54.4928739, 9.567472 54.492846, 9.5675492 54.4928291)'), 8307),
    2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 6',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5623021 54.4932898, 9.5623792 54.4933293, 9.5624564 54.4933699, 9.5625335 54.4934121, 9.5626107 54.4934574, 9.5626878 54.4935008)', 8307),
    2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 7',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5637681 54.4938146, 9.5638453 54.4938229, 9.5639224 54.4938277, 9.5639996 54.4938275, 9.5640767 54.4938211, 9.5641539 54.4938057, 9.5642311 54.493775, 9.5643082 54.4937241, 9.5643854 54.4936858, 9.5644626 54.4936789, 9.5645397 54.4936973, 9.5646169 54.4937284, 9.5646941 54.4937549, 9.5647712 54.4937712, 9.5648484 54.4937753, 9.5649256 54.4937633, 9.5650027 54.4937302, 9.5650799 54.4936734, 9.5651571 54.4936136, 9.5652342 54.4935825, 9.5653114 54.4935704, 9.5653886 54.4935633, 9.5654657 54.4935505, 9.5655429 54.4935264, 9.5656201 54.4934919, 9.5656972 54.4934578, 9.5657744 54.4934327, 9.5658515 54.4934169, 9.5659287 54.493408, 9.5660059 54.4934028, 9.566083 54.4933996, 9.5661602 54.4933976, 9.5662374 54.4933969, 9.5663145 54.4933974, 9.5663917 54.4933991, 9.5664689 54.493401, 9.566546 54.4933978, 9.5666232 54.4933804, 9.5667003 54.4933416, 9.5667775 54.4933003, 9.5668547 54.4932824, 9.5669318 54.4932834, 9.567009 54.4932914, 9.5670862 54.4932957, 9.5671633 54.49329, 9.5672')
    || TO_CLOB('405 54.4932724)'), 8307),
    2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 8',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5650027 54.4940953, 9.5650798 54.494035, 9.565157 54.4939717, 9.5652342 54.4939372, 9.5653114 54.4939218, 9.5653885 54.4939115, 9.5654657 54.4938957, 9.5655428 54.493869, 9.56562 54.4938321, 9.5656972 54.4937961, 9.5657744 54.4937695, 9.5658515 54.4937526, 9.5659287 54.493743, 9.5660058 54.4937376, 9.566083 54.4937347, 9.5661602 54.4937335, 9.5662373 54.4937339, 9.5663145 54.4937361, 9.5663917 54.4937398, 9.5664688 54.4937441, 9.566546 54.4937436, 9.5666232 54.4937292, 9.5667003 54.4936936, 9.5667775 54.4936557, 9.5668547 54.4936412, 9.5669318 54.4936458, 9.567009 54.4936572)', 8307),
    2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 9',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.56562 54.4941704, 9.5656972 54.4941357, 9.5657743 54.4941109, 9.5658515 54.4940962, 9.5659286 54.4940891, 9.5660058 54.4940866, 9.566083 54.4940867, 9.5661601 54.4940887, 9.5662373 54.4940926, 9.5663145 54.4940982, 9.5663916 54.4941055, 9.5664688 54.4941132)', 8307),
    2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 10',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5666231 54.4941048, 9.5667003 54.494072, 9.5667775 54.4940368, 9.5668546 54.4940245)', 8307),
    2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 11',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5613767 54.4905051, 9.5614538 54.4905231, 9.561531 54.4905375, 9.5616081 54.4905496, 9.5616853 54.4905637, 9.5617625 54.4905828, 9.5618396 54.4906033, 9.5619168 54.4906186, 9.5619939 54.4906316, 9.5620711 54.490649, 9.5621482 54.490674, 9.5622254 54.4907019, 9.5623025 54.4907347, 9.5623797 54.4907744, 9.5624568 54.4908156, 9.562534 54.490859, 9.5626111 54.4909062, 9.5626883 54.4909518, 9.5627654 54.4909911, 9.5628426 54.4910243, 9.5629197 54.4910536, 9.5629969 54.4910819, 9.5630741 54.4911121, 9.5631512 54.4911442, 9.5632284 54.4911757, 9.5633055 54.4912056, 9.5633827 54.491233, 9.5634598 54.4912561, 9.563537 54.4912748, 9.5636141 54.4912907, 9.5636913 54.4913051, 9.5637684 54.491318, 9.5638456 54.4913286, 9.5639228 54.4913352, 9.5639999 54.4913362, 9.5640771 54.4913305, 9.5641542 54.4913151, 9.5642314 54.4912838, 9.5643086 54.4912318, 9.5643857 54.4911919, 9.5644629 54.4911828, 9.5645401 54.4911985, 9.5646172 54.4912265, 9.5646944 54.4912495, 9.5647715 54.491262, 9.56484')
    || TO_CLOB('87 54.4912621, 9.5649258 54.4912458, 9.565003 54.4912084, 9.5650802 54.4911472, 9.5651573 54.4910831, 9.5652345 54.4910479, 9.5653117 54.4910318, 9.5653888 54.4910211, 9.565466 54.4910049, 9.5655431 54.490978, 9.5656203 54.490941, 9.5656975 54.490905, 9.5657746 54.4908786, 9.5658518 54.490862, 9.5659289 54.4908529, 9.5660061 54.4908481, 9.5660833 54.4908459, 9.5661604 54.4908454, 9.5662376 54.4908467, 9.5663147 54.4908498, 9.5663919 54.4908545, 9.5664691 54.4908598, 9.5665462 54.4908603, 9.5666234 54.490847, 9.5667005 54.4908124, 9.5667777 54.4907754, 9.5668549 54.4907619, 9.566932 54.4907672, 9.5670092 54.4907794, 9.5670863 54.4907876, 9.5671635 54.4907856, 9.5672406 54.4907715, 9.5673178 54.4907465, 9.567395 54.4907183, 9.5674721 54.4906958, 9.5675493 54.490684, 9.5676264 54.4906819, 9.5677036 54.4906876, 9.5677808 54.4906982, 9.5678579 54.4907102, 9.5679351 54.4907205, 9.5680122 54.4907283, 9.5680894 54.4907346, 9.5681665 54.4907406, 9.5682437 54.4907459, 9.5683209 54.4907508, 9.568')
    || TO_CLOB('398 54.4907552, 9.5684752 54.4907592, 9.5685523 54.4907595, 9.5686295 54.4907519, 9.5687066 54.4907335, 9.5687838 54.4907066, 9.568861 54.4906755, 9.5689381 54.4906441, 9.5690153 54.4906171, 9.5690924 54.4905984, 9.5691696 54.4905899)'), 8307),
    2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 12',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5616854 54.4901742, 9.5617625 54.4901935, 9.5618397 54.4902148, 9.5619168 54.4902313, 9.561994 54.4902459, 9.5620711 54.4902654, 9.5621483 54.4902928, 9.5622254 54.4903234, 9.5623026 54.4903592, 9.5623798 54.4904021, 9.5624569 54.4904466, 9.562534 54.4904935, 9.5626112 54.4905442, 9.5626883 54.4905933, 9.5627655 54.490636, 9.5628426 54.4906723, 9.5629198 54.4907046, 9.562997 54.4907356, 9.5630741 54.4907683, 9.5631513 54.4908024, 9.5632284 54.4908355, 9.5633056 54.4908667, 9.5633827 54.4908949, 9.5634599 54.4909183, 9.563537 54.4909368, 9.5636142 54.4909521, 9.5636913 54.4909654, 9.5637685 54.4909768, 9.5638457 54.4909854, 9.5639228 54.4909897, 9.564 54.4909881, 9.5640771 54.4909794, 9.5641543 54.4909609, 9.5642315 54.4909263, 9.5643086 54.4908709, 9.5643858 54.4908275, 9.5644629 54.4908149, 9.5645401 54.4908272, 9.5646173 54.4908519, 9.5646944 54.4908719, 9.5647716 54.4908816, 9.5648487 54.4908792, 9.5649259 54.4908607, 9.5650031 54.4908216, 9.5650802 54.4907591, 9.56515')
    || TO_CLOB('74 54.4906941, 9.5652345 54.4906584, 9.5653117 54.4906424, 9.5653889 54.4906322, 9.565466 54.490617, 9.5655432 54.4905915, 9.5656203 54.4905564, 9.5656975 54.4905226, 9.5657747 54.4904988, 9.5658518 54.490485, 9.565929 54.490479, 9.5660061 54.4904775, 9.5660833 54.4904787, 9.5661605 54.4904817, 9.5662376 54.4904865, 9.5663148 54.490493, 9.5663919 54.490501, 9.5664691 54.4905094, 9.5665462 54.4905128, 9.5666234 54.490502, 9.5667006 54.4904696, 9.5667777 54.4904346, 9.5668549 54.4904224, 9.566932 54.4904288, 9.5670092 54.4904415, 9.5670863 54.4904498, 9.5671635 54.4904474, 9.5672407 54.4904324, 9.5673178 54.4904061, 9.567395 54.4903761, 9.5674721 54.4903516, 9.5675493 54.4903372, 9.5676265 54.4903324, 9.5677036 54.4903351, 9.5677808 54.4903424, 9.5678579 54.490351, 9.5679351 54.4903578, 9.5680122 54.4903621, 9.5680894 54.490365, 9.5681666 54.4903676, 9.5682437 54.4903698, 9.5683209 54.4903718, 9.568398 54.4903735, 9.5684752 54.4903752, 9.5685523 54.4903735, 9.5686295 54.4903644, 9.568706')
    || TO_CLOB('7 54.4903448, 9.5687838 54.4903173, 9.568861 54.490286, 9.5689381 54.4902549, 9.5690153 54.4902286, 9.5690924 54.4902111, 9.5691696 54.4902043, 9.5692468 54.4902071, 9.5693239 54.4902178, 9.5694011 54.4902337)'), 8307),
    2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 13',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5620712 54.4899279, 9.5621484 54.4899588, 9.5622255 54.4899926, 9.5623027 54.4900316, 9.5623798 54.4900774, 9.562457 54.4901245, 9.5625341 54.4901737, 9.5626113 54.4902262, 9.5626884 54.4902768, 9.5627656 54.4903206, 9.5628427 54.4903575, 9.5629199 54.4903899, 9.562997 54.4904206, 9.5630742 54.4904525, 9.5631513 54.4904853, 9.5632285 54.4905167, 9.5633056 54.4905458, 9.5633828 54.4905716, 9.5634599 54.4905922, 9.5635371 54.4906077, 9.5636142 54.4906197, 9.5636914 54.4906297, 9.5637685 54.4906376, 9.5638457 54.4906428, 9.5639229 54.4906436, 9.564 54.4906386, 9.5640772 54.4906268, 9.5641543 54.4906053, 9.5642315 54.4905681, 9.5643087 54.4905102, 9.5643858 54.4904649, 9.564463 54.4904507, 9.5645401 54.4904618, 9.5646173 54.4904858, 9.5646945 54.4905056, 9.5647716 54.4905155, 9.5648488 54.4905138, 9.5649259 54.4904965, 9.5650031 54.4904589, 9.5650803 54.4903984, 9.5651574 54.4903358, 9.5652346 54.4903028, 9.5653117 54.4902898, 9.5653889 54.4902827, 9.5654661 54.4902709, 9.565')
    || TO_CLOB('5432 54.4902488, 9.5656204 54.4902172, 9.5656975 54.4901869, 9.5657747 54.4901664, 9.5658519 54.4901559, 9.565929 54.4901529, 9.5660062 54.4901541, 9.5660833 54.4901578, 9.5661605 54.4901628, 9.5662376 54.4901693, 9.5663148 54.4901771, 9.566392 54.4901859, 9.5664691 54.4901947, 9.5665463 54.490198, 9.5666234 54.4901866, 9.5667006 54.4901532, 9.5667777 54.4901166, 9.5668549 54.4901026, 9.5669321 54.4901067, 9.5670092 54.4901168, 9.5670864 54.4901222, 9.5671635 54.4901167, 9.5672407 54.4900984, 9.5673178 54.4900687, 9.567395 54.4900352, 9.5674722 54.4900071, 9.5675493 54.4899894, 9.5676265 54.4899813, 9.5677036 54.4899809, 9.5677808 54.4899854, 9.5678579 54.4899915, 9.5679351 54.4899961, 9.5680123 54.4899986, 9.5680894 54.4900001, 9.5681666 54.4900018, 9.5682437 54.4900035, 9.5683209 54.4900055, 9.568398 54.4900077, 9.5684752 54.4900103, 9.5685524 54.49001, 9.5686295 54.4900027, 9.5687067 54.4899853, 9.5687838 54.4899603, 9.568861 54.4899318, 9.5689381 54.4899038, 9.5690153 54.4898808, 9')
    || TO_CLOB('.5690924 54.4898667, 9.5691696 54.4898633, 9.5692468 54.4898696, 9.5693239 54.4898837, 9.5694011 54.489903)'), 8307),
    2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 14',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5623799 54.4897358, 9.562457 54.4897825, 9.5625342 54.4898307, 9.5626113 54.4898818, 9.5626885 54.4899305, 9.5627656 54.489972, 9.5628428 54.4900064, 9.5629199 54.4900359, 9.5629971 54.4900635, 9.5630742 54.490092, 9.5631514 54.4901214, 9.5632285 54.4901494, 9.5633057 54.490175, 9.5633828 54.4901974, 9.56346 54.4902147, 9.5635371 54.4902271, 9.5636143 54.4902362, 9.5636914 54.4902436, 9.5637686 54.4902493, 9.5638458 54.4902526, 9.5639229 54.4902521, 9.5640001 54.4902461, 9.5640772 54.4902338, 9.5641544 54.4902122, 9.5642316 54.4901754, 9.5643087 54.4901185, 9.5643859 54.4900744, 9.564463 54.490062, 9.5645402 54.4900753, 9.5646174 54.4901018, 9.5646945 54.4901244, 9.5647717 54.4901373, 9.5648488 54.4901388, 9.564926 54.4901249, 9.5650031 54.4900908, 9.5650803 54.4900338, 9.5651575 54.4899746, 9.5652346 54.489945, 9.5653118 54.4899351, 9.5653889 54.489931, 9.5654661 54.4899218, 9.5655433 54.489902, 9.5656204 54.4898723, 9.5656976 54.4898435, 9.5657747 54.4898242, 9.5658519 ')
    || TO_CLOB('54.4898143, 9.565929 54.4898115, 9.5660062 54.4898124, 9.5660834 54.4898152, 9.5661605 54.4898191, 9.5662377 54.489824, 9.5663148 54.4898297, 9.566392 54.4898361, 9.5664691 54.4898421, 9.5665463 54.4898424, 9.5666234 54.4898279, 9.5667006 54.4897911, 9.5667778 54.489751, 9.5668549 54.4897335, 9.5669321 54.4897341, 9.5670092 54.4897409, 9.5670864 54.4897431, 9.5671635 54.4897346, 9.5672407 54.4897136, 9.5673179 54.4896815, 9.567395 54.489646, 9.5674722 54.4896163, 9.5675493 54.4895973, 9.5676265 54.4895885, 9.5677036 54.4895878, 9.5677808 54.4895925, 9.567858 54.4895992, 9.5679351 54.489605, 9.5680123 54.489609, 9.5680894 54.4896125, 9.5681666 54.4896165, 9.5682437 54.4896208, 9.5683209 54.4896258, 9.568398 54.4896311, 9.5684752 54.489637, 9.5685524 54.4896402, 9.5686295 54.4896364, 9.5687067 54.4896225, 9.5687838 54.4896009, 9.568861 54.4895756, 9.5689381 54.4895507, 9.5690153 54.4895305, 9.5690925 54.4895188, 9.5691696 54.4895176, 9.5692468 54.4895256, 9.5693239 54.489541, 9.5694011 5')
    || TO_CLOB('4.4895612)'), 8307),
    2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 15',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5628428 54.4896254, 9.56292 54.4896517, 9.5629971 54.4896763, 9.5630743 54.4897021, 9.5631514 54.4897291, 9.5632286 54.489755, 9.5633057 54.4897789, 9.5633829 54.4898, 9.56346 54.4898165, 9.5635372 54.4898286, 9.5636144 54.4898379, 9.5636915 54.4898459, 9.5637687 54.4898527, 9.5638458 54.4898575, 9.563923 54.4898588, 9.5640001 54.4898552, 9.5640773 54.4898454, 9.5641544 54.4898268, 9.5642316 54.4897931, 9.5643088 54.4897395, 9.5643859 54.4896989, 9.5644631 54.4896899, 9.5645402 54.4897067, 9.5646174 54.4897366, 9.5646945 54.4897624, 9.5647717 54.4897784, 9.5648489 54.4897828, 9.564926 54.4897714, 9.5650032 54.4897395, 9.5650803 54.4896842, 9.5651575 54.4896264, 9.5652347 54.4895977, 9.5653118 54.4895882, 9.565389 54.4895841, 9.5654661 54.4895744, 9.5655433 54.4895537, 9.5656204 54.4895226, 9.5656976 54.489492, 9.5657748 54.4894704, 9.5658519 54.489458, 9.5659291 54.4894523, 9.5660062 54.4894502, 9.5660834 54.4894497, 9.5661605 54.4894502, 9.5662377 54.4894516, 9.5663149 5')
    || TO_CLOB('4.4894538, 9.566392 54.4894568, 9.5664692 54.4894595, 9.5665463 54.4894567, 9.5666235 54.4894392, 9.5667006 54.4893999, 9.5667778 54.4893576, 9.566855 54.4893382, 9.5669321 54.4893373, 9.5670093 54.4893431, 9.5670864 54.4893447, 9.5671636 54.4893361, 9.5672407 54.4893155, 9.5673179 54.4892842, 9.567395 54.48925, 9.5674722 54.489222, 9.5675494 54.4892052, 9.5676265 54.4891988, 9.5677037 54.4892009, 9.5677808 54.4892086, 9.567858 54.4892186, 9.5679351 54.4892277, 9.5680123 54.4892352, 9.5680894 54.4892422, 9.5681666 54.4892496, 9.5682438 54.4892573, 9.5683209 54.4892654, 9.5683981 54.4892737, 9.5684752 54.4892823, 9.5685524 54.4892879, 9.5686295 54.489286, 9.5687067 54.4892736, 9.5687838 54.4892532, 9.568861 54.4892286, 9.5689381 54.4892039)'), 8307),
    2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 16',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5633829 54.4894417, 9.5634601 54.4894607, 9.5635373 54.4894755, 9.5636144 54.4894878, 9.5636916 54.489499, 9.5637687 54.4895091, 9.5638459 54.4895174, 9.563923 54.4895223, 9.5640002 54.4895221, 9.5640773 54.4895157, 9.5641545 54.4895002, 9.5642317 54.4894695, 9.5643088 54.4894186, 9.564386 54.4893804, 9.5644631 54.4893734, 9.5645403 54.4893918, 9.5646174 54.4894229, 9.5646946 54.4894495, 9.5647717 54.4894657, 9.5648489 54.4894699, 9.5649261 54.4894578, 9.5650032 54.4894247, 9.5650804 54.4893679, 9.5651575 54.4893081, 9.5652347 54.4892771, 9.5653119 54.489265, 9.565389 54.4892579, 9.5654662 54.489245, 9.5655433 54.489221, 9.5656205 54.4891864, 9.5656976 54.4891523, 9.5657748 54.4891273, 9.565852 54.4891115, 9.5659291 54.4891026)', 8307),
    2 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 17',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5611884 54.4908966, 9.5611914 54.4909416, 9.5611961 54.4909865, 9.5612024 54.4910314, 9.5612101 54.4910763, 9.5612189 54.4911212, 9.5612286 54.4911662, 9.5612389 54.4912111, 9.5612495 54.491256, 9.56126 54.4913009, 9.5612703 54.4913458, 9.5612799 54.4913907, 9.5612885 54.4914357, 9.561296 54.4914806, 9.5613021 54.4915255, 9.5613066 54.4915704, 9.5613094 54.4916153, 9.5613104 54.4916603, 9.5613095 54.4917052, 9.5613069 54.4917501, 9.5613025 54.491795)', 8307),
    1.8 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 18',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5623712 54.4912641, 9.5623785 54.491309, 9.562387 54.4913539, 9.5623965 54.4913989, 9.5624067 54.4914438, 9.5624172 54.4914887, 9.5624278 54.4915336, 9.5624382 54.4915785, 9.562448 54.4916235, 9.5624569 54.4916684, 9.5624648 54.4917133, 9.5624713 54.4917582, 9.5624763 54.4918031, 9.5624795 54.491848, 9.562481 54.491893, 9.5624807 54.4919379, 9.5624785 54.4919828, 9.5624746 54.4920277, 9.5624691 54.4920726, 9.5624621 54.4921176, 9.5624538 54.4921625, 9.5624445 54.4922074, 9.5624344 54.4922523, 9.5624239 54.4922972, 9.5624133 54.4923421, 9.5624028 54.4923871, 9.5623929 54.492432, 9.5623837 54.4924769, 9.5623756 54.4925218, 9.5623687 54.4925667, 9.5623634 54.4926116, 9.5623597 54.4926566, 9.5623578 54.4927015, 9.5623577 54.4927464, 9.5623594 54.4927913, 9.5623629 54.4928362, 9.5623681 54.4928811, 9.5623748 54.4929261, 9.5623828 54.492971, 9.5623919 54.4930159, 9.5624018 54.4930608, 9.5624122 54.4931057, 9.5624228 54.4931507, 9.5624333 54.4931956, 9.5624434 54.4932405, 9.5624')
    || TO_CLOB('528 54.4932854, 9.5624612 54.4933303, 9.5624683 54.4933753, 9.562474 54.4934202)'), 8307),
    1.8 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 19',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5623712 54.4911204, 9.5623785 54.4910754, 9.5623871 54.4910305, 9.5623966 54.4909856, 9.5624067 54.4909407, 9.5624173 54.4908958, 9.5624279 54.4908509, 9.5624383 54.4908059, 9.5624481 54.490761, 9.5624571 54.4907161, 9.562465 54.4906712, 9.5624715 54.4906263, 9.5624765 54.4905814, 9.5624798 54.4905364, 9.5624813 54.4904915, 9.562481 54.4904466, 9.5624788 54.4904017, 9.5624749 54.4903568, 9.5624694 54.4903119, 9.5624624 54.4902669, 9.5624541 54.490222, 9.5624449 54.4901771, 9.5624348 54.4901322, 9.5624243 54.4900873, 9.5624137 54.4900423, 9.5624033 54.4899974, 9.5623933 54.4899525, 9.5623842 54.4899076, 9.562376 54.4898627, 9.5623692 54.4898177, 9.5623639 54.4897728)', 8307),
    1.8 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 20',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5635874 54.4917326, 9.5635828 54.4917776, 9.5635766 54.4918225, 9.563569 54.4918674, 9.5635603 54.4919123, 9.5635506 54.4919572, 9.5635404 54.4920021, 9.5635298 54.4920471, 9.5635192 54.492092, 9.5635089 54.4921369, 9.5634992 54.4921818, 9.5634904 54.4922267, 9.5634828 54.4922717, 9.5634766 54.4923166, 9.563472 54.4923615, 9.563469 54.4924064, 9.5634679 54.4924513, 9.5634686 54.4924962, 9.5634711 54.4925412, 9.5634753 54.4925861, 9.5634811 54.492631, 9.5634884 54.4926759, 9.5634969 54.4927208, 9.5635064 54.4927658, 9.5635165 54.4928107, 9.5635271 54.4928556, 9.5635377 54.4929005, 9.5635481 54.4929454, 9.5635579 54.4929903, 9.5635669 54.4930353, 9.5635747 54.4930802, 9.5635813 54.4931251, 9.5635863 54.49317, 9.5635896 54.4932149, 9.5635911 54.4932599, 9.5635908 54.4933048, 9.5635887 54.4933497, 9.5635848 54.4933946, 9.5635793 54.4934395, 9.5635723 54.4934844, 9.5635641 54.4935294, 9.5635548 54.4935743, 9.5635447 54.4936192, 9.5635342 54.4936641, 9.5635236 54.493709)', 8307),
    1.8 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 21',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5635875 54.4915889, 9.5635829 54.491544, 9.5635767 54.4914991, 9.5635691 54.4914542, 9.5635604 54.4914092, 9.5635507 54.4913643, 9.5635405 54.4913194, 9.5635299 54.4912745, 9.5635193 54.4912296, 9.563509 54.4911846, 9.5634994 54.4911397, 9.5634906 54.4910948, 9.563483 54.4910499, 9.5634768 54.491005, 9.5634722 54.49096, 9.5634693 54.4909151, 9.5634681 54.4908702, 9.5634688 54.4908253, 9.5634713 54.4907804, 9.5634756 54.4907355, 9.5634814 54.4906905, 9.5634887 54.4906456, 9.5634972 54.4906007, 9.5635067 54.4905558, 9.5635169 54.4905109, 9.5635274 54.490466, 9.5635381 54.490421, 9.5635484 54.4903761, 9.5635583 54.4903312, 9.5635673 54.4902863, 9.5635752 54.4902414, 9.5635817 54.4901964, 9.5635867 54.4901515, 9.56359 54.4901066, 9.5635916 54.4900617, 9.5635913 54.4900168, 9.5635892 54.4899719, 9.5635853 54.4899269, 9.5635798 54.489882, 9.5635729 54.4898371, 9.5635646 54.4897922, 9.5635553 54.4897473, 9.5635453 54.4897024, 9.5635348 54.4896574, 9.5635242 54.4896125, 9.5635138')
    || TO_CLOB(' 54.4895676, 9.5635038 54.4895227, 9.5634946 54.4894778, 9.5634865 54.4894328)'), 8307),
    1.8 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 22',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5647033 54.4916761, 9.564693 54.491721, 9.5646834 54.4917659, 9.5646748 54.4918109, 9.5646673 54.4918558, 9.5646612 54.4919007, 9.5646568 54.4919456, 9.564654 54.4919905, 9.564653 54.4920355, 9.5646539 54.4920804, 9.5646566 54.4921253, 9.564661 54.4921702, 9.564667 54.4922151, 9.5646744 54.49226, 9.564683 54.492305, 9.5646926 54.4923499, 9.5647028 54.4923948, 9.5647133 54.4924397, 9.5647239 54.4924846, 9.5647343 54.4925296, 9.564744 54.4925745, 9.5647529 54.4926194, 9.5647606 54.4926643, 9.564767 54.4927092, 9.5647719 54.4927541, 9.564775 54.4927991, 9.5647763 54.492844, 9.5647759 54.4928889, 9.5647736 54.4929338, 9.5647695 54.4929787, 9.5647639 54.4930237, 9.5647567 54.4930686, 9.5647484 54.4931135, 9.564739 54.4931584, 9.5647289 54.4932033, 9.5647184 54.4932482, 9.5647077 54.4932932, 9.5646973 54.4933381, 9.5646874 54.493383, 9.5646783 54.4934279, 9.5646703 54.4934728, 9.5646635 54.4935177, 9.5646583 54.4935627, 9.5646548 54.4936076, 9.564653 54.4936525, 9.5646531 54.49')
    || TO_CLOB('36974, 9.564655 54.4937423, 9.5646586 54.4937873, 9.5646639 54.4938322, 9.5646708 54.4938771, 9.5646789 54.493922, 9.564688 54.4939669)'), 8307),
    1.8 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 23',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5647033 54.4915324, 9.5646931 54.4914875, 9.5646835 54.4914425, 9.5646748 54.4913976, 9.5646674 54.4913527, 9.5646613 54.4913078, 9.5646568 54.4912629, 9.5646541 54.4912179, 9.5646531 54.491173, 9.564654 54.4911281, 9.5646567 54.4910832, 9.5646611 54.4910383, 9.5646671 54.4909934, 9.5646746 54.4909484, 9.5646832 54.4909035, 9.5646927 54.4908586, 9.564703 54.4908137, 9.5647135 54.4907688, 9.5647241 54.4907239, 9.5647345 54.4906789, 9.5647442 54.490634, 9.5647531 54.4905891, 9.5647609 54.4905442, 9.5647673 54.4904993, 9.5647721 54.4904543, 9.5647753 54.4904094, 9.5647766 54.4903645, 9.5647762 54.4903196, 9.5647739 54.4902747, 9.5647699 54.4902298, 9.5647642 54.4901848, 9.5647571 54.4901399, 9.5647487 54.490095, 9.5647394 54.4900501, 9.5647293 54.4900052, 9.5647188 54.4899602, 9.5647081 54.4899153, 9.5646977 54.4898704, 9.5646878 54.4898255, 9.5646787 54.4897806, 9.5646707 54.4897357, 9.564664 54.4896907, 9.5646588 54.4896458, 9.5646553 54.4896009, 9.5646535 54.489556, 9.564')
    || TO_CLOB('6536 54.4895111, 9.5646555 54.4894661, 9.5646592 54.4894212, 9.5646645 54.4893763, 9.5646713 54.4893314, 9.5646794 54.4892865, 9.5646886 54.4892416, 9.5646986 54.4891966)'), 8307),
    1.8 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 24',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5657751 54.4913297, 9.5657836 54.4913747, 9.5657931 54.4914196, 9.5658033 54.4914645, 9.5658138 54.4915094, 9.5658244 54.4915543, 9.5658348 54.4915993, 9.5658446 54.4916442, 9.5658535 54.4916891, 9.5658614 54.491734, 9.5658678 54.4917789, 9.5658728 54.4918238, 9.565876 54.4918688, 9.5658774 54.4919137, 9.5658771 54.4919586, 9.5658749 54.4920035, 9.5658709 54.4920484, 9.5658654 54.4920934, 9.5658583 54.4921383, 9.56585 54.4921832, 9.5658407 54.4922281, 9.5658306 54.492273, 9.5658201 54.4923179, 9.5658095 54.4923629, 9.565799 54.4924078, 9.5657891 54.4924527, 9.5657799 54.4924976, 9.5657718 54.4925425, 9.565765 54.4925874, 9.5657597 54.4926324, 9.5657561 54.4926773, 9.5657542 54.4927222, 9.5657542 54.4927671, 9.565756 54.492812, 9.5657595 54.492857, 9.5657648 54.4929019, 9.5657715 54.4929468, 9.5657795 54.4929917, 9.5657886 54.4930366, 9.5657986 54.4930815, 9.565809 54.4931265, 9.5658196 54.4931714, 9.5658301 54.4932163, 9.5658402 54.4932612, 9.5658495 54.4933061, 9.5658579')
    || TO_CLOB(' 54.4933511, 9.565865 54.493396, 9.5658706 54.4934409, 9.5658746 54.4934858, 9.5658769 54.4935307, 9.5658773 54.4935756, 9.5658759 54.4936206, 9.5658727 54.4936655, 9.5658679 54.4937104, 9.5658615 54.4937553, 9.5658537 54.4938002, 9.5658448 54.4938452, 9.565835 54.4938901, 9.5658246 54.493935, 9.565814 54.4939799, 9.5658035 54.4940248, 9.5657933 54.4940697, 9.5657837 54.4941147, 9.5657751 54.4941596)'), 8307),
    1.8 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GASSE', 'Gasse 25',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5657751 54.491186, 9.5657836 54.4911411, 9.5657931 54.4910962, 9.5658033 54.4910513, 9.5658139 54.4910063, 9.5658245 54.4909614, 9.5658349 54.4909165, 9.5658447 54.4908716, 9.5658536 54.4908267, 9.5658614 54.4907818, 9.5658679 54.4907368, 9.5658729 54.4906919, 9.5658761 54.490647, 9.5658776 54.4906021, 9.5658772 54.4905572, 9.565875 54.4905122, 9.5658711 54.4904673, 9.5658655 54.4904224, 9.5658585 54.4903775, 9.5658502 54.4903326, 9.5658409 54.4902877, 9.5658308 54.4902427, 9.5658203 54.4901978, 9.5658097 54.4901529, 9.5657993 54.490108, 9.5657893 54.4900631, 9.5657802 54.4900181, 9.5657721 54.4899732, 9.5657653 54.4899283, 9.56576 54.4898834, 9.5657564 54.4898385, 9.5657545 54.4897936, 9.5657545 54.4897486, 9.5657563 54.4897037, 9.5657598 54.4896588, 9.5657651 54.4896139, 9.5657718 54.489569, 9.5657799 54.489524, 9.565789 54.4894791, 9.5657989 54.4894342, 9.5658093 54.4893893, 9.56582 54.4893444, 9.5658305 54.4892995, 9.5658406 54.4892545, 9.5658499 54.4892096, 9.5658583')
    || TO_CLOB(' 54.4891647, 9.5658654 54.4891198)'), 8307),
    1.8 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 1',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5612919 54.4913739, 9.5614459 54.4914026, 9.5614083 54.491471, 9.5612543 54.4914424, 9.5612919 54.4913739))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 2',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5614805 54.4913425, 9.5616317 54.4913702, 9.5615946 54.4914388, 9.5614435 54.4914111, 9.5614805 54.4913425))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 10',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5616932 54.4912947, 9.5616228 54.4914251)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 11',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5619304 54.491351, 9.5618556 54.4914788)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 3',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5618472 54.491147, 9.561887 54.491079, 9.5620485 54.491111, 9.5620086 54.491179, 9.5618472 54.491147))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 12',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5622986 54.4914661, 9.5621506 54.4915839)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 13',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5624508 54.4915475, 9.5622837 54.4916535)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 14',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5626416 54.4916095, 9.5628489 54.4914946)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 4',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5625937 54.4917502, 9.5627363 54.4918116, 9.562663 54.4918694, 9.5625204 54.4918081, 9.5625937 54.4917502))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 15',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5628361 54.4917546, 9.5626991 54.4918626)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 5',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5628837 54.4918752, 9.5630508 54.4919446, 9.5629791 54.4920031, 9.562812 54.4919337, 9.5628837 54.4918752))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 16',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5633786 54.4919634, 9.5632019 54.4921316)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 17',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5634108 54.4919327, 9.5635439 54.491806)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 18',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5638669 54.4920606, 9.5638091 54.4922038)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 6',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5637499 54.4918536, 9.5637782 54.4917837, 9.5639473 54.4918068, 9.563919 54.4918768, 9.5637499 54.4918536))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 7',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5638465 54.492209, 9.5639862 54.4922108, 9.5639835 54.4922827, 9.5638437 54.4922809, 9.5638465 54.492209))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 8',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5641779 54.4921331, 9.5643187 54.4920761, 9.5643892 54.4921351, 9.5642483 54.4921921, 9.5641779 54.4921331))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 19',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5642245 54.4919754, 9.5640317 54.4918139)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 20',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5643646 54.4918895, 9.5641186 54.4917282)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 9',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5648388 54.4921346, 9.5650344 54.4920933, 9.5650766 54.4921608, 9.5648809 54.4922022, 9.5648388 54.4921346))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 21',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5649814 54.4919638, 9.5650905 54.4921388)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 22',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5651913 54.4917968, 9.5655104 54.491927)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 10',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5648948 54.491801, 9.5647937 54.4917598, 9.5648835 54.4916851, 9.5649846 54.4917264, 9.5648948 54.491801))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 23',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5656904 54.491596, 9.5655478 54.4914924)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 24',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5658684 54.49155, 9.5657448 54.4913552)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 11',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5659448 54.4917412, 9.5660981 54.4917367, 9.5661042 54.4918085, 9.5659509 54.491813, 9.5659448 54.4917412))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 25',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5661004 54.4915381, 9.5660823 54.4913265)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 26',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5667285 54.4915332, 9.5669102 54.4916703)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 12',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5669023 54.4915777, 9.5670556 54.491594, 9.5670333 54.4916647, 9.56688 54.4916484, 9.5669023 54.4915777))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 27',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5670994 54.491518, 9.567058 54.4916491)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 13',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5674863 54.4915086, 9.5676299 54.4915048, 9.5676355 54.4915766, 9.5674919 54.4915804, 9.5674863 54.4915086))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 14',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5677942 54.4915553, 9.5679956 54.4915757, 9.5679744 54.4916465, 9.567773 54.4916261, 9.5677942 54.4915553))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 28',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5680556 54.4914616, 9.5680049 54.4916313)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 29',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.568255 54.4914755, 9.5682122 54.491685)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 15',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5682976 54.4916034, 9.5684554 54.4916115, 9.5684445 54.4916831, 9.5682868 54.491675, 9.5682976 54.4916034))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 30',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5690369 54.4913412, 9.5692861 54.4915823)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 16',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.561107 54.491266, 9.5612073 54.4912241, 9.5612884 54.4912898, 9.5611882 54.4913317, 9.561107 54.491266))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 17',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.561432 54.491452, 9.561467 54.491383, 9.5616526 54.4914149, 9.5616177 54.4914838, 9.561432 54.491452))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 31',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5615784 54.4916113, 9.5616671 54.4914361)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 18',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5617149 54.4914658, 9.5617638 54.4913998, 9.5619398 54.4914439, 9.561891 54.4915099, 9.5617149 54.4914658))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 19',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5618965 54.4915955, 9.5619346 54.4915271, 9.5620806 54.4915547, 9.5620425 54.4916231, 9.5618965 54.4915955))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 32',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5620173 54.4917045, 9.5620894 54.4915752)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 20',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5621522 54.4915546, 9.5622165 54.4914933, 9.5623788 54.491551, 9.5623145 54.4916123, 9.5621522 54.4915546))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 33',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5623692 54.4918942, 9.5621486 54.4920288)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 34',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5627338 54.4921163, 9.5624967 54.4922615)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 35',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5627763 54.4920903, 9.5630226 54.4919395)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 36',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5629264 54.4922026, 9.5627161 54.4923732)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 21',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5628632 54.4920282, 9.5629352 54.4919698, 9.5630985 54.492038, 9.5630265 54.4920964, 9.5628632 54.4920282))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 22',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5630837 54.4920628, 9.5631563 54.4920046, 9.5632809 54.4920574, 9.5632083 54.4921155, 9.5630837 54.4920628))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 37',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5630927 54.4922271, 9.5632783 54.4920785)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 23',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5632241 54.4924288, 9.5633877 54.4924784, 9.5633307 54.4925422, 9.5631671 54.4924926, 9.5632241 54.4924288))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 38',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5634705 54.4924149, 9.5633654 54.4925324)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 24',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5634856 54.4924982, 9.5636529 54.4925271, 9.5636178 54.492596, 9.5634505 54.4925671, 9.5634856 54.4924982))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 39',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5637097 54.4924603, 9.5636475 54.4925824)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 25',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5643777 54.4925296, 9.5644805 54.4924557, 9.5645764 54.492501, 9.5644736 54.4925748, 9.5643777 54.4925296))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 40',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5643195 54.4923645, 9.5645653 54.4924804)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 26',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5642316 54.4921529, 9.5641982 54.4920837, 9.5643518 54.4920586, 9.5643852 54.4921278, 9.5642316 54.4921529))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 41',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5644733 54.4922675, 9.5643793 54.4920728)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 27',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5646827 54.4924694, 9.5648806 54.4924632, 9.5648873 54.4925349, 9.5646893 54.4925411, 9.5646827 54.4924694))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 42',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5648968 54.4923687, 9.5649103 54.4925162)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 28',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651765 54.4924391, 9.5652936 54.4923443, 9.5653938 54.4923862, 9.5652767 54.4924811, 9.5651765 54.4924391))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 29',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5646849 54.4922334, 9.5645847 54.4921915, 9.5647018 54.4920966, 9.564802 54.4921386, 9.5646849 54.4922334))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 43',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.565051 54.4922248, 9.5647415 54.4920953)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 44',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5652663 54.4921397, 9.5654962 54.4923084)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 30',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.565662 54.4922365, 9.5658011 54.4921731, 9.5658772 54.4922297, 9.5657381 54.4922931, 9.565662 54.4922365))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 45',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.565649 54.4920391, 9.5658755 54.4922077)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 46',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5657613 54.4919555, 9.5655884 54.491766)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 31',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5659964 54.4920664, 9.566143 54.4920721, 9.5661347 54.4921438, 9.5659882 54.4921381, 9.5659964 54.4920664))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 47',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5661727 54.4919731, 9.5661551 54.4921266)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 32',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5660319 54.4917569, 9.5660401 54.4916852, 9.5661866 54.4916909, 9.5661784 54.4917626, 9.5660319 54.4917569))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 48',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5661768 54.4919373, 9.5662029 54.4917095)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 33',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.566355 54.4921546, 9.5665366 54.4921627, 9.5665272 54.4922343, 9.5663455 54.4922262, 9.566355 54.4921546))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 49',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5665801 54.4920053, 9.5665522 54.4922174)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 50',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5668126 54.4919144, 9.5670039 54.492057)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 51',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5670474 54.4919021, 9.5671371 54.4917176)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 34',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5670061 54.4920911, 9.5671964 54.4920853, 9.5672029 54.4921571, 9.5670126 54.4921629, 9.5670061 54.4920911))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 52',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5674093 54.4918652, 9.5676107 54.4920408)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 53',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.567375 54.4918353, 9.5671964 54.4916796)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 35',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5672947 54.4917006, 9.5672572 54.4916321, 9.5674559 54.4915952, 9.5674934 54.4916637, 9.5672947 54.4917006))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 36',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5676475 54.4920063, 9.5677827 54.4920214, 9.5677594 54.492092, 9.5676241 54.4920769, 9.5676475 54.4920063))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 54',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5681802 54.4918231, 9.5681987 54.491636)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 55',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5685914 54.4918637, 9.5686039 54.4920648)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 37',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5683681 54.4916092, 9.5683636 54.4915373, 9.5685479 54.4915335, 9.5685523 54.4916053, 9.5683681 54.4916092))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 38',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5686424 54.4916614, 9.5685721 54.4916023, 9.568711 54.4915464, 9.5687812 54.4916055, 9.5686424 54.4916614))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 39',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5614016 54.4917295, 9.561448 54.4916629, 9.5615965 54.491698, 9.5615502 54.4917646, 9.5614016 54.4917295))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 56',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5614808 54.4918952, 9.5616035 54.491719)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 40',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5613972 54.4920088, 9.5615577 54.4920378, 9.5615211 54.4921064, 9.5613606 54.4920774, 9.5613972 54.4920088))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 57',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5616219 54.4919589, 9.5615503 54.4920929)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 41',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5617854 54.4920971, 9.5619209 54.4921288, 9.5618749 54.4921954, 9.5617394 54.4921638, 9.5617854 54.4920971))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 58',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5619896 54.4920576, 9.5619033 54.4921827)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 42',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.561949 54.4922226, 9.5621012 54.4922995, 9.5620203 54.4923537, 9.5618681 54.4922768, 9.561949 54.4922226))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 59',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5623 54.4921885, 9.5620595 54.4923498)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 43',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.562264 54.4920113, 9.562345 54.491957, 9.5624972 54.4920339, 9.5624162 54.4920882, 9.562264 54.4920113))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 60',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5623405 54.4921614, 9.5624959 54.4920571)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 61',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5624334 54.4922707, 9.5622006 54.4923997)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 44',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.562488 54.4924471, 9.5626315 54.4925284, 9.5625454 54.4925799, 9.5624019 54.4924986, 9.562488 54.4924471))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 62',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5627562 54.4924748, 9.5625848 54.4925772)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 63',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5630448 54.4925523, 9.5632219 54.4924015)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 64',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5632323 54.4926746, 9.5630492 54.492827)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 45',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5633147 54.4925656, 9.5633762 54.4925033, 9.5635319 54.4925553, 9.5634704 54.4926176, 9.5633147 54.4925656))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 65',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.563418 54.492697, 9.563536 54.4925774)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 46',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.56365 54.4928703, 9.5638451 54.4928833, 9.563831 54.4929547, 9.5636359 54.4929417, 9.56365 54.4928703))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 47',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5639642 54.4929312, 9.5641647 54.4929005, 9.5641962 54.49297, 9.5639956 54.4930007, 9.5639642 54.4929312))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 66',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5641329 54.492771, 9.5642134 54.4929487)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 48',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5640353 54.4926844, 9.5639378 54.4926403, 9.5640556 54.4925521, 9.5641531 54.4925962, 9.5640353 54.4926844))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 67',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5642805 54.4926361, 9.5640947 54.4925521)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 49',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5642467 54.4925144, 9.5642095 54.4924458, 9.5643782 54.4924148, 9.5644154 54.4924833, 9.5642467 54.4925144))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 68',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.565125 54.4924653, 9.5649225 54.4923807)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 50',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5652406 54.4925472, 9.5654438 54.4925286, 9.5654629 54.4925996, 9.5652597 54.4926182, 9.5652406 54.4925472))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 69',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5656597 54.4923572, 9.5658709 54.4925317)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 51',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5658944 54.4923987, 9.5660857 54.4924077, 9.5660758 54.4924793, 9.5658844 54.4924703, 9.5658944 54.4923987))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 70',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5661231 54.4923119, 9.5661022 54.4924626)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 52',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5659232 54.4921912, 9.5659331 54.4921195, 9.5661245 54.4921285, 9.5661145 54.4922002, 9.5659232 54.4921912))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 71',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5661281 54.4922761, 9.5661459 54.4921476)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 53',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5660892 54.4924469, 9.5662944 54.4924676, 9.5662734 54.4925384, 9.5660682 54.4925177, 9.5660892 54.4924469))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 54',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5663606 54.4925018, 9.5665324 54.4925092, 9.5665233 54.4925809, 9.5663515 54.4925735, 9.5663606 54.4925018))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 72',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.566574 54.4923515, 9.566547 54.4925639)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 55',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5667487 54.4923287, 9.5669306 54.4923383, 9.5669195 54.4924099, 9.5667376 54.4924002, 9.5667487 54.4923287))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 73',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5669657 54.4922608, 9.566945 54.4923932)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 56',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5667883 54.4920747, 9.5667995 54.4920031, 9.5669814 54.4920127, 9.5669703 54.4920843, 9.5667883 54.4920747))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 74',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5671883 54.4922673, 9.567246 54.4925418)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 75',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.567952 54.4921494, 9.5679196 54.4923329)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 76',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5679583 54.4921137, 9.5679921 54.4919223)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 77',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5683551 54.4921586, 9.568334 54.4924345)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 78',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5686061 54.4921621, 9.5686079 54.4923497)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 79',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.568825 54.4921018, 9.5689804 54.4922644)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 57',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5689852 54.4921809, 9.5691097 54.4921438, 9.569166 54.4922078, 9.5690415 54.4922449, 9.5689852 54.4921809))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 80',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.56903 54.4920309, 9.5691675 54.4921872)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 58',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.56179 54.4922708, 9.5618542 54.4922094, 9.5619809 54.4922543, 9.5619166 54.4923157, 9.56179 54.4922708))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 81',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5618573 54.4923932, 9.5619806 54.4922753)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 59',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5617502 54.492509, 9.5619256 54.4925549, 9.561875 54.4926204, 9.5616997 54.4925746, 9.5617502 54.492509))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 82',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5620134 54.4924753, 9.5619096 54.4926098)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 83',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.562369 54.4926465, 9.5621989 54.4927439)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 84',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5625731 54.4927752, 9.562382 54.492873)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 60',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5624897 54.4928625, 9.5626336 54.4929399, 9.5625498 54.4929927, 9.5624059 54.4929153, 9.5624897 54.4928625))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 85',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5627569 54.4928832, 9.5625887 54.4929892)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 61',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5627368 54.4929998, 9.5628905 54.4930548, 9.5628259 54.4931161, 9.5626721 54.4930611, 9.5627368 54.4929998))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 86',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5629994 54.4929768, 9.5628613 54.4931076)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 62',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5629408 54.4928065, 9.5630054 54.4927453, 9.5631592 54.4928003, 9.5630945 54.4928615, 9.5629408 54.4928065))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 63',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5629163 54.4930455, 9.5630386 54.4930922, 9.562971 54.4931523, 9.5628486 54.4931056, 9.5629163 54.4930455))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 87',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5631333 54.4930274, 9.5630032 54.4931431)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 64',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5630487 54.4931054, 9.5632237 54.4931634, 9.5631626 54.4932259, 9.5629876 54.4931678, 9.5630487 54.4931054))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 88',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5633527 54.4930613, 9.5634736 54.4929378)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 65',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5633369 54.4931961, 9.5634855 54.49322, 9.5634527 54.4932893, 9.5633041 54.4932654, 9.5633369 54.4931961))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 89',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5635442 54.4931381, 9.5634795 54.4932749)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 66',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5635957 54.4932531, 9.5637325 54.4932632, 9.563717 54.4933345, 9.5635802 54.4933244, 9.5635957 54.4932531))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 90',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5637727 54.493159, 9.563738 54.493318)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 67',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5636445 54.4930293, 9.5636601 54.492958, 9.5637969 54.4929681, 9.5637813 54.4930394, 9.5636445 54.4930293))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 68',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5637527 54.4932592, 9.5639429 54.4932579, 9.5639444 54.4933297, 9.5637542 54.4933311, 9.5637527 54.4932592))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 91',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5639646 54.493161, 9.5639678 54.4933116)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 92',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5639639 54.493125, 9.56396 54.4929449)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 93',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5643168 54.4930324, 9.5645805 54.4931535)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 94',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5642684 54.4930101, 9.5640227 54.4928973)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 69',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5652284 54.4930133, 9.565362 54.4929621, 9.5654299 54.4930221, 9.5652964 54.4930733, 9.5652284 54.4930133))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 95',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5652576 54.4928488, 9.5654296 54.4930007)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 70',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5649118 54.4927338, 9.5648438 54.4926738, 9.5649774 54.4926226, 9.5650454 54.4926826, 9.5649118 54.4927338))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 96',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5652236 54.4928188, 9.5650111 54.4926312)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 71',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5653488 54.4927281, 9.5652806 54.4926682, 9.5654478 54.4926038, 9.565516 54.4926637, 9.5653488 54.4927281))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 97',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5656304 54.492738, 9.5654858 54.4926107)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 98',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5660556 54.4926862, 9.5660626 54.4924848)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 99',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5663261 54.4927036, 9.566363 54.4925346)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 72',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5669117 54.4927489, 9.5670861 54.4927539, 9.56708 54.4928257, 9.5669057 54.4928207, 9.5669117 54.4927489))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 100',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5671165 54.4926532, 9.5671033 54.4928084)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 73',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5669344 54.4924819, 9.5669405 54.4924101, 9.5671148 54.4924151, 9.5671088 54.4924869, 9.5669344 54.4924819))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 101',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5673498 54.4925814, 9.5676242 54.492805)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 74',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5675644 54.4927198, 9.5677008 54.4927186, 9.5677026 54.4927905, 9.5675663 54.4927917, 9.5675644 54.4927198))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 75',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5675544 54.492336, 9.5675525 54.4922641, 9.5676889 54.4922629, 9.5676908 54.4923348, 9.5675544 54.492336))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 102',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5680266 54.492519, 9.5679983 54.4927008)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 76',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5625892 54.4932655, 9.5627515 54.4933308, 9.5626813 54.4933899, 9.5625191 54.4933246, 9.5625892 54.4932655))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 77',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5629884 54.4934167, 9.5631376 54.4934668, 9.563076 54.4935291, 9.5629267 54.493479, 9.5629884 54.4934167))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 103',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5632287 54.4933999, 9.56311 54.4935197)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 78',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5631704 54.4932329, 9.563232 54.4931706, 9.5633813 54.4932207, 9.5633196 54.493283, 9.5631704 54.4932329))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 104',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5632595 54.4933687, 9.5633845 54.4932425)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 79',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5631605 54.4934755, 9.5633013 54.493514, 9.5632487 54.493579, 9.563108 54.4935405, 9.5631605 54.4934755))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 80',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5633086 54.4935461, 9.5634994 54.4935759, 9.5634674 54.4936453, 9.5632766 54.4936155, 9.5633086 54.4935461))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 105',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5635707 54.4934765, 9.5634992 54.4936317)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 81',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5634115 54.4933227, 9.5634435 54.4932533, 9.5636342 54.4932831, 9.5636023 54.4933525, 9.5634115 54.4933227))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 106',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5635867 54.4934417, 9.5636501 54.4933042)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 107',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5638895 54.4935022, 9.5638597 54.4936638)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 108',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5640931 54.4934857, 9.5641529 54.4936465)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 82',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5638954 54.4933946, 9.5638692 54.4933243, 9.5640083 54.4933068, 9.5640344 54.493377, 9.5638954 54.4933946))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 109',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.56408 54.4934506, 9.5640322 54.4933222)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 83',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5642152 54.4935661, 9.5643271 54.4935173, 9.5644011 54.4935748, 9.5642892 54.4936236, 9.5642152 54.4935661))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 110',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5645071 54.493327, 9.5645833 54.4935495)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 84',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5647062 54.4932593, 9.5646758 54.4931897, 9.5648225 54.493168, 9.5648529 54.4932377, 9.5647062 54.4932593))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 85',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651323 54.4934954, 9.5652512 54.4934103, 9.565347 54.4934557, 9.5652281 54.4935408, 9.5651323 54.4934954))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 111',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.565101 54.4933216, 9.5653379 54.4934337)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 112',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5654824 54.4932146, 9.5655581 54.4934188)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 86',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5652791 54.4931098, 9.565253 54.4930396, 9.5653927 54.493022, 9.5654188 54.4930923, 9.5652791 54.4931098))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 113',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5654694 54.4931795, 9.5654167 54.4930374)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 87',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5655364 54.4930497, 9.5654829 54.4929849, 9.5656554 54.4929366, 9.5657089 54.4930014, 9.5655364 54.4930497))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 88',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5658538 54.4932981, 9.5660402 54.4932928, 9.5660462 54.4933646, 9.5658598 54.4933698, 9.5658538 54.4932981))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 89',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.566121 54.4932165, 9.5663292 54.4932226, 9.566323 54.4932943, 9.5661149 54.4932883, 9.566121 54.4932165))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 114',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.566366 54.4930972, 9.5663506 54.4932771)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 115',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5665947 54.4930969, 9.5666174 54.4933093)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 116',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5668101 54.4929883, 9.5670409 54.4931311)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 90',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5665135 54.4929909, 9.5664289 54.4929386, 9.5665707 54.4928609, 9.5666553 54.4929132, 9.5665135 54.4929909))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 91',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5670602 54.4932095, 9.5672628 54.493187, 9.567286 54.4932576, 9.5670834 54.4932801, 9.5670602 54.4932095))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 92',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5669516 54.4928785, 9.5669284 54.4928079, 9.567131 54.4927854, 9.5671542 54.492856, 9.5669516 54.4928785))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 93',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5623695 54.4931938, 9.5624511 54.4931399, 9.5625643 54.4931979, 9.5624827 54.4932519, 9.5623695 54.4931938))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 94',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5639119 54.4937252, 9.5638717 54.4936573, 9.5640651 54.4936185, 9.5641053 54.4936865, 9.5639119 54.4937252))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 117',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5641876 54.4937799, 9.5640993 54.4936307)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 95',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5643762 54.4938304, 9.5644884 54.4937748, 9.5645685 54.4938295, 9.5644562 54.4938851, 9.5643762 54.4938304))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 118',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5644038 54.4937003, 9.5645625 54.4938088)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 119',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5643638 54.493673, 9.5641791 54.4935466)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 96',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5644691 54.4935617, 9.5645158 54.4934952, 9.5646459 54.4935261, 9.5645991 54.4935927, 9.5644691 54.4935617))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 97',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5646816 54.4938704, 9.564828 54.4938783, 9.5648166 54.4939498, 9.5646703 54.4939419, 9.5646816 54.4938704))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 120',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5648599 54.493794, 9.5648378 54.4939329)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 98',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5650466 54.4939506, 9.565197 54.4938861, 9.5652702 54.493944, 9.5651198 54.4940085, 9.5650466 54.4939506))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 121',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5650379 54.4937374, 9.5652707 54.4939215)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 122',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5650013 54.4937085, 9.5648442 54.4935844)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 123',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5651636 54.4936384, 9.5654614 54.4937687)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 99',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5648792 54.4936429, 9.5647805 54.4935997, 9.5648749 54.4935265, 9.5649736 54.4935697, 9.5648792 54.4936429))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 100',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5650848 54.4934837, 9.5650527 54.4934143, 9.5652459 54.493384, 9.565278 54.4934534, 9.5650848 54.4934837))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 124',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5653469 54.4935462, 9.5652781 54.4933975)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 101',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.565951 54.4935629, 9.5660991 54.4935568, 9.5661079 54.4936285, 9.5659598 54.4936346, 9.565951 54.4935629))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 125',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5661006 54.4934169, 9.5661242 54.4936098)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 102',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5661638 54.4932561, 9.5661652 54.4931842, 9.5663179 54.4931852, 9.5663165 54.4932571, 9.5661638 54.4932561))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 103',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5667693 54.4934294, 9.5669362 54.4933907, 9.566982 54.4934574, 9.5668151 54.4934962, 9.5667693 54.4934294))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 126',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5668932 54.4932928, 9.5669914 54.4934359)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 104',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5665897 54.4931675, 9.5665439 54.4931008, 9.5667108 54.493062, 9.5667566 54.4931288, 9.5665897 54.4931675))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 105',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5669488 54.4931755, 9.5669604 54.4931039, 9.5671171 54.4931125, 9.5671055 54.4931841, 9.5669488 54.4931755))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 106',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651584 54.4941643, 9.5652473 54.4940949, 9.5653463 54.4941378, 9.5652574 54.4942073, 9.5651584 54.4941643))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 127',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5653412 54.4939348, 9.5654422 54.4941057)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 107',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.565479 54.4940243, 9.5656533 54.493964, 9.5657163 54.4940258, 9.5655421 54.494086, 9.565479 54.4940243))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 108',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5662093 54.4939224, 9.5663652 54.49393, 9.5663549 54.4940016, 9.5661991 54.493994, 9.5662093 54.4939224))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 128',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5664093 54.4937587, 9.566377 54.4939846)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 129',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5665558 54.4937256, 9.5665518 54.493501)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 109',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5666777 54.4938391, 9.5667945 54.4937852, 9.5668712 54.4938415, 9.5667545 54.4938954, 9.5666777 54.4938391))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 130',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5667153 54.4937096, 9.5668667 54.4938207)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 110',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5667435 54.4937648, 9.5669145 54.4937327, 9.5669524 54.4938011, 9.5667814 54.4938332, 9.5667435 54.4937648))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 131',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5668749 54.4936186, 9.5667773 54.4934424)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 132',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5656871 54.4941175, 9.5654948 54.4939724)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 111',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5662516 54.4939868, 9.5662712 54.4939158, 9.5664539 54.4939329, 9.5664343 54.4940039, 9.5662516 54.4939868))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 112',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5665829 54.4938408, 9.5665506 54.4937714, 9.5667424 54.4937411, 9.5667748 54.4938104, 9.5665829 54.4938408))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 133',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5668893 54.4940004, 9.5667745 54.4937546)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 113',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5612298 54.4905957, 9.5613757 54.4906297, 9.5613299 54.4906964, 9.5611839 54.4906625, 9.5612298 54.4905957))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 114',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5613851 54.4906782, 9.5615358 54.4907018, 9.5615037 54.4907712, 9.561353 54.4907476, 9.5613851 54.4906782))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 115',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5615365 54.4906444, 9.561689 54.490682, 9.5616408 54.4907482, 9.5614882 54.4907105, 9.5615365 54.4906444))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 134',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5617927 54.4905707, 9.561934 54.4903768)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 116',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5617355 54.4907774, 9.5619252 54.4908092, 9.561891 54.4908782, 9.5617013 54.4908464, 9.5617355 54.4907774))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 135',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5620268 54.4906558, 9.5619232 54.4908649)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 136',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5622322 54.4907254, 9.5620652 54.4908824)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 117',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5622364 54.490487, 9.5623014 54.4904259, 9.5624617 54.4904837, 9.5623967 54.4905448, 9.5622364 54.490487))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 137',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5622647 54.4906949, 9.5624654 54.4905062)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 118',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5624459 54.4909529, 9.5625505 54.4910148, 9.5624626 54.4910652, 9.5623579 54.4910033, 9.5624459 54.4909529))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 138',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5626656 54.490964, 9.5624976 54.4910603)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 139',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5627096 54.4909388, 9.5628774 54.4908427)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 119',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5626995 54.4911646, 9.5628425 54.4912171, 9.5627767 54.4912779, 9.5626336 54.4912254, 9.5626995 54.4911646))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 120',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5628966 54.4911576, 9.563058 54.4912246, 9.5629862 54.4912831, 9.5628249 54.4912161, 9.5628966 54.4911576))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 140',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.563157 54.4911686, 9.5630243 54.4912768)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 141',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5631928 54.4911394, 9.5634012 54.4909694)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 142',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5635604 54.4912999, 9.5634652 54.4914333)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 121',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5637227 54.4914318, 9.5639121 54.491448, 9.5638941 54.4915191, 9.5637047 54.4915029, 9.5637227 54.4914318))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 122',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5637986 54.4911321, 9.5638166 54.491061, 9.564006 54.4910773, 9.563988 54.4911484, 9.5637986 54.4911321))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 143',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5639685 54.4913209, 9.5640252 54.4910971)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 123',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5640023 54.4912404, 9.5639318 54.4911814, 9.5640438 54.491136, 9.5641143 54.4911951, 9.5640023 54.4912404))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 124',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5642684 54.4910996, 9.5642438 54.4910292, 9.5644072 54.4910098, 9.5644318 54.4910803, 9.5642684 54.4910996))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 144',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5651015 54.4911607, 9.5654055 54.4912906)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 125',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5654726 54.4907817, 9.56541 54.4907198, 9.5655591 54.4906688, 9.5656217 54.4907307, 9.5654726 54.4907817))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 145',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.565775 54.4908577, 9.5655934 54.4906779)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 146',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5661882 54.4908273, 9.5661849 54.4906477)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 126',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5662045 54.4909996, 9.566369 54.4910096, 9.5663561 54.4910811, 9.5661916 54.4910711, 9.5662045 54.4909996))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 147',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5664143 54.490874, 9.5663799 54.4910645)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 127',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5662658 54.4906606, 9.5662787 54.4905891, 9.5664432 54.4905992, 9.5664302 54.4906707, 9.5662658 54.4906606))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 148',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5664208 54.4908382, 9.5664605 54.4906183)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 128',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5668163 54.490598, 9.5668309 54.4905266, 9.566973 54.4905365, 9.5669584 54.4906079, 9.5668163 54.490598))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 149',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5669473 54.4907502, 9.5669871 54.4905556)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 129',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5670094 54.4909342, 9.5671849 54.4909297, 9.5671904 54.4910015, 9.5670148 54.491006, 9.5670094 54.4909342))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 150',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5671974 54.4908028, 9.5672109 54.490983)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 151',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5673344 54.4907617, 9.5675053 54.4909408)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 152',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5677068 54.490706, 9.5676625 54.4909081)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 153',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5678961 54.4906976, 9.5680055 54.4904597)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 154',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5681073 54.490718, 9.5681522 54.490532)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 130',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5684947 54.4905539, 9.5684243 54.4904949, 9.5685695 54.4904363, 9.5686398 54.4904954, 9.5684947 54.4905539))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 155',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5688569 54.4906552, 9.5686052 54.4904438)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 131',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5621003 54.4901518, 9.5621647 54.4900904, 9.5622958 54.490137, 9.5622314 54.4901983, 9.5621003 54.4901518))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 156',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5621692 54.4902792, 9.5622961 54.4901582)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 157',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.562326 54.4903471, 9.5625517 54.4901826)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 132',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5626262 54.4903908, 9.5627185 54.4903431, 9.5628126 54.4904049, 9.5627202 54.4904526, 9.5626262 54.4903908))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 158',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5628008 54.4906307, 9.5629711 54.4905264)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 133',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5628659 54.4905672, 9.5629379 54.4905088, 9.5630783 54.4905675, 9.5630063 54.4906259, 9.5628659 54.4905672))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 159',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5629484 54.4906944, 9.5630779 54.4905894)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 134',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5628363 54.4908825, 9.5629562 54.4909355, 9.5628815 54.4909928, 9.5627616 54.4909398, 9.5628363 54.4908825))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 160',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.563134 54.4908173, 9.5629152 54.4909851)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 161',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5631713 54.4907887, 9.5633807 54.4906282)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 135',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.563747 54.4911259, 9.5638966 54.4911343, 9.5638848 54.4912058, 9.5637352 54.4911974, 9.563747 54.4911259))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 136',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.563789 54.490871, 9.5638009 54.4907995, 9.5639504 54.4908079, 9.5639386 54.4908794, 9.563789 54.490871))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 162',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5639421 54.4909728, 9.5639662 54.4908268)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 163',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.564282 54.4908615, 9.5640462 54.4907502)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 164',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5644882 54.4908294, 9.5645773 54.4910144)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 165',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5644715 54.4907948, 9.5643764 54.4905978)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 166',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5646482 54.4908414, 9.5648169 54.4906629)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 137',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5647004 54.4910006, 9.5648642 54.4909955, 9.5648708 54.4910672, 9.564707 54.4910723, 9.5647004 54.4910006))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 138',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5648042 54.4906784, 9.5647027 54.4906375, 9.5647977 54.4905575, 9.5648993 54.4905983, 9.5648042 54.4906784))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 167',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5651373 54.4906794, 9.564835 54.4905577)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 139',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5654833 54.4907292, 9.5656226 54.4906831, 9.5656836 54.4907456, 9.5655442 54.4907917, 9.5654833 54.4907292))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 168',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5655684 54.4906039, 9.5656858 54.4907243)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 140',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5653003 54.4905416, 9.5652394 54.4904791, 9.5653787 54.490433, 9.5654397 54.4904955, 9.5653003 54.4905416))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 169',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5655379 54.4905726, 9.5654114 54.4904429)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 141',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5654569 54.4905099, 9.5653827 54.4904525, 9.5655148 54.4903947, 9.565589 54.4904521, 9.5654569 54.4905099))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 170',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5656844 54.4905059, 9.5655499 54.4904018)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 142',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5657302 54.4906055, 9.5659141 54.4905727, 9.5659503 54.4906415, 9.5657663 54.4906742, 9.5657302 54.4906055))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 171',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5658987 54.4904955, 9.5659642 54.4906202)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 143',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5656023 54.4903622, 9.5655662 54.4902934, 9.5657501 54.4902607, 9.5657863 54.4903294, 9.5656023 54.4903622))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 144',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5659256 54.4903643, 9.5659288 54.4902925, 9.5661 54.4902951, 9.5660968 54.490367, 9.5659256 54.4903643))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 145',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5661731 54.4903288, 9.5661908 54.4902577, 9.5663939 54.4902748, 9.5663762 54.4903459, 9.5661731 54.4903288))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 172',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5665578 54.4904953, 9.5665856 54.4902843)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 173',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5669741 54.4904141, 9.5670238 54.4902096)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 174',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5674053 54.4903505, 9.5671908 54.4901635)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 146',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5674332 54.490244, 9.56742 54.4901725, 9.5676153 54.4901602, 9.5676285 54.4902317, 9.5674332 54.490244))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 175',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5676681 54.4903117, 9.567643 54.4901766)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 176',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5678599 54.4903695, 9.5677884 54.4905859)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 177',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5678716 54.4903343, 9.5679382 54.4901328)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 178',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5682911 54.4903891, 9.5682753 54.490579)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 147',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5684033 54.4905396, 9.5685673 54.4905361, 9.5685717 54.490608, 9.5684077 54.4906114, 9.5684033 54.4905396))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 179',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5685766 54.490355, 9.5685648 54.4901654)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 180',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5689054 54.4902898, 9.5691771 54.4905167)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 148',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5685387 54.4902159, 9.5684681 54.4901569, 9.5686345 54.4900894, 9.5687051 54.4901484, 9.5685387 54.4902159))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 181',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5688701 54.4902604, 9.5686729 54.4900957)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 182',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5693482 54.4902396, 9.5692721 54.4904261)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 149',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5618225 54.4900513, 9.5619627 54.4901073, 9.5618928 54.4901666, 9.5617526 54.4901105, 9.5618225 54.4900513))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 183',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5621413 54.4899778, 9.5619278 54.4901588)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 184',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5621763 54.4899481, 9.5623433 54.4898066)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 150',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.562267 54.4898779, 9.5623479 54.4898236, 9.5624957 54.4898983, 9.5624148 54.4899526, 9.562267 54.4898779))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 151',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5624955 54.4903261, 9.5626089 54.4903904, 9.5625227 54.4904419, 9.5624094 54.4903776, 9.5624955 54.4903261))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 152',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5627582 54.4901691, 9.5628443 54.4901176, 9.5629577 54.4901819, 9.5628716 54.4902334, 9.5627582 54.4901691))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 185',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5627808 54.4903041, 9.5629503 54.4902028)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 153',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5628769 54.4902283, 9.5629491 54.49017, 9.5631146 54.4902395, 9.5630425 54.4902978, 9.5628769 54.4902283))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 154',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5628191 54.4904655, 9.5629831 54.4905332, 9.5629117 54.4905918, 9.5627477 54.4905241, 9.5628191 54.4904655))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 155',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5630895 54.4902435, 9.5631609 54.4901849, 9.5633248 54.4902526, 9.5632534 54.4903112, 9.5630895 54.4902435))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 186',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5631173 54.4904483, 9.5633275 54.4902757)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 156',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5630419 54.4905766, 9.5632111 54.4906403, 9.563144 54.4907007, 9.5629748 54.4906369, 9.5630419 54.4905766))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 157',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.56323 54.4904074, 9.5632971 54.4903471, 9.5634663 54.4904108, 9.5633992 54.4904712, 9.56323 54.4904074))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 187',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.563351 54.4905415, 9.5634707 54.4904339)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 158',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5636382 54.4905222, 9.5636597 54.4904515, 9.5638259 54.4904685, 9.5638045 54.4905393, 9.5636382 54.4905222))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 188',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5638006 54.4906226, 9.5638413 54.4904884)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 159',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5639052 54.4905498, 9.5638519 54.490485, 9.5640285 54.4904357, 9.5640819 54.4905005, 9.5639052 54.4905498))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 189',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5641742 54.4905798, 9.5640639 54.4904458)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 190',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5644942 54.4904637, 9.5645792 54.4906202)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 160',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5646071 54.4903613, 9.5646569 54.4902955, 9.5648316 54.4903403, 9.5647819 54.490406, 9.5646071 54.4903613))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 191',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.564739 54.4904974, 9.5648411 54.4903623)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 161',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5650986 54.4905737, 9.5652194 54.4904789, 9.5653186 54.4905217, 9.5651977 54.4906165, 9.5650986 54.4905737))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 162',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651942 54.4904659, 9.5653596 54.4903953, 9.5654326 54.4904532, 9.5652672 54.4905239, 9.5651942 54.4904659))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 192',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5654877 54.490249, 9.5653905 54.4900343)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 193',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5661201 54.4901775, 9.5660895 54.4903981)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 163',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5659284 54.4900386, 9.5659384 54.489967, 9.5661247 54.4899758, 9.5661148 54.4900474, 9.5659284 54.4900386))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 194',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5661251 54.4901417, 9.5661455 54.4899948)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 164',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.566124 54.4902693, 9.566287 54.4902857, 9.566266 54.4903565, 9.5661029 54.4903401, 9.566124 54.4902693))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 165',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5662033 54.4900023, 9.5662243 54.4899315, 9.5663874 54.4899479, 9.5663664 54.4900187, 9.5662033 54.4900023))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 195',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5663448 54.4901619, 9.5664025 54.4899676)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 196',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5665238 54.4901826, 9.5665729 54.4900352)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 197',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5669543 54.4900898, 9.5669853 54.4898913)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 166',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5669606 54.4899622, 9.5669456 54.4898909, 9.5671271 54.4898779, 9.5671421 54.4899493, 9.5669606 54.4899622))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 198',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5671961 54.4900963, 9.5671536 54.4898941)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 167',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5671397 54.4900287, 9.5670659 54.489971, 9.5672291 54.4899002, 9.5673029 54.4899578, 9.5671397 54.4900287))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 199',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5674014 54.49001, 9.5672679 54.4899058)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 168',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5672959 54.4898885, 9.5672506 54.4898217, 9.5674164 54.4897836, 9.5674617 54.4898504, 9.5672959 54.4898885))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 200',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5675644 54.4899666, 9.5674485 54.4897955)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 169',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5675774 54.490111, 9.5677834 54.4901229, 9.5677712 54.4901944, 9.5675651 54.4901825, 9.5675774 54.490111))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 170',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5679275 54.489886, 9.5679316 54.4898142, 9.5681139 54.4898177, 9.5681098 54.4898896, 9.5679275 54.489886))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 201',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5681272 54.4899829, 9.5681357 54.4898361)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 171',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5680959 54.489888, 9.5681007 54.4898162, 9.5682566 54.4898197, 9.5682519 54.4898915, 9.5680959 54.489888))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 202',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5682652 54.489986, 9.5682749 54.4898381)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 203',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.568495 54.4899929, 9.5685148 54.4897914)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 172',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5685097 54.4901504, 9.5686695 54.4901352, 9.5686894 54.4902062, 9.5685295 54.4902213, 9.5685097 54.4901504))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 204',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5686572 54.4900183, 9.5687044 54.4901865)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 205',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5690074 54.489863, 9.5688545 54.4896892)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 206',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5693024 54.489856, 9.5693609 54.4896122)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 173',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5624827 54.4896488, 9.5625716 54.4895989, 9.5626742 54.489661, 9.5625853 54.4897108, 9.5624827 54.4896488))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 207',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5624923 54.4897779, 9.5626648 54.4896812)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 208',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5626601 54.4899391, 9.5624863 54.4900323)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 174',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5626983 54.4897683, 9.5627891 54.4897196, 9.5629034 54.4897918, 9.5628127 54.4898405, 9.5626983 54.4897683))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 209',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5627055 54.4899147, 9.562895 54.489813)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 210',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5630429 54.4900588, 9.5632021 54.4899079)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 175',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5629688 54.4901902, 9.563126 54.4902472, 9.5630607 54.4903082, 9.5629036 54.4902512, 9.5629688 54.4901902))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 176',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5631814 54.4899914, 9.5632466 54.4899304, 9.5634038 54.4899873, 9.5633385 54.4900483, 9.5631814 54.4899914))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 177',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5633782 54.4899876, 9.5634333 54.4899232, 9.563574 54.4899641, 9.5635189 54.4900284, 9.5633782 54.4899876))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 178',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5635694 54.4904078, 9.5637391 54.4904203, 9.5637236 54.4904916, 9.5635539 54.4904791, 9.5635694 54.4904078))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 211',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5637936 54.4902693, 9.5637487 54.4904754)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 212',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5640415 54.4902248, 9.5639977 54.4900324)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 179',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5641248 54.4900731, 9.5640384 54.4900218, 9.564148 54.4899592, 9.5642344 54.4900105, 9.5641248 54.4900731))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 213',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5643556 54.4900665, 9.5641833 54.4899642)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 180',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5644742 54.4898982, 9.5645092 54.4898293, 9.5646418 54.4898522, 9.5646068 54.4899211, 9.5644742 54.4898982))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 181',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5648081 54.4900545, 9.5647111 54.49001, 9.5648214 54.4899285, 9.5649184 54.489973, 9.5648081 54.4900545))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 214',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5650586 54.4900208, 9.5648594 54.4899294)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 182',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651927 54.4897923, 9.5651814 54.4897207, 9.565373 54.4897105, 9.5653843 54.489782, 9.5651927 54.4897923))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 215',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5654287 54.4899108, 9.5653998 54.4897271)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 183',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5656209 54.490079, 9.5657925 54.4900129, 9.5658607 54.4900728, 9.5656891 54.4901389, 9.5656209 54.490079))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 216',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5656675 54.4898757, 9.5658651 54.4900496)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 184',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5658559 54.4899218, 9.5659945 54.4899234, 9.565992 54.4899953, 9.5658534 54.4899936, 9.5658559 54.4899218))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 185',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5658661 54.489628, 9.5658685 54.4895562, 9.5660072 54.4895578, 9.5660047 54.4896296, 9.5658661 54.489628))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 186',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5659583 54.4899552, 9.5661655 54.4899656, 9.5661549 54.4900372, 9.5659477 54.4900268, 9.5659583 54.4899552))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 217',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5662102 54.4898396, 9.5661834 54.4900206)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 218',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5664235 54.4898206, 9.5664774 54.4896014)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 219',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5666522 54.4898413, 9.5667524 54.4900211)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 187',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5668706 54.4896117, 9.5668889 54.4895406, 9.5670709 54.4895565, 9.5670525 54.4896276, 9.5668706 54.4896117))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 220',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5670504 54.4897263, 9.567089 54.4895763)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 188',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5672053 54.4898916, 9.567344 54.4898537, 9.5673964 54.4899188, 9.5672577 54.4899566, 9.5672053 54.4898916))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 189',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5671459 54.4896225, 9.5670693 54.4895661, 9.5671824 54.489514, 9.5672589 54.4895704, 9.5671459 54.4896225))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 190',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5675064 54.4897967, 9.56767 54.4897565, 9.567718 54.4898228, 9.5675544 54.4898629, 9.5675064 54.4897967))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 191',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5677297 54.489783, 9.5679029 54.4897959, 9.5678872 54.4898672, 9.5677141 54.4898543, 9.5677297 54.489783))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 221',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5679623 54.4896251, 9.5679128 54.489851)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 222',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5679701 54.4895894, 9.5680126 54.4893955)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 223',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5684347 54.4896156, 9.5684823 54.4893826)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 192',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5684406 54.4895368, 9.5684301 54.4894652, 9.5686217 54.4894557, 9.5686323 54.4895273, 9.5684406 54.4895368))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 193',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5686004 54.4894925, 9.56854 54.4894298, 9.5686597 54.4893907, 9.5687202 54.4894533, 9.5686004 54.4894925))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 194',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5690039 54.4896255, 9.5691908 54.4896225, 9.5691942 54.4896943, 9.5690073 54.4896973, 9.5690039 54.4896255))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 195',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5689912 54.4893537, 9.5689878 54.4892819, 9.5691747 54.4892789, 9.5691781 54.4893508, 9.5689912 54.4893537))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 224',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5629064 54.4896679, 9.5627321 54.4898414)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 196',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5628221 54.4897366, 9.5629958 54.4897947, 9.5629343 54.489857, 9.5627606 54.4897989, 9.5628221 54.4897366))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 225',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5630904 54.4897282, 9.5629714 54.4898487)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 197',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5632456 54.4898803, 9.5633979 54.489913, 9.5633553 54.4899804, 9.563203 54.4899478, 9.5632456 54.4898803))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 226',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5634674 54.4898373, 9.563385 54.4899676)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 198',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5633641 54.489693, 9.5634068 54.4896255, 9.563559 54.4896582, 9.5635164 54.4897256, 9.5633641 54.489693))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 199',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5635731 54.4897299, 9.5635947 54.4896591, 9.5637388 54.489674, 9.5637172 54.4897448, 9.5635731 54.4897299))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 227',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5637098 54.4898295, 9.5637514 54.4896936)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 200',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.563665 54.4900006, 9.563816 54.49001, 9.5638029 54.4900815, 9.5636518 54.490072, 9.563665 54.4900006))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 228',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5638598 54.4898764, 9.563825 54.4900648)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 229',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5641138 54.4898592, 9.5641903 54.4900648)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 201',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5638711 54.4897495, 9.5638449 54.4896792, 9.5640163 54.4896576, 9.5640425 54.4897278, 9.5638711 54.4897495))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 230',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5642492 54.4898079, 9.5644625 54.4899735)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 202',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5644356 54.4898888, 9.5645512 54.489828, 9.564634 54.4898813, 9.5645184 54.4899421, 9.5644356 54.4898888))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 231',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5645961 54.4896997, 9.5647125 54.4895182)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 203',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5650395 54.4899516, 9.5651811 54.4898929, 9.5652526 54.4899515, 9.565111 54.4900101, 9.5650395 54.4899516))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 232',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5650324 54.4897494, 9.5652524 54.4899295)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 204',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5646934 54.4896683, 9.5646219 54.4896098, 9.5647635 54.4895511, 9.564835 54.4896097, 9.5646934 54.4896683))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 205',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651786 54.4897701, 9.565272 54.4897002, 9.5653695 54.4897443, 9.5652761 54.4898142, 9.5651786 54.4897701))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 206',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5653314 54.4896929, 9.5655185 54.4896694, 9.5655445 54.4897396, 9.5653575 54.4897631, 9.5653314 54.4896929))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 233',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5655124 54.489587, 9.5655614 54.4897191)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 207',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.565907 54.489562, 9.566109 54.4895609, 9.5661102 54.4896328, 9.5659082 54.4896339, 9.565907 54.489562))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 208',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5659031 54.4893158, 9.5659019 54.489244, 9.5661039 54.4892428, 9.566105 54.4893147, 9.5659031 54.4893158))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 209',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5661386 54.4896073, 9.5663098 54.4896123, 9.5663036 54.489684, 9.5661325 54.4896791, 9.5661386 54.4896073))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 234',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5663431 54.4894726, 9.5663266 54.4896667)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 235',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5663462 54.4894367, 9.5663658 54.4892074)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 210',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.566399 54.48957, 9.5665624 54.4895641, 9.5665701 54.4896358, 9.5664066 54.4896417, 9.566399 54.48957))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 236',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5667393 54.489404, 9.5669781 54.4895626)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 211',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5664254 54.4893974, 9.566344 54.4893433, 9.5664966 54.4892654, 9.566578 54.4893194, 9.5664254 54.4893974))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 237',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5666986 54.489377, 9.5665361 54.4892692)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 238',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.566967 54.489319, 9.566962 54.4891638)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 239',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5672119 54.489349, 9.5672546 54.4894789)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 212',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5669363 54.4891898, 9.5669131 54.4891192, 9.5671047 54.4890979, 9.5671279 54.4891685, 9.5669363 54.4891898))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 213',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5673859 54.4894329, 9.567546 54.4893619, 9.5676209 54.489419, 9.5674607 54.48949, 9.5673859 54.4894329))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 240',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5674367 54.4892541, 9.5676222 54.4893959)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 241',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5676598 54.4891779, 9.5676242 54.4890323)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 214',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5677435 54.4890912, 9.5677704 54.489021, 9.567927 54.4890414, 9.5679002 54.4891115, 9.5677435 54.4890912))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 215',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5679024 54.4890864, 9.5679228 54.4890155, 9.5680659 54.4890295, 9.5680454 54.4891004, 9.5679024 54.4890864))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 242',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5680297 54.4892187, 9.5680787 54.489049)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 216',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5682807 54.4890812, 9.5683031 54.4890106, 9.5684939 54.4890311, 9.5684715 54.4891018, 9.5682807 54.4890812))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 217',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.568824 54.4893979, 9.5689715 54.4893509, 9.5690307 54.489414, 9.5688832 54.489461, 9.568824 54.4893979))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 243',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5688908 54.4892396, 9.5690344 54.4893924)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 218',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5685584 54.4891151, 9.5684992 54.4890521, 9.5686467 54.4890051, 9.5687059 54.4890682, 9.5685584 54.4891151))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 219',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5632473 54.4895191, 9.5633823 54.4895523, 9.5633343 54.4896185, 9.5631993 54.4895853, 9.5632473 54.4895191))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 244',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5634553 54.489479, 9.5633632 54.4896061)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 245',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5637726 54.4895281, 9.5637163 54.4896731)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 220',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5636584 54.489394, 9.5636856 54.4893239, 9.5638261 54.4893424, 9.5637989 54.4894125, 9.5636584 54.489394))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 221',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5637717 54.4894059, 9.5637849 54.4893345, 9.5639725 54.4893463, 9.5639592 54.4894177, 9.5637717 54.4894059))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 222',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.564039 54.4896312, 9.5642297 54.489593, 9.5642699 54.489661, 9.5640792 54.4896992, 9.564039 54.4896312))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 246',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5642065 54.4895088, 9.5642837 54.4896392)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 223',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5639222 54.4894337, 9.5638821 54.4893658, 9.5640727 54.4893276, 9.5641129 54.4893955, 9.5639222 54.4894337))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 224',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5643483 54.4895281, 9.5644882 54.4894588, 9.5645682 54.4895135, 9.5644283 54.4895828, 9.5643483 54.4895281))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 247',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5644163 54.489389, 9.5645657 54.4894911)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 248',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5645629 54.4893778, 9.5646946 54.4891904)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 225',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5647168 54.4893733, 9.5646848 54.4893039, 9.564848 54.4892783, 9.5648801 54.4893478, 9.5647168 54.4893733))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 226',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5652026 54.489577, 9.5653037 54.4895026, 9.5654005 54.4895471, 9.5652994 54.4896216, 9.5652026 54.489577))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 249',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5650906 54.4893894, 9.5653889 54.4895267)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 250',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5655049 54.4892572, 9.5656054 54.4894616)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 251',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5656373 54.4892016, 9.5658609 54.4893707)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'GARTEN', 'Garten 227',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5657125 54.4892595, 9.5658465 54.489216, 9.5659067 54.4892788, 9.5657726 54.4893223, 9.5657125 54.4892595))', 8307),
    0 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_WEG (SIEDLUNG_ID, ART, NAME, GEOM, BREITE_M) SELECT s.ID, 'ZAUN', 'Zaun 252',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5657964 54.4891408, 9.5659084 54.4892577)', 8307),
    0.1 FROM HB_SIEDLUNG s WHERE s.NAME = 'Haithabu 950' AND s.HERKUNFT = 'MITGELIEFERT';

-- -------------------------------------------------------------------------------------------- Lageplan
DELETE FROM HB_BAUWERK WHERE HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'WALLKAMM', 'Halbkreiswall',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5702683 54.4894212, 9.570173 54.4893755, 9.5700783 54.4893294, 9.5699837 54.4892833, 9.569889 54.4892372, 9.569787 54.4891967, 9.5697061 54.4891426, 9.5696013 54.4891047, 9.5694868 54.4890778, 9.5693712 54.4890527, 9.5692551 54.4890282, 9.5691399 54.4890023, 9.569025 54.4889761, 9.5689106 54.488949, 9.5687967 54.4889213, 9.5686815 54.4888955, 9.5685653 54.4888713, 9.568447 54.4888507, 9.568327 54.4888339, 9.5682057 54.4888206, 9.5680836 54.4888099, 9.567961 54.4888018, 9.5678381 54.4887948, 9.567715 54.4887896, 9.5675916 54.4887888, 9.5674682 54.4887909, 9.5673454 54.4887982, 9.5672229 54.4888072, 9.5671011 54.488819, 9.5669801 54.488833, 9.5668633 54.4888561, 9.5667546 54.48889, 9.5666409 54.4889177, 9.5665183 54.4889246, 9.566396 54.4889148, 9.5662735 54.4889061, 9.5661503 54.4889018, 9.5660268 54.488901, 9.5659034 54.4889011, 9.56578 54.4889041, 9.5656573 54.4889115, 9.565535 54.4889216, 9.5654137 54.4889347, 9.565296 54.4889563, 9.5651797 54.4889804, 9.5650616 54.4890')
    || TO_CLOB('01, 9.5649384 54.489005, 9.5648151 54.4890021, 9.564692 54.4889973, 9.5645688 54.4890014, 9.5644466 54.4890117, 9.5643262 54.4890274, 9.5642084 54.4890489, 9.5640918 54.4890725, 9.5639757 54.4890969, 9.56386 54.4891221, 9.5637443 54.4891471, 9.5636274 54.4891702, 9.5635097 54.4891919, 9.5633926 54.4892145, 9.5632766 54.4892392, 9.5631633 54.4892677, 9.5630504 54.4892967, 9.5629385 54.489327, 9.5628269 54.4893578, 9.5627167 54.4893902, 9.5626092 54.4894255, 9.5625014 54.4894605, 9.5623935 54.4894955, 9.5622865 54.4895313, 9.5621855 54.4895725, 9.5620947 54.4896212, 9.5619983 54.489666, 9.5618981 54.489708, 9.5617972 54.4897492, 9.5617096 54.4897998, 9.5616348 54.489857, 9.5615637 54.4899157, 9.5614956 54.4899756, 9.5614363 54.4900387, 9.5613728 54.4901003, 9.5613111 54.4901625, 9.5612446 54.4902231, 9.5611804 54.4902844, 9.5611229 54.490348, 9.5610603 54.4904099, 9.5609897 54.4904689, 9.5609095 54.4905235, 9.5608295 54.4905781, 9.5607697 54.4906408, 9.5607337 54.4907094, 9.5607254 54.49')
    || TO_CLOB('07811, 9.560723 54.4908528, 9.5606969 54.4909229, 9.560651 54.4909896, 9.560597 54.4910542, 9.5605582 54.4911223, 9.5605316 54.4911925, 9.5605144 54.4912636, 9.5605091 54.4913353, 9.5605217 54.4914068, 9.5605495 54.4914767, 9.56059 54.4915446, 9.5606463 54.4916084, 9.5607203 54.4916659, 9.5608001 54.4917207, 9.5608761 54.4917773, 9.560942 54.491838, 9.561003 54.4919005, 9.5610616 54.4919638, 9.5611182 54.4920277, 9.5611715 54.4920925, 9.5612204 54.4921585, 9.5612686 54.4922246, 9.5613167 54.4922908, 9.5613675 54.4923563, 9.5614179 54.4924219, 9.5614659 54.4924881, 9.5615154 54.492554, 9.561566 54.4926195, 9.5616222 54.4926835, 9.5616723 54.4927492, 9.5617183 54.4928158, 9.5617703 54.492881, 9.5618223 54.4929462, 9.5618738 54.4930113, 9.5619015 54.4930813, 9.5619272 54.4931515, 9.5619401 54.493223, 9.5619519 54.4932943, 9.5619479 54.4933658, 9.5619771 54.4934353, 9.5620342 54.4934987, 9.5621164 54.4935521, 9.5622149 54.4935951, 9.5623237 54.493629, 9.5624377 54.4936566, 9.5625536 54.493')
    || TO_CLOB('6814, 9.5626705 54.4937045, 9.5627877 54.4937271, 9.5629042 54.4937509, 9.5630187 54.4937777, 9.5631306 54.493808, 9.5632378 54.4938434, 9.5633363 54.4938868, 9.5634354 54.4939293, 9.5635432 54.4939643, 9.5636488 54.4940015, 9.5637547 54.4940384, 9.5638645 54.4940712, 9.5639787 54.4940984, 9.5640967 54.4941194, 9.5642164 54.4941368, 9.564338 54.4941494, 9.5644593 54.4941625, 9.5645777 54.4941817, 9.5646855 54.4942162, 9.5647862 54.4942576, 9.5648949 54.4942914, 9.5650096 54.494318, 9.5651251 54.4943434, 9.5652413 54.4943673, 9.565362 54.4943819, 9.5654849 54.4943861, 9.565608 54.4943807, 9.5657306 54.4943722, 9.5658531 54.4943639, 9.5659765 54.4943621, 9.5660998 54.4943646, 9.5662232 54.4943652, 9.5663395 54.4943553, 9.5664488 54.494325, 9.5665697 54.4943106, 9.5666907 54.4942963, 9.5668117 54.4942818, 9.5669326 54.4942673)'), 8307),
    9, 7, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Kammlinie des Halbkreiswalls'), 'Kammlinie 1.402 m, 86 % im DGM1 gemessen, Nordwestbogen und Enden ergänzt', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABEN', 'Graben vor dem Wall',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.570435 54.4893032, 9.5703404 54.489258, 9.5702467 54.4892124, 9.5701521 54.4891662, 9.5700472 54.4891154, 9.5699626 54.4890832, 9.5698753 54.4890259, 9.5697193 54.4889683, 9.5695817 54.4889354, 9.5694613 54.4889093, 9.5693471 54.4888852, 9.5692351 54.48886, 9.5691223 54.4888342, 9.5690107 54.4888078, 9.5688944 54.4887796, 9.568773 54.4887523, 9.5686471 54.4887262, 9.5685153 54.4887032, 9.5683819 54.4886845, 9.5682494 54.48867, 9.5681177 54.4886585, 9.5679887 54.48865, 9.5678607 54.4886426, 9.5677257 54.488637, 9.5675895 54.4886361, 9.5674508 54.4886385, 9.5673156 54.4886464, 9.5671849 54.4886561, 9.5670548 54.4886687, 9.5669126 54.4886854, 9.5667571 54.4887164, 9.5666403 54.4887526, 9.5665772 54.4887695, 9.5665259 54.488772, 9.5664301 54.4887633, 9.566297 54.488754, 9.5661593 54.4887492, 9.5660283 54.4887483, 9.5658979 54.4887485, 9.565761 54.4887518, 9.5656253 54.4887599, 9.5654934 54.4887708, 9.5653496 54.4887866, 9.5652119 54.4888116, 9.5650964 54.4888356, 9.5650176 54')
    || TO_CLOB('.4888504, 9.5649371 54.4888522, 9.5648306 54.4888496, 9.5646929 54.4888446, 9.5645425 54.4888494, 9.5643991 54.4888615, 9.5642575 54.48888, 9.5641259 54.488904, 9.5640042 54.4889286, 9.5638852 54.4889536, 9.5637683 54.488979, 9.5636565 54.4890031, 9.5635459 54.489025, 9.563429 54.4890466, 9.5633066 54.4890702, 9.5631789 54.4890974, 9.5630586 54.4891277, 9.5629419 54.4891576, 9.562827 54.4891888, 9.5627119 54.4892206, 9.5625927 54.4892556, 9.562481 54.4892923, 9.5623737 54.489327, 9.5622651 54.4893623, 9.5621464 54.4894021, 9.5620191 54.4894544, 9.561924 54.4895052, 9.56184 54.4895443, 9.5617479 54.4895828, 9.5616289 54.4896321, 9.5615115 54.4896997, 9.5614231 54.4897668, 9.5613474 54.4898293, 9.5612703 54.4898975, 9.5612092 54.4899623, 9.5611463 54.4900232, 9.5610873 54.4900828, 9.5610224 54.4901419, 9.5609515 54.4902098, 9.5608935 54.4902739, 9.5608392 54.4903277, 9.5607828 54.490375, 9.5607116 54.4904232, 9.560614 54.490491, 9.5605286 54.4905807, 9.5604753 54.4906831, 9.5604632 54.49')
    || TO_CLOB('07765, 9.5604624 54.4908351, 9.5604464 54.4908775, 9.5604127 54.4909258, 9.5603539 54.4909968, 9.5603051 54.4910821, 9.5602735 54.4911653, 9.5602533 54.4912491, 9.5602469 54.4913401, 9.560263 54.4914321, 9.5602973 54.4915188, 9.5603486 54.4916043, 9.5604248 54.4916902, 9.5605162 54.4917618, 9.5605975 54.4918178, 9.5606611 54.4918648, 9.5607167 54.4919162, 9.5607734 54.4919745, 9.5608297 54.4920352, 9.5608834 54.4920958, 9.5609324 54.4921553, 9.5609792 54.4922185, 9.5610268 54.4922839, 9.5610765 54.4923523, 9.5611284 54.4924192, 9.561177 54.4924823, 9.5612249 54.4925486, 9.5612751 54.4926153, 9.5613304 54.4926867, 9.5613854 54.4927492, 9.5614298 54.4928075, 9.561478 54.4928772, 9.561532 54.4929449, 9.5615862 54.4930128, 9.5616242 54.4930583, 9.5616459 54.4931156, 9.5616677 54.4931739, 9.5616795 54.4932408, 9.5616896 54.4932936, 9.561687 54.4933821, 9.5617316 54.4934892, 9.5618193 54.4935863, 9.5619399 54.4936651, 9.562075 54.4937243, 9.5622126 54.4937673, 9.5623424 54.4937989, 9.5624664')
    || TO_CLOB(' 54.4938254, 9.5625875 54.4938494, 9.5627037 54.4938718, 9.562812 54.4938939, 9.5629146 54.4939179, 9.5630119 54.4939442, 9.5630917 54.4939703, 9.5631746 54.494007, 9.5632989 54.4940598, 9.5634106 54.494096, 9.5635116 54.4941317, 9.5636271 54.4941718, 9.563754 54.4942097, 9.5638924 54.4942426, 9.564025 54.4942663, 9.5641644 54.4942865, 9.5642922 54.4942997, 9.5644062 54.4943121, 9.5644772 54.4943227, 9.5645383 54.4943426, 9.5646478 54.4943873, 9.5647877 54.4944308, 9.5649161 54.4944607, 9.5650304 54.4944858, 9.5651708 54.4945144, 9.5653265 54.4945332, 9.5654909 54.4945388, 9.5656342 54.4945327, 9.565765 54.4945236, 9.565872 54.4945162, 9.5659699 54.4945148, 9.566099 54.4945173, 9.5662107 54.4945177, 9.5664626 54.4944902, 9.5665119 54.4944732, 9.5666219 54.4944603, 9.5667434 54.4944459, 9.5668644 54.4944314, 9.5669859 54.4944168)'), 8307),
    -2, 10, 'GESTALTET', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Graben, Palisade, Wehrgang'), 'Graben 17 m vor der Kammlinie, 10 m breit, 2 m tief [G]', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'WALLPALISADE', 'Palisade auf dem Wall',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5702938 54.4894032, 9.5701986 54.4893576, 9.570104 54.4893115, 9.5700094 54.4892654, 9.5699132 54.4892185, 9.5698138 54.4891793, 9.569732 54.4891248, 9.5696193 54.4890838, 9.5695013 54.489056, 9.5693849 54.4890307, 9.5692691 54.4890064, 9.5691545 54.4889806, 9.5690399 54.4889544, 9.5689259 54.4889274, 9.5688117 54.4888997, 9.5686955 54.4888736, 9.5685778 54.4888491, 9.5684575 54.4888281, 9.5683354 54.488811, 9.5682124 54.4887976, 9.5680888 54.4887868, 9.5679652 54.4887786, 9.5678416 54.4887715, 9.5677166 54.4887663, 9.5675913 54.4887655, 9.5674655 54.4887675, 9.5673408 54.488775, 9.5672171 54.4887841, 9.5670941 54.488796, 9.5669698 54.4888104, 9.5668471 54.4888347, 9.5667371 54.488869, 9.5666312 54.488895, 9.5665195 54.4889013, 9.5664012 54.4888916, 9.5662771 54.4888829, 9.5661516 54.4888785, 9.566027 54.4888776, 9.5659025 54.4888778, 9.5657771 54.4888808, 9.5656524 54.4888883, 9.5655287 54.4888985, 9.5654039 54.4889121, 9.5652831 54.4889341, 9.565167 54.4889583, 9.565054')
    || TO_CLOB('9 54.4889779, 9.5649382 54.4889816, 9.5648175 54.4889787, 9.5646921 54.488974, 9.5645647 54.4889781, 9.5644393 54.4889887, 9.5643157 54.4890049, 9.5641958 54.4890268, 9.5640784 54.4890505, 9.5639619 54.489075, 9.563846 54.4891002, 9.5637309 54.489125, 9.563615 54.489148, 9.5634974 54.4891697, 9.5633794 54.4891924, 9.5632617 54.4892175, 9.5631473 54.4892463, 9.5630338 54.4892754, 9.5629214 54.4893059, 9.5628093 54.4893368, 9.5626977 54.4893696, 9.5625896 54.4894051, 9.5624818 54.4894401, 9.5623739 54.4894751, 9.5622651 54.4895115, 9.5621601 54.4895544, 9.5620686 54.4896034, 9.5619741 54.4896474, 9.5618751 54.4896889, 9.5617714 54.4897313, 9.5616793 54.4897845, 9.5616024 54.4898432, 9.5615306 54.4899025, 9.5614612 54.4899637, 9.5614016 54.490027, 9.5613382 54.4900885, 9.5612769 54.4901503, 9.5612106 54.4902106, 9.5611454 54.490273, 9.5610878 54.4903367, 9.5610264 54.4903974, 9.5609581 54.4904545, 9.5608792 54.4905082, 9.5607965 54.4905648, 9.5607328 54.4906316, 9.5606942 54.4907054, 9.56')
    || TO_CLOB('06853 54.4907804, 9.5606832 54.4908501, 9.5606586 54.490916, 9.5606146 54.4909798, 9.5605599 54.4910454, 9.5605195 54.4911162, 9.5604921 54.4911883, 9.5604745 54.4912614, 9.560469 54.4913361, 9.5604821 54.4914106, 9.560511 54.4914832, 9.5605531 54.4915537, 9.5606125 54.4916209, 9.5606891 54.4916805, 9.5607691 54.4917356, 9.5608432 54.4917907, 9.5609076 54.49185, 9.5609678 54.4919119, 9.5610261 54.4919747, 9.5610823 54.4920381, 9.5611349 54.4921021, 9.5611835 54.4921676, 9.5612316 54.4922337, 9.5612799 54.4923002, 9.561331 54.4923659, 9.5613811 54.4924311, 9.561429 54.4924974, 9.5614787 54.4925633, 9.5615299 54.4926298, 9.561586 54.4926935, 9.5616352 54.4927581, 9.5616815 54.4928252, 9.5617339 54.4928908, 9.5617862 54.4929564, 9.5618356 54.4930184, 9.5618624 54.4930865, 9.5618875 54.4931549, 9.5619002 54.4932257, 9.5619118 54.4932942, 9.561908 54.4933683, 9.5619396 54.4934436, 9.5620014 54.4935121, 9.5620894 54.4935693, 9.5621935 54.4936149, 9.5623067 54.4936502, 9.5624231 54.4936783, 9')
    || TO_CLOB('.5625402 54.4937034, 9.5626578 54.4937267, 9.5627748 54.4937493, 9.5628901 54.4937728, 9.5630028 54.4937991, 9.5631124 54.4938289, 9.5632155 54.4938628, 9.5633116 54.4939051, 9.5634145 54.4939493, 9.563523 54.4939844, 9.5636278 54.4940214, 9.5637352 54.4940588, 9.5638476 54.4940924, 9.5639655 54.4941204, 9.5640858 54.4941419, 9.5642085 54.4941597, 9.564331 54.4941724, 9.5644512 54.4941854, 9.5645623 54.4942032, 9.564663 54.4942355, 9.564765 54.4942774, 9.5648785 54.4943128, 9.5649953 54.4943398, 9.5651106 54.4943652, 9.5652305 54.4943898, 9.5653566 54.494405, 9.5654858 54.4944094, 9.565612 54.494404, 9.5657359 54.4943954, 9.565856 54.4943872, 9.5659755 54.4943855, 9.5660997 54.4943879, 9.5662213 54.4943885, 9.5663583 54.4943759, 9.5664584 54.4943476, 9.5665777 54.4943335, 9.5666988 54.4943191, 9.5668197 54.4943047, 9.5669408 54.4942902)'), 8307),
    3, NULL, 'GESTALTET', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Graben, Palisade, Wehrgang'), 'Palisade 3 m auf der Außenkante des Walls, Wehrgang dahinter [G]', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'WALLFLAECHE', 'Fläche im Halbkreiswall',
    MDSYS.SDO_GEOMETRY(TO_CLOB('POLYGON ((9.5702683 54.4894212, 9.5703702 54.489547, 9.5703303 54.4895829, 9.570263 54.4896548, 9.5702156 54.4897266, 9.5701815 54.4897985, 9.5701473 54.4898704, 9.5701164 54.4899422, 9.5700823 54.4900141, 9.5700271 54.490086, 9.5699599 54.4901578, 9.5698916 54.4902297, 9.5698309 54.4903016, 9.5697869 54.4903735, 9.5697505 54.4904453, 9.5697075 54.4905172, 9.5696888 54.4905891, 9.5696866 54.4906609, 9.5697086 54.4907328, 9.5697483 54.4908047, 9.5697736 54.4908765, 9.5697108 54.4909484, 9.5696965 54.4910203, 9.569691 54.4910921, 9.5697384 54.491164, 9.5697769 54.4912359, 9.5697747 54.4913077, 9.569756 54.4913796, 9.5697328 54.4914515, 9.5697086 54.4915234, 9.5696943 54.4915952, 9.5696854 54.4916671, 9.5696755 54.491739, 9.5696568 54.4918108, 9.5696193 54.4918827, 9.5695686 54.4919546, 9.5695124 54.4920264, 9.5694507 54.4920983, 9.5693834 54.4921702, 9.5693052 54.492242, 9.569196 54.4923139, 9.5690759 54.4923858, 9.5689414 54.4924576, 9.5688146 54.4925295, 9.5686846 54.4926014, 9.568549 ')
    || TO_CLOB('54.4926732, 9.5683968 54.4927451, 9.5681951 54.492817, 9.5680132 54.4928888, 9.5678512 54.4929607, 9.567752 54.4930326, 9.5676891 54.4931044, 9.5676417 54.4931763, 9.5676087 54.4932482, 9.5675778 54.4933201, 9.5675447 54.4933919, 9.5674984 54.4934638, 9.5674477 54.4935357, 9.5673926 54.4936075, 9.5673463 54.4936794, 9.5673044 54.4937513, 9.5672713 54.4938231, 9.5672405 54.493895, 9.5672085 54.4939669, 9.5671798 54.4940387, 9.5671607 54.4940926, 9.5671478 54.4941286, 9.5669326 54.4942673, 9.5668117 54.4942818, 9.5666907 54.4942963, 9.5665697 54.4943106, 9.5664488 54.494325, 9.5663395 54.4943553, 9.5662232 54.4943652, 9.5660998 54.4943646, 9.5659765 54.4943621, 9.5658531 54.4943639, 9.5657306 54.4943722, 9.565608 54.4943807, 9.5654849 54.4943861, 9.565362 54.4943819, 9.5652413 54.4943673, 9.5651251 54.4943434, 9.5650096 54.494318, 9.5648949 54.4942914, 9.5647862 54.4942576, 9.5646855 54.4942162, 9.5645777 54.4941817, 9.5644593 54.4941625, 9.564338 54.4941494, 9.5642164 54.4941368, 9.5640')
    || TO_CLOB('967 54.4941194, 9.5639787 54.4940984, 9.5638645 54.4940712, 9.5637547 54.4940384, 9.5636488 54.4940015, 9.5635432 54.4939643, 9.5634354 54.4939293, 9.5633363 54.4938868, 9.5632378 54.4938434, 9.5631306 54.493808, 9.5630187 54.4937777, 9.5629042 54.4937509, 9.5627877 54.4937271, 9.5626705 54.4937045, 9.5625536 54.4936814, 9.5624377 54.4936566, 9.5623237 54.493629, 9.5622149 54.4935951, 9.5621164 54.4935521, 9.5620342 54.4934987, 9.5619771 54.4934353, 9.5619479 54.4933658, 9.5619519 54.4932943, 9.5619401 54.493223, 9.5619272 54.4931515, 9.5619015 54.4930813, 9.5618738 54.4930113, 9.5618223 54.4929462, 9.5617703 54.492881, 9.5617183 54.4928158, 9.5616723 54.4927492, 9.5616222 54.4926835, 9.561566 54.4926195, 9.5615154 54.492554, 9.5614659 54.4924881, 9.5614179 54.4924219, 9.5613675 54.4923563, 9.5613167 54.4922908, 9.5612686 54.4922246, 9.5612204 54.4921585, 9.5611715 54.4920925, 9.5611182 54.4920277, 9.5610616 54.4919638, 9.561003 54.4919005, 9.560942 54.491838, 9.5608761 54.4917773, 9.5')
    || TO_CLOB('608001 54.4917207, 9.5607203 54.4916659, 9.5606463 54.4916084, 9.56059 54.4915446, 9.5605495 54.4914767, 9.5605217 54.4914068, 9.5605091 54.4913353, 9.5605144 54.4912636, 9.5605316 54.4911925, 9.5605582 54.4911223, 9.560597 54.4910542, 9.560651 54.4909896, 9.5606969 54.4909229, 9.560723 54.4908528, 9.5607254 54.4907811, 9.5607337 54.4907094, 9.5607697 54.4906408, 9.5608295 54.4905781, 9.5609095 54.4905235, 9.5609897 54.4904689, 9.5610603 54.4904099, 9.5611229 54.490348, 9.5611804 54.4902844, 9.5612446 54.4902231, 9.5613111 54.4901625, 9.5613728 54.4901003, 9.5614363 54.4900387, 9.5614956 54.4899756, 9.5615637 54.4899157, 9.5616348 54.489857, 9.5617096 54.4897998, 9.5617972 54.4897492, 9.5618981 54.489708, 9.5619983 54.489666, 9.5620947 54.4896212, 9.5621855 54.4895725, 9.5622865 54.4895313, 9.5623935 54.4894955, 9.5625014 54.4894605, 9.5626092 54.4894255, 9.5627167 54.4893902, 9.5628269 54.4893578, 9.5629385 54.489327, 9.5630504 54.4892967, 9.5631633 54.4892677, 9.5632766 54.4892392, 9')
    || TO_CLOB('.5633926 54.4892145, 9.5635097 54.4891919, 9.5636274 54.4891702, 9.5637443 54.4891471, 9.56386 54.4891221, 9.5639757 54.4890969, 9.5640918 54.4890725, 9.5642084 54.4890489, 9.5643262 54.4890274, 9.5644466 54.4890117, 9.5645688 54.4890014, 9.564692 54.4889973, 9.5648151 54.4890021, 9.5649384 54.489005, 9.5650616 54.489001, 9.5651797 54.4889804, 9.565296 54.4889563, 9.5654137 54.4889347, 9.565535 54.4889216, 9.5656573 54.4889115, 9.56578 54.4889041, 9.5659034 54.4889011, 9.5660268 54.488901, 9.5661503 54.4889018, 9.5662735 54.4889061, 9.566396 54.4889148, 9.5665183 54.4889246, 9.5666409 54.4889177, 9.5667546 54.48889, 9.5668633 54.4888561, 9.5669801 54.488833, 9.5671011 54.488819, 9.5672229 54.4888072, 9.5673454 54.4887982, 9.5674682 54.4887909, 9.5675916 54.4887888, 9.567715 54.4887896, 9.5678381 54.4887948, 9.567961 54.4888018, 9.5680836 54.4888099, 9.5682057 54.4888206, 9.568327 54.4888339, 9.568447 54.4888507, 9.5685653 54.4888713, 9.5686815 54.4888955, 9.5687967 54.4889213, 9.568910')
    || TO_CLOB('6 54.488949, 9.569025 54.4889761, 9.5691399 54.4890023, 9.5692551 54.4890282, 9.5693712 54.4890527, 9.5694868 54.4890778, 9.5696013 54.4891047, 9.5697061 54.4891426, 9.569787 54.4891967, 9.569889 54.4892372, 9.5699837 54.4892833, 9.5700783 54.4893294, 9.570173 54.4893755, 9.5702683 54.4894212))'), 8307),
    NULL, NULL, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Höhe und Fläche des Walls'), 'Zwischen Kammlinie und Ufer von 950: 28,2 ha (Literatur 26 ha)', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'TOR', 'Südtor',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56658, 54.488922, NULL), NULL, NULL),
    NULL, 3.6, 'GESTALTET', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Tore'), 'Torbau [G]; 260 m vom Südende der Kammlinie', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'TOR', 'Westtor',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.560909, 54.490524, NULL), NULL, NULL),
    NULL, 3.6, 'GESTALTET', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Tore'), 'Torbau [G]; 696 m vom Südende der Kammlinie', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'TOR', 'Nordtor',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.562467, 54.493663, NULL), NULL, NULL),
    NULL, 3.6, 'GESTALTET', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Tore'), 'Torbau [G]; 1.090 m vom Südende der Kammlinie', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'BACHDURCHLASS', 'Bachdurchlass',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56083, 54.490578, NULL), NULL, NULL),
    NULL, NULL, 'GESTALTET', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Tore'), 'Der Haithabu-Bach läuft durch den Wall', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'HOCHBURG', 'Hochburg',
    MDSYS.SDO_GEOMETRY('POLYGON ((9.5651157 54.4965593, 9.5660147 54.4961791, 9.5681919 54.4979234, 9.5672928 54.4983036, 9.5651157 54.4965593))', 8307),
    2, NULL, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Hochburg'), 'Innenfläche 240 × 72 m auf der Moränenkuppe, Wall 2 m um 950, Tor im Nordosten [G in Lage und Maß]', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 01',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567449, 54.498144, NULL), NULL, NULL),
    1.32, 10.43, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 02',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56731, 54.498117, NULL), NULL, NULL),
    1.17, 9.3, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 03',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567572, 54.498081, NULL), NULL, NULL),
    1.19, 9.4, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 04',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567171, 54.498063, NULL), NULL, NULL),
    1.25, 9.85, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 05',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567124, 54.497992, NULL), NULL, NULL),
    1.24, 9.82, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 06',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567094, 54.497929, NULL), NULL, NULL),
    1.23, 9.72, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 07',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567248, 54.49792, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 08',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56802, 54.497875, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 09',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567016, 54.497848, NULL), NULL, NULL),
    1, 7.98, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 10',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567495, 54.497848, NULL), NULL, NULL),
    1.4, 10.97, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 11',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567171, 54.49783, NULL), NULL, NULL),
    0.86, 6.91, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 12',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567263, 54.497803, NULL), NULL, NULL),
    0.89, 7.15, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 13',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566862, 54.497794, NULL), NULL, NULL),
    1.1, 8.77, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 14',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567124, 54.497731, NULL), NULL, NULL),
    1.02, 8.14, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 15',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566692, 54.497722, NULL), NULL, NULL),
    1.02, 8.13, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 16',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567773, 54.497722, NULL), NULL, NULL),
    0.89, 7.21, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 17',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566631, 54.497641, NULL), NULL, NULL),
    1.06, 8.41, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 18',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566785, 54.497641, NULL), NULL, NULL),
    1.05, 8.37, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 19',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567186, 54.497641, NULL), NULL, NULL),
    0.91, 7.32, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 20',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567418, 54.497623, NULL), NULL, NULL),
    1.1, 8.79, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 21',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56697, 54.497551, NULL), NULL, NULL),
    1.15, 9.14, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 22',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567618, 54.497551, NULL), NULL, NULL),
    0.84, 6.82, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 23',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566445, 54.497533, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 24',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566631, 54.497515, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 25',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567325, 54.497497, NULL), NULL, NULL),
    1.02, 8.14, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 26',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56714, 54.49747, NULL), NULL, NULL),
    0.85, 6.9, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 27',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566353, 54.497461, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 28',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.5668, 54.497444, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 29',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567248, 54.497426, NULL), NULL, NULL),
    1.03, 8.24, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 30',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566538, 54.497417, NULL), NULL, NULL),
    0.93, 7.45, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 31',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566677, 54.497399, NULL), NULL, NULL),
    0.89, 7.15, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 32',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567202, 54.497372, NULL), NULL, NULL),
    0.92, 7.38, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 33',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566183, 54.497318, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 34',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566584, 54.497318, NULL), NULL, NULL),
    0.87, 7.05, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 35',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567016, 54.497309, NULL), NULL, NULL),
    1.39, 10.91, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 36',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566415, 54.497291, NULL), NULL, NULL),
    0.9, 7.26, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 37',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567202, 54.497273, NULL), NULL, NULL),
    0.88, 7.13, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 38',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566137, 54.497264, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 39',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566384, 54.497219, NULL), NULL, NULL),
    0.84, 6.83, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 40',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566476, 54.497219, NULL), NULL, NULL),
    0.9, 7.24, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 41',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566013, 54.497192, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 42',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566646, 54.497183, NULL), NULL, NULL),
    0.94, 7.54, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 43',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.567032, 54.497183, NULL), NULL, NULL),
    1.34, 10.58, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 44',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565936, 54.497129, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 45',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566986, 54.49712, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 46',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566137, 54.497111, NULL), NULL, NULL),
    0.89, 7.16, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 47',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566569, 54.497093, NULL), NULL, NULL),
    0.88, 7.13, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 48',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566198, 54.497057, NULL), NULL, NULL),
    0.99, 7.89, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 49',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565843, 54.497039, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 50',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566384, 54.49703, NULL), NULL, NULL),
    1.12, 8.93, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 51',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566553, 54.49703, NULL), NULL, NULL),
    0.87, 7.03, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 52',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.5668, 54.496994, NULL), NULL, NULL),
    0.95, 7.62, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 53',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565797, 54.496958, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 54',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566492, 54.496949, NULL), NULL, NULL),
    0.89, 7.16, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 55',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566692, 54.496922, NULL), NULL, NULL),
    0.99, 7.9, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 56',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566152, 54.496913, NULL), NULL, NULL),
    0.99, 7.91, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 57',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565952, 54.496851, NULL), NULL, NULL),
    1.07, 8.56, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 58',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566569, 54.496851, NULL), NULL, NULL),
    0.99, 7.9, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 59',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566106, 54.496833, NULL), NULL, NULL),
    0.87, 7, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 60',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565658, 54.496815, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 61',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566415, 54.49677, NULL), NULL, NULL),
    1.14, 9.03, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 62',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565844, 54.496743, NULL), NULL, NULL),
    0.95, 7.62, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 63',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566152, 54.496743, NULL), NULL, NULL),
    1.07, 8.52, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 64',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565998, 54.496725, NULL), NULL, NULL),
    1.12, 8.92, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 65',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566245, 54.496716, NULL), NULL, NULL),
    1.31, 10.33, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 66',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565489, 54.496671, NULL), NULL, NULL),
    1.38, 10.82, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 67',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56606, 54.496671, NULL), NULL, NULL),
    0.97, 7.76, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 68',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56589, 54.496653, NULL), NULL, NULL),
    0.98, 7.86, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 69',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566121, 54.496644, NULL), NULL, NULL),
    0.96, 7.71, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 70',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565396, 54.496626, NULL), NULL, NULL),
    1.33, 10.47, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 71',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565952, 54.496626, NULL), NULL, NULL),
    0.97, 7.78, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 72',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565319, 54.496599, NULL), NULL, NULL),
    1.24, 9.8, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 73',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566445, 54.496572, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 74',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565751, 54.496491, NULL), NULL, NULL),
    1.25, 9.87, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 75',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565411, 54.496482, NULL), NULL, NULL),
    0.93, 7.47, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 76',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565597, 54.496482, NULL), NULL, NULL),
    0.91, 7.35, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 77',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566044, 54.496482, NULL), NULL, NULL),
    1.02, 8.14, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 78',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.566214, 54.496482, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 79',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56609, 54.496401, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'GRABHUEGEL', 'Grabhügel 80',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.565952, 54.496347, NULL), NULL, NULL),
    1.4, 11, 'GEMESSEN', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Grabhügel der Hochburg'), 'Kuppe im DGM1; Höhe um 950 gestaltet', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'WALL_EINGEEBNET', 'Verbindungswall, Stück 1',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5600187 54.4906201, 9.5597409 54.4905572, 9.5594323 54.4904673, 9.5591391 54.4904404, 9.5587996 54.4904224, 9.558491 54.4904134, 9.5581824 54.4903954, 9.5578738 54.4903684, 9.5575651 54.4904043, 9.5572565 54.4904312, 9.5569324 54.4904491, 9.5566238 54.4904401, 9.5562997 54.4904401, 9.5559911 54.490449, 9.5557442 54.4904041)', 8307),
    NULL, NULL, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Verbindungswall'), 'Im DGM1 erhalten, um 950 noch nicht gebaut (um 968): eingeebnet (F24)', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'WALL_EINGEEBNET', 'Verbindungswall, Stück 2',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5538152 54.4905206, 9.5535066 54.4905206, 9.553198 54.4905026, 9.5528894 54.4904936, 9.5525807 54.4904576, 9.5522721 54.4904396, 9.5520869 54.4904216)', 8307),
    NULL, NULL, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Verbindungswall'), 'Im DGM1 erhalten, um 950 noch nicht gebaut (um 968): eingeebnet (F24)', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'WALL_EINGEEBNET', 'Verbindungswall, Stück 3',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5485376 54.4905378, 9.5484142 54.4905378, 9.5481056 54.4905287, 9.5477969 54.4905377, 9.5474729 54.4905286, 9.5471642 54.4905915, 9.5468556 54.4906363, 9.5465469 54.4906722, 9.5462537 54.490735, 9.545945 54.4907709, 9.5456364 54.4908157, 9.5453431 54.4908606, 9.5450191 54.4908695, 9.5447104 54.4909144, 9.5444017 54.4909502, 9.5441085 54.4909951, 9.5437999 54.49104, 9.5435066 54.4910758, 9.5433832 54.4911028)', 8307),
    NULL, NULL, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Verbindungswall'), 'Im DGM1 erhalten, um 950 noch nicht gebaut (um 968): eingeebnet (F24)', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'PLATTFORM', 'Plattform 1',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5697658 54.4911149, 9.5698112 54.4911492, 9.569841 54.4911852, 9.5698533 54.4912293, 9.5698552 54.491272, 9.5698516 54.4913115, 9.5698435 54.4913496, 9.5698321 54.4913871, 9.5698207 54.491424, 9.5698086 54.49146, 9.5697956 54.4914953, 9.5697848 54.4915303, 9.5697775 54.4915647, 9.5697711 54.4915994, 9.5697667 54.491635, 9.5697624 54.4916705, 9.5697568 54.4917068, 9.5697522 54.4917441, 9.5697451 54.491782, 9.569732 54.4918208, 9.5697141 54.4918598, 9.569692 54.4918978, 9.5696656 54.4919354, 9.5696394 54.4919724, 9.5696114 54.492009, 9.569582 54.4920458, 9.5695516 54.4920825, 9.5695191 54.4921191, 9.5694852 54.4921559, 9.5694499 54.492193, 9.5694112 54.4922311, 9.5693666 54.4922692, 9.5693111 54.492307, 9.5692526 54.4923445, 9.5691928 54.4923812, 9.5691296 54.492418, 9.5690636 54.4924545, 9.5689944 54.4924903, 9.5689274 54.4925261, 9.5688681 54.4925619, 9.5688053 54.4925978, 9.5687371 54.4926343, 9.5686689 54.4926707, 9.5685992 54.4927073, 9.5685242 54.4927449, 9.568441 54.')
    || TO_CLOB('492782, 9.5683368 54.4928186, 9.5682369 54.4928548, 9.5681457 54.4928902, 9.5680582 54.4929253, 9.567976 54.4929601, 9.5679042 54.4929934)'), 8307),
    0.9, 13, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Landebrücken und Plattformen'), 'Plattform am Ufer, 261 m lang, 13 m breit', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'PLATTFORM', 'Plattform 2',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5702219 54.4898818, 9.5702065 54.4899176, 9.570191 54.4899537, 9.5701749 54.489991, 9.5701548 54.4900294, 9.5701289 54.4900677, 9.5700963 54.4901059, 9.5700631 54.4901433, 9.5700275 54.4901795, 9.5699923 54.4902154, 9.56996 54.4902505, 9.5699293 54.4902849, 9.569902 54.4903191, 9.5698803 54.490353, 9.5698602 54.4903874, 9.5698427 54.4904231, 9.5698239 54.4904591, 9.5698023 54.4904943, 9.5697823 54.4905281, 9.5697703 54.4905608, 9.5697656 54.4905929)', 8307),
    0.9, 13, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Landebrücken und Plattformen'), 'Plattform am Ufer, 85 m lang, 13 m breit', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'LANDEBRUECKE', 'Querkopf 1',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5699284 54.4911674, 9.570832 54.4909843)', 8307),
    0.9, 3.924102, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Landebrücken und Plattformen'), '62 m lang, 3,9 m breit', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'LANDEBRUECKE', 'Landebrücke 2',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5698763 54.4915386, 9.5707454 54.4916177)', 8307),
    0.9, 4.458676, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Landebrücken und Plattformen'), '57 m lang, 4,5 m breit', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'LANDEBRUECKE', 'Landebrücke 3',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5698365 54.4917906, 9.570705 54.4918718)', 8307),
    0.9, 3.376045, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Landebrücken und Plattformen'), '57 m lang, 3,4 m breit', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'LANDEBRUECKE', 'Querkopf 4',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5696345 54.4921066, 9.5704074 54.4923315)', 8307),
    0.9, 4.437398, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Landebrücken und Plattformen'), '56 m lang, 4,4 m breit', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'LANDEBRUECKE', 'Landebrücke 5',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5693204 54.4923812, 9.569965 54.4927296)', 8307),
    0.9, 3.961616, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Landebrücken und Plattformen'), '57 m lang, 4,0 m breit', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'LANDEBRUECKE', 'Landebrücke 6',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5688001 54.4926738, 9.569399 54.4930488)', 8307),
    0.9, 3.310581, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Landebrücken und Plattformen'), '57 m lang, 3,3 m breit', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'LANDEBRUECKE', 'Landebrücke 7',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5702806 54.4899674, 9.5711013 54.4900933)', 8307),
    0.9, 3.534158, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Landebrücken und Plattformen'), '55 m lang, 3,5 m breit', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'LANDEBRUECKE', 'Landebrücke 8',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.570042 54.4902755, 9.570808 54.4905084)', 8307),
    0.9, 3.514673, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Landebrücken und Plattformen'), '56 m lang, 3,5 m breit', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'LANDEBRUECKE', 'Landebrücke 9',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5698909 54.49051, 9.5707621 54.4906639)', 8307),
    0.9, 3.750467, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Landebrücken und Plattformen'), '59 m lang, 3,8 m breit', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'UMSCHLAGPLATZ', 'Umschlagplatz',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5700226 54.4915819, 9.5700169 54.4916128, 9.5700128 54.4916471, 9.5700086 54.4916814, 9.5700029 54.491719, 9.5699974 54.4917607)', 8307),
    0.9, 18, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Landebrücken und Plattformen'), 'Markt und Umschlag am Hafen', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'HAFENPALISADE', 'Hafenpalisade 1',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5703945 54.489529, 9.5710332 54.4898266, 9.5711647 54.4898879, 9.5714259 54.4900334, 9.5715962 54.4902051, 9.5717077 54.4903991, 9.5718006 54.4905764, 9.5718874 54.490726, 9.5719899 54.4908161, 9.5721334 54.4907915, 9.5722667 54.4906846, 9.5724033 54.490673, 9.5725151 54.4907814, 9.5726154 54.4908528, 9.5726852 54.4908878, 9.5727818 54.4910583, 9.5728616 54.4911462, 9.5729162 54.4912899, 9.5729828 54.4915539, 9.5730091 54.4917706, 9.5729938 54.4919234, 9.5729338 54.4921162, 9.5728244 54.4923627, 9.5726621 54.4926502, 9.5724173 54.4929498, 9.5721093 54.4932118)', 8307),
    1.3, NULL, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Hafenpalisade'), 'Pfahlreihe im Wasser, Kopf 1,3 m über dem Mittelwasser', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'HAFENPALISADE', 'Hafenpalisade 2',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5718849 54.4933709, 9.5715428 54.4935831, 9.5711835 54.493769, 9.5708043 54.493921, 9.5704341 54.4940399, 9.5701363 54.4941091, 9.5699679 54.4940805, 9.5699059 54.4939743, 9.5699292 54.4938338, 9.5699207 54.4937386, 9.5697771 54.4937517, 9.5695585 54.49383, 9.5693121 54.4939234, 9.569055 54.4939953, 9.5687937 54.4940374, 9.5685121 54.4940681, 9.5681595 54.4940979, 9.5679869 54.4941198, 9.5671478 54.4941286)', 8307),
    1.3, NULL, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Hafenpalisade'), 'Pfahlreihe im Wasser, Kopf 1,3 m über dem Mittelwasser', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'DURCHFAHRT', 'Durchfahrt',
    MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.571998, 54.493293, NULL), NULL, NULL),
    NULL, 14, 'GESTALTET', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Durchfahrt'), '14 m breit, nach Nordost zur Schlei', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'HAFENBECKEN', 'Hafenbecken',
    MDSYS.SDO_GEOMETRY(TO_CLOB('POLYGON ((9.5703945 54.489529, 9.5703945 54.489529, 9.5709847 54.4898066, 9.571123 54.4898671, 9.571351 54.4899848, 9.5715473 54.4901444, 9.5716747 54.4903338, 9.5717696 54.4905216, 9.5718597 54.4906782, 9.57195 54.4907985, 9.5720839 54.4908111, 9.5722246 54.4907228, 9.5723567 54.4906507, 9.5724773 54.4907495, 9.5725863 54.4908402, 9.5726594 54.4908682, 9.5727569 54.4910065, 9.5728318 54.4911228, 9.5729002 54.4912371, 9.5729599 54.4914586, 9.5730082 54.4917179, 9.5730033 54.4918682, 9.5729592 54.4920465, 9.5728668 54.4922738, 9.5727228 54.4925515, 9.5725088 54.4928523, 9.5722165 54.4931282, 9.5718849 54.4933709, 9.5715428 54.4935831, 9.5711835 54.493769, 9.5708043 54.493921, 9.5704341 54.4940399, 9.5701363 54.4941091, 9.5699679 54.4940805, 9.5699059 54.4939743, 9.5699292 54.4938338, 9.5699207 54.4937386, 9.5697771 54.4937517, 9.5695585 54.49383, 9.5693121 54.4939234, 9.569055 54.4939953, 9.5687937 54.4940374, 9.5685121 54.4940681, 9.5681595 54.4940979, 9.5679869 54.4941198, 9.5671478 5')
    || TO_CLOB('4.4941286, 9.5671607 54.4940926, 9.5671941 54.4940028, 9.5672405 54.493895, 9.5672868 54.4937872, 9.5673463 54.4936794, 9.5674191 54.4935716, 9.5674984 54.4934638, 9.5675624 54.493356, 9.5676087 54.4932482, 9.5676627 54.4931404, 9.567752 54.4930326, 9.5679284 54.4929248, 9.5681951 54.492817, 9.5684773 54.4927092, 9.5686846 54.4926014, 9.5688742 54.4924936, 9.5690759 54.4923858, 9.5692522 54.492278, 9.5693834 54.4921702, 9.5694826 54.4920624, 9.5695686 54.4919546, 9.5696403 54.4918468, 9.5696755 54.491739, 9.5696899 54.4916312, 9.5697086 54.4915234, 9.569745 54.4914156, 9.5697747 54.4913077, 9.5697681 54.4911999, 9.569691 54.4910921, 9.5697031 54.4909843, 9.5697736 54.4908765, 9.5697295 54.4907687, 9.5696866 54.4906609, 9.5696943 54.4905531, 9.5697505 54.4904453, 9.5698078 54.4903375, 9.5698916 54.4902297, 9.5699952 54.4901219, 9.5700823 54.4900141, 9.5701319 54.4899063, 9.5701815 54.4897985, 9.5702377 54.4896907, 9.5703303 54.4895829, 9.5703945 54.489529))'), 8307),
    NULL, NULL, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Hafenpalisade'), 'Becken innerhalb der Palisade, 10,0 ha (Literatur 8 bis 11 ha)', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'UFER_950', 'Ufer von 950',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5703945 54.489529, 9.5703475 54.4895649, 9.5702928 54.4896188, 9.5702377 54.4896907, 9.5701969 54.4897626, 9.5701649 54.4898344, 9.5701319 54.4899063, 9.570101 54.4899782, 9.570058 54.49005, 9.5699952 54.4901219, 9.5699246 54.4901938, 9.5698596 54.4902657, 9.5698078 54.4903375, 9.5697692 54.4904094, 9.5697284 54.4904813, 9.5696943 54.4905531, 9.5696855 54.490625, 9.5696943 54.4906969, 9.5697295 54.4907687, 9.5697626 54.4908406, 9.5697362 54.4909125, 9.5697031 54.4909843, 9.5696921 54.4910562, 9.5696921 54.4911281, 9.5697681 54.4911999, 9.569778 54.4912718, 9.569767 54.4913437, 9.569745 54.4914156, 9.5697196 54.4914874, 9.5697009 54.4915593, 9.5696899 54.4916312, 9.5696799 54.491703, 9.5696689 54.4917749, 9.5696403 54.4918468, 9.569594 54.4919186, 9.569541 54.4919905, 9.5694826 54.4920624, 9.5694176 54.4921342, 9.569347 54.4922061, 9.5692522 54.492278, 9.5691376 54.4923498, 9.5690108 54.4924217, 9.5688742 54.4924936, 9.5687518 54.4925654, 9.5686173 54.4926373, 9.5684773 54')
    || TO_CLOB('.4927092, 9.5682943 54.492781, 9.5681025 54.4928529, 9.5679284 54.4929248, 9.5677884 54.4929966, 9.5677189 54.4930685, 9.5676627 54.4931404, 9.5676252 54.4932123, 9.5675921 54.4932841, 9.5675624 54.493356, 9.5675227 54.4934279, 9.5674742 54.4934997, 9.5674191 54.4935716, 9.5673683 54.4936435, 9.5673253 54.4937153, 9.5672868 54.4937872, 9.5672559 54.4938591, 9.567225 54.4939309, 9.5671941 54.4940028, 9.5671677 54.4940747, 9.567154 54.4941106, 9.5671478 54.4941286)'), 8307),
    NULL, NULL, 'GESTALTET', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Uferlinie von 950'), 'Ufer zwischen den Wallenden, rund 1 m unter dem heutigen [G]', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'BACH', 'Haithabu-Bach',
    MDSYS.SDO_GEOMETRY(TO_CLOB('LINESTRING (9.5565634 54.4901335, 9.5566788 54.4901383, 9.5567481 54.4901411, 9.5568405 54.4901449, 9.5569328 54.4901486, 9.5570253 54.4901524, 9.5571175 54.4901562, 9.55721 54.49016, 9.5573023 54.4901638, 9.5573947 54.4901676, 9.557487 54.4901713, 9.5575794 54.4901751, 9.5576717 54.4901789, 9.5577641 54.4901825, 9.5578564 54.490184, 9.5579482 54.4901811, 9.5580389 54.4901728, 9.5581286 54.4901601, 9.5582176 54.4901454, 9.5583067 54.4901304, 9.5583956 54.4901155, 9.5584846 54.4901006, 9.5585735 54.4900856, 9.5586626 54.4900707, 9.5587514 54.4900557, 9.5588405 54.4900408, 9.5589295 54.4900261, 9.5590195 54.4900145, 9.5591099 54.4900098, 9.5591994 54.4900153, 9.5592852 54.490032, 9.5593661 54.490057, 9.5594432 54.4900866, 9.5595185 54.490118, 9.5595937 54.4901494, 9.5596686 54.490181, 9.5597438 54.4902125, 9.5598189 54.490244, 9.5598941 54.4902755, 9.5599692 54.4903069, 9.5600444 54.4903385, 9.5601195 54.49037, 9.5601947 54.4904015, 9.5602704 54.4904324, 9.560348 54.4904616, 9.5604276 54')
    || TO_CLOB('.4904889, 9.5605091 54.4905144, 9.5605918 54.4905386, 9.5606769 54.4905592, 9.5607625 54.490573, 9.5608418 54.4905815, 9.5609114 54.49059, 9.5609668 54.4906043, 9.5610117 54.4906268, 9.5610469 54.4906554, 9.5610734 54.4906874, 9.561095 54.4907209, 9.5611186 54.4907537, 9.5611507 54.4907827, 9.5611941 54.490806, 9.5612462 54.490824, 9.5613021 54.4908393, 9.5613582 54.4908542, 9.5614143 54.4908692, 9.5614709 54.4908834, 9.5615288 54.4908957, 9.5615872 54.4909069, 9.5616454 54.4909187, 9.5617022 54.4909326, 9.561757 54.4909489, 9.561811 54.4909661, 9.5618661 54.4909818, 9.5619232 54.490995, 9.5619809 54.4910072, 9.5620374 54.4910209, 9.5620912 54.491038, 9.5621428 54.4910576, 9.5621935 54.491078, 9.5622438 54.4910988, 9.5622915 54.4911213, 9.562337 54.4911454, 9.5623812 54.4911703, 9.5624251 54.4911954, 9.5624694 54.4912204, 9.5625129 54.4912459, 9.5625551 54.4912721, 9.5625967 54.4912986, 9.5626385 54.4913251, 9.5626814 54.4913508, 9.5627262 54.4913755, 9.5627732 54.4913986, 9.5628225 54')
    || TO_CLOB('.4914202, 9.5628734 54.4914404, 9.5629255 54.4914597, 9.5629782 54.4914784, 9.5630303 54.4914976, 9.5630819 54.4915174, 9.5631328 54.4915376, 9.563184 54.4915577, 9.5632359 54.4915772, 9.5632885 54.491596, 9.5633417 54.4916141, 9.5633963 54.4916306, 9.5634527 54.4916451, 9.5635105 54.4916573, 9.5635696 54.4916677, 9.5636294 54.4916767, 9.5636894 54.4916851, 9.5637497 54.4916925, 9.5638104 54.4916988, 9.5638716 54.4917032, 9.5639331 54.4917048, 9.5639942 54.4917027, 9.5640545 54.4916967, 9.564113 54.4916864, 9.5641673 54.4916707, 9.5642158 54.4916499, 9.5642579 54.4916243, 9.564296 54.4915961, 9.5643352 54.4915686, 9.5643804 54.4915466, 9.5644323 54.4915349, 9.5644877 54.4915368, 9.5645422 54.4915498, 9.5645945 54.4915684, 9.5646471 54.4915869, 9.5647027 54.4916019, 9.564761 54.4916118, 9.5648209 54.4916152, 9.5648797 54.4916101, 9.5649341 54.4915965, 9.5649823 54.4915755, 9.565024 54.4915494, 9.5650608 54.4915208, 9.5650956 54.4914911, 9.5651304 54.4914616, 9.5651704 54.4914352, 9.5652')
    || TO_CLOB('179 54.4914153, 9.5652732 54.4914027, 9.5653334 54.4913959, 9.565394 54.4913901, 9.5654528 54.491381, 9.5655085 54.4913671, 9.5655602 54.491348, 9.5656093 54.4913264, 9.5656582 54.4913045, 9.5657092 54.4912847, 9.5657636 54.4912685, 9.5658212 54.4912569, 9.5658812 54.4912497, 9.5659425 54.491246, 9.5660041 54.4912445, 9.5660658 54.4912444, 9.5661274 54.4912453, 9.5661891 54.4912471, 9.5662507 54.4912496, 9.5663121 54.491253, 9.5663733 54.4912571, 9.5664346 54.4912617, 9.5664959 54.491265, 9.5665561 54.4912635, 9.5666113 54.4912537, 9.5666612 54.4912353, 9.5667056 54.4912109, 9.56675 54.4911864, 9.5667997 54.4911682, 9.5668548 54.4911594, 9.5669142 54.4911604, 9.5669744 54.4911672, 9.5670348 54.4911741, 9.5670951 54.4911767, 9.567155 54.4911726, 9.5672122 54.4911616, 9.5672664 54.4911449, 9.5673175 54.4911251, 9.5673676 54.4911041, 9.5674186 54.491084, 9.5674723 54.491067, 9.5675292 54.4910545, 9.5675888 54.4910477, 9.5676499 54.4910463, 9.567711 54.4910495, 9.5677716 54.4910556, 9.5678')
    || TO_CLOB('32 54.4910631, 9.5678923 54.4910702, 9.5679531 54.4910761, 9.5680144 54.4910808, 9.5680756 54.4910849, 9.5681369 54.491089, 9.5681983 54.4910931, 9.5682596 54.4910972, 9.568321 54.4911013, 9.5683823 54.4911053, 9.5684435 54.4911095, 9.5685049 54.4911131, 9.5685659 54.4911134, 9.5686258 54.4911087, 9.5686836 54.4910981, 9.5687392 54.4910827, 9.5687927 54.491065, 9.5688451 54.491046, 9.5688971 54.4910266, 9.5689497 54.491008, 9.5690042 54.4909913, 9.569061 54.4909781, 9.5691202 54.4909703, 9.5691807 54.4909684, 9.5692413 54.4909722, 9.5693011 54.4909805, 9.5693594 54.4909919, 9.5694168 54.491005, 9.5694737 54.4910189, 9.5695308 54.4910327, 9.5695884 54.4910455, 9.5696469 54.4910568, 9.5696762 54.4910623, 9.5697359 54.4910713)'), 8307),
    NULL, NULL, 'BELEGT', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Haithabu-Bach'), 'Lauf aus dem Gelände gefunden, bis zur Mündung am Ufer von 950', 'MITGELIEFERT' FROM DUAL;
INSERT INTO HB_BAUWERK (ART, NAME, GEOM, HOEHE_M, BREITE_M, BEFUND, BEFUND_ID, BESCHREIBUNG, HERKUNFT)
  SELECT 'DAMM_ENTFERNT', 'Damm zwischen Noor und Schlei',
    MDSYS.SDO_GEOMETRY('LINESTRING (9.5738081 54.5005418, 9.5758128 54.5003435, 9.5778222 54.5004867, 9.5799913 54.5009976, 9.5821579 54.5013287)', 8307),
    NULL, 70, 'GESTALTET', (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Damm zwischen Noor und Schlei'), 'Damm von Bundesstraße und Bahn, für 950 auf Wasser gesetzt (F23)', 'MITGELIEFERT' FROM DUAL;

-- --------------------------------------------------------------------------------------------- Gelände
MERGE INTO HB_GELAENDE t USING (SELECT 'Haddebyer Noor' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.QUELLE = 'DGM1 Schleswig-Holstein, 48 km²', t.AUSSCHNITT = MDSYS.SDO_GEOMETRY('POLYGON ((9.5400675 54.5094554, 9.5400941 54.4726587, 9.6032741 54.4726576, 9.6033042 54.5094544, 9.5400675 54.5094554))', 8307), t.URSPRUNG = MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56971, 54.491061, NULL), NULL, NULL),
    t.RASTER_M = 1, t.SPALTEN = 4096, t.ZEILEN = 4096, t.ANTEIL_GEMESSEN_PROZ = 75.2, t.DATEI = 'daten/gelaende/hoehe.r16', t.PRUEFSUMME = '7df9d2498e05dbc6410a1029532a4670a9b066f633064decc9e611230dc57d4c',
    t.EINGRIFFE = 'Damm zwischen Noor und Schlei entfernt (F23); Verbindungswall eingeebnet (F24); Noorgrund modelliert, Uferlinie von 950 rund 1 m unter heute; Wall geformt (Phase 7)' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, QUELLE, AUSSCHNITT, URSPRUNG, RASTER_M, SPALTEN, ZEILEN, ANTEIL_GEMESSEN_PROZ, DATEI, PRUEFSUMME, EINGRIFFE, HERKUNFT)
  VALUES ('Haddebyer Noor', 'DGM1 Schleswig-Holstein, 48 km²', MDSYS.SDO_GEOMETRY('POLYGON ((9.5400675 54.5094554, 9.5400941 54.4726587, 9.6032741 54.4726576, 9.6033042 54.5094544, 9.5400675 54.5094554))', 8307), MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.56971, 54.491061, NULL), NULL, NULL), 1, 4096, 4096, 75.2, 'daten/gelaende/hoehe.r16', '7df9d2498e05dbc6410a1029532a4670a9b066f633064decc9e611230dc57d4c', 'Damm zwischen Noor und Schlei entfernt (F23); Verbindungswall eingeebnet (F24); Noorgrund modelliert, Uferlinie von 950 rund 1 m unter heute; Wall geformt (Phase 7)', 'MITGELIEFERT');

-- --------------------------------------------------------------------------------------------- Schiffe
MERGE INTO HB_SCHIFFSTYP t USING (SELECT 'LANGSCHIFF' AS NAME, (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Haithabu 1') AS BID FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEZEICHNUNG = 'Langschiff (Haithabu 1)', t.VORBILD = 'Haithabu 1 (um 985)', t.LAENGE_M = 30.9, t.BREITE_M = 2.7, t.TIEFGANG_M = 0.85, t.RIEMENPAARE = 26, t.SEGEL = 1, t.MASSE_KG = 26000, t.BEFUND = 'BELEGT', t.BEFUND_ID = q.BID WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEZEICHNUNG, VORBILD, LAENGE_M, BREITE_M, TIEFGANG_M, RIEMENPAARE, SEGEL, MASSE_KG, BEFUND, BEFUND_ID, HERKUNFT)
  VALUES ('LANGSCHIFF', 'Langschiff (Haithabu 1)', 'Haithabu 1 (um 985)', 30.9, 2.7, 0.85, 26, 1, 26000, 'BELEGT', q.BID, 'MITGELIEFERT');
MERGE INTO HB_SCHIFFSTYP t USING (SELECT 'KNORR' AS NAME, (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Knorr') AS BID FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEZEICHNUNG = 'Knorr (Handelsschiff)', t.VORBILD = 'Haithabu 3 (um 1023)', t.LAENGE_M = 22, t.BREITE_M = 6, t.TIEFGANG_M = 1.45, t.RIEMENPAARE = 3, t.SEGEL = 1, t.MASSE_KG = 60000, t.BEFUND = 'GESTALTET', t.BEFUND_ID = q.BID WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEZEICHNUNG, VORBILD, LAENGE_M, BREITE_M, TIEFGANG_M, RIEMENPAARE, SEGEL, MASSE_KG, BEFUND, BEFUND_ID, HERKUNFT)
  VALUES ('KNORR', 'Knorr (Handelsschiff)', 'Haithabu 3 (um 1023)', 22, 6, 1.45, 3, 1, 60000, 'GESTALTET', q.BID, 'MITGELIEFERT');
MERGE INTO HB_SCHIFFSTYP t USING (SELECT 'FAERING' AS NAME, (SELECT MAX(ID) FROM HB_BEFUND WHERE GEGENSTAND = 'Faering') AS BID FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEZEICHNUNG = 'Faering (Ruderboot)', t.VORBILD = NULL, t.LAENGE_M = 6.6, t.BREITE_M = 1.5, t.TIEFGANG_M = 0.3, t.RIEMENPAARE = 2, t.SEGEL = 0, t.MASSE_KG = 900, t.BEFUND = 'GESTALTET', t.BEFUND_ID = q.BID WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEZEICHNUNG, VORBILD, LAENGE_M, BREITE_M, TIEFGANG_M, RIEMENPAARE, SEGEL, MASSE_KG, BEFUND, BEFUND_ID, HERKUNFT)
  VALUES ('FAERING', 'Faering (Ruderboot)', NULL, 6.6, 1.5, 0.3, 2, 0, 900, 'GESTALTET', q.BID, 'MITGELIEFERT');
MERGE INTO HB_SCHIFF t USING (SELECT 'Knorr' AS NAME, (SELECT ID FROM HB_SCHIFFSTYP WHERE NAME = 'KNORR') AS TID FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.SCHIFFSTYP_ID = q.TID, t.ROLLE = 'KNORR', t.LIEGEPLATZ = MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.570457, 54.492346, NULL), NULL, NULL), t.RICHTUNG_GRAD = 153.43, t.LADUNG = 'Mühlsteine, Specksteintöpfe, Fässer [G]' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, SCHIFFSTYP_ID, ROLLE, LIEGEPLATZ, RICHTUNG_GRAD, LADUNG, HERKUNFT) VALUES ('Knorr', q.TID, 'KNORR', MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.570457, 54.492346, NULL), NULL, NULL), 153.43, 'Mühlsteine, Specksteintöpfe, Fässer [G]', 'MITGELIEFERT');
MERGE INTO HB_SCHIFF t USING (SELECT 'Knorr am Querkopf' AS NAME, (SELECT ID FROM HB_SCHIFFSTYP WHERE NAME = 'KNORR') AS TID FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.SCHIFFSTYP_ID = q.TID, t.ROLLE = 'LIEGER', t.LIEGEPLATZ = MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.570884, 54.490974, NULL), NULL, NULL), t.RICHTUNG_GRAD = 19.2, t.LADUNG = 'Mühlsteine, Specksteintöpfe, Fässer [G]' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, SCHIFFSTYP_ID, ROLLE, LIEGEPLATZ, RICHTUNG_GRAD, LADUNG, HERKUNFT) VALUES ('Knorr am Querkopf', q.TID, 'LIEGER', MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.570884, 54.490974, NULL), NULL, NULL), 19.2, 'Mühlsteine, Specksteintöpfe, Fässer [G]', 'MITGELIEFERT');
MERGE INTO HB_SCHIFF t USING (SELECT 'Langschiff' AS NAME, (SELECT ID FROM HB_SCHIFFSTYP WHERE NAME = 'LANGSCHIFF') AS TID FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.SCHIFFSTYP_ID = q.TID, t.ROLLE = 'LIEGER', t.LIEGEPLATZ = MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.570463, 54.491817, NULL), NULL, NULL), t.RICHTUNG_GRAD = 260.87, t.LADUNG = NULL WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, SCHIFFSTYP_ID, ROLLE, LIEGEPLATZ, RICHTUNG_GRAD, LADUNG, HERKUNFT) VALUES ('Langschiff', q.TID, 'LIEGER', MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.570463, 54.491817, NULL), NULL, NULL), 260.87, NULL, 'MITGELIEFERT');
MERGE INTO HB_SCHIFF t USING (SELECT 'Faering' AS NAME, (SELECT ID FROM HB_SCHIFFSTYP WHERE NAME = 'FAERING') AS TID FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.SCHIFFSTYP_ID = q.TID, t.ROLLE = 'LIEGER', t.LIEGEPLATZ = MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.570643, 54.490614, NULL), NULL, NULL), t.RICHTUNG_GRAD = 253.11, t.LADUNG = NULL WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, SCHIFFSTYP_ID, ROLLE, LIEGEPLATZ, RICHTUNG_GRAD, LADUNG, HERKUNFT) VALUES ('Faering', q.TID, 'LIEGER', MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.570643, 54.490614, NULL), NULL, NULL), 253.11, NULL, 'MITGELIEFERT');
MERGE INTO HB_SCHIFF t USING (SELECT 'Fischerboot 1' AS NAME, (SELECT ID FROM HB_SCHIFFSTYP WHERE NAME = 'FAERING') AS TID FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.SCHIFFSTYP_ID = q.TID, t.ROLLE = 'FISCHER', t.LIEGEPLATZ = MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.570646, 54.49164, NULL), NULL, NULL), t.RICHTUNG_GRAD = 261.12, t.LADUNG = NULL WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, SCHIFFSTYP_ID, ROLLE, LIEGEPLATZ, RICHTUNG_GRAD, LADUNG, HERKUNFT) VALUES ('Fischerboot 1', q.TID, 'FISCHER', MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.570646, 54.49164, NULL), NULL, NULL), 261.12, NULL, 'MITGELIEFERT');
MERGE INTO HB_SCHIFF t USING (SELECT 'Fischerboot 2' AS NAME, (SELECT ID FROM HB_SCHIFFSTYP WHERE NAME = 'FAERING') AS TID FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.SCHIFFSTYP_ID = q.TID, t.ROLLE = 'FISCHER', t.LIEGEPLATZ = MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569886, 54.492647, NULL), NULL, NULL), t.RICHTUNG_GRAD = 227.12, t.LADUNG = NULL WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, SCHIFFSTYP_ID, ROLLE, LIEGEPLATZ, RICHTUNG_GRAD, LADUNG, HERKUNFT) VALUES ('Fischerboot 2', q.TID, 'FISCHER', MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569886, 54.492647, NULL), NULL, NULL), 227.12, NULL, 'MITGELIEFERT');
MERGE INTO HB_SCHIFF t USING (SELECT 'Fischerboot 3' AS NAME, (SELECT ID FROM HB_SCHIFFSTYP WHERE NAME = 'FAERING') AS TID FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.SCHIFFSTYP_ID = q.TID, t.ROLLE = 'FISCHER', t.LIEGEPLATZ = MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569219, 54.492974, NULL), NULL, NULL), t.RICHTUNG_GRAD = 222.91, t.LADUNG = NULL WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, SCHIFFSTYP_ID, ROLLE, LIEGEPLATZ, RICHTUNG_GRAD, LADUNG, HERKUNFT) VALUES ('Fischerboot 3', q.TID, 'FISCHER', MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.569219, 54.492974, NULL), NULL, NULL), 222.91, NULL, 'MITGELIEFERT');
MERGE INTO HB_SCHIFF t USING (SELECT 'Brander' AS NAME, (SELECT ID FROM HB_SCHIFFSTYP WHERE NAME = 'LANGSCHIFF') AS TID FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.SCHIFFSTYP_ID = q.TID, t.ROLLE = 'BRANDER', t.LIEGEPLATZ = MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.571731, 54.494696, NULL), NULL, NULL), t.RICHTUNG_GRAD = NULL, t.LADUNG = 'Pech und Reet: der Brander der Nacht von 1050 [G]' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, SCHIFFSTYP_ID, ROLLE, LIEGEPLATZ, RICHTUNG_GRAD, LADUNG, HERKUNFT) VALUES ('Brander', q.TID, 'BRANDER', MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE(9.571731, 54.494696, NULL), NULL, NULL), NULL, 'Pech und Reet: der Brander der Nacht von 1050 [G]', 'MITGELIEFERT');

-- ----------------------------------------------------------------------------------------- Wetterlagen
MERGE INTO HB_WETTERLAGE t USING (SELECT 'Klar' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEAUFORT = 3, t.PHASE = 'KLAR', t.WIND_MS = 5, t.RICHTUNG_GRAD = 260, t.BOEIGKEIT = 0.14, t.BEDECKUNG_ACHTEL = 2.5, t.HOHE_SCHICHT = 0.05, t.WOLKENART = 'CUMULUS', t.REGEN_MMH = 0, t.SICHT_KM = 30, t.NEBEL = 0, t.LUFTDRUCK_HPA = 1024, t.TEMPERATUR_C = 13, t.FEUCHTE_PROZ = 72, t.GEWITTER = 0, t.MONATE = '1-12', t.BESCHREIBUNG = 'Hoch über der westlichen Ostsee, leichte Brise über dem Noor, Schönwetterwolken' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEAUFORT, PHASE, WIND_MS, RICHTUNG_GRAD, BOEIGKEIT, BEDECKUNG_ACHTEL, HOHE_SCHICHT, WOLKENART, REGEN_MMH, SICHT_KM, NEBEL, LUFTDRUCK_HPA, TEMPERATUR_C, FEUCHTE_PROZ, GEWITTER, MONATE, BESCHREIBUNG, HERKUNFT)
  VALUES ('Klar', 3, 'KLAR', 5, 260, 0.14, 2.5, 0.05, 'CUMULUS', 0, 30, 0, 1024, 13, 72, 0, '1-12', 'Hoch über der westlichen Ostsee, leichte Brise über dem Noor, Schönwetterwolken', 'MITGELIEFERT');
MERGE INTO HB_WETTERLAGE t USING (SELECT 'Aufziehend' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEAUFORT = 4, t.PHASE = 'AUFZIEHEND', t.WIND_MS = 7.5, t.RICHTUNG_GRAD = 205, t.BOEIGKEIT = 0.16, t.BEDECKUNG_ACHTEL = 3.5, t.HOHE_SCHICHT = 0.75, t.WOLKENART = 'CUMULUS', t.REGEN_MMH = 0, t.SICHT_KM = 22, t.NEBEL = 0, t.LUFTDRUCK_HPA = 1013, t.TEMPERATUR_C = 13, t.FEUCHTE_PROZ = 78, t.GEWITTER = 0, t.MONATE = '1-12', t.BESCHREIBUNG = 'Ein Tief nähert sich: Cirren, rückdrehender Wind' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEAUFORT, PHASE, WIND_MS, RICHTUNG_GRAD, BOEIGKEIT, BEDECKUNG_ACHTEL, HOHE_SCHICHT, WOLKENART, REGEN_MMH, SICHT_KM, NEBEL, LUFTDRUCK_HPA, TEMPERATUR_C, FEUCHTE_PROZ, GEWITTER, MONATE, BESCHREIBUNG, HERKUNFT)
  VALUES ('Aufziehend', 4, 'AUFZIEHEND', 7.5, 205, 0.16, 3.5, 0.75, 'CUMULUS', 0, 22, 0, 1013, 13, 78, 0, '1-12', 'Ein Tief nähert sich: Cirren, rückdrehender Wind', 'MITGELIEFERT');
MERGE INTO HB_WETTERLAGE t USING (SELECT 'Front' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEAUFORT = 6, t.PHASE = 'FRONT', t.WIND_MS = 13, t.RICHTUNG_GRAD = 225, t.BOEIGKEIT = 0.2, t.BEDECKUNG_ACHTEL = 8, t.HOHE_SCHICHT = 0.2, t.WOLKENART = 'NIMBOSTRATUS', t.REGEN_MMH = 4, t.SICHT_KM = 8, t.NEBEL = 0, t.LUFTDRUCK_HPA = 1000, t.TEMPERATUR_C = 12, t.FEUCHTE_PROZ = 95, t.GEWITTER = 0, t.MONATE = '1-12', t.BESCHREIBUNG = 'Die Front: geschlossene Regenschicht, der Wind frischt auf' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEAUFORT, PHASE, WIND_MS, RICHTUNG_GRAD, BOEIGKEIT, BEDECKUNG_ACHTEL, HOHE_SCHICHT, WOLKENART, REGEN_MMH, SICHT_KM, NEBEL, LUFTDRUCK_HPA, TEMPERATUR_C, FEUCHTE_PROZ, GEWITTER, MONATE, BESCHREIBUNG, HERKUNFT)
  VALUES ('Front', 6, 'FRONT', 13, 225, 0.2, 8, 0.2, 'NIMBOSTRATUS', 4, 8, 0, 1000, 12, 95, 0, '1-12', 'Die Front: geschlossene Regenschicht, der Wind frischt auf', 'MITGELIEFERT');
MERGE INTO HB_WETTERLAGE t USING (SELECT 'Sturm' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEAUFORT = 9, t.PHASE = 'STURM', t.WIND_MS = 22, t.RICHTUNG_GRAD = 250, t.BOEIGKEIT = 0.22, t.BEDECKUNG_ACHTEL = 7.5, t.HOHE_SCHICHT = 0, t.WOLKENART = 'NIMBOSTRATUS', t.REGEN_MMH = 6, t.SICHT_KM = 6, t.NEBEL = 0, t.LUFTDRUCK_HPA = 987, t.TEMPERATUR_C = 11, t.FEUCHTE_PROZ = 92, t.GEWITTER = 1, t.MONATE = '9-3', t.BESCHREIBUNG = 'Sturm aus Südwest bis West, Schauer; auf dem Noor höchstens Bft 7 (F7)' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEAUFORT, PHASE, WIND_MS, RICHTUNG_GRAD, BOEIGKEIT, BEDECKUNG_ACHTEL, HOHE_SCHICHT, WOLKENART, REGEN_MMH, SICHT_KM, NEBEL, LUFTDRUCK_HPA, TEMPERATUR_C, FEUCHTE_PROZ, GEWITTER, MONATE, BESCHREIBUNG, HERKUNFT)
  VALUES ('Sturm', 9, 'STURM', 22, 250, 0.22, 7.5, 0, 'NIMBOSTRATUS', 6, 6, 0, 987, 11, 92, 1, '9-3', 'Sturm aus Südwest bis West, Schauer; auf dem Noor höchstens Bft 7 (F7)', 'MITGELIEFERT');
MERGE INTO HB_WETTERLAGE t USING (SELECT 'Gewitter' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEAUFORT = 8, t.PHASE = 'GEWITTER', t.WIND_MS = 18, t.RICHTUNG_GRAD = 265, t.BOEIGKEIT = 0.3, t.BEDECKUNG_ACHTEL = 7, t.HOHE_SCHICHT = 0, t.WOLKENART = 'CUMULONIMBUS', t.REGEN_MMH = 14, t.SICHT_KM = 4, t.NEBEL = 0, t.LUFTDRUCK_HPA = 992, t.TEMPERATUR_C = 10, t.FEUCHTE_PROZ = 94, t.GEWITTER = 3, t.MONATE = '5-8', t.BESCHREIBUNG = 'Sommergewitter über der Schlei, Böen und Starkregen' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEAUFORT, PHASE, WIND_MS, RICHTUNG_GRAD, BOEIGKEIT, BEDECKUNG_ACHTEL, HOHE_SCHICHT, WOLKENART, REGEN_MMH, SICHT_KM, NEBEL, LUFTDRUCK_HPA, TEMPERATUR_C, FEUCHTE_PROZ, GEWITTER, MONATE, BESCHREIBUNG, HERKUNFT)
  VALUES ('Gewitter', 8, 'GEWITTER', 18, 265, 0.3, 7, 0, 'CUMULONIMBUS', 14, 4, 0, 992, 10, 94, 3, '5-8', 'Sommergewitter über der Schlei, Böen und Starkregen', 'MITGELIEFERT');
MERGE INTO HB_WETTERLAGE t USING (SELECT 'Abklingend' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEAUFORT = 6, t.PHASE = 'ABKLINGEND', t.WIND_MS = 11, t.RICHTUNG_GRAD = 295, t.BOEIGKEIT = 0.18, t.BEDECKUNG_ACHTEL = 5, t.HOHE_SCHICHT = 0.1, t.WOLKENART = 'STRATOCUMULUS', t.REGEN_MMH = 0.8, t.SICHT_KM = 16, t.NEBEL = 0, t.LUFTDRUCK_HPA = 1004, t.TEMPERATUR_C = 9, t.FEUCHTE_PROZ = 85, t.GEWITTER = 0, t.MONATE = '1-12', t.BESCHREIBUNG = 'Der Sturm flaut ab, Schauer, aufklarender Himmel' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEAUFORT, PHASE, WIND_MS, RICHTUNG_GRAD, BOEIGKEIT, BEDECKUNG_ACHTEL, HOHE_SCHICHT, WOLKENART, REGEN_MMH, SICHT_KM, NEBEL, LUFTDRUCK_HPA, TEMPERATUR_C, FEUCHTE_PROZ, GEWITTER, MONATE, BESCHREIBUNG, HERKUNFT)
  VALUES ('Abklingend', 6, 'ABKLINGEND', 11, 295, 0.18, 5, 0.1, 'STRATOCUMULUS', 0.8, 16, 0, 1004, 9, 85, 0, '1-12', 'Der Sturm flaut ab, Schauer, aufklarender Himmel', 'MITGELIEFERT');
MERGE INTO HB_WETTERLAGE t USING (SELECT 'Aufklarend' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEAUFORT = 4, t.PHASE = 'AUFKLAREND', t.WIND_MS = 6.5, t.RICHTUNG_GRAD = 310, t.BOEIGKEIT = 0.15, t.BEDECKUNG_ACHTEL = 3, t.HOHE_SCHICHT = 0.1, t.WOLKENART = 'CUMULUS', t.REGEN_MMH = 0, t.SICHT_KM = 40, t.NEBEL = 0, t.LUFTDRUCK_HPA = 1015, t.TEMPERATUR_C = 9, t.FEUCHTE_PROZ = 75, t.GEWITTER = 0, t.MONATE = '1-12', t.BESCHREIBUNG = 'Rückseite: klare Luft, weite Sicht, Wind auf Nordwest' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEAUFORT, PHASE, WIND_MS, RICHTUNG_GRAD, BOEIGKEIT, BEDECKUNG_ACHTEL, HOHE_SCHICHT, WOLKENART, REGEN_MMH, SICHT_KM, NEBEL, LUFTDRUCK_HPA, TEMPERATUR_C, FEUCHTE_PROZ, GEWITTER, MONATE, BESCHREIBUNG, HERKUNFT)
  VALUES ('Aufklarend', 4, 'AUFKLAREND', 6.5, 310, 0.15, 3, 0.1, 'CUMULUS', 0, 40, 0, 1015, 9, 75, 0, '1-12', 'Rückseite: klare Luft, weite Sicht, Wind auf Nordwest', 'MITGELIEFERT');
MERGE INTO HB_WETTERLAGE t USING (SELECT 'Seenebel' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEAUFORT = 2, t.PHASE = 'NEBEL', t.WIND_MS = 2.5, t.RICHTUNG_GRAD = 200, t.BOEIGKEIT = 0.08, t.BEDECKUNG_ACHTEL = 1, t.HOHE_SCHICHT = 0.25, t.WOLKENART = 'CUMULUS', t.REGEN_MMH = 0, t.SICHT_KM = 14, t.NEBEL = 0.9, t.LUFTDRUCK_HPA = 1022, t.TEMPERATUR_C = 12, t.FEUCHTE_PROZ = 99, t.GEWITTER = 0, t.MONATE = '9-11', t.BESCHREIBUNG = 'Schwacher Wind, feuchte Luft über kühlerem Wasser, dichter Nebel über dem Noor' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEAUFORT, PHASE, WIND_MS, RICHTUNG_GRAD, BOEIGKEIT, BEDECKUNG_ACHTEL, HOHE_SCHICHT, WOLKENART, REGEN_MMH, SICHT_KM, NEBEL, LUFTDRUCK_HPA, TEMPERATUR_C, FEUCHTE_PROZ, GEWITTER, MONATE, BESCHREIBUNG, HERKUNFT)
  VALUES ('Seenebel', 2, 'NEBEL', 2.5, 200, 0.08, 1, 0.25, 'CUMULUS', 0, 14, 0.9, 1022, 12, 99, 0, '9-11', 'Schwacher Wind, feuchte Luft über kühlerem Wasser, dichter Nebel über dem Noor', 'MITGELIEFERT');
MERGE INTO HB_WETTERLAGE t USING (SELECT 'Windstille' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEAUFORT = 0, t.PHASE = 'KLAR', t.WIND_MS = 0.2, t.RICHTUNG_GRAD = 180, t.BOEIGKEIT = 0.05, t.BEDECKUNG_ACHTEL = 0, t.HOHE_SCHICHT = 0.1, t.WOLKENART = 'CUMULUS', t.REGEN_MMH = 0, t.SICHT_KM = 40, t.NEBEL = 0, t.LUFTDRUCK_HPA = 1032, t.TEMPERATUR_C = 15, t.FEUCHTE_PROZ = 70, t.GEWITTER = 0, t.MONATE = '1-12', t.BESCHREIBUNG = 'Das Noor spiegelglatt, wolkenlos, Hochdruck [G]' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEAUFORT, PHASE, WIND_MS, RICHTUNG_GRAD, BOEIGKEIT, BEDECKUNG_ACHTEL, HOHE_SCHICHT, WOLKENART, REGEN_MMH, SICHT_KM, NEBEL, LUFTDRUCK_HPA, TEMPERATUR_C, FEUCHTE_PROZ, GEWITTER, MONATE, BESCHREIBUNG, HERKUNFT)
  VALUES ('Windstille', 0, 'KLAR', 0.2, 180, 0.05, 0, 0.1, 'CUMULUS', 0, 40, 0, 1032, 15, 70, 0, '1-12', 'Das Noor spiegelglatt, wolkenlos, Hochdruck [G]', 'MITGELIEFERT');
MERGE INTO HB_WETTERLAGE t USING (SELECT 'Nebelmorgen im Herbst' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEAUFORT = 0, t.PHASE = 'NEBEL', t.WIND_MS = 0.6, t.RICHTUNG_GRAD = 160, t.BOEIGKEIT = 0.05, t.BEDECKUNG_ACHTEL = 0.5, t.HOHE_SCHICHT = NULL, t.WOLKENART = NULL, t.REGEN_MMH = 0, t.SICHT_KM = 10, t.NEBEL = 0.9, t.LUFTDRUCK_HPA = 1026, t.TEMPERATUR_C = 5, t.FEUCHTE_PROZ = 99, t.GEWITTER = 0, t.MONATE = '9-11', t.BESCHREIBUNG = 'Wie der erste Schritt von „Ein Nebelmorgen“: windstill, Nebel liegt flach über dem Noor [G]' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEAUFORT, PHASE, WIND_MS, RICHTUNG_GRAD, BOEIGKEIT, BEDECKUNG_ACHTEL, HOHE_SCHICHT, WOLKENART, REGEN_MMH, SICHT_KM, NEBEL, LUFTDRUCK_HPA, TEMPERATUR_C, FEUCHTE_PROZ, GEWITTER, MONATE, BESCHREIBUNG, HERKUNFT)
  VALUES ('Nebelmorgen im Herbst', 0, 'NEBEL', 0.6, 160, 0.05, 0.5, NULL, NULL, 0, 10, 0.9, 1026, 5, 99, 0, '9-11', 'Wie der erste Schritt von „Ein Nebelmorgen“: windstill, Nebel liegt flach über dem Noor [G]', 'MITGELIEFERT');
MERGE INTO HB_WETTERLAGE t USING (SELECT 'Ostwind 1050' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEAUFORT = 4, t.PHASE = 'KLAR', t.WIND_MS = 6.75, t.RICHTUNG_GRAD = 80, t.BOEIGKEIT = 0.14, t.BEDECKUNG_ACHTEL = 1, t.HOHE_SCHICHT = NULL, t.WOLKENART = NULL, t.REGEN_MMH = 0, t.SICHT_KM = NULL, t.NEBEL = 0, t.LUFTDRUCK_HPA = NULL, t.TEMPERATUR_C = NULL, t.FEUCHTE_PROZ = NULL, t.GEWITTER = 0, t.MONATE = '10', t.BESCHREIBUNG = 'Die Nacht von 1050: Ostwind Bft 4 über See, klar, trocken [G]' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEAUFORT, PHASE, WIND_MS, RICHTUNG_GRAD, BOEIGKEIT, BEDECKUNG_ACHTEL, HOHE_SCHICHT, WOLKENART, REGEN_MMH, SICHT_KM, NEBEL, LUFTDRUCK_HPA, TEMPERATUR_C, FEUCHTE_PROZ, GEWITTER, MONATE, BESCHREIBUNG, HERKUNFT)
  VALUES ('Ostwind 1050', 4, 'KLAR', 6.75, 80, 0.14, 1, NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, 0, '10', 'Die Nacht von 1050: Ostwind Bft 4 über See, klar, trocken [G]', 'MITGELIEFERT');
MERGE INTO HB_WETTERLAGE t USING (SELECT 'Schneetag' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BEAUFORT = 3, t.PHASE = 'FRONT', t.WIND_MS = 5, t.RICHTUNG_GRAD = 70, t.BOEIGKEIT = 0.12, t.BEDECKUNG_ACHTEL = 8, t.HOHE_SCHICHT = NULL, t.WOLKENART = 'STRATOCUMULUS', t.REGEN_MMH = 1.5, t.SICHT_KM = 3, t.NEBEL = 0, t.LUFTDRUCK_HPA = 1018, t.TEMPERATUR_C = -2, t.FEUCHTE_PROZ = 92, t.GEWITTER = 0, t.MONATE = '12-2', t.BESCHREIBUNG = 'Grauer Wintertag mit leichtem Schneefall aus Ost, um −2 °C [G]' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BEAUFORT, PHASE, WIND_MS, RICHTUNG_GRAD, BOEIGKEIT, BEDECKUNG_ACHTEL, HOHE_SCHICHT, WOLKENART, REGEN_MMH, SICHT_KM, NEBEL, LUFTDRUCK_HPA, TEMPERATUR_C, FEUCHTE_PROZ, GEWITTER, MONATE, BESCHREIBUNG, HERKUNFT)
  VALUES ('Schneetag', 3, 'FRONT', 5, 70, 0.12, 8, NULL, 'STRATOCUMULUS', 1.5, 3, 0, 1018, -2, 92, 0, '12-2', 'Grauer Wintertag mit leichtem Schneefall aus Ost, um −2 °C [G]', 'MITGELIEFERT');

-- ----------------------------------------------------------------------------------------- Regiebücher
MERGE INTO HB_REGIEBUCH t USING (SELECT 'Ein Handelstag' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = '16.10.950, 6 bis 20 Uhr im Zeitraffer 60: Herde, die Knorr kommt und geht, Markt, Fackeln, das Langfeuer', t.SZ_JAHR = 950, t.SZ_MONAT = 10, t.SZ_TAG = 16, t.SZ_STUNDE = 6, t.ZEITRAFFER = 60, t.LAENGE_S = 841, t.BLATT = 1, t.WETTER = 'Wetter: 06:00 | 60' || CHR(10) || 'Schritt: 3 | KLAR | Ein klarer Herbstmorgen | WIND=2.5 DIRECTION=240 COVER=1 FOG=0.05 TEMPERATURE=7 | Hafen' || CHR(10) || 'Schritt: 6 | KLAR | Ein Handelstag, Wolken ziehen | WIND=4 DIRECTION=250 COVER=3 TEMPERATURE=13 | Gasse' || CHR(10) || 'Schritt: 6 | KLAR | Abend über dem Noor | WIND=3 DIRECTION=245 COVER=2 TEMPERATURE=10 | Vom Wall' || CHR(10) || '' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BESCHREIBUNG, SZ_JAHR, SZ_MONAT, SZ_TAG, SZ_STUNDE, ZEITRAFFER, LAENGE_S, BLATT, WETTER, HERKUNFT)
  VALUES ('Ein Handelstag', '16.10.950, 6 bis 20 Uhr im Zeitraffer 60: Herde, die Knorr kommt und geht, Markt, Fackeln, das Langfeuer', 950, 10, 16, 6, 60, 841, 1, 'Wetter: 06:00 | 60' || CHR(10) || 'Schritt: 3 | KLAR | Ein klarer Herbstmorgen | WIND=2.5 DIRECTION=240 COVER=1 FOG=0.05 TEMPERATURE=7 | Hafen' || CHR(10) || 'Schritt: 6 | KLAR | Ein Handelstag, Wolken ziehen | WIND=4 DIRECTION=250 COVER=3 TEMPERATURE=13 | Gasse' || CHR(10) || 'Schritt: 6 | KLAR | Abend über dem Noor | WIND=3 DIRECTION=245 COVER=2 TEMPERATURE=10 | Vom Wall' || CHR(10) || '', 'MITGELIEFERT');
DELETE FROM HB_STICHWORT WHERE REGIEBUCH_ID IN (SELECT ID FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 1, 0, 'ZEIT', '16.10.950 06:00', '6 Uhr: Morgen am Noor' FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 2, 0, 'WETTER', NULL, NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 3, 0, 'RAFFER', '60', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 4, 0, 'ANSICHT', 'Vom Noor', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 5, 60, 'ANSICHT', 'Am Bach', '7 Uhr: die Herde brennen, Rauch über den Dächern' FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 6, 96, 'FOTO', 'Am Bach: Rauch der Morgenherde', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 7, 108, 'EINLAUFEN', NULL, '8 Uhr: die Knorr läuft ein' FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 8, 108, 'ANSICHT', 'Hafen', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 9, 180, 'FOTO', 'Hafen: die Knorr kommt herein', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 10, 270, 'ANSICHT', 'Gasse', '10:30: Markt am Umschlagplatz, Werkstätten' FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 11, 312, 'FOTO', 'Gasse: Markt und Werkstätten', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 12, 420, 'ANSICHT', 'Vom Wall', '13 Uhr: vom Wall über die Siedlung' FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 13, 456, 'FOTO', 'Vom Wall: Ziegen am Hang', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 14, 570, 'AUSLAUFEN', NULL, '15:30: die Knorr läuft aus' FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 15, 570, 'ANSICHT', 'Hafen', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 16, 636, 'FOTO', 'Hafen: die Knorr legt ab', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 17, 660, 'ANSICHT', 'Hochburg', '17 Uhr: Sonnenuntergang von der Hochburg' FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 18, 684, 'FOTO', 'Hochburg: Abend über dem Noor', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 19, 744, 'ANSICHT', 'Vom Wall', '18:30: Fackeln an Toren und Brücken' FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 20, 774, 'FOTO', 'Vom Wall: Fackeln und Rauch am Abend', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 21, 792, 'ANSICHT', 'Im Haus', '19 Uhr: im Versammlungshaus' FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 22, 822, 'FOTO', 'Im Haus: das Langfeuer', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 23, 840, 'BLATT', 'Ein Handelstag', '20 Uhr: Ende des Tages' FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 24, 840, 'RAFFER', '1', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 25, 840, 'SAGE', 'Ein Handelstag ist zu Ende', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Handelstag' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_REGIEBUCH t USING (SELECT 'Ein Nebelmorgen' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = '16.10.950, 5 bis 10 Uhr im Zeitraffer 60: Nebel über dem Noor, die Hochburg ragt heraus, die Knorr kommt aus dem Dunst', t.SZ_JAHR = 950, t.SZ_MONAT = 10, t.SZ_TAG = 16, t.SZ_STUNDE = 5, t.ZEITRAFFER = 60, t.LAENGE_S = 301, t.BLATT = 1, t.WETTER = 'Wetter: 05:00 | 60' || CHR(10) || 'Schritt: 1.5 | NEBEL | Nebel vor Tag, windstill | WIND=0.6 DIRECTION=160 GUST=0.05 COVER=0.5 VISIBILITY=10 FOG=0.9 PRESSURE=1026 TEMPERATURE=5 HUMIDITY=99 | Hochburg' || CHR(10) || 'Schritt: 1.25 | NEBEL | Sonnenaufgang im Nebel | WIND=0.8 FOG=0.85 TEMPERATURE=5.5 HUMIDITY=99 | Hochburg' || CHR(10) || 'Schritt: 1.5 | NEBEL | Der Nebel steigt | WIND=1.4 FOG=0.6 TEMPERATURE=8 HUMIDITY=96 | Hochburg' || CHR(10) || 'Schritt: 1.25 | KLAR | Nebelfetzen über dem Wasser | WIND=2.2 COVER=1 FOG=0.22 TEMPERATURE=10 HUMIDITY=88 | Vom Noor' || CHR(10) || 'Schritt: 4.5 | KLAR | Ein klarer Herbsttag | WIND=3 COVER=2 VISIBILITY=30 FOG=0 TEMPERATURE=13 HUMIDITY=75 | Vom Noor' || CHR(10) || '' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BESCHREIBUNG, SZ_JAHR, SZ_MONAT, SZ_TAG, SZ_STUNDE, ZEITRAFFER, LAENGE_S, BLATT, WETTER, HERKUNFT)
  VALUES ('Ein Nebelmorgen', '16.10.950, 5 bis 10 Uhr im Zeitraffer 60: Nebel über dem Noor, die Hochburg ragt heraus, die Knorr kommt aus dem Dunst', 950, 10, 16, 5, 60, 301, 1, 'Wetter: 05:00 | 60' || CHR(10) || 'Schritt: 1.5 | NEBEL | Nebel vor Tag, windstill | WIND=0.6 DIRECTION=160 GUST=0.05 COVER=0.5 VISIBILITY=10 FOG=0.9 PRESSURE=1026 TEMPERATURE=5 HUMIDITY=99 | Hochburg' || CHR(10) || 'Schritt: 1.25 | NEBEL | Sonnenaufgang im Nebel | WIND=0.8 FOG=0.85 TEMPERATURE=5.5 HUMIDITY=99 | Hochburg' || CHR(10) || 'Schritt: 1.5 | NEBEL | Der Nebel steigt | WIND=1.4 FOG=0.6 TEMPERATURE=8 HUMIDITY=96 | Hochburg' || CHR(10) || 'Schritt: 1.25 | KLAR | Nebelfetzen über dem Wasser | WIND=2.2 COVER=1 FOG=0.22 TEMPERATURE=10 HUMIDITY=88 | Vom Noor' || CHR(10) || 'Schritt: 4.5 | KLAR | Ein klarer Herbsttag | WIND=3 COVER=2 VISIBILITY=30 FOG=0 TEMPERATURE=13 HUMIDITY=75 | Vom Noor' || CHR(10) || '', 'MITGELIEFERT');
DELETE FROM HB_STICHWORT WHERE REGIEBUCH_ID IN (SELECT ID FROM HB_REGIEBUCH WHERE NAME = 'Ein Nebelmorgen' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 1, 0, 'ZEIT', '16.10.950 05:00', '5 Uhr: Nebel vor Tag' FROM HB_REGIEBUCH WHERE NAME = 'Ein Nebelmorgen' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 2, 0, 'WETTER', NULL, NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Nebelmorgen' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 3, 0, 'RAFFER', '60', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Nebelmorgen' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 4, 0, 'ANSICHT', 'Hochburg', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Nebelmorgen' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 5, 108, 'FOTO', 'Hochburg: Sonnenaufgang im Nebel', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Nebelmorgen' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 6, 120, 'ANSICHT', 'Vom Noor', '7 Uhr: über dem Noor' FROM HB_REGIEBUCH WHERE NAME = 'Ein Nebelmorgen' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 7, 156, 'FOTO', 'Vom Noor: der Nebel steigt', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Nebelmorgen' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 8, 168, 'EINLAUFEN', NULL, '7:50: die Knorr kommt aus dem Dunst' FROM HB_REGIEBUCH WHERE NAME = 'Ein Nebelmorgen' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 9, 168, 'ANSICHT', 'Hafen', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Nebelmorgen' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 10, 216, 'FOTO', 'Hafen: Nebelfetzen, die Knorr', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Nebelmorgen' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 11, 240, 'ANSICHT', 'Am Bach', '9 Uhr: Am Bach' FROM HB_REGIEBUCH WHERE NAME = 'Ein Nebelmorgen' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 12, 276, 'FOTO', 'Am Bach: ein klarer Herbsttag', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Nebelmorgen' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 13, 300, 'BLATT', 'Ein Nebelmorgen', '10 Uhr: der Nebel ist fort' FROM HB_REGIEBUCH WHERE NAME = 'Ein Nebelmorgen' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 14, 300, 'RAFFER', '1', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Nebelmorgen' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 15, 300, 'SAGE', 'Ein Nebelmorgen ist zu Ende', NULL FROM HB_REGIEBUCH WHERE NAME = 'Ein Nebelmorgen' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_REGIEBUCH t USING (SELECT 'Die Nacht von 1050' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = '16.10.1050, ab 1:30 Uhr: ein Brander treibt in den Hafen, das Feuer springt auf die Uferhäuser und mit dem Ostwind in die Siedlung', t.SZ_JAHR = 1050, t.SZ_MONAT = 10, t.SZ_TAG = 16, t.SZ_STUNDE = 1.5, t.ZEITRAFFER = 1, t.LAENGE_S = 356, t.BLATT = 1, t.WETTER = NULL WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, BESCHREIBUNG, SZ_JAHR, SZ_MONAT, SZ_TAG, SZ_STUNDE, ZEITRAFFER, LAENGE_S, BLATT, WETTER, HERKUNFT)
  VALUES ('Die Nacht von 1050', '16.10.1050, ab 1:30 Uhr: ein Brander treibt in den Hafen, das Feuer springt auf die Uferhäuser und mit dem Ostwind in die Siedlung', 1050, 10, 16, 1.5, 1, 356, 1, NULL, 'MITGELIEFERT');
DELETE FROM HB_STICHWORT WHERE REGIEBUCH_ID IN (SELECT ID FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 1, 0, 'ZEIT', '16.10.1050 01:30', '1:30 Uhr: Ostwind über dem Noor' FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 2, 0, 'WETTER_FREI', 'KLAR 4 80', NULL FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 3, 0, 'RAFFER', '1', NULL FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 4, 0, 'ANSICHT', 'Hafen', NULL FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 5, 4, 'BRANDER', NULL, 'Draußen vor der Palisade: ein Langschiff, es brennt' FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 6, 30, 'FOTO', 'Hafen: der Brander vor der Palisade', NULL FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 7, 75, 'SAGE', 'Der Brander treibt in den Hafen', 'Die Mannschaft verlässt ihn in der Durchfahrt' FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 8, 115, 'FOTO', 'Hafen: der Brander treibt auf die Brücken', NULL FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 9, 140, 'ZUENDEN', NULL, 'Das Feuer springt auf das Ufer' FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 10, 170, 'ANSICHT', 'Am Bach', 'Am Bach' FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 11, 200, 'FOTO', 'Am Bach: die Häuser am Ufer brennen', NULL FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 12, 230, 'ANSICHT', 'Vom Wall', 'Vom Wall: der Wind treibt das Feuer nach Westen' FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 13, 270, 'FOTO', 'Vom Wall: der Brand frisst sich in die Siedlung', NULL FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 14, 300, 'ANSICHT', 'Hochburg', 'Von der Hochburg' FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 15, 340, 'FOTO', 'Hochburg: Haithabu brennt', NULL FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 16, 355, 'BLATT', 'Die Nacht von 1050', 'Ende' FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STICHWORT (REGIEBUCH_ID, NR, SEKUNDE, BEFEHL, ARGUMENTE, TEXT) SELECT ID, 17, 355, 'SAGE', 'Die Nacht von 1050 ist zu Ende; das Feuer brennt weiter', NULL FROM HB_REGIEBUCH WHERE NAME = 'Die Nacht von 1050' AND HERKUNFT = 'MITGELIEFERT';

-- ------------------------------------------------------------------------------ Ansichten (Tasten 1–7)
MERGE INTO HB_ANSICHT t USING (SELECT 'Vom Noor' AS NAME FROM DUAL) q ON (t.NAME = q.NAME AND t.ART = 'FEST')
WHEN MATCHED THEN UPDATE SET t.TASTE = 1, t.KAM_X = 0, t.KAM_Z = 0, t.KAM_GIER_GRAD = 268, t.KAM_NICK_GRAD = 7, t.AUGE_UEBER_GRUND_M = 0, t.ORBIT = 1, t.ABSTAND_M = 420 WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, TASTE, ART, KAM_X, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, AUGE_UEBER_GRUND_M, ORBIT, ABSTAND_M, HERKUNFT)
  VALUES ('Vom Noor', 1, 'FEST', 0, 0, 268, 7, 0, 1, 420, 'MITGELIEFERT');
MERGE INTO HB_ANSICHT t USING (SELECT 'Hafen' AS NAME FROM DUAL) q ON (t.NAME = q.NAME AND t.ART = 'FEST')
WHEN MATCHED THEN UPDATE SET t.TASTE = 2, t.KAM_X = 6, t.KAM_Z = -80.5, t.KAM_GIER_GRAD = 65, t.KAM_NICK_GRAD = 4, t.AUGE_UEBER_GRUND_M = 2.6, t.ORBIT = 0, t.ABSTAND_M = NULL WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, TASTE, ART, KAM_X, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, AUGE_UEBER_GRUND_M, ORBIT, ABSTAND_M, HERKUNFT)
  VALUES ('Hafen', 2, 'FEST', 6, -80.5, 65, 4, 2.6, 0, NULL, 'MITGELIEFERT');
MERGE INTO HB_ANSICHT t USING (SELECT 'Am Bach' AS NAME FROM DUAL) q ON (t.NAME = q.NAME AND t.ART = 'FEST')
WHEN MATCHED THEN UPDATE SET t.TASTE = 3, t.KAM_X = -166, t.KAM_Z = -16, t.KAM_GIER_GRAD = 92, t.KAM_NICK_GRAD = 3, t.AUGE_UEBER_GRUND_M = 1.7, t.ORBIT = 0, t.ABSTAND_M = NULL WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, TASTE, ART, KAM_X, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, AUGE_UEBER_GRUND_M, ORBIT, ABSTAND_M, HERKUNFT)
  VALUES ('Am Bach', 3, 'FEST', -166, -16, 92, 3, 1.7, 0, NULL, 'MITGELIEFERT');
MERGE INTO HB_ANSICHT t USING (SELECT 'Vom Wall' AS NAME FROM DUAL) q ON (t.NAME = q.NAME AND t.ART = 'FEST')
WHEN MATCHED THEN UPDATE SET t.TASTE = 4, t.KAM_X = -560.5, t.KAM_Z = -102.8, t.KAM_GIER_GRAD = 95, t.KAM_NICK_GRAD = 4, t.AUGE_UEBER_GRUND_M = 2.7, t.ORBIT = 0, t.ABSTAND_M = NULL WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, TASTE, ART, KAM_X, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, AUGE_UEBER_GRUND_M, ORBIT, ABSTAND_M, HERKUNFT)
  VALUES ('Vom Wall', 4, 'FEST', -560.5, -102.8, 95, 4, 2.7, 0, NULL, 'MITGELIEFERT');
MERGE INTO HB_ANSICHT t USING (SELECT 'Hochburg' AS NAME FROM DUAL) q ON (t.NAME = q.NAME AND t.ART = 'FEST')
WHEN MATCHED THEN UPDATE SET t.TASTE = 5, t.KAM_X = -200, t.KAM_Z = -700, t.KAM_GIER_GRAD = 160, t.KAM_NICK_GRAD = 4, t.AUGE_UEBER_GRUND_M = 1.7, t.ORBIT = 0, t.ABSTAND_M = NULL WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, TASTE, ART, KAM_X, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, AUGE_UEBER_GRUND_M, ORBIT, ABSTAND_M, HERKUNFT)
  VALUES ('Hochburg', 5, 'FEST', -200, -700, 160, 4, 1.7, 0, NULL, 'MITGELIEFERT');
MERGE INTO HB_ANSICHT t USING (SELECT 'Gegenufer' AS NAME FROM DUAL) q ON (t.NAME = q.NAME AND t.ART = 'FEST')
WHEN MATCHED THEN UPDATE SET t.TASTE = 6, t.KAM_X = 700, t.KAM_Z = 60, t.KAM_GIER_GRAD = 272, t.KAM_NICK_GRAD = 5, t.AUGE_UEBER_GRUND_M = 1.7, t.ORBIT = 0, t.ABSTAND_M = NULL WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, TASTE, ART, KAM_X, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, AUGE_UEBER_GRUND_M, ORBIT, ABSTAND_M, HERKUNFT)
  VALUES ('Gegenufer', 6, 'FEST', 700, 60, 272, 5, 1.7, 0, NULL, 'MITGELIEFERT');
MERGE INTO HB_ANSICHT t USING (SELECT 'Im Haus' AS NAME FROM DUAL) q ON (t.NAME = q.NAME AND t.ART = 'FEST')
WHEN MATCHED THEN UPDATE SET t.TASTE = 7, t.KAM_X = 0, t.KAM_Z = 0, t.KAM_GIER_GRAD = 0, t.KAM_NICK_GRAD = 0, t.AUGE_UEBER_GRUND_M = 0, t.ORBIT = 0, t.ABSTAND_M = NULL WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, TASTE, ART, KAM_X, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, AUGE_UEBER_GRUND_M, ORBIT, ABSTAND_M, HERKUNFT)
  VALUES ('Im Haus', 7, 'FEST', 0, 0, 0, 0, 0, 0, NULL, 'MITGELIEFERT');

-- --------------------------------------------------------------------------------------- Kamerafahrten
MERGE INTO HB_FAHRT t USING (SELECT 'Über den Wall' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.TASTE = 8, t.ART = 'WALLKAMM', t.SCHLEIFE = 0, t.BESCHREIBUNG = 'Auf dem Wehrgang vom Südende am Noor bis zum Nordende; die App folgt dem Kamm aus dem Gelände' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, TASTE, ART, SCHLEIFE, BESCHREIBUNG, HERKUNFT) VALUES ('Über den Wall', 8, 'WALLKAMM', 0, 'Auf dem Wehrgang vom Südende am Noor bis zum Nordende; die App folgt dem Kamm aus dem Gelände', 'MITGELIEFERT');
DELETE FROM HB_STUETZPUNKT WHERE FAHRT_ID IN (SELECT ID FROM HB_FAHRT WHERE NAME = 'Über den Wall' AND HERKUNFT = 'MITGELIEFERT');
MERGE INTO HB_FAHRT t USING (SELECT 'Mitfahrt' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.TASTE = 9, t.ART = 'MITFAHRT', t.SCHLEIFE = 0, t.BESCHREIBUNG = 'Am Steuer der einlaufenden Knorr: unter Segel heran, durch die Palisade, an den Querkopf' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, TASTE, ART, SCHLEIFE, BESCHREIBUNG, HERKUNFT) VALUES ('Mitfahrt', 9, 'MITFAHRT', 0, 'Am Steuer der einlaufenden Knorr: unter Segel heran, durch die Palisade, an den Querkopf', 'MITGELIEFERT');
DELETE FROM HB_STUETZPUNKT WHERE FAHRT_ID IN (SELECT ID FROM HB_FAHRT WHERE NAME = 'Mitfahrt' AND HERKUNFT = 'MITGELIEFERT');
MERGE INTO HB_FAHRT t USING (SELECT 'Durch die Gasse' AS NAME FROM DUAL) q ON (t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.TASTE = 0, t.ART = 'STUETZPUNKTE', t.SCHLEIFE = 0, t.BESCHREIBUNG = 'Auf dem Bohlenweg am Bach, durch den Hof und die Osttür ins Versammlungshaus; die App rechnet sie aus der aktiven Siedlung' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (NAME, TASTE, ART, SCHLEIFE, BESCHREIBUNG, HERKUNFT) VALUES ('Durch die Gasse', 0, 'STUETZPUNKTE', 0, 'Auf dem Bohlenweg am Bach, durch den Hof und die Osttür ins Versammlungshaus; die App rechnet sie aus der aktiven Siedlung', 'MITGELIEFERT');
DELETE FROM HB_STUETZPUNKT WHERE FAHRT_ID IN (SELECT ID FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 1, 0, -172, 6.35, -17.38, 106.36, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 2, 5.14, -166, 6.34, -17.14, 111.11, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 3, 10.62, -160, 6.13, -14.94, 115.57, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 4, 16.74, -154, 5.89, -11.04, 118.12, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 5, 22.97, -148, 5.25, -6.93, 111.63, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 6, 28.64, -142, 5.17, -4.14, 101.16, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 7, 33.86, -136, 5.09, -3.04, 91.4, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 8, 39.01, -130, 4.89, -3.29, 84.56, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 9, 44.23, -124, 4.7, -4.37, 72.13, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 10, 49.48, -118, 4.66, -5.62, 49.04, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 11, 54.88, -111.77, 4.6, -6.6, 19.38, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 12, 56.81, -111.93, 4.74, -8.85, 4.42, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 13, 58.77, -112.34, 4.84, -11.1, 351.39, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 14, 60.75, -112.87, 4.91, -13.35, 334.23, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 15, 62.73, -113.4, 4.92, -15.61, 320.23, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 16, 64.69, -113.81, 4.98, -17.86, 311.25, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 17, 66.63, -113.97, 5.02, -20.11, 301.21, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 18, 68, -115.57, 4.9, -20.11, 292.14, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 19, 69.11, -116.87, 4.9, -20.11, 283.12, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 20, 70.14, -118.07, 4.9, -20.11, 274.12, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 21, 71.13, -118.65, 4.9, -19.11, 278.86, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 22, 71.6, -118.8, 4.9, -18.57, 287.08, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 23, 73.08, -119.05, 4.9, -16.87, 328.21, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_STUETZPUNKT (FAHRT_ID, NR, ZEIT_S, KAM_X, KAM_Y, KAM_Z, KAM_GIER_GRAD, KAM_NICK_GRAD, KAM_FOV_GRAD) SELECT ID, 24, 75, -119.4, 4.9, -14.65, 8, 3, NULL FROM HB_FAHRT WHERE NAME = 'Durch die Gasse' AND HERKUNFT = 'MITGELIEFERT';

-- -------------------------------------------------------------------------------- Presets der Packages
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.ocean' AS PAKET, 'Ocean' AS KLASSE, 'breeze' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset breeze() aus com.dan.ocean' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.ocean', 'Ocean', 'breeze', 'Preset breeze() aus com.dan.ocean', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '6.7' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fetch', 'DOUBLE', '150000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'depth', 'DOUBLE', '10000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'choppiness', 'DOUBLE', '0.85' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'heightOverride', 'DOUBLE', 'NaN' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fetchLimited', 'BOOLEAN', 'false' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'swellHeight', 'DOUBLE', '0.48' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'swellPeriod', 'DOUBLE', '9.4' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'swellFromDeg', 'DOUBLE', '290' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'foamDecay', 'DOUBLE', '2.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'foamAmount', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'ringHsLow', 'DOUBLE', '0.15' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'ringHsHigh', 'DOUBLE', '1.6' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.ocean' AS PAKET, 'Ocean' AS KLASSE, 'calm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset calm() aus com.dan.ocean' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.ocean', 'Ocean', 'calm', 'Preset calm() aus com.dan.ocean', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '0.9' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fetch', 'DOUBLE', '150000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'depth', 'DOUBLE', '10000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'choppiness', 'DOUBLE', '0.85' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'heightOverride', 'DOUBLE', 'NaN' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fetchLimited', 'BOOLEAN', 'false' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'swellHeight', 'DOUBLE', '0.318' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'swellPeriod', 'DOUBLE', '8.35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'swellFromDeg', 'DOUBLE', '290' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'foamDecay', 'DOUBLE', '2.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'foamAmount', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'ringHsLow', 'DOUBLE', '0.15' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'ringHsHigh', 'DOUBLE', '1.6' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.ocean' AS PAKET, 'Ocean' AS KLASSE, 'gale' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset gale() aus com.dan.ocean' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.ocean', 'Ocean', 'gale', 'Preset gale() aus com.dan.ocean', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '19' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fetch', 'DOUBLE', '150000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'depth', 'DOUBLE', '10000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'choppiness', 'DOUBLE', '0.85' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'heightOverride', 'DOUBLE', 'NaN' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fetchLimited', 'BOOLEAN', 'false' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'swellHeight', 'DOUBLE', '1.29' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'swellPeriod', 'DOUBLE', '10.8' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'swellFromDeg', 'DOUBLE', '290' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'foamDecay', 'DOUBLE', '2.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'foamAmount', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'ringHsLow', 'DOUBLE', '0.15' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'ringHsHigh', 'DOUBLE', '1.6' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.ocean' AS PAKET, 'Ocean' AS KLASSE, 'storm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset storm() aus com.dan.ocean' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.ocean', 'Ocean', 'storm', 'Preset storm() aus com.dan.ocean', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '26.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fetch', 'DOUBLE', '150000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'depth', 'DOUBLE', '10000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'choppiness', 'DOUBLE', '0.85' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'heightOverride', 'DOUBLE', 'NaN' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fetchLimited', 'BOOLEAN', 'false' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'swellHeight', 'DOUBLE', '1.92' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'swellPeriod', 'DOUBLE', '11.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'swellFromDeg', 'DOUBLE', '290' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'foamDecay', 'DOUBLE', '2.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'foamAmount', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'ringHsLow', 'DOUBLE', '0.15' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'ringHsHigh', 'DOUBLE', '1.6' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.ocean' AND KLASSE = 'Ocean' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.reed' AS PAKET, 'Reed' AS KLASSE, 'breeze' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset breeze() aus com.dan.reed' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.reed', 'Reed', 'breeze', 'Preset breeze() aus com.dan.reed', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '4.4' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '245' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'gust', 'DOUBLE', '0.3' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'season', 'DOUBLE', '0.75' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'wetness', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'snowDepth', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'frost', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'density', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.reed' AS PAKET, 'Reed' AS KLASSE, 'calm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset calm() aus com.dan.reed' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.reed', 'Reed', 'calm', 'Preset calm() aus com.dan.reed', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '0.9' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '245' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'gust', 'DOUBLE', '0.2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'season', 'DOUBLE', '0.75' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'wetness', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'snowDepth', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'frost', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'density', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.reed' AS PAKET, 'Reed' AS KLASSE, 'fresh' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset fresh() aus com.dan.reed' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.reed', 'Reed', 'fresh', 'Preset fresh() aus com.dan.reed', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'fresh' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'fresh' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '9.4' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'fresh' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '245' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'fresh' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'gust', 'DOUBLE', '0.4' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'fresh' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'season', 'DOUBLE', '0.75' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'fresh' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'wetness', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'fresh' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'snowDepth', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'fresh' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'frost', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'fresh' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'density', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'fresh' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'fresh' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.reed' AS PAKET, 'Reed' AS KLASSE, 'gale' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset gale() aus com.dan.reed' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.reed', 'Reed', 'gale', 'Preset gale() aus com.dan.reed', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '19' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '245' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'gust', 'DOUBLE', '0.55' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'season', 'DOUBLE', '0.75' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'wetness', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'snowDepth', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'frost', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'density', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.reed' AND KLASSE = 'Reed' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.cloud' AS PAKET, 'Clouds' AS KLASSE, 'fair' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset fair() aus com.dan.cloud' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.cloud', 'Clouds', 'fair', 'Preset fair() aus com.dan.cloud', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'fair' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'oktas', 'DOUBLE', '3' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'fair' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'type', 'ENUM', 'CUMULUS' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'fair' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'highCover', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'fair' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'precipitation', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'fair' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '10' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'fair' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '250' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'fair' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'evolve', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'fair' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'fair' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'maxDistance', 'DOUBLE', '60000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'fair' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.cloud' AS PAKET, 'Clouds' AS KLASSE, 'overcast' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset overcast() aus com.dan.cloud' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.cloud', 'Clouds', 'overcast', 'Preset overcast() aus com.dan.cloud', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'overcast' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'oktas', 'DOUBLE', '8' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'overcast' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'type', 'ENUM', 'STRATOCUMULUS' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'overcast' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'highCover', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'overcast' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'precipitation', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'overcast' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '10' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'overcast' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '250' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'overcast' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'evolve', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'overcast' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'overcast' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'maxDistance', 'DOUBLE', '60000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'overcast' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.cloud' AS PAKET, 'Clouds' AS KLASSE, 'storm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset storm() aus com.dan.cloud' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.cloud', 'Clouds', 'storm', 'Preset storm() aus com.dan.cloud', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'oktas', 'DOUBLE', '6' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'type', 'ENUM', 'CUMULONIMBUS' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'highCover', 'DOUBLE', '0.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'precipitation', 'DOUBLE', '0.8' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '22' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '250' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'evolve', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'maxDistance', 'DOUBLE', '60000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.cloud' AND KLASSE = 'Clouds' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.rain' AS PAKET, 'Rain' AS KLASSE, 'breeze' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset breeze() aus com.dan.rain' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.rain', 'Rain', 'breeze', 'Preset breeze() aus com.dan.rain', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rate', 'DOUBLE', '2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '9.3' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'gust', 'DOUBLE', '0.25' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cloudBase', 'DOUBLE', '800' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'MEDIUM' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1885' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeY', 'DOUBLE', '10' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.rain' AS PAKET, 'Rain' AS KLASSE, 'calm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset calm() aus com.dan.rain' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.rain', 'Rain', 'calm', 'Preset calm() aus com.dan.rain', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rate', 'DOUBLE', '0.3' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '0.9' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'gust', 'DOUBLE', '0.13' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cloudBase', 'DOUBLE', '800' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'MEDIUM' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1885' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeY', 'DOUBLE', '10' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.rain' AS PAKET, 'Rain' AS KLASSE, 'cloudburst' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset cloudburst() aus com.dan.rain' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.rain', 'Rain', 'cloudburst', 'Preset cloudburst() aus com.dan.rain', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'cloudburst' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rate', 'DOUBLE', '60' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'cloudburst' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '7' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'cloudburst' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'cloudburst' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'gust', 'DOUBLE', '0.2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'cloudburst' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cloudBase', 'DOUBLE', '800' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'cloudburst' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'cloudburst' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'MEDIUM' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'cloudburst' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1885' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'cloudburst' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'cloudburst' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeY', 'DOUBLE', '10' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'cloudburst' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'cloudburst' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.rain' AS PAKET, 'Rain' AS KLASSE, 'drizzle' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset drizzle() aus com.dan.rain' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.rain', 'Rain', 'drizzle', 'Preset drizzle() aus com.dan.rain', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'drizzle' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rate', 'DOUBLE', '0.3' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'drizzle' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '7' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'drizzle' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'drizzle' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'gust', 'DOUBLE', '0.2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'drizzle' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cloudBase', 'DOUBLE', '800' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'drizzle' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'drizzle' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'MEDIUM' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'drizzle' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1885' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'drizzle' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'drizzle' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeY', 'DOUBLE', '10' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'drizzle' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'drizzle' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.rain' AS PAKET, 'Rain' AS KLASSE, 'gale' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset gale() aus com.dan.rain' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.rain', 'Rain', 'gale', 'Preset gale() aus com.dan.rain', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rate', 'DOUBLE', '8' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '18.9' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'gust', 'DOUBLE', '0.34' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cloudBase', 'DOUBLE', '800' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'MEDIUM' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1885' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeY', 'DOUBLE', '10' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.rain' AS PAKET, 'Rain' AS KLASSE, 'heavy' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset heavy() aus com.dan.rain' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.rain', 'Rain', 'heavy', 'Preset heavy() aus com.dan.rain', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'heavy' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rate', 'DOUBLE', '15' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'heavy' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '7' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'heavy' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'heavy' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'gust', 'DOUBLE', '0.2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'heavy' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cloudBase', 'DOUBLE', '800' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'heavy' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'heavy' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'MEDIUM' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'heavy' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1885' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'heavy' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'heavy' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeY', 'DOUBLE', '10' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'heavy' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'heavy' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.rain' AS PAKET, 'Rain' AS KLASSE, 'light' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset light() aus com.dan.rain' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.rain', 'Rain', 'light', 'Preset light() aus com.dan.rain', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'light' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rate', 'DOUBLE', '1.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'light' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '7' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'light' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'light' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'gust', 'DOUBLE', '0.2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'light' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cloudBase', 'DOUBLE', '800' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'light' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'light' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'MEDIUM' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'light' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1885' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'light' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'light' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeY', 'DOUBLE', '10' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'light' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'light' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.rain' AS PAKET, 'Rain' AS KLASSE, 'moderate' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset moderate() aus com.dan.rain' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.rain', 'Rain', 'moderate', 'Preset moderate() aus com.dan.rain', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'moderate' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rate', 'DOUBLE', '5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'moderate' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '7' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'moderate' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'moderate' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'gust', 'DOUBLE', '0.2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'moderate' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cloudBase', 'DOUBLE', '800' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'moderate' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'moderate' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'MEDIUM' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'moderate' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1885' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'moderate' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'moderate' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeY', 'DOUBLE', '10' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'moderate' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'moderate' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.rain' AS PAKET, 'Rain' AS KLASSE, 'storm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset storm() aus com.dan.rain' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.rain', 'Rain', 'storm', 'Preset storm() aus com.dan.rain', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rate', 'DOUBLE', '20' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '26.4' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'gust', 'DOUBLE', '0.4' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cloudBase', 'DOUBLE', '800' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'MEDIUM' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1885' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeY', 'DOUBLE', '10' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'eyeZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.rain' AND KLASSE = 'Rain' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.fog' AS PAKET, 'Fog' AS KLASSE, 'banks' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset banks() aus com.dan.fog' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.fog', 'Fog', 'banks', 'Preset banks() aus com.dan.fog', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'banks' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'banks' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'amount', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'banks' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'visibilityM', 'DOUBLE', '250' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'banks' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'coverage', 'DOUBLE', '0.45' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'banks' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'top', 'DOUBLE', '55' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'banks' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'base', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'banks' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'softness', 'DOUBLE', '0.35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'banks' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'bankSize', 'DOUBLE', '1800' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'banks' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'wisps', 'DOUBLE', '0.35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'banks' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '3' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'banks' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'banks' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'banks' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'banks' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'signalBelowM', 'DOUBLE', '3704' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'banks' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'hazeVisibilityM', 'DOUBLE', '30000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'banks' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.fog' AS PAKET, 'Fog' AS KLASSE, 'breeze' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset breeze() aus com.dan.fog' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.fog', 'Fog', 'breeze', 'Preset breeze() aus com.dan.fog', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'amount', 'DOUBLE', '0.55' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'visibilityM', 'DOUBLE', '200' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'coverage', 'DOUBLE', '0.4' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'top', 'DOUBLE', '35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'base', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'softness', 'DOUBLE', '0.35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'bankSize', 'DOUBLE', '1800' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'wisps', 'DOUBLE', '0.35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '6.7' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'signalBelowM', 'DOUBLE', '3704' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'hazeVisibilityM', 'DOUBLE', '30000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.fog' AS PAKET, 'Fog' AS KLASSE, 'calm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset calm() aus com.dan.fog' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.fog', 'Fog', 'calm', 'Preset calm() aus com.dan.fog', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'amount', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'visibilityM', 'DOUBLE', '200' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'coverage', 'DOUBLE', '0.7' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'top', 'DOUBLE', '50' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'base', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'softness', 'DOUBLE', '0.35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'bankSize', 'DOUBLE', '1800' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'wisps', 'DOUBLE', '0.35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '0.9' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'signalBelowM', 'DOUBLE', '3704' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'hazeVisibilityM', 'DOUBLE', '30000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.fog' AS PAKET, 'Fog' AS KLASSE, 'dense' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset dense() aus com.dan.fog' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.fog', 'Fog', 'dense', 'Preset dense() aus com.dan.fog', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'dense' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'dense' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'amount', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'dense' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'visibilityM', 'DOUBLE', '70' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'dense' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'coverage', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'dense' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'top', 'DOUBLE', '90' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'dense' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'base', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'dense' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'softness', 'DOUBLE', '0.35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'dense' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'bankSize', 'DOUBLE', '1800' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'dense' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'wisps', 'DOUBLE', '0.35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'dense' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'dense' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'dense' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'dense' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'dense' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'signalBelowM', 'DOUBLE', '3704' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'dense' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'hazeVisibilityM', 'DOUBLE', '30000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'dense' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.fog' AS PAKET, 'Fog' AS KLASSE, 'gale' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset gale() aus com.dan.fog' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.fog', 'Fog', 'gale', 'Preset gale() aus com.dan.fog', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'amount', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'visibilityM', 'DOUBLE', '200' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'coverage', 'DOUBLE', '0.4' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'top', 'DOUBLE', '35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'base', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'softness', 'DOUBLE', '0.35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'bankSize', 'DOUBLE', '1800' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'wisps', 'DOUBLE', '0.35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '19' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'signalBelowM', 'DOUBLE', '3704' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'hazeVisibilityM', 'DOUBLE', '30000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.fog' AS PAKET, 'Fog' AS KLASSE, 'haze' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset haze() aus com.dan.fog' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.fog', 'Fog', 'haze', 'Preset haze() aus com.dan.fog', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'haze' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'haze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'amount', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'haze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'visibilityM', 'DOUBLE', '3000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'haze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'coverage', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'haze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'top', 'DOUBLE', '160' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'haze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'base', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'haze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'softness', 'DOUBLE', '0.35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'haze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'bankSize', 'DOUBLE', '1800' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'haze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'wisps', 'DOUBLE', '0.15' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'haze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '3' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'haze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'haze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'haze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'haze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'signalBelowM', 'DOUBLE', '3704' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'haze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'hazeVisibilityM', 'DOUBLE', '30000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'haze' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.fog' AS PAKET, 'Fog' AS KLASSE, 'shallow' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset shallow() aus com.dan.fog' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.fog', 'Fog', 'shallow', 'Preset shallow() aus com.dan.fog', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'shallow' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'shallow' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'amount', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'shallow' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'visibilityM', 'DOUBLE', '120' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'shallow' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'coverage', 'DOUBLE', '0.9' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'shallow' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'top', 'DOUBLE', '18' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'shallow' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'base', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'shallow' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'softness', 'DOUBLE', '0.3' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'shallow' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'bankSize', 'DOUBLE', '1800' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'shallow' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'wisps', 'DOUBLE', '0.35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'shallow' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '3' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'shallow' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'shallow' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'shallow' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'shallow' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'signalBelowM', 'DOUBLE', '3704' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'shallow' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'hazeVisibilityM', 'DOUBLE', '30000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'shallow' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.fog' AS PAKET, 'Fog' AS KLASSE, 'storm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset storm() aus com.dan.fog' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.fog', 'Fog', 'storm', 'Preset storm() aus com.dan.fog', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'amount', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'visibilityM', 'DOUBLE', '200' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'coverage', 'DOUBLE', '0.4' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'top', 'DOUBLE', '35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'base', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'softness', 'DOUBLE', '0.35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'bankSize', 'DOUBLE', '1800' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'wisps', 'DOUBLE', '0.35' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '26.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'signalBelowM', 'DOUBLE', '3704' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'hazeVisibilityM', 'DOUBLE', '30000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.fog' AND KLASSE = 'Fog' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.lightning' AS PAKET, 'Lightning' AS KLASSE, 'breeze' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset breeze() aus com.dan.lightning' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.lightning', 'Lightning', 'breeze', 'Preset breeze() aus com.dan.lightning', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'perMinute', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cgFraction', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'spiderFraction', 'DOUBLE', '0.18' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cx', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cz', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'radius', 'DOUBLE', '12000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cloudBase', 'DOUBLE', '1200' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'chargeAbove', 'DOUBLE', '2500' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'groundLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'listenerX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'listenerY', 'DOUBLE', '2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'listenerZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'temperatureC', 'DOUBLE', '15' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'leaderSpeed', 'DOUBLE', '200000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'sheetDistance', 'DOUBLE', '28000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'candelaPerMetre', 'DOUBLE', '5000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'maxBolts', 'INT', '6' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.lightning' AS PAKET, 'Lightning' AS KLASSE, 'calm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset calm() aus com.dan.lightning' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.lightning', 'Lightning', 'calm', 'Preset calm() aus com.dan.lightning', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'perMinute', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cgFraction', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'spiderFraction', 'DOUBLE', '0.18' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cx', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cz', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'radius', 'DOUBLE', '12000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cloudBase', 'DOUBLE', '1200' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'chargeAbove', 'DOUBLE', '2500' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'groundLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'listenerX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'listenerY', 'DOUBLE', '2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'listenerZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'temperatureC', 'DOUBLE', '15' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'leaderSpeed', 'DOUBLE', '200000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'sheetDistance', 'DOUBLE', '28000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'candelaPerMetre', 'DOUBLE', '5000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'maxBolts', 'INT', '6' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.lightning' AS PAKET, 'Lightning' AS KLASSE, 'gale' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset gale() aus com.dan.lightning' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.lightning', 'Lightning', 'gale', 'Preset gale() aus com.dan.lightning', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'perMinute', 'DOUBLE', '5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cgFraction', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'spiderFraction', 'DOUBLE', '0.18' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cx', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cz', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'radius', 'DOUBLE', '12000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cloudBase', 'DOUBLE', '1200' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'chargeAbove', 'DOUBLE', '2500' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'groundLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'listenerX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'listenerY', 'DOUBLE', '2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'listenerZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'temperatureC', 'DOUBLE', '15' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'leaderSpeed', 'DOUBLE', '200000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'sheetDistance', 'DOUBLE', '28000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'candelaPerMetre', 'DOUBLE', '5000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'maxBolts', 'INT', '6' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.lightning' AS PAKET, 'Lightning' AS KLASSE, 'storm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset storm() aus com.dan.lightning' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.lightning', 'Lightning', 'storm', 'Preset storm() aus com.dan.lightning', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'perMinute', 'DOUBLE', '8' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cgFraction', 'DOUBLE', '0.28' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'spiderFraction', 'DOUBLE', '0.18' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cx', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cz', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'radius', 'DOUBLE', '12000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'cloudBase', 'DOUBLE', '1200' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'chargeAbove', 'DOUBLE', '2500' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'groundLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'listenerX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'listenerY', 'DOUBLE', '2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'listenerZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'temperatureC', 'DOUBLE', '15' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'leaderSpeed', 'DOUBLE', '200000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'sheetDistance', 'DOUBLE', '28000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'candelaPerMetre', 'DOUBLE', '5000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'maxBolts', 'INT', '6' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.lightning' AND KLASSE = 'Lightning' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.weathering' AS PAKET, 'Weathering' AS KLASSE, 'breeze' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset breeze() aus com.dan.weathering' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.weathering', 'Weathering', 'breeze', 'Preset breeze() aus com.dan.weathering', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'meanHighWater', 'DOUBLE', '1.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'meanLowWater', 'DOUBLE', '-1.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waveHeight', 'DOUBLE', '2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '9.3' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rainRate', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'sun', 'DOUBLE', '0.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rust', 'DOUBLE', '0.6' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'algae', 'DOUBLE', '0.8' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'salt', 'DOUBLE', '0.4' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'moss', 'DOUBLE', '0.1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1885' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'MEDIUM' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'mapWidthM', 'DOUBLE', '30' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'mapHeightM', 'DOUBLE', '32' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'mapBottom', 'DOUBLE', '-2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.weathering' AS PAKET, 'Weathering' AS KLASSE, 'calm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset calm() aus com.dan.weathering' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.weathering', 'Weathering', 'calm', 'Preset calm() aus com.dan.weathering', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'meanHighWater', 'DOUBLE', '1.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'meanLowWater', 'DOUBLE', '-1.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waveHeight', 'DOUBLE', '0.1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '0.9' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rainRate', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'sun', 'DOUBLE', '0.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rust', 'DOUBLE', '0.6' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'algae', 'DOUBLE', '0.8' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'salt', 'DOUBLE', '0.4' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'moss', 'DOUBLE', '0.1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1885' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'MEDIUM' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'mapWidthM', 'DOUBLE', '30' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'mapHeightM', 'DOUBLE', '32' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'mapBottom', 'DOUBLE', '-2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.weathering' AS PAKET, 'Weathering' AS KLASSE, 'gale' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset gale() aus com.dan.weathering' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.weathering', 'Weathering', 'gale', 'Preset gale() aus com.dan.weathering', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'meanHighWater', 'DOUBLE', '1.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'meanLowWater', 'DOUBLE', '-1.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waveHeight', 'DOUBLE', '5.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '18.9' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rainRate', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'sun', 'DOUBLE', '0.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rust', 'DOUBLE', '0.6' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'algae', 'DOUBLE', '0.8' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'salt', 'DOUBLE', '0.4' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'moss', 'DOUBLE', '0.1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1885' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'MEDIUM' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'mapWidthM', 'DOUBLE', '30' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'mapHeightM', 'DOUBLE', '32' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'mapBottom', 'DOUBLE', '-2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.weathering' AS PAKET, 'Weathering' AS KLASSE, 'storm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset storm() aus com.dan.weathering' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.weathering', 'Weathering', 'storm', 'Preset storm() aus com.dan.weathering', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'meanHighWater', 'DOUBLE', '1.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'meanLowWater', 'DOUBLE', '-1.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waveHeight', 'DOUBLE', '11.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '30.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rainRate', 'DOUBLE', '6' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'sun', 'DOUBLE', '0.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rust', 'DOUBLE', '0.6' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'algae', 'DOUBLE', '0.8' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'salt', 'DOUBLE', '0.4' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'moss', 'DOUBLE', '0.1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1885' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'MEDIUM' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'mapWidthM', 'DOUBLE', '30' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'mapHeightM', 'DOUBLE', '32' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'mapBottom', 'DOUBLE', '-2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.weathering' AND KLASSE = 'Weathering' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.buoyancy' AS PAKET, 'Buoyancy' AS KLASSE, 'breeze' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset breeze() aus com.dan.buoyancy' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.buoyancy', 'Buoyancy', 'breeze', 'Preset breeze() aus com.dan.buoyancy', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '6.7' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'ambientLux', 'DOUBLE', '10000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'lightsOnLux', 'DOUBLE', '200' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'shipEveryMin', 'DOUBLE', '25' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fairwayX', 'DOUBLE', '900' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fairwayZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fairwayDeg', 'DOUBLE', '330' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fairwayHalf', 'DOUBLE', '7000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.buoyancy' AS PAKET, 'Buoyancy' AS KLASSE, 'calm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset calm() aus com.dan.buoyancy' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.buoyancy', 'Buoyancy', 'calm', 'Preset calm() aus com.dan.buoyancy', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '0.9' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'ambientLux', 'DOUBLE', '10000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'lightsOnLux', 'DOUBLE', '200' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'shipEveryMin', 'DOUBLE', '25' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fairwayX', 'DOUBLE', '900' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fairwayZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fairwayDeg', 'DOUBLE', '330' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fairwayHalf', 'DOUBLE', '7000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.buoyancy' AS PAKET, 'Buoyancy' AS KLASSE, 'gale' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset gale() aus com.dan.buoyancy' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.buoyancy', 'Buoyancy', 'gale', 'Preset gale() aus com.dan.buoyancy', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '19' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'ambientLux', 'DOUBLE', '10000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'lightsOnLux', 'DOUBLE', '200' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'shipEveryMin', 'DOUBLE', '25' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fairwayX', 'DOUBLE', '900' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fairwayZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fairwayDeg', 'DOUBLE', '330' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fairwayHalf', 'DOUBLE', '7000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.buoyancy' AS PAKET, 'Buoyancy' AS KLASSE, 'storm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset storm() aus com.dan.buoyancy' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.buoyancy', 'Buoyancy', 'storm', 'Preset storm() aus com.dan.buoyancy', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '26.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'ambientLux', 'DOUBLE', '10000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'lightsOnLux', 'DOUBLE', '200' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'shipEveryMin', 'DOUBLE', '50' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fairwayX', 'DOUBLE', '900' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fairwayZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fairwayDeg', 'DOUBLE', '330' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'fairwayHalf', 'DOUBLE', '7000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.buoyancy' AND KLASSE = 'Buoyancy' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.flock' AS PAKET, 'Flock' AS KLASSE, 'breeze' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset breeze() aus com.dan.flock' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.flock', 'Flock', 'breeze', 'Preset breeze() aus com.dan.flock', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '6.7' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'ambientLux', 'DOUBLE', '20000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'nightLux', 'DOUBLE', '30' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'homeX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'homeZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'homeRadius', 'DOUBLE', '160' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'coastDeg', 'DOUBLE', '150' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'dayOfYear', 'INT', '200' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.flock' AS PAKET, 'Flock' AS KLASSE, 'calm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset calm() aus com.dan.flock' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.flock', 'Flock', 'calm', 'Preset calm() aus com.dan.flock', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '0.9' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'ambientLux', 'DOUBLE', '20000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'nightLux', 'DOUBLE', '30' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'homeX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'homeZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'homeRadius', 'DOUBLE', '160' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'coastDeg', 'DOUBLE', '150' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'dayOfYear', 'INT', '200' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.flock' AS PAKET, 'Flock' AS KLASSE, 'gale' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset gale() aus com.dan.flock' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.flock', 'Flock', 'gale', 'Preset gale() aus com.dan.flock', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '19' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'ambientLux', 'DOUBLE', '20000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'nightLux', 'DOUBLE', '30' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'homeX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'homeZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'homeRadius', 'DOUBLE', '160' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'coastDeg', 'DOUBLE', '150' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'dayOfYear', 'INT', '200' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.flock' AS PAKET, 'Flock' AS KLASSE, 'storm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset storm() aus com.dan.flock' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.flock', 'Flock', 'storm', 'Preset storm() aus com.dan.flock', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '26.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'ambientLux', 'DOUBLE', '20000' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'nightLux', 'DOUBLE', '30' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'homeX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'homeZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'homeRadius', 'DOUBLE', '160' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'coastDeg', 'DOUBLE', '150' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'dayOfYear', 'INT', '200' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.flock' AND KLASSE = 'Flock' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.soundscape' AS PAKET, 'Soundscape' AS KLASSE, 'breeze' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset breeze() aus com.dan.soundscape' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.soundscape', 'Soundscape', 'breeze', 'Preset breeze() aus com.dan.soundscape', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'volume', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'autoGain', 'BOOLEAN', 'true' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '6.7' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'gustiness', 'DOUBLE', '0.18' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rainRate', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waveHeight', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'wavePeriod', 'DOUBLE', '5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'surfX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'surfZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'surfRadius', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'surfStrength', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'temperatureC', 'DOUBLE', '11' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'earX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'earY', 'DOUBLE', '2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'earZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'earYawDeg', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'inside', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'glassDrops', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'roofDrops', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'reedNear', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'thatchNear', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'obstruction', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'roughness', 'DOUBLE', '0.0002' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.soundscape' AS PAKET, 'Soundscape' AS KLASSE, 'calm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset calm() aus com.dan.soundscape' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.soundscape', 'Soundscape', 'calm', 'Preset calm() aus com.dan.soundscape', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'volume', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'autoGain', 'BOOLEAN', 'true' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '0.9' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'gustiness', 'DOUBLE', '0.18' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rainRate', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waveHeight', 'DOUBLE', '0.1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'wavePeriod', 'DOUBLE', '3' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'surfX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'surfZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'surfRadius', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'surfStrength', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'temperatureC', 'DOUBLE', '11' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'earX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'earY', 'DOUBLE', '2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'earZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'earYawDeg', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'inside', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'glassDrops', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'roofDrops', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'reedNear', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'thatchNear', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'obstruction', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'roughness', 'DOUBLE', '0.0002' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.soundscape' AS PAKET, 'Soundscape' AS KLASSE, 'gale' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset gale() aus com.dan.soundscape' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.soundscape', 'Soundscape', 'gale', 'Preset gale() aus com.dan.soundscape', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'volume', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'autoGain', 'BOOLEAN', 'true' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '18.9' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'gustiness', 'DOUBLE', '0.25' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rainRate', 'DOUBLE', '2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waveHeight', 'DOUBLE', '5.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'wavePeriod', 'DOUBLE', '9' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'surfX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'surfZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'surfRadius', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'surfStrength', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'temperatureC', 'DOUBLE', '11' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'earX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'earY', 'DOUBLE', '2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'earZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'earYawDeg', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'inside', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'glassDrops', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'roofDrops', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'reedNear', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'thatchNear', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'obstruction', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'roughness', 'DOUBLE', '0.0002' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.soundscape' AS PAKET, 'Soundscape' AS KLASSE, 'storm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset storm() aus com.dan.soundscape' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.soundscape', 'Soundscape', 'storm', 'Preset storm() aus com.dan.soundscape', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'HIGH' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'volume', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'autoGain', 'BOOLEAN', 'true' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '26.4' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'gustiness', 'DOUBLE', '0.25' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'rainRate', 'DOUBLE', '6' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waveHeight', 'DOUBLE', '9' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'wavePeriod', 'DOUBLE', '11' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'surfX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'surfZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'surfRadius', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'surfStrength', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waterLevel', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'temperatureC', 'DOUBLE', '11' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'earX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'earY', 'DOUBLE', '2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'earZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'earYawDeg', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'inside', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'glassDrops', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'roofDrops', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'reedNear', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'thatchNear', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'obstruction', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'roughness', 'DOUBLE', '0.0002' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.soundscape' AND KLASSE = 'Soundscape' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.spray' AS PAKET, 'Spray' AS KLASSE, 'breeze' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset breeze() aus com.dan.spray' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.spray', 'Spray', 'breeze', 'Preset breeze() aus com.dan.spray', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '9.3' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waveHeight', 'DOUBLE', '2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'strength', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'MEDIUM' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1885' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'focusX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'focusZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'focusRadius', 'DOUBLE', '120' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'samplesPer10m', 'INT', '10' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'sampleRate', 'DOUBLE', '20' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'breeze' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.spray' AS PAKET, 'Spray' AS KLASSE, 'calm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset calm() aus com.dan.spray' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.spray', 'Spray', 'calm', 'Preset calm() aus com.dan.spray', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '2.4' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waveHeight', 'DOUBLE', '0.2' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'strength', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'MEDIUM' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1885' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'focusX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'focusZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'focusRadius', 'DOUBLE', '120' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'samplesPer10m', 'INT', '10' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'sampleRate', 'DOUBLE', '20' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'calm' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.spray' AS PAKET, 'Spray' AS KLASSE, 'gale' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset gale() aus com.dan.spray' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.spray', 'Spray', 'gale', 'Preset gale() aus com.dan.spray', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '18.9' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waveHeight', 'DOUBLE', '5.5' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'strength', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'MEDIUM' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1885' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'focusX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'focusZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'focusRadius', 'DOUBLE', '120' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'samplesPer10m', 'INT', '10' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'sampleRate', 'DOUBLE', '20' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'gale' AND HERKUNFT = 'MITGELIEFERT';
MERGE INTO HB_PAKET_PRESET t USING (SELECT 'com.dan.spray' AS PAKET, 'Spray' AS KLASSE, 'storm' AS NAME FROM DUAL) q ON (t.PAKET = q.PAKET AND t.KLASSE = q.KLASSE AND t.NAME = q.NAME)
WHEN MATCHED THEN UPDATE SET t.BESCHREIBUNG = 'Preset storm() aus com.dan.spray' WHERE t.HERKUNFT = 'MITGELIEFERT'
WHEN NOT MATCHED THEN INSERT (PAKET, KLASSE, NAME, BESCHREIBUNG, HERKUNFT) VALUES ('com.dan.spray', 'Spray', 'storm', 'Preset storm() aus com.dan.spray', 'MITGELIEFERT');
DELETE FROM HB_PAKET_WERT WHERE PAKET_PRESET_ID IN (SELECT ID FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT');
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windSpeed', 'DOUBLE', '26.4' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'windFromDeg', 'DOUBLE', '240' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'waveHeight', 'DOUBLE', '9' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'strength', 'DOUBLE', '1' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'quality', 'ENUM', 'MEDIUM' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'seed', 'INT', '1885' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'focusX', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'focusZ', 'DOUBLE', '0' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'focusRadius', 'DOUBLE', '120' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'samplesPer10m', 'INT', '10' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';
INSERT INTO HB_PAKET_WERT (PAKET_PRESET_ID, FELD, TYP, WERT) SELECT ID, 'sampleRate', 'DOUBLE', '20' FROM HB_PAKET_PRESET WHERE PAKET = 'com.dan.spray' AND KLASSE = 'Spray' AND NAME = 'storm' AND HERKUNFT = 'MITGELIEFERT';

COMMIT;

-- Ende 04_startdaten.sql
