package com.dan.glacier.scene;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Der Faden der Physik (F21 A, Werkbuch Abschnitt 10): {@code fracture}, {@code wave} und {@code buoyancy} rechnen
 * nicht im Bildlauf, sondern hier mit festem Schritt von 1/120 s. Der Bildlauf gibt nur die verstrichene Zeit weiter
 * ({@link #advance}) und liest Lagen und Höhen, die die Aufgaben selbst bereitstellen. Hinkt der Faden hinterher,
 * werden höchstens {@link #MAX_BEHIND} Schritte nachgeholt, der Rest verfällt (die Szene läuft dann langsamer, statt
 * zu explodieren).
 * <p>
 * Phase 1: der Faden läuft und misst sich selbst, Aufgaben gibt es noch keine. Ab Phase 6 hängt {@code fracture}
 * seine Starrkörper an, ab Phase 8 {@code wave} das Flachwasser, ab Phase 9 {@code buoyancy} die Eisberge.
 */
public final class Physik {
    /** Eine Aufgabe im Faden: ein fester Schritt der Länge dt (s) zur Laufzeit t (s). */
    @FunctionalInterface
    public interface Aufgabe {
        void step(double t, double dt);
        default String name() { return getClass().getSimpleName(); }
    }

    public static final double DT = 1.0 / 120;
    public static final int MAX_BEHIND = 12;

    private final List<Aufgabe> aufgaben = new CopyOnWriteArrayList<>();
    private final Object lock = new Object();
    private double pending, t;
    private long steps, dropped;
    private volatile double stepMs, busy;
    private volatile boolean running;
    private Thread thread;

    private final String name;

    public Physik() { this("Physik"); }

    /** Ein Faden mit eigenem Namen (seit Phase 8: „Welle“ für com.dan.wave). */
    public Physik(String name) { this.name = name; }

    public void add(Aufgabe a) { aufgaben.add(a); }
    public void remove(Aufgabe a) { aufgaben.remove(a); }
    public int aufgaben() { return aufgaben.size(); }

    /** Vom Bildlauf: dt echte Sekunden sind vergangen (0 bei stehender Szene). */
    public void advance(double dt) {
        synchronized (lock) {
            pending = Math.min(pending + Math.max(0, dt), DT * MAX_BEHIND);
            lock.notifyAll();
        }
    }

    /** Rechnet ohne Faden alles, was ansteht (für Prüfungen und Standbilder); gibt die Zahl der Schritte zurück. */
    public int drain() {
        int n = 0;
        while (true) {
            synchronized (lock) {
                if (pending < DT) return n;
                pending -= DT;
            }
            once();
            n++;
        }
    }

    private void once() {
        long t0 = System.nanoTime();
        for (Aufgabe a : aufgaben) {
            try {
                a.step(t, DT);
            } catch (RuntimeException e) {
                System.err.println("Physik: " + a.name() + ": " + e);
                aufgaben.remove(a);
            }
        }
        t += DT;
        steps++;
        double ms = (System.nanoTime() - t0) / 1e6;
        stepMs = stepMs * 0.95 + ms * 0.05;
    }

    public void start() {
        if (running) return;
        running = true;
        thread = new Thread(() -> {
            long last = System.nanoTime(), busyNs = 0;
            while (running) {
                boolean go;
                synchronized (lock) {
                    if (pending >= DT * MAX_BEHIND) { dropped++; }
                    go = pending >= DT;
                    if (go) pending -= DT;
                    else try { lock.wait(4); } catch (InterruptedException e) { return; }
                }
                if (go) {
                    long a = System.nanoTime();
                    once();
                    busyNs += System.nanoTime() - a;
                }
                long now = System.nanoTime();
                if (now - last > 1_000_000_000L) {
                    busy = busyNs / (double) (now - last);
                    busyNs = 0;
                    last = now;
                }
            }
        }, name);
        thread.setDaemon(true);
        thread.setPriority(Thread.NORM_PRIORITY + 1);
        thread.start();
    }

    public void stop() {
        running = false;
        if (thread != null) thread.interrupt();
    }

    public double time() { return t; }
    public long steps() { return steps; }

    /** „Physik 1/120 s · 0 Aufgaben · 0,00 ms je Schritt · Faden 0 % belegt“ */
    public String describe() {
        return String.format(Locale.GERMAN, name + " 1/%d s · %d Aufgaben · %.2f ms je Schritt · Faden %.0f %% belegt%s",
                Math.round(1 / DT), aufgaben.size(), stepMs, busy * 100, dropped > 0 ? " · " + dropped + "× nicht nachgekommen" : "");
    }
}
