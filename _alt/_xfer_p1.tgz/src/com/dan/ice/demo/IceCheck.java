package com.dan.ice.demo;

import com.dan.ice.Ice;

/**
 * Prüfklasse ohne Fenster (Paketvertrag Punkt 10). Endet mit „Alles in Ordnung.“ oder mit den Verstößen
 * (Rückgabewert 1). Phase 1 prüft die Hülle; Phase 4 und 5 hängen Material und Gletscher an.
 */
public final class IceCheck {
    private static int bad;

    public static void main(String[] args) {
        check(Ice.firn().bubbles > Ice.glacier().bubbles && Ice.glacier().bubbles > Ice.blue().bubbles, "Presets: Firn weißer als Gletschereis, das weißer als Blaueis");
        double f = new Ice().submergedFraction(1000);
        check(Math.abs(f - 0.9) < 1e-9, "Gletschereis schwimmt mit 9 Zehnteln unter Wasser");
        check(new Ice().describe().contains("Hülle"), "Stand: Hülle (Phase 1)");
        check(Ice.Quality.values().length == 4, "vier Qualitätsstufen LOW bis ULTRA");
        System.out.println(bad == 0 ? "Alles in Ordnung." : bad + " Verstöße.");
        System.exit(bad == 0 ? 0 : 1);
    }

    static void check(boolean c, String what) {
        if (!c) bad++;
        System.out.println((c ? "  ok    " : "  FEHLER ") + what);
    }

    private IceCheck() { }
}
