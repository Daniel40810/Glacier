# com.dan.ice – Eis als Material und als Körper

**Stand: Hülle (Phase 1).** Material folgt in Phase 4, der Gletscher in Phase 5 (Werkbuch Glacier, Abschnitt 9).

Eis, das wie Eis aussieht – nicht wie Glas und nicht wie Gips: weiß am Rand, blau in der Tiefe, Risse, die in der Sonne blitzen. Und ein Gletscher als Körper, dessen Form aus Regeln folgt, die jeder Gletscher hat. Das Package kennt keine App und kein anderes Package; der Kern braucht nur Java 21, `gl/` zusätzlich JOGL, `demo/` zusätzlich `FStyle.jar`.

Zum Herauskopieren reicht `src/com/dan/ice/`.

## Was es können wird

- **Material (Phase 4):** Licht im Eis nach Beer-Lambert je Farbkanal mit den Absorptionswerten von reinem Eis (Warren & Brandt 2008): Rot ist nach wenigen Metern halbiert, Blau erst nach weit über hundert. Dicke aus einem Rückseiten-Tiefenbild; Blasen streuen und machen Firn weiß; altes, gepresstes Eis tiefblau; Risse als Zellgrenzen im Volumen mit Totalreflexion; Moränenbänder; Schmelzwasserfilm mit Fresnel; Glitzer; Schnee.
- **Körper (Phase 5):** Zunge aus Oberfläche, Grund und Fließfeld; Spalten quer und längs aus der Dehnung; Türme und Seracs im Eisfall; die Front als Wand mit Schmelzkerbe an der Wasserlinie; Vorstoß als Verschiebung der Front; Eisberge, deren Schwerpunkt mit der Schmelze wandert.
- **Für andere Packages:** Zellen mit Festigkeit je Fläche für `fracture`, Eisberge als Körper für `buoyancy`, Kollisionsflächen.

## Was die Hülle schon hat

- `Quality.LOW` bis `ULTRA`, `seed`, offene Felder (`bubbles`, `cracks`, `density`, `airTempC`, `waterTempC`).
- Presets `firn()`, `glacier()`, `blue()`.
- `submergedFraction(ρWasser)`: neun Zehntel unter Wasser bei 900 kg/m³.

## Aufbau

| Klasse | Aufgabe |
|---|---|
| `Ice` | Kern: Presets, offene Werte, Qualitätsstufen |
| `demo/IceCheck` | Prüfung ohne Fenster, endet mit „Alles in Ordnung.“ |

Phase 4 bringt `gl/IceGl` mit den Shadern als Ressourcen im Package und `demo/IceDemo` (ein Block von 10 m, drehbar, daneben ein Eisberg mit Fuß unter Wasser, Regler für Blasen, Risse, Dicke).

## Grenzen

- Die Hülle zeichnet nichts. Bis Phase 4 steht in der App ein Platzhalter-Block.
