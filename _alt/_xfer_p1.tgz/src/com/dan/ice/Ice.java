package com.dan.ice;

/**
 * Eis als Material und als Körper (Werkbuch Glacier, Abschnitt 4). Stand Phase 1: die Hülle nach dem Paketvertrag –
 * Qualitätsstufen, {@code seed}, Presets und die offenen Werte, die die Phasen 4 und 5 füllen. Der Kern kennt nur
 * Java 21; das Package kennt weder die App noch ein anderes Package.
 * <ul>
 * <li><b>Material (Phase 4):</b> Licht im Eis nach Beer-Lambert je Farbkanal (Absorption von reinem Eis nach Warren &amp;
 * Brandt 2008), Dicke aus einem Rückseiten-Tiefenbild, Blasen als Streuung (Firn weiß, altes Eis blau), Risse als
 * Zellgrenzen im Volumen mit Totalreflexion, Moränenbänder, Schmelzwasserfilm, Glitzer, Schnee.</li>
 * <li><b>Körper (Phase 5):</b> ein Gletscher aus Oberfläche, Grund und Fließfeld; Spalten quer und längs aus der Dehnung,
 * Türme im Eisfall, die Front mit Schmelzkerbe, Vorstoß; Eisberge mit wanderndem Schwerpunkt; Zellen mit Festigkeit
 * für {@code fracture}.</li>
 * </ul>
 */
public final class Ice {
    /** Qualitätsstufen, eigene Kopie im Package (Paketvertrag Punkt 7). */
    public enum Quality { LOW, MEDIUM, HIGH, ULTRA }

    /** Stand des Packages: 1 = Hülle; 4 = Material; 5 = Gletscher. */
    public static final int STAGE = 1;

    /** Startwert des Zufalls: gleicher seed, gleiches Eis (Punkt 6). */
    public long seed = 1;
    public Quality quality = Quality.MEDIUM;
    /** Anteil der Luftblasen 0..1 (Firn 1, altes gepresstes Eis 0) und Dichte der Risse 0..1 (Phase 4). */
    public double bubbles = 0.5, cracks = 0.3;
    /** Dichte des Eises (kg/m³); Gletschereis rund 900 (Werkbuch, Abschnitt 2). */
    public double density = 900;
    /** Lufttemperatur (°C) und Wassertemperatur (°C) für Schmelze und Schmelzkerbe (Phase 5). */
    public double airTempC = 8, waterTempC = 2;

    // ------------------------------------------------------------------ Presets (Punkt 5)
    /** Junges Eis und Firn: viele Blasen, weiß. */
    public static Ice firn() { Ice i = new Ice(); i.bubbles = 0.9; i.cracks = 0.1; i.density = 830; return i; }
    /** Gletschereis an der Front: wenig Blasen, blau in der Tiefe, viele Risse. */
    public static Ice glacier() { Ice i = new Ice(); i.bubbles = 0.25; i.cracks = 0.5; return i; }
    /** Altes, gepresstes Eis aus der Tiefe einer Spalte oder dem Fuß eines Eisbergs: fast klar, tiefblau. */
    public static Ice blue() { Ice i = new Ice(); i.bubbles = 0.05; i.cracks = 0.2; i.density = 917; return i; }

    /** Anteil eines schwimmenden Stücks unter Wasser bei der Dichte des Wassers (kg/m³): ρ_Eis / ρ_Wasser. */
    public double submergedFraction(double waterDensity) { return Math.min(1, density / waterDensity); }

    /** „ice: Hülle (Phase 1) · Blasen 50 % · Risse 30 % · 900 kg/m³ · MEDIUM“ */
    public String describe() {
        return String.format(java.util.Locale.GERMAN, "ice: %s · Blasen %.0f %% · Risse %.0f %% · %.0f kg/m³ · %s",
                STAGE == 1 ? "Hülle (Phase 1)" : "Stufe " + STAGE, bubbles * 100, cracks * 100, density, quality);
    }
}
