# com.dan.fracture – Bruch und Starrkörper

**Stand: Hülle (Phase 1).** Die Engine folgt in Phase 6, die Kalbung mit ihr in Phase 7 (Werkbuch Glacier, Abschnitt 9).

Ein Körper bricht, weil die Spannung die Festigkeit übersteigt – nicht nach Drehbuch. Das Package kennt kein Eis, kein Wasser und keinen Fels: Dichte, Festigkeit und die Höhe des Wassers kommen von außen. Darum taugt es genauso für einen Felssturz, eine Staumauer, ein einstürzendes Haus, einen Eisgang oder eine Lavakruste. Der Kern braucht nur Java 21.

Zum Herauskopieren reicht `src/com/dan/fracture/`.

## Was es können wird

- **Zellen:** einen beliebigen Körper (Netz oder Höhenfeld) in Zellen zerlegen (3D-Voronoi mit Dichte nach Ort), Festigkeit je Zellfläche.
- **Spannung:** je Zellsäule aus einem Balkenmodell – Eigengewicht, Überhang, Auftrieb, Stützung.
- **Riss:** wo Spannung über Festigkeit liegt, läuft ein Riss durch die schwächsten Flächen, bis ein Stück frei ist; `onCrack` meldet ihn Sekunden vor dem Bruch.
- **Starrkörper:** Masse und Trägheit aus der Zelle, Schwerkraft, Auftrieb aus dem untergetauchten Volumen (Abfrage `Water`), Widerstand, Stöße mit Wand, Boden und anderen Stücken nach dem Impulsverfahren mit Wärmstart, Schlaf nach 30 s, höchstens 1 000 wache Stücke.
- **Ereignisse:** `onCrack` (Weg, Energie), `onBreak` (Stück, Volumen, Masse), `onImpact` (Ort, Volumen, Tempo) für Welle, Gischt und Klang.

## Was die Hülle schon hat

- `Quality`, `seed`, offene Felder (`gravity`, `density`, `strength`, `maxAwake`, `sleepAfter`), die vier Schnittstellen.
- Presets `ice()`, `rock()`, `concrete()`.
- `freeFall(h)` als Handrechnung für die Prüfung in Phase 6.

## Aufbau

| Klasse | Aufgabe |
|---|---|
| `Fracture` | Kern: Presets, offene Werte, Ereignisse, Qualitätsstufen |
| `demo/FractureCheck` | Prüfung ohne Fenster, endet mit „Alles in Ordnung.“ |

Phase 6 bringt die Demo mit drei Fällen (ein Pfeiler bricht unter Last, ein überhängender Block kippt ins Wasser, ein Fels rollt einen Hang hinab) und die Prüfung gegen die Handrechnung (Bruchlast der Säule auf 10 %).

## Grenzen

- Die Hülle rechnet nichts.
- Keine finiten Elemente (F8 A): die Engine rechnet Zellen und Starrkörper, damit sie auf dem Prozessor in Echtzeit bleibt.
