package com.dan.fracture;

/**
 * Bruch und Starrkörper (Werkbuch Glacier, Abschnitt 4). Stand Phase 1: die Hülle nach dem Paketvertrag –
 * Qualitätsstufen, {@code seed}, Presets, die offenen Werte und die drei Ereignisse, die Phase 6 füllt. Kennt kein
 * Eis, kein Wasser und keinen Fels: Dichte, Festigkeit und die Höhe des Wassers kommen von außen.
 * <ul>
 * <li>Zerlegung eines Körpers in Zellen (3D-Voronoi, dichter wo {@code density} es will), Festigkeit je Zellfläche;</li>
 * <li>Spannung je Zellsäule aus einem Balkenmodell (Eigengewicht, Überhang, Auftrieb, Stützung); läuft die Spannung
 * über die Festigkeit, läuft ein Riss entlang der schwächsten Flächen, bis ein Stück frei ist;</li>
 * <li>freie Stücke als Starrkörper: Masse und Trägheit aus der Zelle, Schwerkraft, Auftrieb aus dem untergetauchten
 * Volumen, Widerstand, Stöße nach dem Impulsverfahren, Schlaf.</li>
 * </ul>
 */
public final class Fracture {
    public enum Quality { LOW, MEDIUM, HIGH, ULTRA }

    /** Stand des Packages: 1 = Hülle; 6 = Engine. */
    public static final int STAGE = 1;

    /** Ein Riss läuft: Weg als Punkte {x, y, z, …} (m), freigesetzte Energie (J), ob das Stück damit frei ist. */
    @FunctionalInterface public interface Crack { void crack(double[] path, double energyJ, boolean broken); }
    /** Ein Stück ist frei: Kennung, Volumen (m³), Masse (kg). */
    @FunctionalInterface public interface Break { void broke(int piece, double volumeM3, double massKg); }
    /** Ein Stück schlägt auf: Ort (m), verdrängtes Volumen in diesem Schritt (m³), Tempo (m/s), ob ins Wasser. */
    @FunctionalInterface public interface Impact { void impact(double x, double y, double z, double volumeM3, double speed, boolean water); }
    /** Die Höhe des Wassers am Ort (m) zur Laufzeit t (s); kommt von außen, ohne Wasser NaN. */
    @FunctionalInterface public interface Water { double heightAt(double x, double z, double t); }

    public long seed = 1;
    public Quality quality = Quality.MEDIUM;
    /** Erdbeschleunigung (m/s²), Dichte des Stoffs (kg/m³) und mittlere Zugfestigkeit der Zellflächen (Pa). */
    public double gravity = 9.81, density = 900, strength = 1.0e6;
    /** Höchstzahl wacher Stücke und Ruhezeit bis zum Schlaf (s) (Werkbuch, Abschnitt 10). */
    public int maxAwake = 1000;
    public double sleepAfter = 30;
    public Crack onCrack;
    public Break onBreak;
    public Impact onImpact;
    public Water water;

    // ------------------------------------------------------------------ Presets
    /** Gletschereis: 900 kg/m³, Zugfestigkeit rund 1 MPa [zu prüfen, Phase 6]. */
    public static Fracture ice() { return new Fracture(); }
    /** Fels (Granit) für einen Felssturz: 2 700 kg/m³, rund 10 MPa [G]. */
    public static Fracture rock() { Fracture f = new Fracture(); f.density = 2700; f.strength = 1.0e7; return f; }
    /** Beton einer Staumauer: 2 400 kg/m³, rund 3 MPa [G]. */
    public static Fracture concrete() { Fracture f = new Fracture(); f.density = 2400; f.strength = 3.0e6; return f; }

    /** Fallzeit aus der Höhe h (m) ohne Luft: √(2h/g) (Handrechnung für die Prüfung in Phase 6). */
    public double freeFall(double h) { return Math.sqrt(2 * Math.max(0, h) / gravity); }

    /** „fracture: Hülle (Phase 1) · 900 kg/m³ · 1,0 MPa · bis 1 000 Stücke · MEDIUM“ */
    public String describe() {
        return String.format(java.util.Locale.GERMAN, "fracture: %s · %.0f kg/m³ · %.1f MPa · bis %,d Stücke · %s",
                STAGE == 1 ? "Hülle (Phase 1)" : "Stufe " + STAGE, density, strength / 1e6, maxAwake, quality);
    }
}
