package com.dan.fracture.demo;

import com.dan.fracture.Fracture;

/**
 * Prüfklasse ohne Fenster (Paketvertrag Punkt 10). Endet mit „Alles in Ordnung.“ oder mit den Verstößen
 * (Rückgabewert 1). Phase 1 prüft die Hülle; Phase 6 hängt Säule, Balken und Kragplatte gegen die Handrechnung an.
 */
public final class FractureCheck {
    private static int bad;

    public static void main(String[] args) {
        Fracture f = Fracture.ice();
        check(Math.abs(f.freeFall(50) - 3.19) < 0.01, String.format(java.util.Locale.GERMAN, "freier Fall aus 50 m: %.2f s", f.freeFall(50)));
        check(Fracture.rock().density > Fracture.concrete().density && Fracture.concrete().density > f.density, "Presets: Fels schwerer als Beton schwerer als Eis");
        check(f.onCrack == null && f.onBreak == null && f.onImpact == null && f.water == null, "ohne Zuhörer und ohne Wasser startklar");
        check(f.describe().contains("Hülle"), "Stand: Hülle (Phase 1)");
        System.out.println(bad == 0 ? "Alles in Ordnung." : bad + " Verstöße.");
        System.exit(bad == 0 ? 0 : 1);
    }

    static void check(boolean c, String what) {
        if (!c) bad++;
        System.out.println((c ? "  ok    " : "  FEHLER ") + what);
    }

    private FractureCheck() { }
}
