package com.dan.glacier.gl;

import java.util.Locale;

/**
 * Qualitätsstufen der App (aus Haithabu, entschlackt). Phase 1: Anteil der Bildgröße, in dem gerechnet wird, und das
 * Zeitbudget. Jede weitere Package-Phase hängt die Stufe ihres Packages an (Phase 2: ocean, reed, forest, Gelände;
 * Phase 3: Himmel und Wetter; Phase 4–9: ice, fracture, wave, buoyancy). Die Packages haben ihre eigene Kopie dieser
 * Aufzählung (Paketvertrag Punkt 7).
 * Ziel (F21 A): „Mittel“ hält 60 Bilder/s in Full HD auf der Radeon 680M, „Hoch“ mindestens 30.
 */
public enum Quality {
    NIEDRIG("Niedrig", 0.67),
    MITTEL("Mittel", 0.85),
    HOCH("Hoch", 1.0),
    ULTRA("Ultra", 1.0);

    public final String label;
    /** Anteil der Bildgröße, in dem gerechnet wird. */
    public final double renderScale;

    Quality(String label, double renderScale) {
        this.label = label;
        this.renderScale = renderScale;
    }

    /**
     * Bildzeit, die die Stufe höchstens verbrauchen darf (ms): „Mittel“ 15,7 ms nach dem Budget im Werkbuch
     * (Abschnitt 10, 1 ms Reserve auf 16,7 ms), „Hoch“ das Doppelte, „Niedrig“ die Hälfte.
     */
    public double budgetMs() {
        return switch (this) { case NIEDRIG -> 7.85; case MITTEL -> 15.7; case HOCH -> 31.4; case ULTRA -> 50.0; };
    }

    /** Was die Stufe einstellt, als eine Zeile (Bedienfeld, README). */
    public String summary() {
        return String.format(Locale.GERMAN, "%s: %d %% der Auflösung, Budget %.1f ms", label, Math.round(renderScale * 100), budgetMs());
    }

    @Override public String toString() { return label; }
}
