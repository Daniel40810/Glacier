package com.dan.glacier.camera;

import com.dan.glacier.scene.Buehne;

import java.util.List;
import java.util.Locale;

/**
 * Die Ansichten auf den Tasten 1 bis 7 (F15 A). Phase 1 stellt sie auf die flache Bühne ({@link Buehne}) [G]; die
 * echten Orte kommen mit dem Gelände (Phase 2: Steg, Brazo Rico, Berg), dem Gletscher (Phase 5: Südflanke, Auf dem Eis)
 * und den Eisbergen (Phase 9: Unter Wasser). Die Augenhöhe wird über der Bühne genommen, darum passen die Ansichten
 * auch nach einem neuen Gelände.
 */
public final class Ansichten {
    /** Eine Ansicht: Taste, Name, Lage (x, z), Blickrichtung (Grad von Nord), Neigung (Grad nach unten), Augenhöhe über Grund, ab Phase. */
    public record Ansicht(int key, String name, double x, double z, double heading, double pitch, double eyeAboveGround, int phase) {
        @Override public String toString() { return key + " " + name; }
    }

    public static final List<Ansicht> ALLE = List.of(
            new Ansicht(1, "Vom Steg", Buehne.TIP + 30, 20, 272, -4, 22, 1),
            new Ansicht(2, "Südflanke", 900, 1900, 300, -2, 8, 1),
            new Ansicht(3, "Vom Boot", 320, -900, 245, -3, 4, 1),
            new Ansicht(4, "Auf dem Eis", -700, -300, 85, 3, 1.7, 1),
            new Ansicht(5, "Brazo Rico", 1600, 3400, 300, 0, 6, 1),
            new Ansicht(6, "Vom Berg", 5200, -3800, 240, 9, 900, 1),
            new Ansicht(7, "Unter Wasser", 120, 0, 270, -10, -30, 9));

    /** Ob die Ansicht schon einen Ort hat („Unter Wasser“ erst mit den Eisbergen in Phase 9). */
    public static boolean ready(Ansicht a, int phase) { return a.phase() <= phase; }

    public static Ansicht byName(String name) {
        for (Ansicht a : ALLE) if (a.name().equalsIgnoreCase(name) || a.name().replace(" ", "").equalsIgnoreCase(name)) return a;
        return null;
    }

    public static Ansicht byKey(int key) {
        for (Ansicht a : ALLE) if (a.key() == key) return a;
        return null;
    }

    /** Stellt die Kamera auf die Ansicht; false, wenn sie in dieser Phase noch keinen Ort hat. */
    public static boolean apply(Ansicht a, Camera c, int phase) {
        if (!ready(a, phase)) return false;
        c.stopFahrt();
        c.place(a.x(), Buehne.height(a.x(), a.z()) + a.eyeAboveGround(), a.z(), a.heading(), a.pitch());
        return true;
    }

    /** „4 Auf dem Eis (Eis, 76 m über dem See)“ */
    public static String describe(Ansicht a, int phase) {
        if (!ready(a, phase)) return a + " (folgt in Phase " + a.phase() + ")";
        return String.format(Locale.GERMAN, "%s (%s, %.0f m über dem See)", a, Buehne.zone(a.x(), a.z()), Buehne.height(a.x(), a.z()) + a.eyeAboveGround());
    }

    private Ansichten() { }
}
