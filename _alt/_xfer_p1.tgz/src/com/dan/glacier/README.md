# com.dan.glacier – die App

Glacier – Weißer Donner: der Perito-Moreno-Gletscher am Lago Argentino als 3D-Echtzeitszene. Die App verdrahtet die Element-Packages und zeichnet; sie selbst enthält keine Physik der Elemente.

**Stand: Phase 1 (Grundgerüst).**

| Paket | Inhalt |
|---|---|
| `app` | `GlacierApp`: Startbild, FFrame maximiert, Szene, Bedienfeld, Statuszeile, Fehlerdatei `daten/fehler.txt` |
| `gl` | Engine aus Haithabu, entschlackt: `Renderer` (Himmel-Platzhalter, Bühne, Nachbearbeitung, HUD, Zeitmessung je Durchgang, Auflösungsregelung, Foto F12, Shader neu F5), `SceneView`, `Shader`, `Gpu`, `Mat4`, `HudOverlay`, `ComputeProbe`, `Quality` |
| `gl/shader` | `common.glsl` (Platzhalter-Himmel), `sky.frag`, `stage.frag` (Bühne), `post.frag`, `overlay.frag`, `probe.comp` |
| `camera` | `Camera` (Kreisen, Frei, Fahrt, Mitfahrt), `Fahrt`, `Ansichten` 1–7 |
| `scene` | `Site` (Ort und Maße, Abschnitt 2), `Geo` (transversale Mercator, UTM 18 Süd), `Sun`, `SceneClock` (ART, UTC−3), `Buehne` (Phase-1-Platzhalter), `Physik` (eigener Faden, fester Schritt 1/120 s) |
| `wiring` | 15 Schnittstellen und `Wiring` – siehe [wiring/README.md](wiring/README.md) |
| `ui` | `ControlPanel` (ZEIT, WETTER, SEE, KAMERA, BILD, TECHNIK), `Startbild`, `AppIcon`, `Theme` |
| `tools` | `Tempo`: Tempo-Probe und Standbild ohne Fenster |

## Bühne (Phase 1)

Bis das Gelände (Phase 2) und der Gletscher (Phase 4 und 5) kommen, steht eine flache Bühne [G]: der See auf y = 0, die Front als gerade Wand bei x = 0 über 5 km und 74 m hoch, dahinter das Eis als Block 8 km nach Westen, östlich davor die Halbinsel Magallanes mit ihrer Spitze 400 m vor der Front. Nördlich der Canal de los Témpanos, südlich der Brazo Rico. Marken: Raster 100 m und 1 km, die Front als Linie, der Ring an den Stegen, ein Nordstrich.

## Raum und Zeit

- 1 Einheit = 1 m, x Ost, y oben, z Süd (Nord = −z), Ursprung in der Mitte der Front auf dem Seespiegel; Lage in SRID 8307.
- Die Uhr zählt argentinische Zeit (UTC−3). Start 16. Januar 2026, 15:00 Uhr [G]. Die Sonne steht mittags im Norden, gegen 14 Uhr.

## Schalter

`-Dglacier.splash=false` ohne Startbild · `-Dglacier.gljpanel=true` leichter GL-Rückfall · `-Dglacier.shaders=<ordner>` Shader von der Platte (F5 lädt neu) · `-Dglacier.daten=<ordner>` statt `daten/`.

## Prüfen

- `ant pruefung` (oder `com.dan.glacier.test.Pruefung` mit „Run File“) endet mit „ERGEBNIS: alles in Ordnung“.
- `ant check-packages` übersetzt jedes Element-Package einzeln; läuft nach jedem Übersetzen.
