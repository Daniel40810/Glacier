package com.dan.glacier.wiring;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Die Verdrahtung der App (Paketvertrag Punkt 4): Hier und nur hier reden die Packages miteinander. Jedes Package
 * bietet Eingänge an und meldet Ereignisse über die kleinen Schnittstellen dieses Pakets; die Phasen 2 bis 15 hängen
 * ihre Verbindungen hier ein. Wo ein Package eine eigene Kopie einer Schnittstelle mitbringt (gleicher Name, gleiche
 * Form), übersetzt {@code wiring} mit einer Zeile.
 * <p>
 * Phase 1: Uhr, Wind von Hand (Westwind vom Eisfeld, Bft 4 [G]), fester Seespiegel, Brazo Rico ohne Stau; alle
 * Schnittstellen aus dem Werkbuch (Abschnitt 4) stehen, verbunden ist nur die Uhr mit Kamera, Himmel-Platzhalter und
 * Bühne. {@link #planned()} nennt, was nach dem Phasenplan kommt, {@link #links()} was schon verbunden ist.
 */
public final class Wiring {
    /** Eine Verbindung: von wem, an wen, über welche Schnittstelle, in welcher Phase. */
    public record Link(String from, String to, String via, int phase) {
        @Override public String toString() { return from + " → " + to + " (" + via + ", Phase " + phase + ")"; }
    }

    /** Wind von Hand, bis {@code weather} ihn in Phase 3 setzt. Start: Bft 4 aus West vom Eisfeld [G]. */
    public static final class ManualWind implements Wind {
        public volatile double speed = Beaufort.mid(4), fromDeg = 270, gust = 0.35;
        @Override public double speed() { return speed; }
        @Override public double fromDeg() { return fromDeg; }
        @Override public double gustiness() { return gust; }
    }

    /** Seespiegel von Hand: Hauptsee und Brazo Rico (Stau in m über dem Hauptsee). */
    public static final class ManualLevel implements WaterLevel {
        public volatile double level, stau;
        @Override public double level() { return level; }
        @Override public double brazoRico() { return level + stau; }
    }

    public final Clock clock;
    public final ManualWind wind = new ManualWind();
    public final ManualLevel waterLevel = new ManualLevel();
    /** Phase 2: das Gelände (die App setzt es, sobald es geladen ist). */
    public volatile Terrain terrain;
    private final List<Link> links = new ArrayList<>();

    /** Der Plan aus dem Werkbuch, Abschnitt 4: wer wem was gibt, ab welcher Phase. */
    private static final List<Link> PLANNED = List.of(
            new Link("weather", "ocean, cloud, rain, fog, spray, forest, reed, flock, soundscape, Eisberge", "Wind", 3),
            new Link("App (Seespiegel, Stau des Brazo Rico)", "ocean, wave, ice, buoyancy, weathering, Kamera", "WaterLevel", 2),
            new Link("Gelände (GLO-30, Grund modelliert)", "ice, wave, forest, ground, river, reed, Kamera", "Terrain", 2),
            new Link("sky, lightning", "ocean, cloud, ice, Szene", "Lighting, Flash", 3),
            new Link("ice, App (Stege, Katamaran)", "ocean, rain, spray, weathering", "Collider, SurfaceHit", 5),
            new Link("ice (Zellen mit Festigkeit)", "fracture", "Cells", 6),
            new Link("fracture (onCrack)", "soundscape, ice", "Crack (Donner aus dem Weg, Riss sichtbar)", 7),
            new Link("ocean + wave", "buoyancy, spray, ice, fracture", "Sea (Summe der Höhen)", 7),
            new Link("fracture (onImpact)", "wave, spray, soundscape", "Impact (Quelle, Schwall, Aufschlag)", 8),
            new Link("wave (onRunup)", "weathering, soundscape, App", "Runup (nasse Stege, Rauschen, Kurve)", 8),
            new Link("season (Klima Patagonien)", "ice, forest, reed, ocean, weather", "Season", 11),
            new Link("fracture, wave, flock, buoyancy, lightning", "soundscape", "SoundEvent", 12));

    public Wiring(Clock clock) {
        this.clock = clock;
        link("Uhr (SceneClock)", "Himmel-Platzhalter, Bühne, Kamera, HUD", "Clock (Datum, Sonne über Norden)", 1);
        link("App (Hand)", "Bühne (Platzhalter-Wellen)", "Wind, WaterLevel", 1);
    }

    /** Eine Verbindung eintragen (das Bedienfeld zeigt die Liste). */
    public void link(String from, String to, String via, int phase) { links.add(new Link(from, to, via, phase)); }

    public List<Link> links() { return Collections.unmodifiableList(links); }

    /** Was nach dem Phasenplan noch kommt (ohne das, was schon verbunden ist). */
    public static List<Link> planned() { return PLANNED; }

    /** Die Schnittstellen des Pakets, wie sie im Werkbuch stehen (Prüfung). */
    public static final String[] INTERFACES = {"Clock", "Wind", "WaterLevel", "Terrain", "Lighting", "Flash", "Sea", "Cells", "Impact", "Crack",
            "Collider", "SurfaceHit", "Runup", "Season", "SoundEvent"};

    /** „2 Verbindungen, 12 geplant“ */
    public String summary() {
        return String.format(Locale.GERMAN, "%d %s, %d geplant", links.size(), links.size() == 1 ? "Verbindung" : "Verbindungen", PLANNED.size());
    }
}
