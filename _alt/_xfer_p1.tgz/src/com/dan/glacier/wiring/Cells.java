package com.dan.glacier.wiring;

/**
 * Ein Körper, in Zellen zerlegt (neu in Glacier). Gibt: {@code ice} (die Zellen der Front mit Festigkeit, Phase 6–7).
 * Nimmt: {@code fracture}. Nur Zahlen: {@code fracture} kennt kein Eis, sondern Zellen, Dichte und Festigkeit.
 */
public interface Cells {
    /** Zahl der Zellen. */
    int count();

    /** Mittelpunkt der Zelle i (m). */
    double[] center(int i);

    /** Dichte des Stoffs in Zelle i (kg/m³; Gletschereis rund 900). */
    double density(int i);

    /** Zugfestigkeit der Fläche zwischen den Zellen i und j (Pa; reines Eis rund 1 MPa [zu prüfen, Phase 6]). */
    double strength(int i, int j);
}
