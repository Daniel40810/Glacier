# com.dan.glacier.wiring – die Verdrahtung

Hier reden die Packages miteinander, und nur hier. Kein Element-Package (die achtzehn aus Haithabu und die drei neuen `ice`, `fracture`, `wave`) kennt ein anderes oder die App. Jedes bietet Eingänge an und meldet Ereignisse; die App verbindet sie in `Wiring`.

Stand Phase 1: alle Schnittstellen stehen, verbunden ist nur die Uhr mit Kamera, Himmel-Platzhalter und Bühne. `Wiring.planned()` nennt die Verbindungen aus dem Phasenplan.

## Die Schnittstellen

| Schnittstelle | Inhalt | Gibt | Nimmt | ab Phase |
|---|---|---|---|---|
| `Clock` | Laufzeit, Schritt, Uhrzeit, Ort | App (`SceneClock`) | alle | 1 |
| `Wind` | Geschwindigkeit, Richtung, Böigkeit, Bft | weather (bis dahin von Hand) | ocean, cloud, rain, fog, spray, forest, reed, flock, soundscape, Eisberge | 1 |
| `WaterLevel` | Spiegel des Hauptsees, Stau des Brazo Rico | App (nach Jahr und Regie) | ocean, wave, ice, buoyancy, weathering, Kamera | 1 |
| `Terrain` | Höhe, Wassertiefe, Normale am Ort | Gelände aus GLO-30, Grund modelliert | ice, wave, forest, ground, river, reed, Kamera | 2 |
| `Lighting`, `Flash` | Sonne, Mond, Himmel, Dunst; Blitz | sky, lightning | ocean, cloud, ice, Szene | 3 |
| `Collider`, `SurfaceHit` | fester Körper als Abstandsfeld; Einschlag auf einer Fläche | ice, App (Stege, Katamaran) | ocean, rain, spray, weathering | 5 |
| `Cells` **neu** | Zellen mit Mittelpunkt, Dichte, Festigkeit je Fläche | ice | fracture | 6–7 |
| `Crack` **neu** | Weg des Risses, Energie, frei oder nicht | fracture (`onCrack`) | soundscape, ice | 7 |
| `Sea` **neu** | Höhe als Summe: `ocean.heightAt + wave.heightAt` | App | buoyancy, spray, ice, fracture | 7–8 |
| `Impact` **neu** | Ort, Volumen, Tempo eines Einschlags | fracture (`onImpact`) | wave, spray, soundscape | 7–8 |
| `Runup` **neu** | Auflaufhöhe am Ufer | wave (`onRunup`) | weathering, soundscape, App | 8 |
| `Season` | Laub, Färbung, Schnee, Eisrand, Schmelze, Kalbungsrate | season | ice, forest, reed, ocean, weather | 11 |
| `SoundEvent` | Klangereignis | fracture, wave, flock, buoyancy, lightning | soundscape | 12 |

`Beaufort` gibt die gemeinsame Sprache für alle Presets: Grenzen nach WMO und die deutschen Bezeichnungen.

## Regeln

- Jede Schnittstelle besteht nur aus Zahlen, Aufzählungen und Funktionen. Keine Klassen aus anderen Packages.
- Braucht ein Package dieselbe Form, bringt es eine eigene Kopie mit gleichem Namen mit. `Wiring` übersetzt mit einer Zeile.
- Jede neue Verbindung wird mit `link(von, an, über, Phase)` eingetragen. Das Bedienfeld zeigt die Liste.
