package com.dan.wave;

/**
 * Eine Welle, die läuft (Werkbuch Glacier, Abschnitt 4). Stand Phase 1: die Hülle nach dem Paketvertrag –
 * Qualitätsstufen, {@code seed}, Presets, die offenen Werte und die Abfragen, die Phase 8 füllt.
 * <ul>
 * <li>Flachwassergleichungen auf einem Höhenfeld (Höhe, Impuls in x und z) mit zwei Gittern, Zeitschritt nach CFL in
 * Unterschritten;</li>
 * <li>Quellen aus verdrängtem Volumen je Schritt (Einschlag) und als Abfluss (Dammbruch, Ruptura);</li>
 * <li>Auflaufen am Ufer mit nassem Saum, Reflexion an senkrechten Wänden, Reibung am Grund, Dämpfung am Rand;</li>
 * <li>Abfragen {@code heightAt}, {@code velocityAt}, {@code runupAt} ohne Grafikkarte.</li>
 * </ul>
 */
public final class Wave {
    public enum Quality { LOW, MEDIUM, HIGH, ULTRA }

    /** Stand des Packages: 1 = Hülle; 8 = Löser. */
    public static final int STAGE = 1;

    /** Eine Welle läuft am Ufer auf: Ort (m), Auflaufhöhe (m), Laufzeit (s). */
    @FunctionalInterface public interface Runup { void runup(double x, double z, double heightM, double t); }

    public long seed = 1;
    public Quality quality = Quality.MEDIUM;
    public double gravity = 9.81;
    /** Feines Gitter: Zellgröße (m) und Zellen je Kante; grobes Gitter ebenso (Werkbuch, Abschnitt 10). */
    public double fineCell = 2, coarseCell = 8;
    public int fineN = 512, coarseN = 1024;
    /** Reibung am Grund (Manning n) und Dämpfung am Rand (Anteil je s). */
    public double manning = 0.025, edgeDamping = 0.5;
    public Runup onRunup;

    // ------------------------------------------------------------------ Presets
    /** Ein See vor einer Gletscherfront (Glacier): zwei Gitter wie oben. */
    public static Wave lake() { return new Wave(); }
    /** Ein kleines Becken für die Demo: nur das feine Gitter, 256² zu 1 m. */
    public static Wave basin() { Wave w = new Wave(); w.fineCell = 1; w.fineN = 256; w.coarseN = 0; return w; }

    /** Tempo einer langen Welle bei der Tiefe h (m): √(g·h). */
    public double celerity(double depth) { return Math.sqrt(gravity * Math.max(0, depth)); }

    /** Größter stabiler Schritt (s) auf Zellen der Größe dx bei der größten Tiefe h (CFL 0,5). */
    public double cflStep(double dx, double maxDepth) { return 0.5 * dx / Math.max(1e-9, celerity(maxDepth)); }

    /** Höhe der laufenden Welle am Ort (m); die Hülle ist ruhig. */
    public double heightAt(double x, double z) { return 0; }

    /** „wave: Hülle (Phase 1) · 512² zu 2 m, 1 024² zu 8 m · MEDIUM“ */
    public String describe() {
        return String.format(java.util.Locale.GERMAN, "wave: %s · %d² zu %.0f m, %,d² zu %.0f m · %s",
                STAGE == 1 ? "Hülle (Phase 1)" : "Stufe " + STAGE, fineN, fineCell, coarseN, coarseCell, quality);
    }
}
