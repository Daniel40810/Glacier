package com.dan.wave.demo;

import com.dan.wave.Wave;

/**
 * Prüfklasse ohne Fenster (Paketvertrag Punkt 10). Endet mit „Alles in Ordnung.“ oder mit den Verstößen
 * (Rückgabewert 1). Phase 1 prüft die Hülle; Phase 8 hängt Tempo gegen √(g·h), Erhaltung des Volumens und die
 * Auflaufhöhe gegen die Handrechnung an.
 */
public final class WaveCheck {
    private static int bad;

    public static void main(String[] args) {
        Wave w = Wave.lake();
        double c = w.celerity(100);
        check(Math.abs(c - 31.32) < 0.01, String.format(java.util.Locale.GERMAN, "lange Welle bei 100 m Tiefe: %.1f m/s (Werkbuch: gut 30 m/s)", c));
        double dt = w.cflStep(2, 170);
        check(dt > 0.02 && dt < 0.03, String.format(java.util.Locale.GERMAN, "Schritt auf 2 m bei 170 m Tiefe: %.3f s (Werkbuch: rund 0,03 s)", dt));
        check(w.heightAt(0, 0) == 0, "die Hülle ist ruhig");
        check(Wave.basin().coarseN == 0, "Preset Becken ohne grobes Gitter");
        System.out.println(bad == 0 ? "Alles in Ordnung." : bad + " Verstöße.");
        System.exit(bad == 0 ? 0 : 1);
    }

    static void check(boolean c, String what) {
        if (!c) bad++;
        System.out.println((c ? "  ok    " : "  FEHLER ") + what);
    }

    private WaveCheck() { }
}
