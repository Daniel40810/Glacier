# com.dan.wave – eine Welle, die läuft

**Stand: Hülle (Phase 1).** Der Löser folgt in Phase 8 (Werkbuch Glacier, Abschnitt 9).

Eine Welle aus einem Einschlag, die über ein Gewässer läuft, am Ufer aufläuft, an einer Wand zurückgeworfen wird und abklingt. Anders als die Ringwellen in `com.dan.ocean` kennt sie Tiefe und Ufer. Das Package kennt keine App und kein anderes Package; der Kern braucht nur Java 21, `gl/` zusätzlich JOGL. Wiederverwendbar für einen Felssturz in den Edersee, einen Dammbruch, eine Welle im Noor oder im Hafen.

Zum Herauskopieren reicht `src/com/dan/wave/`.

## Was es können wird

- Flachwassergleichungen auf einem Höhenfeld (Höhe, Impuls in x und z) mit zwei Gittern: fein (2 m auf 1 km²) und grob (8 m auf 8 km).
- Quellen aus dem verdrängten Volumen eines Einschlags je Schritt und als Abfluss (die Ruptura).
- Auflaufen am Ufer mit nassem Saum, Reflexion an senkrechten Wänden, Reibung am Grund, Dämpfung am Rand.
- Zeitschritt nach CFL in Unterschritten; bei 170 m Tiefe läuft eine lange Welle mit rund 41 m/s.
- Abfragen `heightAt`, `velocityAt`, `runupAt` ohne Grafikkarte; `gl/` hält die Höhe als Textur für fremde Wasseroberflächen.
- Ereignis `onRunup` (Ort, Höhe) für Nässe und Klang.

## Was die Hülle schon hat

- `Quality`, `seed`, offene Felder (Gitter, Reibung, Dämpfung), die Schnittstelle `Runup`.
- Presets `lake()`, `basin()`.
- `celerity(h)` = √(g·h) und `cflStep(dx, h)`; `heightAt` liefert noch 0.

## Aufbau

| Klasse | Aufgabe |
|---|---|
| `Wave` | Kern: Presets, offene Werte, Abfragen, Qualitätsstufen |
| `demo/WaveCheck` | Prüfung ohne Fenster, endet mit „Alles in Ordnung.“ |

## Grenzen

- Die Hülle rechnet keine Welle.
- Flachwasser gilt für lange Wellen; die kurze Windsee bleibt bei `ocean`, die App summiert beide (Schnittstelle `Sea`).
