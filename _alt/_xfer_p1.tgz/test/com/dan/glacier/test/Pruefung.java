package com.dan.glacier.test;

import com.dan.glacier.camera.Ansichten;
import com.dan.glacier.camera.Camera;
import com.dan.glacier.gl.ComputeProbe;
import com.dan.glacier.gl.Mat4;
import com.dan.glacier.gl.Quality;
import com.dan.glacier.gl.Renderer;
import com.dan.glacier.gl.Shader;
import com.dan.glacier.scene.Buehne;
import com.dan.glacier.scene.Geo;
import com.dan.glacier.scene.Physik;
import com.dan.glacier.scene.SceneClock;
import com.dan.glacier.scene.Site;
import com.dan.glacier.scene.Sun;
import com.dan.glacier.ui.AppIcon;
import com.dan.glacier.wiring.Beaufort;
import com.dan.glacier.wiring.Collider;
import com.dan.glacier.wiring.Wiring;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Locale;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Prüfprogramm der App ohne Grafikkarte und ohne Datenbank (aus Haithabu). In NetBeans: Rechtsklick → „Run File“,
 * oder Ant-Target {@code pruefung}. Endet mit „ERGEBNIS: alles in Ordnung“ oder mit der Liste der Verstöße
 * (Rückgabewert 1). Wächst mit jeder Phase. Die Packages haben zusätzlich je ihre eigene Prüfklasse in {@code .demo}.
 */
public final class Pruefung {
    private static int ok, bad;

    public static void main(String[] args) throws Exception {
        long t0 = System.nanoTime();
        mathe();
        ort();
        sonne();
        uhr();
        buehne();
        kamera();
        qualitaet();
        physik();
        shader();
        verdrahtung();
        symbol();
        pakete();
        isolation();
        System.out.printf(Locale.GERMAN, "%n%d Prüfungen, %d Verstöße, %.1f s%n", ok + bad, bad, (System.nanoTime() - t0) / 1e9);
        System.out.println(bad == 0 ? "ERGEBNIS: alles in Ordnung" : "ERGEBNIS: " + bad + " Verstöße");
        System.exit(bad == 0 ? 0 : 1);
    }

    static void check(boolean cond, String what) {
        if (cond) ok++; else bad++;
        System.out.println((cond ? "  ok    " : "  FEHLER ") + what);
    }

    static void mathe() {
        System.out.println("Matrizen");
        float[] v = Mat4.lookAt(10, 20, 30, 0, 14, 0);
        float[] p = Mat4.perspective(55, 16 / 9.0, 0.5, 80000, true);
        float[] vp = Mat4.mul(p, v), id = Mat4.mul(vp, Mat4.invert(vp));
        double err = 0;
        for (int i = 0; i < 16; i++) err = Math.max(err, Math.abs(id[i] - (i % 5 == 0 ? 1 : 0)));
        check(err < 1e-4, String.format(Locale.GERMAN, "Projektion·Blick mal Inverse = Einheit (Fehler %.1e)", err));
        float[] look = Mat4.lookAt(0, 0, 0, 0, 0, -1);
        double[] c = Mat4.apply(Mat4.mul(p, look), 0, 0, -100);
        check(Math.abs(c[2] / c[3] - 0.5 / 100) < 1e-6, "Umgekehrte Tiefe: Punkt in 100 m hat Tiefe Nahebene/100");
        double[] far = Mat4.apply(Mat4.mul(p, look), 0, 0, -12000);
        check(far[2] / far[3] > 0 && far[2] / far[3] < 1e-4, "Berge in 12 km liegen zwischen 0 und Nahebene, vor dem Unendlichen");
    }

    static void ort() {
        System.out.println("Ort und Maßstab");
        check(Site.dms(Site.LAT, Site.LON).equals("50°28′40″ S · 73°02′50″ W"), "Mitte der Front [G] in Grad, Minuten, Sekunden: " + Site.dms(Site.LAT, Site.LON));
        double[] xz = Site.xz(new double[]{Site.LAT, Site.LON});
        check(Math.abs(xz[0]) < 1e-6 && Math.abs(xz[1]) < 1e-6, "Ursprung der Szene liegt auf der Mitte der Front");
        double x = 1234.5, z = -987.25;
        double[] back = Site.xz(Site.latLon(x, z));
        check(Math.abs(back[0] - x) < 1e-6 && Math.abs(back[1] - z) < 1e-6, "Szene ↔ Breite/Länge hin und zurück (Südhalbkugel)");
        check(Site.lat(-1000) > Site.LAT && Site.lon(1000) > Site.LON, "Nord ist −z (Breite steigt gegen null), Ost ist +x");
        double[] u = Geo.UTM18S.forward(Site.LAT, Site.LON), ll = Geo.UTM18S.inverse(u[0], u[1]);
        check(Math.abs(ll[0] - Site.LAT) < 1e-9 && Math.abs(ll[1] - Site.LON) < 1e-9 && u[1] < 10_000_000 && u[0] > 500_000,
                String.format(Locale.GERMAN, "UTM 18 Süd hin und zurück: %.0f E, %.0f N", u[0], u[1]));
        double[] g = Site.xz(new double[]{Site.GLACIER_LAT, Site.GLACIER_LON});
        check(g[0] < -2000 && g[1] > 0, String.format(Locale.GERMAN, "Der Gletscher als Ganzes (50°30′ S 73°08′ W) liegt %.1f km westlich, %.1f km südlich der Front – oben auf der Zunge", -g[0] / 1000, g[1] / 1000));
        check(Math.abs(Site.FRONT_DRAFT - 96) < 1e-9, "Front: 74 m über Wasser, 170 m Eis, also 96 m unter dem Spiegel");
        check(Math.abs(Site.waveSpeed(100) - 31.3) < 0.1, String.format(Locale.GERMAN, "Lange Welle bei 100 m Tiefe: %.1f m/s, über 600 m Kanal in %.0f s", Site.waveSpeed(100), 600 / Site.waveSpeed(100)));
    }

    static void sonne() {
        System.out.println("Sonne (Südhalbkugel)");
        SceneClock c = new SceneClock(LocalDate.of(2026, 1, 16), 0);
        double day = c.epochMillis();
        double up = hourOf(Sun.crossing(day, Site.LAT, Site.LON, true)), down = hourOf(Sun.crossing(day, Site.LAT, Site.LON, false));
        check(up > 5.0 && up < 6.5 && down > 21.0 && down < 22.5, "16.1.2026 Aufgang " + hm(up) + ", Untergang " + hm(down) + " ART");
        double len = down - up;
        check(len > 15.5 && len < 16.8, String.format(Locale.GERMAN, "Tag im Januar %.2f h (50,5° S, Hochsommer)", len));
        double best = -90, bestH = 0;
        for (double h = 10; h < 18; h += 1 / 60.0) {
            c.set(LocalDate.of(2026, 1, 16), h);
            double e = c.sun()[0];
            if (e > best) { best = e; bestH = h; }
        }
        c.set(LocalDate.of(2026, 1, 16), bestH);
        double az = c.sun()[1];
        check((az < 5 || az > 355) && bestH > 13.5 && bestH < 14.5, String.format(Locale.GERMAN, "Höchststand %s ART bei %.1f°, Azimut %03.0f° – die Sonne steht mittags im Norden", hm(bestH), best, az));
        SceneClock dez = new SceneClock(LocalDate.of(2026, 12, 21), 0);
        double dd = hourOf(Sun.crossing(dez.epochMillis(), Site.LAT, Site.LON, false));
        check(dd > 22.0, "21.12.2026 Untergang " + hm(dd) + " ART (Werkbuch: im Dezember bis nach 22 Uhr)");
        SceneClock jul = new SceneClock(LocalDate.of(2026, 7, 16), 0);
        double ju = hourOf(Sun.crossing(jul.epochMillis(), Site.LAT, Site.LON, true)), jd = hourOf(Sun.crossing(jul.epochMillis(), Site.LAT, Site.LON, false));
        check(jd - ju < 9, String.format(Locale.GERMAN, "16.7.2026 Tag %.1f h (Winter)", jd - ju));
    }

    static void uhr() {
        System.out.println("Uhr");
        SceneClock c = new SceneClock();
        check(c.label().equals("16.1.2026 15:00 ART"), "Start: " + c.label());
        check(Math.abs(c.local().getOffset().getTotalSeconds() + 3 * 3600) < 1, "Argentinische Zeit UTC−3");
        c.lapse = 60;
        c.step(30);
        check(c.label().equals("16.1.2026 15:30 ART"), "Zeitraffer 1 min/s, 30 s → " + c.label());
        double e0 = c.epochMillis();
        c.lapse = 1e9;
        c.step(1);
        check(Math.abs(c.epochMillis() - e0 - SceneClock.MAX_LAPSE * 1000) < 1e-3, "Zeitraffer höchstens 3600-fach");
        c.set(LocalDate.of(2026, 12, 31), 23.5);
        c.lapse = 3600;
        c.step(1);
        check(c.dateLabel().equals("1.1.2027"), "Jahreswechsel: " + c.label());
        SceneClock s = new SceneClock();
        s.lapse = 0;
        s.step(2.5);
        check(Math.abs(s.t() - 2.5) < 1e-9 && s.label().equals("16.1.2026 15:00 ART"), "Uhr steht, Laufzeit läuft weiter (Wellen bewegen sich)");
    }

    static void buehne() {
        System.out.println("Bühne (Phase 1)");
        check(Buehne.ice(-10, 0) && !Buehne.ice(10, 0) && !Buehne.ice(-10, 2600) && Buehne.height(-100, 0) == Site.FRONT_HEIGHT, "Eis westlich der Front, 5 km breit, 74 m hoch");
        check(Buehne.land(Buehne.TIP + 30, 20) && !Buehne.land(Buehne.TIP - 30, 0), String.format(Locale.GERMAN, "Halbinsel: Spitze %.0f m vor der Front, dort die Stege", Buehne.TIP));
        check(Buehne.zone(200, -800).equals("Canal de los Témpanos") && Buehne.zone(200, 900).equals("Brazo Rico"), "Kanal nördlich, Brazo Rico südlich der Halbinsel");
        String sf = Shader.read("stage.frag");
        check(sf.contains("uPen.x + uPen.y") && sf.contains("150.0 * u"), "stage.frag zeichnet dieselbe Halbinsel wie Buehne.land()");
    }

    static void kamera() {
        System.out.println("Kamera");
        Camera cam = new Camera();
        check(cam.eye[0] > 1200 && Math.abs(cam.eye[2]) < 400 && cam.heading() > 260 && cam.heading() < 290,
                String.format(Locale.GERMAN, "Grundansicht: %.0f m vor der Front, Blick %03.0f° auf die Wand", cam.eye[0], cam.heading()));
        cam.place(-500, 0, 0, 90, 0);
        cam.groundLevel = Buehne.height(-500, 0);
        cam.step(0.1);
        check(cam.eye[1] >= Site.FRONT_HEIGHT + Camera.MIN_EYE - 1e-9, String.format(Locale.GERMAN, "Frei auf dem Eis: Auge bleibt über dem Eis (%.1f m)", cam.eye[1]));
        cam.setMode(Camera.Mode.KREISEN);
        check(cam.mode == Camera.Mode.KREISEN && cam.dist > 1, "Wechsel Frei → Kreisen behält die Ansicht");
        int ready = 0;
        for (Ansichten.Ansicht a : Ansichten.ALLE) {
            Camera c = new Camera();
            if (Ansichten.apply(a, c, Renderer.PHASE)) {
                ready++;
                double ground = Buehne.height(a.x(), a.z());
                if (c.eye[1] < ground) check(false, a + " liegt unter der Bühne");
            }
        }
        check(ready == 6 && Ansichten.ALLE.size() == 7, ready + " von 7 Ansichten auf der Bühne; „Unter Wasser“ folgt in Phase 9");
        Ansichten.Ansicht steg = Ansichten.byKey(1);
        check(steg.name().equals("Vom Steg") && Buehne.land(steg.x(), steg.z()), "1 Vom Steg steht auf der Halbinsel");
        Ansichten.Ansicht eis = Ansichten.byName("AufdemEis");
        check(eis != null && Buehne.ice(eis.x(), eis.z()), "4 Auf dem Eis steht auf dem Eis");
    }

    static void qualitaet() {
        System.out.println("Qualität");
        boolean mono = true;
        Quality[] q = Quality.values();
        for (int i = 1; i < q.length; i++) mono &= q[i].renderScale >= q[i - 1].renderScale && q[i].budgetMs() > q[i - 1].budgetMs();
        check(mono, "Stufen Niedrig → Ultra steigen an");
        check(Math.abs(Quality.MITTEL.budgetMs() - 15.7) < 1e-9 && Math.abs(Quality.HOCH.budgetMs() - 2 * 15.7) < 1e-9, "„Mittel“ hat das Budget aus Abschnitt 10: 15,7 ms, „Hoch“ das Doppelte");
        Renderer r = new Renderer();
        check(r.quality() == Quality.MITTEL, "Start auf „Mittel“ (F21 A)");
        r.regulateForTest(30, 10_000_000_000L);
        check(r.renderScale < Quality.MITTEL.renderScale, String.format(Locale.GERMAN, "Grafikkarte 30 ms: Auflösung sinkt auf %.0f %%", r.renderScale * 100));
        check(r.renderScale >= Renderer.MIN_SCALE, "nie unter " + Math.round(Renderer.MIN_SCALE * 100) + " %");
    }

    static void physik() {
        System.out.println("Faden der Physik (F21 A)");
        Physik p = new Physik();
        int[] n = {0};
        p.add((t, dt) -> n[0]++);
        p.advance(0.5);
        int steps = p.drain();
        check(steps == Physik.MAX_BEHIND && n[0] == steps, "Fester Schritt 1/120 s, höchstens " + Physik.MAX_BEHIND + " Schritte nachgeholt (" + steps + ")");
        p.advance(Physik.DT * 3.5);
        check(p.drain() == 3, "3,5 Schritte Zeit → 3 Schritte, der Rest wartet");
        p.add((t, dt) -> { throw new IllegalStateException("Probe"); });
        p.advance(Physik.DT);
        p.drain();
        check(p.aufgaben() == 1, "Eine fehlerhafte Aufgabe fällt heraus, die anderen laufen weiter");
    }

    static void shader() {
        System.out.println("Shader");
        for (String[] prog : Renderer.shaderFiles()) {
            for (String f : prog) {
                boolean found;
                String text = "";
                try {
                    text = Shader.source(f, null).text;
                    found = text.startsWith("#version 430 core");
                } catch (RuntimeException e) {
                    found = false;
                }
                check(found, "Shader " + f + " gefunden und Bausteine eingesetzt (" + text.split("\n").length + " Zeilen)");
            }
        }
        String st = Shader.source("stage.frag", null).text;
        check(st.contains("iceBox") && st.contains("gl_FragDepth") && st.contains("reflected("), "Bühne: Eisblock, eigene Tiefe, Spiegelung der Wand im See");
        check(!Pattern.compile("\\bhalf\\b").matcher(st).find(), "kein reserviertes Wort „half“ in der Bühne (AMD-Treiber sind streng)");
        check(ComputeProbe.expected(0, 63) == 64 * 65 / 2 && ComputeProbe.expected(1, 0) == 65, "Compute-Test: Erwartungswerte der Präfixsumme");
    }

    static void verdrahtung() {
        System.out.println("Verdrahtung");
        Wiring w = new Wiring(new SceneClock());
        check(w.links().size() == 2 && w.links().stream().allMatch(l -> l.phase() == 1), "Phase 1: " + w.summary());
        int found = 0;
        for (String n : Wiring.INTERFACES) {
            try {
                Class<?> c = Class.forName("com.dan.glacier.wiring." + n);
                if (c.isInterface()) found++;
            } catch (ClassNotFoundException e) { /* fehlt */ }
        }
        check(found == Wiring.INTERFACES.length && found == 15, found + " von 15 Schnittstellen aus Abschnitt 4 stehen als Interface, darunter neu Sea, Cells, Impact, Crack, Runup");
        check(Wiring.planned().stream().anyMatch(l -> l.via().startsWith("Cells") && l.phase() == 6)
                && Wiring.planned().stream().anyMatch(l -> l.via().startsWith("Impact") && l.phase() == 8), "Plan: Cells ab Phase 6, Impact ab Phase 8");
        check(Beaufort.of(w.wind.speed()) == 4, "Wind von Hand: Bft 4 (" + Beaufort.NAME[4] + ")");
        double[] to = w.wind.toVector();
        check(to[0] > 0.99, "Westwind vom Eisfeld weht nach Osten über die Front auf den Kanal");
        w.waterLevel.stau = 25;
        check(w.waterLevel.brazoRico() - w.waterLevel.level() == 25, "Stau des Brazo Rico über dem Hauptsee");
        Collider block = Collider.box(-50, 37, 0, 50, 37, 2500);
        check(block.distance(-50, 37, 0) < 0 && Math.abs(block.distance(10, 37, 0) - 10) < 1e-9, "Collider: Eisblock als Quader");
    }

    static void symbol() {
        System.out.println("Programmsymbol");
        boolean all = true;
        for (int s : AppIcon.SIZES) {
            java.awt.image.BufferedImage b = AppIcon.paint(s);
            all &= b.getWidth() == s && (b.getRGB(s / 2, s / 2) >>> 24) == 255 && (b.getRGB(0, 0) >>> 24) < 255;
        }
        check(all, "Symbol in " + AppIcon.SIZES.length + " Größen gemalt, deckend in der Mitte, runde Ecken");
    }

    /** Die 21 Element-Packages stehen im Quellordner, jedes mit README; die 7 abgestellten liegen in _alt/packages (F6 A). */
    static void pakete() {
        System.out.println("Packages");
        File base = new File("src/com/dan");
        if (!base.isDirectory()) { System.out.println("  (Quellordner nicht gefunden, übersprungen)"); return; }
        String[] wanted = {"ice", "fracture", "wave", "sky", "cloud", "weather", "rain", "fog", "lightning", "ocean", "spray", "buoyancy",
                "weathering", "flock", "forest", "ground", "river", "reed", "season", "soundscape", "store"};
        int n = 0;
        for (String w : wanted) if (new File(base, w + "/README.md").isFile()) n++;
        File[] dirs = base.listFiles(f -> f.isDirectory() && !f.getName().equals("glacier"));
        check(n == wanted.length && dirs != null && dirs.length == wanted.length, n + " von 21 Packages mit README im Build (18 aus Haithabu, 3 neu)");
        String[] gone = {"timber", "smoke", "hearth", "herd", "longship", "road", "muster"};
        int m = 0;
        for (String g : gone) if (!new File(base, g).exists() && new File("_alt/packages/" + g).isDirectory()) m++;
        check(m == gone.length, m + " von 7 Packages nach _alt/packages abgestellt (F6 A)");
        check(!new File("db/Object_nach_Schema.sql").exists() && !new File("db/TableFormat.sql").exists() && new File("db/USER.sql").isFile(),
                "db/: nur USER.sql, die beiden fremden Dateien in _alt (F19 A)");
    }

    /** Kein Element-Package kennt die App (die volle Prüfung macht check-packages). */
    static void isolation() throws Exception {
        System.out.println("Isolation");
        File base = new File("src/com/dan");
        if (!base.isDirectory()) { System.out.println("  (Quellordner nicht gefunden, übersprungen)"); return; }
        Pattern p = Pattern.compile("com\\.dan\\.glacier");
        int found = 0, files = 0;
        File[] dirs = base.listFiles(f -> f.isDirectory() && !f.getName().equals("glacier"));
        if (dirs != null) for (File d : dirs) {
            try (Stream<Path> s = Files.walk(d.toPath())) {
                for (Path f : (Iterable<Path>) s.filter(x -> x.toString().endsWith(".java"))::iterator) {
                    files++;
                    if (p.matcher(Files.readString(f, StandardCharsets.UTF_8)).find()) { found++; System.out.println("    " + f); }
                }
            }
        }
        check(found == 0, files + " Dateien in " + (dirs == null ? 0 : dirs.length) + " Packages, keine nennt com.dan.glacier");
    }

    static double hourOf(double epochMs) {
        var z = Instant.ofEpochMilli((long) epochMs).atZone(SceneClock.ZONE);
        return z.getHour() + z.getMinute() / 60.0 + z.getSecond() / 3600.0;
    }

    static String hm(double h) { return String.format("%02d:%02d", (int) h, (int) Math.round((h - (int) h) * 60) % 60); }

    private Pruefung() { }
}
